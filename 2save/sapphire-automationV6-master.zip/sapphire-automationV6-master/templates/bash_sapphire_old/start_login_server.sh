#!/bin/sh

mkdir -p ./pid

export NODE_ENV=production

#TODO REMOVE -full-log in production
export PROCESS_ARGS=-full-log

#TODO CHANGE THESE PER MACHINE
export MOUNT_DIR=/export/home/nui/sagie
export NODE_HOME=/export/home/nui/builds/sapphireBuild_0.1.376/node_binary

#TODO CHANGE THESE PER PROCESS
export LOG_DIRECTORY=/export/home/nui/sagie/sample/log/login-server
export NODE_CACHE_DIR=/export/home/nui/sagie/sample/.cache/login-server
export NODE_CONFIG_KEY=login-server/instance1
export NODE_EBS_AUTH_TOKEN=DEV
export LOGIN_SERVER_ROOT=${MOUNT_DIR}/login_server/login-server
export NODE_EXTERNAL_CONFIG_FILE=/export/home/nui/sagie/sample/config/config.json

($NODE_HOME/bin/node ${LOGIN_SERVER_ROOT}/lib/app.js $PROCESS_ARGS & echo $! > "./pid/login_server.pid")&
