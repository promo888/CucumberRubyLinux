#!/bin/sh

. ~/.nvm/nvm.sh
nvm use ${BUILD_NODE_VERSION}

cd ${0%/*}
cd ../..

PACKAGE_PRODUCTION_RELEASE=""
NPM_VERSION_SUFFIX=""
RELEASE_DIR_PART=""
GENERIC_COMPONENTS_NPM_VERSION="@latest"
if [ -n "$JOB_PACKAGE_PRODUCTION_RELEASE" ]; then
 PACKAGE_PRODUCTION_RELEASE="$JOB_PACKAGE_PRODUCTION_RELEASE"
 NPM_VERSION_SUFFIX="@~$PACKAGE_PRODUCTION_RELEASE"
 RELEASE_DIR_PART="/production-release$PACKAGE_PRODUCTION_RELEASE"
 GENERIC_COMPONENTS_NPM_VERSION=${NPM_VERSION_SUFFIX}
fi

echo "NPM version suffix: ${NPM_VERSION_SUFFIX}"
echo "Release directory part: ${RELEASE_DIR_PART}"

echo "node version"
node --version
echo "npm version"
npm --version

rm -Rf ./target/ebs-dashboard

set -e

echo 'Reset Git'
git reset --hard origin/master
echo 'Running Git pull'
git checkout master
git pull origin master

NODE_ENV=production

mkdir -p ./target/ebs-dashboard
cd target/ebs-dashboard

echo "creating tools tar.gz"
mkdir -p ./tools
cd ./tools
cp -R ../../../dashboard/bin/tools/*.sh ./
cd ..
tar --gzip -cf ./tools.tar.gz tools

echo "copying node.js"
mkdir -p ./node_temp
cd ./node_temp
cp $BUILD_NODE_ZIP ./node.tar.gz
tar -xf ./node.tar.gz
rm -f ./node.tar.gz
cd node*
tar --gzip -cf ../../node.tar.gz .
cd ../..

echo "copying redis"
mkdir -p ./redis_temp
cd ./redis_temp
cp $BUILD_REDIS_ZIP ./redis.tar.gz
tar -xf ./redis.tar.gz
rm -f ./redis.tar.gz
cd redis*
tar --gzip -cf ../../redis.tar.gz .
cd ../..

mkdir -p ./cloud-controller/node_modules
cd cloud-controller
npm --no-proxy install "ebs-cloud-controller"
cd -

mkdir -p ./login-server/node_modules
cd login-server
npm --no-proxy install "ebs-login-server$GENERIC_COMPONENTS_NPM_VERSION"
cd -

mkdir -p ./process-launcher/node_modules
cd process-launcher
npm --no-proxy install "ebs-process-launcher$GENERIC_COMPONENTS_NPM_VERSION"
cd -

mkdir -p ./ebs-dashboard/node_modules
cd ebs-dashboard
npm --no-proxy install "ebs-dashboard$NPM_VERSION_SUFFIX"
cd -

echo "creating backend package"
mkdir -p ./backend/server
mv ./ebs-dashboard/node_modules/ebs-dashboard/server ./backend/server
cp -R ./ebs-dashboard/node_modules ./backend/server/node_modules
cp ./ebs-dashboard/node_modules/ebs-dashboard/package.json ./backend/server/

echo "creating frontend package"
mkdir -p ./frontend/nginx-proxy
cd ./frontend/nginx-proxy
tar -xf "/home/staff/buildServer/Releases/EBS-UI${RELEASE_DIR_PART}/nginx-proxy/nginx-proxy.tar.gz"
cd -

echo "creating login server package"
mkdir -p ./login_server
mv ./login-server/node_modules/ebs-login-server ./login_server/login-server
if [ -d ./login_server/login-server/node_modules/ebs ]; then
 echo "Using old NPM"
else
 cp -R ./login-server/node_modules ./login_server/login-server/node_modules
fi

echo "creating monitor server package"
mkdir -p ./monitor-server
mv ./cloud-controller/node_modules/ebs-cloud-controller ./monitor-server/cloud-controller
if [ -d ./monitor-server/cloud-controller/node_modules/ebs ]; then
 echo "Using old NPM"
else
 cp -R ./cloud-controller/node_modules ./monitor-server/cloud-controller/node_modules
fi

echo "creating process launcher package"
mkdir -p ./process_launcher
mv ./process-launcher/node_modules/ebs-process-launcher ./process_launcher/process-launcher
if [ -d ./process_launcher/process-launcher/node_modules/ebs ]; then
 echo "Using old NPM"
else
 cp -R ./process-launcher/node_modules ./process_launcher/process-launcher/node_modules
fi

echo "creating backend tar.gz"
tar --gzip -cf ./backend.tar.gz backend
echo "creating frontend tar.gz"
tar --gzip -cf ./frontend.tar.gz frontend
echo "creating login server tar.gz"
tar --gzip -cf ./login-server.tar.gz login_server
echo "creating monitor server tar.gz"
tar --gzip -cf ./monitor-server.tar.gz monitor-server
echo "creating process launcher tar.gz"
tar --gzip -cf ./process-launcher.tar.gz process_launcher

echo "Read version"
BUNDLE_VERSION=`cat ./ebs-dashboard/node_modules/ebs-dashboard/package.json | grep version | cut -d':' -f 2 | cut -d'"' -f 2`

echo "creating installer package"
mkdir -p ./installer/node_modules
cp -R ./backend/server/node_modules/ebs-dashboard/installer ./installer
cp -R ./backend/server/node_modules/lodash ./installer/node_modules
cp -R ./backend/server/node_modules/ebs-installer ./installer/node_modules
tar --gzip -cf ./installer.tar.gz installer

echo "All packages created, creating full bundle: dashboard_full_$BUNDLE_VERSION.tar.gz"
cp -R ../../dashboard/bin/install.sh ./
cp -R ../../dashboard/bin/post_install.sh ./
echo $BUNDLE_VERSION > ./version_$BUILD_NUMBER.txt
echo $BUNDLE_VERSION > ./version.txt
tar --gzip -cf ./dashboard_full_$BUNDLE_VERSION.tar.gz tools.tar.gz backend.tar.gz frontend.tar.gz login-server.tar.gz monitor-server.tar.gz process-launcher.tar.gz node.tar.gz redis.tar.gz installer.tar.gz install.sh post_install.sh version.txt

cd ../..

echo "Done"
