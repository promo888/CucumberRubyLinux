#!/bin/sh

#THIS IS TESTING SH AND SHOULD NOT BE USED!!!!
echo "THIS IS TESTING SH AND SHOULD NOT BE USED!!!!"

rm -Rf /export/home/nui/sagie/local
rm -Rf /export/home/nui/sagie/local2

mkdir -p /export/home/nui/sagie/local/logs/
mkdir -p /export/home/nui/sagie/local2/logs/

export PATH=${PATH}:/export/home/nui/sagie/libai:/export/home/nui/sagie/oci
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/export/home/nui/sagie/libai:/export/home/nui/sagie/oci

/export/home/nui/sagie/sapphire_0.1.760/node-v0.10.31-linux-x64/bin/node /export/home/nui/sagie/sapphire_0.1.760/process_launcher/process-launcher/index.js -env-file /export/home/nui/sagie/sapphire_0.1.760/sample/env.json -env-group BACKEND_MACHINE_1 -launch-delay 15000 &

/export/home/nui/sagie/sapphire_0.1.760/node-v0.10.31-linux-x64/bin/node /export/home/nui/sagie/sapphire_0.1.760/process_launcher/process-launcher/index.js -env-file /export/home/nui/sagie/sapphire_0.1.760/sample/env.json -env-group BACKEND_MACHINE_2 -launch-delay 15000 &

sleep 5

/export/home/nui/sagie/sapphire_0.1.760/node-v0.10.31-linux-x64/bin/node /export/home/nui/sagie/sapphire_0.1.760/process_launcher/process-launcher/index.js -env-file /export/home/nui/sagie/sapphire_0.1.760/sample/env.json -env-group MOCK &

sleep 25

/export/home/nui/sagie/sapphire_0.1.760/node-v0.10.31-linux-x64/bin/node /export/home/nui/sagie/sapphire_0.1.760/process_launcher/process-launcher/index.js -env-file /export/home/nui/sagie/sapphire_0.1.760/sample/env.json -env-group LOGIN_SERVER_MACHINE_1 &

/export/home/nui/sagie/sapphire_0.1.760/node-v0.10.31-linux-x64/bin/node /export/home/nui/sagie/sapphire_0.1.760/process_launcher/process-launcher/index.js -env-file /export/home/nui/sagie/sapphire_0.1.760/sample/env.json -env-group FRONTEND_MACHINE_1 &

/export/home/nui/sagie/sapphire_0.1.760/node-v0.10.31-linux-x64/bin/node /export/home/nui/sagie/sapphire_0.1.760/process_launcher/process-launcher/index.js -env-file /export/home/nui/sagie/sapphire_0.1.760/sample/env.json -env-group LOGIN_SERVER_MACHINE_2 &

/export/home/nui/sagie/sapphire_0.1.760/node-v0.10.31-linux-x64/bin/node /export/home/nui/sagie/sapphire_0.1.760/process_launcher/process-launcher/index.js -env-file /export/home/nui/sagie/sapphire_0.1.760/sample/env.json -env-group FRONTEND_MACHINE_2 &
