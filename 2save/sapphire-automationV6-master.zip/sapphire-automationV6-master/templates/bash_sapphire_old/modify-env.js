'use strict';

var args = process.argv.slice(2);

if (args.length) {
    var fs = require('fs');

    if ((args.length === 5) && (args[0] === '-domain')) {
        var name = args[1];
        console.log('Domain: ', name);
        var idmDomain = 'idm.' + name;
        var appDomain = 'trading.' + name;

        var jsonFile = args[2];
        console.log('Reading: ', jsonFile);
        var json = require(jsonFile);
        var ip = json.backendMachine1;
        var end = ip.substring(ip.lastIndexOf('.') + 1);
        var nginxPort = json.httpProxyPort;

        jsonFile = args[3];
        console.log('Reading: ', jsonFile);
        json = require(jsonFile);
        json.config.nginx.data.corsDomain = name;
        json.config.nginx.data.cookieDomain = name;
        json.config.nginx.data.idmLoginURL = 'https://' + end + '.' + idmDomain + ':8900';
        fs.writeFileSync(jsonFile, JSON.stringify(json, undefined, 2));

        jsonFile = args[4];
        console.log('Reading: ', jsonFile);
        json = require(jsonFile);
        json.config['login-server'].data.cookieDomain = name;
        json.config['login-server'].data.proxy.target.forEach(function (target) {
            target.url = 'https://' + end + '.' + appDomain + ':' + nginxPort;
        });
        fs.writeFileSync(jsonFile, JSON.stringify(json, undefined, 2));
    }
}
