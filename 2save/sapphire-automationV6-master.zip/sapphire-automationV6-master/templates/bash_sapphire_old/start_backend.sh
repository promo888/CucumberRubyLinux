#!/bin/sh

mkdir -p ./pid

#TODO CHANGE THESE REDIS SPECIFIC
export REDIS_BIN=/export/home/nui/redis-2.8.19/src
export REDIS_CONF_FILE=/export/home/nui/sagie/sample/redis-config/ebs-redis.conf

($REDIS_BIN/redis-server ${REDIS_CONF_FILE} & echo $! > "./pid/redis.pid")&

export NODE_ENV=production

#TODO REMOVE -full-log in production
export PROCESS_ARGS=-full-log

#TODO CHANGE THESE PER MACHINE
export MOUNT_DIR=/export/home/nui/sagie
export NODE_HOME=/export/home/nui/builds/sapphireBuild_0.1.376/node_binary

#TODO CHANGE THESE PER PROCESS
export LOG_DIRECTORY=/export/home/nui/sagie/sample/log/cloud-controller
export NODE_CACHE_DIR=/export/home/nui/sagie/sample/.cache/cloud-controller
export NODE_CONFIG_KEY=cloud-controller/instance1
export NODE_EBS_AUTH_TOKEN=DEV
export CC_ROOT=${MOUNT_DIR}/backend/cloud-controller
export NODE_EXTERNAL_CONFIG_FILE=/export/home/nui/sagie/sample/config/cloud-controller.json

($NODE_HOME/bin/node ${CC_ROOT}/server/app.js $PROCESS_ARGS & echo $! > "./pid/cloud-controller.pid")&

#give time to cloud controller to start up so next process can fetch the config from it
sleep 10

#TODO CHANGE THESE PER PROCESS
export LOG_DIRECTORY=/export/home/nui/sagie/sample/log/server
export NODE_CACHE_DIR=/export/home/nui/sagie/sample/.cache/server
export NODE_CONFIG_KEY=app/instance1
export NODE_EBS_AUTH_TOKEN=DEV
export SERVER_ROOT=${MOUNT_DIR}/backend/server/server
export NODE_EXTERNAL_CONFIG_FILE=/export/home/nui/sagie/sample/config/config.json

($NODE_HOME/bin/node ${SERVER_ROOT}/server/app.js $PROCESS_ARGS & echo $! > "./pid/server.pid")&
