#!/bin/sh

PID=`cat ./pid/server.pid`

echo "[EBS] Stopping process with PID: $PID"

kill -9 $PID

PID=`cat ./pid/cloud-controller.pid`

echo "[EBS] Stopping process with PID: $PID"

kill -9 $PID

PID=`cat ./pid/redis.pid`

echo "[EBS] Stopping process with PID: $PID"

kill -9 $PID
