#!/bin/sh

###########################################################################
#### This script should only be used by development team to build      ####
#### a standalone, not integrative env.                                ####
###########################################################################

pwd=$(pwd)

cd
cd ./dashboard_remote/env
./dev_stop.sh

cd $pwd

export SKIP_CHMOD=true

if [ "$1" == "-domain" ]; then
    echo "modifying domain...."

    cd ../dashboard_remote
    remote=$(pwd)
    cd $pwd
    ${remote}/node/bin/node ./modify-env.js "-domain" "$2" ${remote}/env/installer.json ${remote}/env/frontend-env.json ${remote}/env/backend-env.json
else
    ./single_machine_setup.sh "$@"

    cd
    chmod -R 777 dashboard_remote/env

    cd
fi

cd
cd dashboard_remote/env
