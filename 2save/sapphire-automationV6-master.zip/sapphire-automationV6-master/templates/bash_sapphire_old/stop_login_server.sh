#!/bin/sh

PID=`cat ./pid/login_server.pid`

echo "[EBS] Stopping process with PID: $PID"

kill -9 $PID
