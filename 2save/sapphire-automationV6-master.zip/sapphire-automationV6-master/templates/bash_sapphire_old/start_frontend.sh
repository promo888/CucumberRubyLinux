#!/bin/sh

mkdir -p ./pid

export NODE_ENV=production

#TODO REMOVE -full-log in production
export PROCESS_ARGS=-full-log

#TODO CHANGE THESE PER MACHINE
export MOUNT_DIR=/export/home/nui/sagie
export NODE_HOME=/export/home/nui/builds/sapphireBuild_0.1.376/node_binary

#TODO CHANGE THESE PER PROCESS
export LOG_DIRECTORY=/export/home/nui/sagie/sample/log/http-proxy
export NODE_CACHE_DIR=/export/home/nui/sagie/sample/.cache/http-proxy
export NODE_CONFIG_KEY=http-proxy/instance1
export NODE_EBS_AUTH_TOKEN=DEV
export HTTP_PROXY_ROOT=${MOUNT_DIR}/frontend/http-proxy
export NODE_EXTERNAL_CONFIG_FILE=/export/home/nui/sagie/sample/config/config.json

($NODE_HOME/bin/node ${HTTP_PROXY_ROOT}/lib/app.js $PROCESS_ARGS & echo $! > "./pid/http-proxy.pid")&

#TODO CHANGE THESE PER PROCESS
export LOG_DIRECTORY=/export/home/nui/sagie/sample/log/pmdp1
export NODE_CACHE_DIR=/export/home/nui/sagie/sample/.cache/pmdp1
export NODE_CONFIG_KEY=pmdp/instance1
export NODE_EBS_AUTH_TOKEN=DEV
export PMDP_ROOT=${MOUNT_DIR}/frontend/pmdp/pmdp
export NODE_EXTERNAL_CONFIG_FILE=/export/home/nui/sagie/sample/config/config.json

($NODE_HOME/bin/node ${PMDP_ROOT}/pmdp/master.js $PROCESS_ARGS & echo $! > "./pid/pmdp1.pid")&

#TODO CHANGE THESE PER PROCESS
export LOG_DIRECTORY=/export/home/nui/sagie/sample/log/pmdp2
export NODE_CACHE_DIR=/export/home/nui/sagie/sample/.cache/pmdp2
export NODE_CONFIG_KEY=pmdp/instance2
export NODE_EBS_AUTH_TOKEN=DEV
export PMDP_ROOT=${MOUNT_DIR}/frontend/pmdp/pmdp
export NODE_EXTERNAL_CONFIG_FILE=/export/home/nui/sagie/sample/config/config.json

($NODE_HOME/bin/node ${PMDP_ROOT}/pmdp/master.js $PROCESS_ARGS & echo $! > "./pid/pmdp2.pid")&
