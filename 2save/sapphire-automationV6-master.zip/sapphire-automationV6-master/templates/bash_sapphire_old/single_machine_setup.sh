#!/bin/sh

##################################################################################
#### This script should only be used by development/israel internal QA team   ####
#### to build a standalone, not integrative env.                              ####
##################################################################################

rm -Rf ./temp_build
mkdir -p ./temp_build
cd ./temp_build

JENKINS_URL=http://10.20.30.155:8080/jenkins/job
JOB_NAME=Dashboard-Release-Deployment

if [ $# -eq 3 ]; then
    if [ "$1" == "-skip" ]; then
        if [ "$2" == "-job" ]; then
            JOB_NAME="$3"
        fi
    fi
fi

echo "Using JOB: $JOB_NAME"

#echo $JENKINS_URL/$JOB_NAME/lastCompletedBuild/buildNumber
LAST_BUILD=$(curl $JENKINS_URL/$JOB_NAME/lastCompletedBuild/buildNumber)

function downloadAndInstall {
    rm -f *.tar.gz
    rm -Rf backend
    rm -Rf frontend
    rm -Rf login-server
    rm -Rf monitor-server
    rm -Rf process-launcher
    rm -Rf node
    rm -Rf redis
    rm -Rf installer
    rm -f installer.sh

    #download build output
    rm -f version*.txt
    curl -o version_remote.txt $JENKINS_URL/$JOB_NAME/$1/deployedArtifacts/download/artifact.2/
    BUNDLE_VERSION=`cat ./version_remote.txt`
    rm -f version*.txt
    BUNDLE_VERSION=$(echo $BUNDLE_VERSION|tr -d '\n')
    curl -o ./dashboard_full_$BUNDLE_VERSION.tar.gz $JENKINS_URL/$JOB_NAME/$1/deployedArtifacts/download/artifact.1/
    chmod 777 *.tar.gz
    tar -xvf ./dashboard_full_$BUNDLE_VERSION.tar.gz
}

if [ "$1" == "-skip" ]; then
    if [ $# -eq 1 ]; then
        downloadAndInstall $LAST_BUILD
    else
        downloadAndInstall $2
    fi
else
    let NEW_BUILD=$LAST_BUILD+1

    #run new build
    RUN_BUILD_URL=$JENKINS_URL/$JOB_NAME/build?token=dashboard-deployment-v1
    echo "Running build via URL: $RUN_BUILD_URL"
    curl $RUN_BUILD_URL

    #wait for build to finish
    let LAST_BUILD$LAST_BUILD+0
    while [  $LAST_BUILD -lt $NEW_BUILD ]; do
        LAST_BUILD=$(curl $JENKINS_URL/$JOB_NAME/lastCompletedBuild/buildNumber)
        let LAST_BUILD$LAST_BUILD+0
        sleep 30s
    done

    downloadAndInstall $NEW_BUILD
fi

BUNDLE_VERSION=`cat ./version.txt`
cd ..
mkdir -p ./dashboard_$BUNDLE_VERSION/remote
mv ./temp_build/* ./dashboard_$BUNDLE_VERSION/remote
cwd=$(pwd)
mkdir -p ${cwd}/dashboard_$BUNDLE_VERSION/local

cd
unlink ./dashboard_remote
unlink ./dashboard_local
ln -s ${cwd}/dashboard_$BUNDLE_VERSION/remote ./dashboard_remote
ln -s ${cwd}/dashboard_$BUNDLE_VERSION/local ./dashboard_local

cd ./dashboard_remote
sh ./install.sh -untar
cd

cd ./dashboard_remote

if [ -z "$SKIP_CHMOD" ]; then
    chmod -R 555 *
fi
cd

cd
echo "Installation Done"
