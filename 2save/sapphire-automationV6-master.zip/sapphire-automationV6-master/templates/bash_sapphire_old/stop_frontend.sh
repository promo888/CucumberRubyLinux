#!/bin/sh

PID=`cat ./pid/pmdp1.pid`

echo "[EBS] Stopping process with PID: $PID"

kill -9 $PID

PID=`cat ./pid/pmdp2.pid`

echo "[EBS] Stopping process with PID: $PID"

kill -9 $PID

PID=`cat ./pid/http-proxy.pid`

echo "[EBS] Stopping process with PID: $PID"

kill -9 $PID
