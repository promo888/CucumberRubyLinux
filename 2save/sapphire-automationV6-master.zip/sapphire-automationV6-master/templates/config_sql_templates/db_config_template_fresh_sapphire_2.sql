prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/../sap_version.sql  ****/
DEFINE  CURR_VER_ID="4.2.225"


prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/header.sql  ****/
set define "^"
define MY_APP_NAME='sapphire_2'

column tm new_value file_time noprint
select to_char(sysdate, 'YYYY-MM-DD-hh24-mi') tm from dual ;
spool ^MY_APP_NAME._^file_time..log

set feedback on
set verify off
set time on
set timing on
set echo on
set linesize 2000
set pagesize 100
set trimout on
set trimspool on
WHENEVER SQLERROR EXIT SQL.SQLCODE;
WHENEVER OSERROR  EXIT SQL.SQLCODE;


/* Log some  schema & installion info*/
select
	'Current_date:..'||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')
	||chr(10)||chr(13)||'### OS info'
	||chr(10)||chr(13)||'TERMINAL:......' || SYS_CONTEXT('USERENV', 'TERMINAL')
	||chr(10)||chr(13)||'CLIENT_IP:.....' || SYS_CONTEXT('USERENV', 'IP_ADDRESS')
	||chr(10)||chr(13)||'OS_USER:.......' || SYS_CONTEXT('USERENV', 'OS_USER')
	||chr(10)||chr(13)||'EXTERNAL_NAME:.' || SYS_CONTEXT('USERENV', 'EXTERNAL_NAME')
	||chr(10)||chr(13)||'### Database info'
	||chr(10)||chr(13)||'DB_NAME:.......' || SYS_CONTEXT('USERENV', 'DB_NAME')
	||chr(10)||chr(13)||'DB_UNIQUE_NAME:' || SYS_CONTEXT('USERENV', 'DB_UNIQUE_NAME')
	||chr(10)||chr(13)||'DB Server:.....' || SYS_CONTEXT('USERENV', 'HOST')
	||chr(10)||chr(13)||'SERVICE_NAME:..' || SYS_CONTEXT('USERENV', 'SERVICE_NAME')
	||chr(10)||chr(13)||'### Session info'
	||chr(10)||chr(13)||'CURRENT_USER:..' || SYS_CONTEXT('USERENV', 'CURRENT_USER')
	||chr(10)||chr(13)||'CURRENT_SCHEMA:' || SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA')
	||chr(10)||chr(13)||'SESSION_USER:..' || SYS_CONTEXT('USERENV', 'SESSION_USER')
	||chr(10)||chr(13)||'ISDBA:.........' || SYS_CONTEXT('USERENV', 'ISDBA')
	||chr(10)||chr(13)||'SESSIONID:.....' || SYS_CONTEXT('USERENV', 'SESSIONID') "Database Info"
from dual ;

/* Log schema privs */
select 'ROLE' Type, GRANTED_ROLE, ADMIN_OPTION, DEFAULT_ROLE from USER_ROLE_PRIVS
union all
select 'PRIV' Type, PRIVILEGE, ADMIN_OPTION, null from USER_SYS_PRIVS
order by 1,2;


select owner, table_name as object_name, grantor, privilege
from all_tab_privs_recd
where grantee = USER
order by owner, table_name;

var vBuildID number
begin
  select substr('^CURR_VER_ID',instr('^CURR_VER_ID','.',-1)+1) into :vBuildID from dual ;
end;
/



prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/db_config_sap.sql  ****/
DEFINE MY_APP_NAME='sapphire_2'
DEFINE SDATA_SCHEMA=SDATA_2
DEFINE PTRADE_SCHEMA=PTRADE_2
DEFINE FR_SCHEMA=FR



prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/../CNFG_SAP_SYNONYMS.table  ****/

CREATE TABLE CNFG_SAP_SYNONYMS (
    LOCAL_NAME            VARCHAR2(30)          NOT NULL,
    REFERRED_OBJECT       VARCHAR2(120)         NOT NULL,
    IS_ENABLED            NUMBER(1)  DEFAULT 1  NOT NULL,
    LAST_CREATION_OK      TIMESTAMP,
    LAST_CREATION_ATTEMPT TIMESTAMP,
    LAST_CREATION_ERROR   VARCHAR2(1000),
  CONSTRAINT PK_CNFG_SAP_SYNONYMS PRIMARY KEY (LOCAL_NAME)
);



prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/../EBS_APP_CONFIG.table  ****/

CREATE TABLE EBS_APP_CONFIG( 
  PK        NUMBER NOT NULL,
  VERSION   NUMBER NOT NULL,
  ENV       VARCHAR2 (250) NOT NULL,
  KEY       VARCHAR2 (250) NOT NULL,
  PARENT    VARCHAR2 (250),
  JSON      CLOB,
  CONSTRAINT PK_EBS_APP_CONFIG PRIMARY KEY (PK),
  CONSTRAINT VERSION_EBS_APP_CONFIG UNIQUE (VERSION)
);



prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/../LOM_USER_DEFAULTS.table  ****/

CREATE TABLE LOM_USER_DEFAULTS
( PK varchar2 (250) not null,
  DATA CLOB,
  CONSTRAINT PK_LOM_USER_DEFAULTS PRIMARY KEY (PK)
);



prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/../LOM_USER_PANELS.table  ****/

CREATE TABLE LOM_USER_PANELS
( PK varchar2 (250) not null,
  DATA CLOB,
  CONSTRAINT PK_LOM_USER_PANELS PRIMARY KEY (PK)
);



prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/../LOM_USER_SETTINGS.table  ****/

CREATE TABLE LOM_USER_SETTINGS
( PK varchar2 (250) not null,
  DATA CLOB,
  CONSTRAINT PK_LOM_USER_SETTINGS PRIMARY KEY (PK)
);




prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/../SCHEMA_VERSION.table  ****/

CREATE TABLE SCHEMA_VERSION (
    APP_NAME        VARCHAR2(64 BYTE)       NOT NULL ,
    VERSION_ID      NUMBER(10,0)            NOT NULL ,
    VERSION_NAME    VARCHAR2(64 BYTE)       NOT NULL ,
    CREATION_TIME   DATE DEFAULT sysdate    NOT NULL 
);



prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/../v_deals_report_csv.view  ****/

create or replace force view v_deals_reports_csv as
select
       d.ID,
       d.TXN_TIME,
       d.INSTR_SYMBOL,
       d.INSTR_PRODUCT_TYPE,
       d.TENOR_TYPE,
       d.TENOR_VALUE,
       d.MARKET_SEGMENT,
       d.ecn,
       d.ALGO_TYPE,
       d.EXEC_ID,
       d.EFP_EXEC_ID,
       d.ECP_EXEC_ID,
       d.EFP_EBS_ORDER_ID,
       d.EFP_ORDER_ID,
       d.ECP_ORDER_ID,
       d.FP_EXEC_SIDE,
       d.FP_SIDE,
       d.QTY_DEALT,
       d.QTY_DEALT_EXP,
       d.VC_QTY_DEALT,
       d.CCY_DEALT,
       d.IS_TERM_CCY,
       d.QTY_CNTR,
       d.QTY_CNTR_EXP,
       d.VC_QTY_CNTR,
       d.CCY_CONTRA,
       d.TRADE_DATE,
       d.DATE_SETTLEMENT,
       d.DATE_MATURITY,
       d.SPOT_SETTL_DATE,
       d.PX_SWAP_POINTS,
       d.PX_SWAP_POINTS_EXP,
       d.PX_ALLIN,
       d.PX_EXP,
       d.PX_EFFECTIVE,
       d.PX_EFFECTIVE_EXP,
       d.VC_PX_EFFECTIVE,
       d.PX_SPOT_ALLIN,
       d.PX_SPOT_BD_EXP,
       d.PX_FWDP_ALLIN,
       d.PX_FWDP_BD_EXP,
       d.FP_INSTITUTION,
       fp_node.location_name    FP_NAME,
       fp_inst.institution_name fp_inst_name,
       d.FP_FLOOR,
       d.EFP_ACCOUNT,
       d.FP_TRADER,
       d.FP_LEI,
       d.FP_BIC,
       d.FP_SI_TYPE,
       d.FP_SI_BANK,
       d.FP_SI_BANK_ACC,
       d.FP_SI_BANK_CITYCODE,
       d.FP_SI_BANK_LOCATION,
       d.FP_SI_BANK_BIC,
       d.CP_INSTITUTION,
       cp_node.location_name    CP_NAME,
       cp_inst.institution_name cp_inst_name,
       d.CP_ACCOUNT,
       d.ECP_ACCOUNT,
       d.CP_TRADER,
       d.CP_LEI,
       d.CP_BIC,
       d.CP_SI_TYPE,
       d.CP_SI_BANK,
       d.CP_SI_BANK_ACC,
       d.CP_SI_BANK_CITYCODE,
       ' ' as ENTERING_USER,
       d.CP_SI_BANK_LOCATION,
       d.CP_SI_BANK_BIC,
       d.FP_INSTITUTION_KEY,
       d.DOMAIN_ID,
       d.LEG_TYPE,
       null tenor_sort_order
from v_deals_reports_source d, 
     nodes_bin        fp_node,
     INSTITUTION_BIN  fp_inst,
     nodes_bin        cp_node,
     INSTITUTION_BIN  cp_inst
where d.fp_floor = fp_node.node_name 
  and fp_node.INSTITUTION = fp_inst.INSTITUTION_CODE
  and d.cp_floor = cp_node.node_name
  and cp_node.INSTITUTION = cp_inst.INSTITUTION_CODE
;



prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/../v_deals_reports.view  ****/
create or replace force view v_deals_reports as
select
       d.ALGO_TYPE,
       d.CCY_DEALT,
       d.CCY_CONTRA,
       d.CP_ACCOUNT,
       d.CP_TRADER,
       /*d.CP_CUSTOMER_NAME,*/
       d.CP_BIC,
       d.CP_LEI,
       d.CP_INSTITUTION,
       /*d.CP_RCV_CCY,*/
       /*d.CP_RCV_QTY,*/
       d.DATE_SETTLEMENT,
       d.DATE_MATURITY,
       d.DOMAIN_ID,
       d.ECP_ACCOUNT,
       d.ECN,
       d.EXEC_ID,
       d.EFP_EBS_ORDER_ID,
       d.ECP_EXEC_ID,
       d.ECP_ORDER_ID,
       d.EFP_EXEC_ID,
       d.EFP_ORDER_ID,
       d.EFP_EXEC_SIDE,
       /*d.ENTERING_USER,*/
       d.FP_ACCOUNT,
       d.FP_EXEC_SIDE,
       d.FP_BIC,
       d.FP_LEI,
       d.FP_INSTITUTION,
       d.FP_INSTITUTION_KEY,
       d.FP_FLOOR,
       /*d.FP_RCV_CCY,*/
       /*d.FP_RCV_QTY,*/
       d.FP_SIDE,
       d.FP_TRADER,
       d.INSTR_SYMBOL,
       d.INSTR_PRODUCT_TYPE,
       d.ID AS TICKET_ID,
       d.IS_TERM_CCY,
       d.LEG_TYPE,
       d.MARKET_SEGMENT,
       d.PX_ALLIN,
       d.PX_EFFECTIVE,
       d.PX_EFFECTIVE_EXP,
       d.PX_EXP,
       d.PX_FWDP_ALLIN,
       d.PX_FWDP_EXP,
       d.PX_FWDP_BD_TRADER,
       d.PX_FWDP_BD_SALES,
       d.PX_FWDP_BD_ECOM,
       d.PX_FWDP_BD_VENUE,
       d.PX_FWDP_BD_EXP,
       d.PX_SWAP_POINTS,
       d.PX_SWAP_POINTS_EXP,
       d.PX_SPOT_ALLIN,
       d.PX_SPOT_EXP,
       d.PX_SPOT_BD_TRADER,
       d.PX_SPOT_BD_SALES,
       d.PX_SPOT_BD_ECOM,
       d.PX_SPOT_BD_VENUE,
       d.PX_SPOT_BD_EXP,
       d.QTY_CNTR,
       d.QTY_CNTR_EXP,
       d.QTY_DEALT,
       d.QTY_DEALT_EXP,
       d.SPOT_SETTL_DATE,
       d.TENOR_TYPE,
       d.TENOR_VALUE,
       d.TRADE_DATE,
       d.TXN_TIME,
       d.VC_QTY_DEALT,
       d.VC_QTY_CNTR,
       d.VC_PX_EFFECTIVE,
       cp_node.location_name    CP_NAME,
       cp_inst.institution_name cp_inst_name,
       fp_node.location_name    FP_NAME,
       fp_inst.institution_name fp_inst_name,
       null tenor_sort_order
from v_deals_reports_source d,
     nodes_bin        fp_node,
     INSTITUTION_BIN  fp_inst,
     nodes_bin        cp_node,
     INSTITUTION_BIN  cp_inst
where d.fp_floor = fp_node.node_name
  and fp_node.INSTITUTION = fp_inst.INSTITUTION_CODE
  and d.cp_floor = cp_node.node_name
  and cp_node.INSTITUTION = cp_inst.INSTITUTION_CODE
;



prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/../V_SAP_ORDERS.view  ****/

CREATE OR REPLACE FORCE EDITIONABLE VIEW V_SAP_ORDERS AS
SELECT
  O.EFP_EBS_ORDER_ID AS ORDER_ID,
  O.EFP_ORD_SUBMIT_TIME AS SUBMIT_TIME,
  O.ORD_STATUS AS STATUS,
  O.ORD_ACCESS_METHOD,
  -------------------------------------
  O.INSTR_SYMBOL AS INSTR_SYMBOL,
  O.NOL_CCY_DEALT AS CCY_DEALT,
  O.NOL_CCY_CONTRA AS CCY_CONTRA,
  -------------------------------------
  O.INSTR_PRODUCT_TYPE AS INSTR_PRODUCT_TYPE,
  O.ECN AS ECN,
  O.ORD_SIDE AS ORD_SIDE,
  O.ALGO_TYPE  AS ALGO_TYPE,
  O.ORD_TIME_IN_FORCE AS ORD_TIME_IN_FORCE,
  O.ORD_CPTYS AS CPTYS,
  -------------------------------------
  O.NOL_TENOR_TYPE AS NOL_TENOR_TYPE,
  O.FOL_TENOR_TYPE AS FOL_TENOR_TYPE,
  O.NOL_DATE_SETTLEMENT AS NOL_DATE_SETTLEMENT,
  O.NOL_TENOR_VALUE AS NOL_TENOR_VALUE,
  O.FOL_TENOR_VALUE AS FOL_TENOR_VALUE,
  O.FOL_DATE_SETTLEMENT AS FOL_DATE_SETTLEMENT,
  -------------------------------------
  O.NOL_QTY AS NOL_QTY,
  O.NOL_QTY_EXP AS NOL_QTY_EXP,
  O.VC_NOL_QTY AS VC_NOL_QTY,
  -------------------------------------
  D.TXN_TIME,
  D.NTL_QTY_CUM AS NTL_QTY_CUM,
  D.NTL_QTY_CUM_EXP  AS NTL_QTY_CUM_EXP,
  D.VC_NTL_QTY_CUM AS VC_NTL_QTY_CUM,
  -------------------------------------
  ROUND((D.VC_NTL_QTY_CUM/O.VC_NOL_QTY)*100,1) AS FILLED,
  CASE WHEN D.NTL_QTY_CUM > 0 THEN 1 ELSE 0 END AS DEALS,
  -------------------------------------
  O.NOL_PX AS NOL_PX,
  O.NOL_PX_EXP AS NOL_PX_EXP,
  O.VC_NOL_PX AS VC_NOL_PX,
  -------------------------------------
  O.PX_SWAP_POINTS AS SWAP_POINTS,
  O.PX_SWAP_POINTS_EXP AS SWAP_POINTS_EXP,
  O.VC_PX_SWAP_POINTS AS VC_PX_SWAP_POINTS,
  -------------------------------------
  D.NTL_PX_AVG AS NTL_PX_AVG,
  D.NTL_PX_AVG_EXP AS NTL_PX_AVG_EXP,
  D.VC_NTL_PX_AVG AS VC_NTL_PX_AVG,
  -------------------------------------
  O.EFP_INSTITUTION_KEY AS EFP_INSTITUTION_KEY,
  O.EFP_ACCOUNT AS EFP_ACCOUNT,
  O.EFP_FLOOR AS EFP_FLOOR,
  O.EFP_TRADER AS EFP_TRADER,
  -------------------------------------
  O.ENP_INSTITUTION_KEY AS ENP_INSTITUTION_KEY,
  O.ENP_ACCOUNT AS ENP_ACCOUNT,
  O.ENP_FLOOR AS ENP_FLOOR,
  O.ENP_TRADER AS ENP_TRADER
  -------------------------------------
FROM V_FX_ORD       O,
     V_FX_ORD_DET   D
WHERE D.EFP_EBS_ORDER_ID = O.EFP_EBS_ORDER_ID
  AND D.EFP_INSTITUTION_KEY = O.EFP_INSTITUTION_KEY
  AND D.ORD_DET_ID = O.ORD_DET_ID
;



prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/../V_SAP_TICKETS.view  ****/
CREATE OR REPLACE FORCE VIEW V_SAP_TICKETS AS
select
    d.*,
    cp_node.location_name    CP_NAME,
    cp_inst.institution_name CP_INSTITUTION_NAME,
    fp_node.location_name    FP_NAME,
    fp_inst.institution_name FP_INSTITUTION_NAME,
    d.ID                     TICKET_ID,
    ' ' as ENTERING_USER,
    PX_BD_BASE *power(10,PX_BD_EXP) as VC_PX_BD_BASE
from v_deals_reports_source d,
     nodes_bin        fp_node,
     INSTITUTION_BIN  fp_inst,
     nodes_bin        cp_node,
     INSTITUTION_BIN  cp_inst
where d.fp_floor_key = fp_node.FLOOR_KEY
  and fp_node.INSTITUTION = fp_inst.INSTITUTION_CODE
  and d.cp_floor_key = cp_node.FLOOR_KEY
  and cp_node.INSTITUTION = cp_inst.INSTITUTION_CODE;



prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/../create_synonyms.procedure  ****/
create or replace procedure create_synonyms as
    lErrMsg     varchar2(1000);
begin
    for synonymList in (
        select LOCAL_NAME as localSynonym, REFERRED_OBJECT referredObject
        from CNFG_SAP_SYNONYMS
        where IS_ENABLED=1
        order by local_name )
    loop
       begin
            execute immediate 'CREATE OR REPLACE SYNONYM '||synonymList.localSynonym||' for '||synonymList.referredObject;
            update CNFG_SAP_SYNONYMS set
                LAST_CREATION_ATTEMPT = systimestamp,
                LAST_CREATION_OK = systimestamp,
                LAST_CREATION_ERROR = null
            where IS_ENABLED=1 and LOCAL_NAME=synonymList.localSynonym;
            commit;
       exception
          when others then
            lErrMsg := SUBSTR(SQLERRM,1,1000);
            update CNFG_SAP_SYNONYMS set
                LAST_CREATION_ATTEMPT = systimestamp,
                LAST_CREATION_ERROR = lErrMsg
            where IS_ENABLED=1 and LOCAL_NAME=synonymList.localSynonym;
            commit;
       end;
    end loop;
end;
/



prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/../go_public.procedure  ****/
create or replace procedure go_public (obj_type in varchar2 default '%', obj_name in varchar2 default '%', grantee_name in varchar2 default 'PUBLIC' ) is
    lpublicSQL varchar2(4000);
    lGrantType varchar2(20);
begin
    for i in (select OBJECT_NAME, OBJECT_TYPE
              from user_objects
              where object_name like obj_name
                and object_type like obj_type
                and object_type in ('TABLE','VIEW','PROCEDURE','FUNCTION','PACKAGE')
              order by OBJECT_TYPE, OBJECT_NAME)
    loop
        begin
            case
                when i.object_type in ('TABLE','VIEW') then lGrantType := 'SELECT';
                when i.object_type in ('PROCEDURE','FUNCTION','PACKAGE') then lGrantType := 'EXECUTE';
                else lGrantType := 'ERROR';
            end case;
            lpublicSQL := 'GRANT '|| lGrantType ||' on '||i.object_name||' to '||grantee_name;
            dbms_output.put_line(lpublicSQL);
            execute immediate lpublicSQL;
        exception
            when others then null;
        end;
    end loop;
end;
/


prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/../cnfg_sap_synonyms.sys_data  ****/

BEGIN
    delete CNFG_SAP_SYNONYMS;
    INSERT INTO CNFG_SAP_SYNONYMS (LOCAL_NAME, REFERRED_OBJECT) values ('sap_static_data',            '^SDATA_SCHEMA..V_SD_FULL_CURRENCY_JSON2');
    INSERT INTO CNFG_SAP_SYNONYMS (LOCAL_NAME, REFERRED_OBJECT) values ('sap_ccy_calendar',           '^SDATA_SCHEMA..V_SD_CCY_CALENDAR_JSON');
    INSERT INTO CNFG_SAP_SYNONYMS (LOCAL_NAME, REFERRED_OBJECT) values ('asd_util_pkg',               '^SDATA_SCHEMA..asd_util_pkg');
    INSERT INTO CNFG_SAP_SYNONYMS (LOCAL_NAME, REFERRED_OBJECT) values ('v_user_info',                '^SDATA_SCHEMA..v_asd_users_info_json');
    INSERT INTO CNFG_SAP_SYNONYMS (LOCAL_NAME, REFERRED_OBJECT) values ('sap_permissions',            '^SDATA_SCHEMA..V_ASD_PERMISSIONS_JSON');
    INSERT INTO CNFG_SAP_SYNONYMS (LOCAL_NAME, REFERRED_OBJECT) values ('sap_sdata_version',          '^SDATA_SCHEMA..schema_version');
    INSERT INTO CNFG_SAP_SYNONYMS (LOCAL_NAME, REFERRED_OBJECT) values ('v_sd_active_product_tenors', '^SDATA_SCHEMA..v_sd_active_product_tenors');
    INSERT INTO CNFG_SAP_SYNONYMS (LOCAL_NAME, REFERRED_OBJECT) values ('nodes_bin',                  '^SDATA_SCHEMA..nodes_bin');
    INSERT INTO CNFG_SAP_SYNONYMS (LOCAL_NAME, REFERRED_OBJECT) values ('institution_bin',            '^SDATA_SCHEMA..institution_bin');
    INSERT INTO CNFG_SAP_SYNONYMS (LOCAL_NAME, REFERRED_OBJECT) values ('sap_ptrade_version',         '^PTRADE_SCHEMA..schema_version');
    INSERT INTO CNFG_SAP_SYNONYMS (LOCAL_NAME, REFERRED_OBJECT) values ('v_deals_reports_source',     '^PTRADE_SCHEMA..v_FX_TICKET_LEGS');
    INSERT INTO CNFG_SAP_SYNONYMS (LOCAL_NAME, REFERRED_OBJECT) values ('V_FX_ORD',                   '^FR_SCHEMA..V_FX_ORD');
    INSERT INTO CNFG_SAP_SYNONYMS (LOCAL_NAME, REFERRED_OBJECT) values ('V_FX_ORD_DET',               '^FR_SCHEMA..V_FX_ORD_DET');
    commit;
exception
   when others then
    rollback;
    raise;
END;
/



prompt /**** File: /home/staff/slave/workspace/Sapphire-Production-Release4/config/schema/db/bin/footer.sql  ****/

/* Mark successful installation */
begin
    delete schema_version where  APP_NAME='^MY_APP_NAME';
    insert into schema_version (APP_NAME, VERSION_ID, VERSION_NAME,CREATION_TIME) values ('^MY_APP_NAME',:vBuildID, substr('^CURR_VER_ID ^1 ended OK',1,64), systimestamp);
    commit;
end;
/

begin
    create_synonyms;
    go_public;
end;
/


spool off
exit



