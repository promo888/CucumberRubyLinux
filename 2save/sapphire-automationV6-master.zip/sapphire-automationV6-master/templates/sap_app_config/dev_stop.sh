#!/bin/sh

kill -9 `ps -ef | grep node | awk '{ print $2 }'`

kill -9 `ps -ef | grep java | awk '{ print $2 }'`

kill -9 `ps -ef | grep redis | awk '{ print $2 }'`

kill -9 `ps -ef | grep nginx | awk '{ print $2 }'`
