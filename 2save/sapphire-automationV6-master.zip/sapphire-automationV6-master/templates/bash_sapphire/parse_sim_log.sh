#!/bin/bash

logPath=${1:-}

if ! [ -s "$logPath" ]; then
	echo -e "File \""$logPath"\" not found or file size equals 0"
	exit 1
fi

while [ "true" ]
do
	if [ $(cat "$logPath" |grep -F 'AbstractExecutionStepsSynchronizer:DEBUG:(LPA Sim) Thread is going to sleep for 45100 millis'|wc -l) -gt 0 ]; then
        break
	fi
	sleep 1
done

echo -e "The simulated prices should be sent after the following lines:\n"
cat "$logPath" |grep -F 'AbstractExecutionStepsSynchronizer:DEBUG:(LPA Sim) Thread is going to sleep for 45100 millis'