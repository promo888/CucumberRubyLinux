#!/bin/sh

USER_HOME_DIR="$(whoami)"
INT=$(netstat -rn | tail -1 |awk '{print $(NF)}')
IP=$(/sbin/ifconfig $INT |grep addr: |cut -f2 -d: |cut -f1 -d" ")

/export/home/${USER_HOME_DIR}/sapphire_remote/env/dev_stop.sh

#/export/home/${USER_HOME_DIR}/sapphire_remote/node/bin/node /export/home/${USER_HOME_DIR}/sapphire_remote/process_launcher/process-launcher/index.js -env-file /export/home/${USER_HOME_DIR}/sapphire_remote/env/mock-env.json -env-group MOCK -launch-delay 100 -archive-dir /export/home/${USER_HOME_DIR}/sapphire_archive &
#sleep 5
export EBS_PROCESS_LAUNCHER_ID=mock
/export/home/${USER_HOME_DIR}/sapphire_remote/env/start_sapphire.sh mock-env.json MOCK 100 /export/home/${USER_HOME_DIR}/sapphire_archive &

export EBS_PROCESS_LAUNCHER_ID=monitor
/export/home/${USER_HOME_DIR}/sapphire_remote/env/start_sapphire.sh backend-env.json MONITOR_SERVER_MACHINE 100 /export/home/${USER_HOME_DIR}/sapphire_archive &

export EBS_PROCESS_LAUNCHER_ID=backend
/export/home/${USER_HOME_DIR}/sapphire_remote/env/start_sapphire.sh backend-env.json "$IP" 100 /export/home/${USER_HOME_DIR}/sapphire_archive &

export EBS_PROCESS_LAUNCHER_ID=login
/export/home/${USER_HOME_DIR}/sapphire_remote/env/start_sapphire.sh backend-env.json LOGIN_SERVER_MACHINE 100 /export/home/${USER_HOME_DIR}/sapphire_archive &

export EBS_PROCESS_LAUNCHER_ID=frontend
/export/home/${USER_HOME_DIR}/sapphire_remote/env/start_sapphire.sh frontend-env.json "$IP" 100 /export/home/${USER_HOME_DIR}/sapphire_archive &
