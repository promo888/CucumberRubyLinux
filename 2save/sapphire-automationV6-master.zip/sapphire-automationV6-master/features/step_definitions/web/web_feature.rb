require 'cucumber'
require 'capybara'
require "capybara/dsl"
require 'date'
require 'time'
require 'capybara-screenshot'
#require 'selenium/webdriver'
supportPath = Dir.getwd+'/features/support'
require File.expand_path("#{supportPath}/custom_config", __FILE__)
include CONFIG
##include Capybara::DSL
# encoding: utf-8

$jsonFilename ="#{supportPath}/userEntitlements.json"
$jsonUiDefaultsFilename = "#{supportPath}/uiDefaults.json"
$jsonUiDefaultsFilenameVer5 = "#{supportPath}/uiDefaults_ver5.json"
$sqlFilesPath = "#{supportPath}"
$ui = nil
$arrDates = nil

begin
  require Dir.getwd+'/features/helpers/UiHelpers'
  require Dir.getwd+'/features/helpers/Panel'
  require Dir.getwd+'/features/helpers/Actions'
  require Dir.getwd+'/features/helpers/Globals'
  require Dir.getwd+'/features/helpers/OrderFormsPanel'
  require Dir.getwd+'/features/helpers/OrderItem'
rescue LoadError=>e
  $world.puts 'LoadError: ' + e.message if e!=nil
end

$debug = false
if ((ENV['debug'] != nil) && (ENV['debug'] == "true"))
  $debug = true
end

def log(message)
  parentFunc = caller_locations(1).first.label
  Controls.log(message, File.basename(__FILE__), parentFunc.to_s)
end

def getTenors(numbersArray)
  totalTenors = []
  tenorsHash = {}
  for i in 0..(numbersArray.length) do
    num = numbersArray[i]
    if ($uiDefaults["allowed"]["tenorsInMenu"].has_key?(num.to_s))
      tenorsHash[i] = $uiDefaults["allowed"]["tenorsInMenu"][num.to_s]
    else
      tenorsHash[i] = []
    end
  end

  totalTenors = tenorsHash[0] + tenorsHash[1]
  return totalTenors
end

def getMaxTenors(source)
  maxAllowed = []
  case source
    when Globals.sourceMenu
      maxAllowed = $uiDefaults["allowed"]["tenorsInMenu"]["maximumAllowed"]
      if (maxAllowed == nil)   # While running version 6 with entitlements of version 5.
        maxAllowed = []
        for k in $uiDefaults["allowed"]["tenorsInMenu"].keys
          cur = $uiDefaults["allowed"]["tenorsInMenu"][k]
          maxAllowed |= cur
        end
      end
    when Globals.sourceDatepicker
      maxAllowed = $uiDefaults["allowed"]["tenorsInDatePicker"][$uiDefaults["defaultValues"]["floor"]]
  end
  return maxAllowed
end

def getTenorsByMinAndMaxTenors(source = Globals.sourceDatepicker, minTenor = nil, maxTenor = nil,
                               arrElementsToExclude = nil)
  tenors = getMaxTenors(source)
  i = 0
  minLoc = -1
  maxLoc = -1
  if (minTenor == nil)
    minLoc = 0
  end

  if (maxTenor == nil)
    maxLoc = tenors.length - 1
  end

  tenors.each do |t|
    if ((minLoc < 0) && (t == minTenor))
      minLoc = i
    end

    if ((maxLoc < 0) && (t == maxTenor))
      maxLoc = i
    end

    if ((minLoc >= 0) && (maxLoc >= 0))
      break
    end

    i += 1
  end

  tenorsToReturn = []
  if ((minLoc >= 0) && (maxLoc >= 0))
    for i in minLoc..maxLoc do
      t = tenors[i]
      if ((arrElementsToExclude != nil) && (arrElementsToExclude.include?(t)))
        next
      end

      tenorsToReturn.push(t)
    end
  end

  return tenorsToReturn
end

def getFloorsForUI()
  return $uiDefaults["allowed"]["tenorsInDatePicker"].keys
end

def getLPs(floor, ccy)
  if ($dbData.nil?)
    UiHelpers.throw "$dbData is required in this step"
  end
  return $dbData[floor.to_s][ccy.to_s].keys
end

def getCcys(floor)
  return $dbData[floor.to_s].keys
end

def getUiDefaults(filename = $jsonUiDefaultsFilename)

  res = File.read(filename)
  json = JSON.parse(res)
  return json
end

def getDbHash(schema, tradingCode)
  dbHash = {}
  #sapphireUsername = ENV["SapphireUiUser"]
  #db_user = schema.to_s.downcase
  #db_pwd = schema.to_s.downcase
  #query0 = "SELECT asd_util_pkg.getUserEntitlement('#{sapphireUsername}') FROM dual;"
  #res = Actions.getDbQueryResults(db_user,db_pwd,query0)
  #json = res[0]['ASD_UTIL_PKG.GETUSERENTITLEMEN']
  json = nil
  if ((@@entitlements == nil) || (@@entitlements['entitlement_json'] == nil))
    UiHelpers.throw("No JSON data from DB, getting local JSON data instead", false, false, true, false)
  else
    json = @@entitlements['entitlement_json']
    if ((json["floors"] == nil) || (json["pairsProducts"] == nil))
      UiHelpers.throw("Damaged JSON data from DB, getting local JSON data instead", false, false, true, false)
      json = nil
    end
  end

  if (json == nil)
    res = File.read($jsonFilename)
    fail('Could not get JSON using DB') if res.nil? || res.empty?
    json = JSON.parse(res)
  end
  uiFloors = getFloorsForUI()
  for floor in json["floors"].keys do
    if (! uiFloors.include?(floor))
      log "Floor #{floor} is not on UI therefore should be ignored"
      next
    end
    dbHash[floor] = {}
    jsonFloor = json["floors"][floor][tradingCode]
    fail("floor #{floor}  not found") if jsonFloor.nil? || jsonFloor.empty?
    jsonFloorCurrency = jsonFloor["currency"]
    if (jsonFloorCurrency.nil? || jsonFloorCurrency.empty?)
      log "No currency key for for floor #{floor}"
      next
    end
    for currencyPairs in jsonFloorCurrency.keys do
      dbHash[floor][currencyPairs] = {}
      log "Working on currency pairs: #{currencyPairs}"
      ccyRelatedNum = jsonFloorCurrency[currencyPairs]
      if (ccyRelatedNum.nil? || ccyRelatedNum.empty?)
        log "#{currencyPairs} do not have related number"
        next
      end

      jsonPairsProduct = json["pairsProducts"]
      if (jsonPairsProduct.nil? || jsonPairsProduct.empty?)
        fail("No pairs product in JSON")
      end

      jsonPairsProductRelatedToCcy = jsonPairsProduct[ccyRelatedNum]
      if (jsonPairsProductRelatedToCcy.nil? || jsonPairsProductRelatedToCcy.empty?)
        log "No pairs product related to num #{ccyRelatedNum} of currency pairs #{currencyPairs}"
        next
      end

      numRepresentTenors = {}
      lps = $uiDefaults["allowed"]["lpsOnDB"] # Order is important here (SP,OT,SW,NDF,NSF)
      for i in 0..(jsonPairsProductRelatedToCcy.length - 1) do
        if (jsonPairsProductRelatedToCcy[i] != nil)
          lp = lps[i]
          numRepresentTenors[lp] = jsonPairsProductRelatedToCcy[i]
          dbHash[floor][currencyPairs][lp] = {}

          jsonEntitlements = json["productEntitlements"]
          if (jsonEntitlements.nil? || jsonEntitlements.empty?)
            fail("No field json entitlements found")
          end

          tenorsRelatedNumbers = jsonEntitlements[numRepresentTenors[lp]]
          if (tenorsRelatedNumbers.nil? || tenorsRelatedNumbers.empty?)
            log "No entitlement for number"
            next
          end

          tenorsRelatedNumbers = tenorsRelatedNumbers["tenors"]
          if (tenorsRelatedNumbers.nil? || tenorsRelatedNumbers.empty?)
            log "No tenors for number"
            next
          end

          dbHash[floor][currencyPairs][lp] = getTenors(tenorsRelatedNumbers)
        end
      end
    end
  end

  return dbHash
end

Then /^Sapphire backend\.env is set to "([^"]+)"$/ do |usage|
  usage = usage.to_s.downcase
  baseF = "#{CONFIG.get['REMOTE_HOME']}/#{CONFIG.get['APP_HOST_USER']}/sapphire_remote/env/backend-env.json"
  tempF = "/tmp/backend-env.json"
  gcOrderPort = "3021"
  gcMarketPort = "3022"
  isGcMock = false
  if (usage =~ /mock/)
    gcOrderPort = "6323"
    gcMarketPort = "5500"
    isGcMock = true
  end
  cmd = "cat #{baseF} | perl -e '$data=\"\"; " +
      "while($line = (<>)){$data=\"$data$line\";} " +
      "$data =~ s/(\"gc\":.*?\"market\".*?\"port\": )(\\d+)(.*?\}.*?\"order\":.*?\"port\": )(\\d+)/" +
                  "${1}#{gcMarketPort}${3}#{gcOrderPort}/s;" +
      "print $data;' > #{tempF}; mv #{tempF} #{baseF}"
  res = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15)

  if (isGcMock)
    verifyInBackendEnvThatGcMockDebugOutputsToFiles()
  else
    verifyInBackendEnvThatGcMockDebugNotOutputsToFiles()
  end
end

When /^getting calendar days from sdata$/ do
  #datesForTest
  date = Date.today()
  arrTradingDates = {}
  arrNonTradingDates = {}

  for i in 1..12 do
    tradingDates = $uiDefaults["defaultValues"]["trading"]
    nonTradingDates = $uiDefaults["defaultValues"]["nonTrading"]
    defaultCCY = $uiDefaults["defaultValues"]["ccy"]
    keyInArr = "#{date.month.to_s}/#{date.year.to_s}"
    dateMonth = date.month
    dateYear = date.year
    arrTradingDates[keyInArr] = getSpecificMonthDates(dateMonth, dateYear, tradingDates, defaultCCY)
    arrNonTradingDates[keyInArr] = getSpecificMonthDates(dateMonth, dateYear, nonTradingDates, defaultCCY)
    date = date.next_month()
  end

  $arrDates = {}
  $arrDates[$uiDefaults["defaultValues"]["ccy"]] = {
      Globals.typeTradingDates => arrTradingDates,
      Globals.typeNonTradingDates => arrNonTradingDates
  }
end

When /^getting tenors from sdata, DB ENTITLEMENTS SHOULD BE IMPLEMENTED$/ do
  Entitlements.loadJsonEntitlements(CONFIG.get['SDATA_SCHEMA'],ENV["SapphireUiUser"],ENV["SAP_RELEASE_NUMBER"])
  $dbData = getDbHash(Globals.sdataVersion, "EBSD")

end

Then /^verify that all properties match between UI and DB$/ do
  floors = getFloorsForUI()
  defaultCCY = $uiDefaults["defaultValues"]["ccy"]
  defaultFloor = $uiDefaults["defaultValues"]["lp"]
  $uiDefaults["allowed"]["tenorsInMenu"] = {}
  for floor in floors do
    $uiDefaults["allowed"]["tenorsInMenu"][floor] = $dbData[floor][defaultCCY][defaultFloor]
  end


  dbData = {}
  uiData = {}
  elements = {}
  errors = ""

  floorVal = Globals.panelDDFloor
  dbData[floorVal] = $dbData.keys
  uiData[floorVal] = $panel.getPanelDDValues2(floorVal)
  errors += minusIntersection(uiData[floorVal], dbData[floorVal],
                              "UI",
                              "DB", "arr2-arr1")

  for floor in dbData[floorVal] do
# next if (floor != "LCLD");
    log "since we currently need to filter specific currency pairs"
    ccyVal = Globals.panelDDCCY
    dbData[ccyVal] = []
    for currencyPair in $dbData[floor].keys do
      if ($uiDefaults["ccysUnsupported"].include?(currencyPair))
        next
      end
      dbData[ccyVal].push(currencyPair)
    end

    log "Setting Floor to #{floor}"
    $panel.setFloor(floor)
    log "Testing currency pairs for floor #{floor}"
    uiData[ccyVal] = $panel.getPanelDDValues2(ccyVal)
    errorsCurrencyPair = minusIntersection(uiData[ccyVal], dbData[ccyVal],
                                           "UI(floor: #{floor})",
                                           "DB(floor: #{floor})", "arr2-arr1")
    errors += errorsCurrencyPair

    for currencyPair in dbData[ccyVal] do
# next if (currencyPair != "AUD/CAD");
      if (errorsCurrencyPair.include?(currencyPair))
        log "Skipping currencyPair #{currencyPair} since it is already found in errors"
        next
      end
      $panel.setCurrencyPair(currencyPair)
      lpVal = Globals.panelDDProductType
      log "Testing lp for floor #{floor} and currency pair #{currencyPair}"
      dbData[lpVal] = $dbData[floor][currencyPair].keys
      uiData[lpVal] = $panel.getPanelDDValues2(lpVal)
      if (uiData[lpVal].nil? || uiData[lpVal].empty?)
        uiData[lpVal] = []
        current = Controls.value("panel_current_liquidityProvider", $panel.getActivePanelElement())
        uiData[lpVal].push(current)
      end
      errors += minusIntersection(uiData[lpVal], dbData[lpVal],
                                  "UI(floor: #{floor}, currencyPair: #{currencyPair})",
                                  "DB(floor: #{floor}, currencyPair: #{currencyPair})", "arr2-arr1")

      for lp in dbData[lpVal] do
        tenorsVal = Globals.panelDDTenor
        dbData[tenorsVal] = $dbData[floor][currencyPair][lp]
        if (dbData[tenorsVal].nil? || dbData[tenorsVal].empty?)
          log "Skipping test of tenors for floor: #{floor}, currency pair: #{currencyPair}," +
                  " lp: #{lp}, since it has no tenors in DB"
          next
        end


        log "Setting lp to #{lp}"
        $panel.setProductType(lp)
        timeToWait = 2
        log "Waiting #{timeToWait.to_s} before getting tenors"
        sleep timeToWait
        log "Testing tenors for lp #{lp}"
        uiData[tenorsVal] = $panel.getPanelDDValues2(tenorsVal)
        dbData[tenorsVal] = $dbData[floor][currencyPair][lp] # List of tenors is already in array
        log "Comparing tenors from UI, with tenors from DB"
        errors += minusIntersection(uiData[tenorsVal], dbData[tenorsVal],
                                    "UI(floor: #{floor}, currencyPair: #{currencyPair}, lp: #{lp})",
                                    "DB(floor: #{floor}, currencyPair: #{currencyPair}, lp: #{lp})",
                                    "arr2-arr1")
      end
    end
  end

  if ((!errors.nil?) && (!errors.empty?))
    raise "Errors where found:\n#{errors}\n"
  end
end

Given /^the App is deployed and started$/ do
    sap_version = Actions.displaySapphireAppOnlyVersion2(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
    if (!sap_version.nil? && !sap_version.empty?)
      fail("Sapphire installation not found") if sap_version.to_s.downcase.include?("not_set")

      if ENV['WITHOUT_DEPLOYMENT_AND_STOP'].to_s.downcase != 'true'
        steps %Q{
          Then Sapphire App is launched
        }
      elsif ENV['WITHOUT_DEPLOYMENT_AND_STOP'].to_s.downcase == 'true'
        Actions.v 'Continuing without starting Sapphire'
      end
    else
      fail("Sapphire installation not found")
    end
end

When /^json data is available$/ do
  if (ENV["SAP_RELEASE_NUMBER"].to_s == "6")
    $uiDefaults = getUiDefaults()
  else
    $uiDefaults = getUiDefaults($jsonUiDefaultsFilenameVer5)
  end
end

Then /^perpare for MSL and Gateway tests$/ do
  steps %Q{
      Then set deals columns for MSL tests
  }
  $deals.verifyPostTradeIsUp()
  $deals.verifySapCmdIsInstalled()
end

Then /^test that MSL and Gateway work correctly$/ do
  $baseDetails = ""
  errorsInExecution = ""
  begin
    setOn = Globals.settingsOn
    setOff = Globals.settingsOff
    $panelSettings = SettingsPanel.new($ui, Globals.newPanelTypeNumber, 1)

    # LPs definitions
    defaultLPsAlwaysSetOn = [Globals.cptyLPLB, Globals.cptyLPLK] # LPLK is for prices from  LPA simulators
    defaultLPsToSet = nil
    allowedRfqLPs = $ui.getAllowedRfqLPsFromDB()
    specificLPsToSet = (defaultLPsAlwaysSetOn + allowedRfqLPs).product([setOn]).to_h # rfq lps are on.
    specificLPsToSet[Globals.cptyOthers] = setOff # if found other lps they will be unchecked

    # Logs definitions
    logsBasePath = CONFIG.get['REMOTE_HOME'] + '/' + CONFIG.get['APP_HOST_USER'] + '/sapphire_local/logs'
    nosLogs = ["#{logsBasePath}/app-server/nos.log"]
    gcOrderLogs = $deals.getGcOrderLogFiles(logsBasePath)
    afterClickLogsPrefix = "_afterClick"
    logsProperties = {
        "nos" => {  "filenames" => nosLogs,
                    "regexBefore" => /.*Order\s+valid,\s+submitting\s+to\s+GC[^{]+/mi,
                    "regexAfter"  => /\n\n.*/mi,
                    "errorMessageNoLogData" => "no data was not found in nos logs",
                    "failWhenNoDataFound" => true,
                    "diffLogName" => "NOS logs",
                    "diffUiName" => "orders",
                    "cmpDirection" => "BOTH",
                    "diffLogIgnore" => [],
                    "diffUiIgnore" => [Globals.dealItemOrderId]
        },
        "gcOrder" => { "filenames" => gcOrderLogs,
                       "regexBefore" => /^.*ORDER_REQUEST[^\n]+\s*/im,
                       "regexAfter"  => /\n\n.*/mi,
                       "errorMessageNoLogData" => "no data was found in gc order logs",
                       "failWhenNoDataFound" => false,
                       "diffLogName" => "gcOrder logs",
                       "diffUiName" => "orders",
                       "cmpDirection" => "BOTH",
                       "diffLogIgnore" => [],
                       "diffUiIgnore" => [Globals.dealItemOrderId],
        },
        "gcOrder2" => { "filenames" => gcOrderLogs,
                        "regexBefore" => /^.*Sent\s+message\s+NOS.*?to\s+GW\s+server[^\n]+\s*/i,
                        "regexAfter"  => /\n\n.*/mi,
                        "errorMessageNoLogData" => "no data was found in gc order logs",
                        "failWhenNoDataFound" => false,
                        "diffLogName" => "gcOrder logs",
                        "diffUiName" => "orders",
                        "cmpDirection" => "BOTH",
                        "diffLogIgnore" => [],
                        "diffUiIgnore" => [Globals.dealItemOrderId],
        }
    }
    logDataFilesToSave = logsProperties.values.collect{|h| h['filenames']}.flatten.uniq
    sp = Globals.panelLpSP
    ot = Globals.panelLpOT
    sw = Globals.panelLpSW
    sell = Globals.orderItemSell
    buy = Globals.orderItemBuy
    swBuySell = Globals.orderItemBuySell
    swSellBuy = Globals.orderItemSellBuy
    floor = $uiDefaults["defaultValues"]["floor"]
    ccy = $uiDefaults["defaultValues"]["ccy"]
    # Tests definitions
    testsToPerform = [
        [Globals.dealtAmountStr50M,   swSellBuy,  setOff, sw, defaultLPsToSet],
        [Globals.dealtAmountStr50M,   swBuySell,  setOff, sw, defaultLPsToSet],
        [Globals.dealtAmountStr50M,   sell,       setOff, ot, defaultLPsToSet],
        [Globals.dealtAmountStr50M,   sell,       setOn,  ot, defaultLPsToSet],
        [Globals.dealtAmountStr100M,  buy,        setOff, sp, defaultLPsToSet],
        [Globals.dealtAmountStr100M,  buy,        setOn,  sp, defaultLPsToSet],
        [Globals.dealtAmountStr100M,  sell,       setOff, sp, defaultLPsToSet],
        [Globals.dealtAmountStr100M,  sell,       setOn,  sp, defaultLPsToSet]
    ]

    # Starting the tests
    testsToPerform.each do |test|
      amountToSend,buyOrSell,confirmOnSend,productType,lpsToSet = test
      $baseDetails = "amountToSend: #{amountToSend.to_s}, buyOrSell: #{buyOrSell.to_s}, " +
                      "confirm: #{confirmOnSend.to_s}"
      maxAllowedStuckOrdersBeforeFailues = 5
      shouldSendMessageBeforeVerification = true
      while ( (shouldSendMessageBeforeVerification) &&
              (maxAllowedStuckOrdersBeforeFailues > 0))
        performBeforeMslAndGwTests(confirmOnSend)
        sentOrderHash = $deals.sendNosMessage(amountToSend, buyOrSell, confirmOnSend, floor, ccy,
                                              productType, lpsToSet, logDataFilesToSave, afterClickLogsPrefix)
        if ((sentOrderHash == nil) || (sentOrderHash.length == 0))
          UiHelpers.throw("Nos message wasn't sent properly", true, false, true, true)
        end
        if (OrderItem.isStuckOrderExist())
          UiHelpers.createAndShowScreenshot("Sent message is stuck (in orders panel)")
          maxAllowedStuckOrdersBeforeFailues -= 1
          if (maxAllowedStuckOrdersBeforeFailues > 0)
           log "Retrying to send again"
          else
            UiHelpers.throw("all sent messages were stuck", true, false, true, true)
          end
        else
          shouldSendMessageBeforeVerification = false
        end
      end
      UiHelpers.createAndShowScreenshot("After nos message was sent (#{$baseDetails})")
      orderTransactions = $orderItem.getOrderTransactions()
      diffLogsToUI(logsProperties, sentOrderHash, afterClickLogsPrefix, productType)
      diffPanelSettingsLpsToOrderLps(orderTransactions)
      diffOrderToDealBlotter(sentOrderHash, orderTransactions, productType)
      UiHelpers.createAndShowScreenshot("After deal was recieved on blotter (#{$baseDetails})")
    end
  rescue =>ex
      message = "Error: #{ex.message} (#{$baseDetails})"
      errorsInExecution += "#{message}\n"
  end
  if (errorsInExecution != "")
    # First ensure required steps after ending step will be executed.
    steps %Q{
            Then perform after ending MSL and Gateway tests
          }
    # Handle the errors.
    UiHelpers.throw(errorsInExecution, true, true, true, true)
  end
end

Then /^perform after ending MSL and Gateway tests$/ do
  steps %Q{
    Then set default deals columns
   }
end

Then /^set ers to DB from CSV file "([\w\.]+)" for date "([^\"]+)"$/ do |filename, datePeriod|
  filename = filename.to_s.gsub(/.*\//, "")
  datePeriod = datePeriod.to_s
  log "Setting ers to DB from CSV (filename: #{filename}, datePeriod: #{datePeriod})"
  data = $ui.getUsersDataDB("TID,INSTITUION_KEY, INSTITUITION")
  dataValuesArr = data[0].values
  currentUserID = dataValuesArr[0].to_s
  currentInstitutionKey = dataValuesArr[1].to_s
  currentInstitution = dataValuesArr[2].to_s
  floor = $uiDefaults["defaultValues"]["floor"]
  if (currentUserID.nil? || currentUserID.empty?)
    UiHelpers.throw "No user id found"
  end
  if (currentInstitutionKey.nil? || currentInstitutionKey.empty?)
    UiHelpers.throw "No institution key found"
  end
  if (currentInstitution.nil? || currentInstitution.empty?)
    UiHelpers.throw "No institution found"
  end
  if (floor.nil? || floor.empty?)
    UiHelpers.throw "No floor found"
  end
  doubleFloor = "#{floor}#{floor}"
  floorKey = $ui.getFloorKeyFromDB(floor).to_s
  if (floorKey.nil? || floorKey.empty?)
    UiHelpers.throw "No floor key found"
  end

  $userID = currentUserID
  $institutionKey = currentInstitutionKey
  $institution = currentInstitution

  db_table = @@CONFIG['PTRADE_SCHEMA'].to_s.upcase + '.FX_TICKET_LEG'
  path = Dir.getwd+"/features/support/#{filename}"
  defaultValue = "SG1"
  $allErs = CSV.read(path)
  if ($allErs.nil? || $allErs.empty?)
    UiHelpers.throw "Error: cannot read csv file"
  end
  columns = "(#{$allErs[0].join(',')})"
  log "Removing all ers from DB"
  sql = 'DELETE FROM ' + db_table
  insertToSapphireCustomDb(sql, CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SCHEMA'])
  todayDate = Date.today()
  log "TodayDate = #{todayDate.to_s}"
  @shouldAddTimeLowerThanDefaultToDate = false
  if (datePeriod =~ /^[^0-9]+$/)
    datePeriodFromUI = $deals.getDatesPeriodFromUI(datePeriod)
    dateToSet = Date.parse(datePeriodFromUI['from'])
  else
    dateToSet = Date.parse(datePeriod)
  end

  if (dateToSet == todayDate)
    @shouldAddTimeLowerThanDefaultToDate = true
  end

  if (@shouldAddTimeLowerThanDefaultToDate == false) # Special case, for filters in Reports page.
    timeToSet = Time.parse(dateToSet.to_s + " 22:00:01 UTC")
  else # default case.
    timeToSet = Time.parse(dateToSet.to_s + " 20:00:00 UTC")
  end
  dateToSet = timeToSet.to_i.to_s  + "000" #Set specific time to dates of deals (instead of 00:00:00).
  log "datePeriod = #{datePeriod}, dateToSet = #{dateToSet}"

  indexesOfDateToReplace = []
  for headerTitle in [ "TXN_TIME", "DATE_SETTLEMENT", "TRADE_DATE", "SPOT_SETTL_DATE", "END_DATE"]
    curIndex = $allErs[0].index(headerTitle)
    indexesOfDateToReplace.push(curIndex)
  end
  indexesOfFloorToReplace = []
  for headerTitle in [ "FP_FLOOR", "EFP_ACCOUNT", "EFP_FLOOR" ]
    curIndex = $allErs[0].index(headerTitle)
    indexesOfFloorToReplace.push(curIndex)
  end
  indexesOfDoubleFloorToReplace = []
  for headerTitle in [ "FP_BIC", "EFP_BIC" ]
    curIndex = $allErs[0].index(headerTitle)
    indexesOfDoubleFloorToReplace.push(curIndex)
  end
  indexesOfFloorKeyToReplace = []
  for headerTitle in ["FP_FLOOR_KEY", "EFP_FLOOR_KEY"]
    curIndex = $allErs[0].index(headerTitle)
    indexesOfFloorKeyToReplace.push(curIndex)
  end
  indexesOfInstittutionKeyToReplace = []
  for headerTitle in ["FP_INSTITUTION_KEY", "EFP_INSTITUTION_KEY", "ENP_INSTITUTION_KEY"]
    curIndex = $allErs[0].index(headerTitle)
    indexesOfInstittutionKeyToReplace.push(curIndex)
  end
  indexesOfInstitutionToReplace = []
  for headerTitle in ["FP_INSTITUTION", "EFP_INSTITUTION", "ENP_INSTITUTION", ]
    curIndex = $allErs[0].index(headerTitle)
    indexesOfInstitutionToReplace.push(curIndex)
  end

  defaultValue = " '#{defaultValue}'" # bug fix
  currentUserID = " '#{currentUserID}'"
  floor = "'#{floor}'"
  doubleFloor = "'#{doubleFloor}'"
  currentInstitution = "'#{currentInstitution}'"
  for i in 1 .. ($allErs.length - 1)
    lineArr = $allErs[i]
    replaceIndex = lineArr.index(defaultValue)
    if (replaceIndex != nil)
      lineArr[replaceIndex] = currentUserID
    end

    # Prevent bugs in reports, by setting all deals' date to today.
    indexesOfDateToReplace.each do |indexToReplace|
      lineArr[indexToReplace] = dateToSet
    end
    indexesOfFloorToReplace.each do |indexToReplace|
      lineArr[indexToReplace] = floor
    end
    indexesOfDoubleFloorToReplace.each do |indexToReplace|
      lineArr[indexToReplace] = doubleFloor
    end
    indexesOfFloorKeyToReplace.each do |indexToReplace|
      lineArr[indexToReplace] = floorKey
    end
    indexesOfInstittutionKeyToReplace.each do |indexToReplace|
      lineArr[indexToReplace] = currentInstitutionKey
    end
    indexesOfInstitutionToReplace.each do |indexToReplace|
      lineArr[indexToReplace] = currentInstitution
    end

    values = "VALUES (" + lineArr.join(',') + ")"
    sql = "INSERT INTO #{db_table} #{columns} #{values}"
    log sql
    insertToSapphireCustomDb(sql, CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SCHEMA'])
  end

  sqlVerify = "SELECT ID FROM #{db_table}"
  res = Actions.getDbQueryResults(CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SCHEMA'],sqlVerify)
  if (res == nil)
    res = []
  end
  resLength = res.length
  log "Finished updating DB\n" +
          "(AMOUNT IN DB: #{resLength.to_s}, DATA: #{res.to_s})"
end

Then /^verify that filters in Reports page work correctly$/ do
  csvFilename = "ers.csv"
  today = Date.today()
  filtersShouldNotShow = {
      Globals.datePeriod3Month => [Globals.datePeriodToday],
      Globals.datePeriod1Month => [Globals.datePeriodToday],
      Globals.datePeriodFirstDayOfMonthToToday => [],
      Globals.datePeriod1Week => [Globals.datePeriodToday],
      Globals.datePeriodYesterday => [Globals.datePeriodToday],
      Globals.datePeriodToday => [Globals.datePeriodYesterday]
      #Globals.datePeriodFirstDayOfWeekToToday => [] # Since there is a know bug.
  }

  errorsExpectedDealsNotToBeFound = ""
  for datePeriod in filtersShouldNotShow.keys
    datePeriodFromUI = $deals.getDatesPeriodFromUI(datePeriod)
    log "First: verifying that filter #{datePeriod} SHOWS all ers with date #{datePeriodFromUI['from']}"
     steps %Q{
	     Then set ers to DB from CSV file "#{csvFilename}" for date "#{datePeriodFromUI['from']}"
       Then logout and login via UI
     }
    $ui.redirectTo(Globals.pageReports)
    beforeFilteringDealsFromUI = getDealsFromUI()
    if ((beforeFilteringDealsFromUI == nil) || (beforeFilteringDealsFromUI.length == 0))
      UiHelpers.throw("No deals found (period: #{datePeriod})")
    end

    $deals.filterDealsByDate(datePeriod)
    afterFilteringDealsFromUI = getDealsFromUI()
    errors = minusIntersection(afterFilteringDealsFromUI, beforeFilteringDealsFromUI,
                               "After filtering by #{datePeriod}", "Before filtering by #{datePeriod}")
    if (errors != "")
      UiHelpers.throw errors
    end
    log "Done"
    log "Second: verifying that filters which should not return ers, don't return ers."
    arrFiltersShouldNotShow = filtersShouldNotShow[datePeriod]
    arrFiltersShouldNotShow.each do |currentFilterDatePeriod|
      $deals.filterDealsByDate(currentFilterDatePeriod)
      arrOfDealsShouldBeEmpty = getDealsFromUI(false)
      if ((arrOfDealsShouldBeEmpty != nil) && (arrOfDealsShouldBeEmpty.length > 0))
        errorsExpectedDealsNotToBeFound +=  "Deals found (expected: not to be found, " +
                                            "date: #{datePeriodFromUI['from']}, filter: #{currentFilterDatePeriod})\n"
      end
    end
  end

  if (errorsExpectedDealsNotToBeFound != "")
    UiHelpers.throw errorsExpectedDealsNotToBeFound
  end
end

When /^login username is set to "([^"]+)"$/  do |username|
  $defaultUsername = @@CONFIG[Globals.configLoginUsername]
  @@CONFIG[Globals.configLoginUsername] = username.to_s
end

When /^login username is rolled back to default username$/ do
  username = $defaultUsername rescue nil
  if ((! username.nil?) && (! username.empty?)) then @@CONFIG[Globals.configLoginUsername] = username; end
end

When /^user logs in via UI$/  do
  ### 1st attempt to login
  begin
    $ui = UiHelpers.new(Capybara.page, Capybara.current_driver)
    Capybara.app_host = @@CONFIG[Globals.configLoginURL]
    username = @@CONFIG[Globals.configLoginUsername]

    $ui.signInToSapphire(username,'',Capybara.app_host)
    UiHelpers.setHowToHandleFailure()
    UiHelpers.verifyThereAreNoErrorsAfterLogin()
    log 'User is logged in'

  ### 1st restart and 2nd attempt to login
  rescue
    message = 'First failure at login'
    log message

    if (ENV['WITHOUT_DEPLOYMENT_AND_STOP'].to_s.downcase != 'true')
      Actions.v 'Restarting Sapphire and trying to log in again'

      # Given pre-install operations
      stopSapphireApp(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
      moveSapphireLogs(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])

      Actions.v 'Closing Capybara page driver'
      Capybara.page.driver.quit

      # Given the App is deployed and started
      sap_version = Actions.displaySapphireAppOnlyVersion2(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
      if (!sap_version.nil? && !sap_version.empty?)
        fail('Sapphire installation not found') if sap_version.to_s.downcase.include?('not_set')
        steps %Q{
          Then Sapphire App is launched
        }
      else
        fail('Sapphire installation not found')
      end

      begin
        $ui = UiHelpers.new(Capybara.page, Capybara.current_driver)
        Capybara.app_host = @@CONFIG[Globals.configLoginURL]
        username = @@CONFIG[Globals.configLoginUsername]

        $ui.signInToSapphire(username, '', Capybara.app_host)
        UiHelpers.setHowToHandleFailure()
        log 'User is logged in'
        #Capybara.page.execute_script('document.body.style.zoom = "65%"')
      ### 2nd restart and 3rd attempt to login
      rescue
        message = 'Second failure at login'
        log message
        Actions.v 'Restarting Sapphire and trying to log in again'

        # Given pre-install operations
        stopSapphireApp(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
        moveSapphireLogs(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])

        Actions.v 'Closing Capybara page driver'
        Capybara.page.driver.quit

        # Given the App is deployed and started
        sap_version = Actions.displaySapphireAppOnlyVersion2(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
        if (!sap_version.nil? && !sap_version.empty?)
          fail('Sapphire installation not found') if sap_version.to_s.downcase.include?('not_set')
          steps %Q{
            Then Sapphire App is launched
          }
        else
          fail('Sapphire installation not found')
        end

        begin
          $ui = UiHelpers.new(Capybara.page, Capybara.current_driver)
          Capybara.app_host = @@CONFIG[Globals.configLoginURL]
          username = @@CONFIG[Globals.configLoginUsername]

          $ui.signInToSapphire(username, '', Capybara.app_host)
          UiHelpers.setHowToHandleFailure()
          log 'User is logged in'
          #Capybara.page.execute_script('document.body.style.zoom = "65%"')
        rescue Exception=>e
          message = 'Failed to login to Sapphire, check that you can login manually'
          UiHelpers.throw(message, true, true, true, true)
        end
      end
    else
      Actions.v 'WITHOUT_DEPLOYMENT_AND_STOP: not trying to restart Sapphire and relogin'
      handleError('Failed to login to Sapphire, check that you can login manually', 'Failure: at login')
    end
  end
end

Then /^logout and login via UI$/ do
  $ui.logoutFromSapphire()
  $ui.signInToSapphire(@@CONFIG['SapphireUiUser'],'',@@CONFIG['SapphireLoginUrl'])
end

Then /^init sapphire settings$/ do
  ignoreIfNotFound = true
  defaultSettings = $uiDefaults["allowed"]["settings"]
  $ui.setSettings(defaultSettings, ignoreIfNotFound)
  $ui.redirectTo(Globals.pageTrade,Globals.tabSwaps)
  $panel = Panel.new($ui, Globals.newPanelTypeNumber, 1)
end

Then /^verify deals from DB exist in UI$/ do
  dealsFromDB = []
  if ($allErs == nil)
    UiHelpers.throw "This step requires $allErs to be declared"
  end

  if ($deals == nil)
    UiHelpers.throw "This step requires $deals to be declared"
  end

  index = $allErs[0].index("ID")
  for i in 1..($allErs.length - 1)
    curEr = $allErs[i]
    curDealID = curEr[index].dup.gsub(/'/,"")
    dealsFromDB.push(curDealID)
  end

  $ui.redirectTo(Globals.pageTrade)
  dealsFromUI = getDealsFromUI()
  if ((dealsFromUI == nil) || (dealsFromUI.length == 0))
    UiHelpers.throw("Error: could not get deals from UI", true, true, true, true)
  end

  errors = minusIntersection(dealsFromDB, dealsFromUI, "DB", "UI")
  if ((errors != nil)  &&  (errors != ""))
    UiHelpers.throw errors
  end
end

Then /^verify that deals in UI exist in downloaded CSV file$/ do
  maxSecondsToSleep = 3
  csvPath = $downloadLocation.to_s.gsub(/\\/, "/") + "/*.csv"
  filename = ""
  Dir.glob(csvPath).each do |filenameToDelete|
    File.delete(filenameToDelete)
  end
  eNameDownloadBtn = "btn_deals_download"
  btn = Controls.firstElement(eNameDownloadBtn, $ui.getBaseElement())
  $ui.clickOnWebElement(btn)
  for i in 1 .. maxSecondsToSleep do
    arrFilenames = Dir.glob(csvPath)
    if (arrFilenames.length > 0)
      filename = Dir.glob(csvPath)[0]
      break
    end
  end
  if ((filename == nil) || (filename == ""))
    UiHelpers.throw "CSV file was not downloaded"
  end

  dealsFromCSV = []
  lines = IO.readlines(filename)
  if ((lines == nil) || (lines.length == 0))
    UiHelpers.throw "Cannot read CSV file (#{filename})"
  end
  indexTicketID = lines[0].gsub(/"/,"").split(",").index("TICKET_ID")
  for i in 1..(lines.length - 1)
    curID = lines[i].gsub(/"/,"").split(",")[indexTicketID]
    dealsFromCSV.push(curID)
  end

  dealsFromUI = getDealsFromUI()

  errors = minusIntersection(dealsFromCSV, dealsFromUI, "CSV", "UI")
  if (errors != "")
    UiHelpers.throw errors
  end
end

Then /^set default deals columns$/ do
  defaultDeals = $uiDefaults["allowed"]["columns"]["dealsHeader"]
  $ui.redirectTo(Globals.pageTrade)
  $deals = Deals.new($ui, 1)
  $deals.setColumns(defaultDeals)
end

Then /^set deals columns for MSL tests$/ do
  defaultDeals = $uiDefaults["allowed"]["columns"]["dealsHeaderForMslTests"]
  $ui.redirectTo(Globals.pageTrade)
  $deals = Deals.new($ui, 1)
  $deals.setColumns(defaultDeals)
end

Then /^verify that panels can be added and removed$/ do
  baseCCY = $uiDefaults["defaultValues"]["ccy"]
  createdPanel = $panel.setNewPanel(baseCCY)
  sleep 3
  createdPanel.removePanel()
end

Then /^verify that tabs can be added and removed$/ do
  tabName = "ebsTest"
  $ui.setNewTab(Globals.pageTrade, tabName)
  $ui.removeExistingTab(tabName)
end


Then /^assert Trading Date in a given month is coloured appropriately, clickable and appears after selection$/ do
=begin
  query = "select NODE_NAME from NODES_BIN t where institution =(select INSTITUITION from v_asd_users where email='"+@@CONFIG['SapphireUiUser'].to_s+"')"
  res =Actions.getDbQueryForSapphire(CONFIG.get['SDATA_SCHEMA'],query)
  floors = res.each.collect{|floor| floor["NODE_NAME"]}
=end
  floors = [$uiDefaults["defaultValues"]["floor"]]
  begin
    for floor in floors do
      $panel.setFloor(floor)
      defaultCCY = $uiDefaults["defaultValues"]["ccy"]
      setDatePickerForAllDates(Globals.typeTradingDates, Globals.typeCurrent, false, defaultCCY)
    end
  rescue => e
    errorMessage = e.message
    if (errorMessage.to_s.downcase =~ /no\s*dates/)
      today = Date.today
      if ((today.wday >= 4) &&               # Thu, Fri ...
          (today.month < (today + 4).month)) # 28, 29, 30 ...
        errorMessage = ""
      end
    end

    if (errorMessage != "")
      handleError(errorMessage,  "Failure: at Datepicker, current month - clickable dates")
    end
  end
end

Then /^assert WeekEnd Date in a given month is coloured appropriately, clickable and DOESN'T appear after selection$/ do
  begin
    log "In this test we should not succeed because we try to set weekend date"

#TODO return floor with Max(tenors)
=begin
    query = "select NODE_NAME from NODES_BIN t where institution =(select INSTITUITION from v_asd_users where email='"+@@CONFIG['SapphireUiUser'].to_s+"')"
    res =Actions.getDbQueryForSapphire(CONFIG.get['SDATA_SCHEMA'],query)
    floors = res.each.collect{|floor| floor["NODE_NAME"]}
=end
    floors = [$uiDefaults["defaultValues"]["floor"]]
    for floor in floors do
      $panel.setFloor(floor)
      defaultCCY = $uiDefaults["defaultValues"]["ccy"]
      shouldFailIfNotSet = true
      filterWeekend = Globals.filterWeekend
      setDatePickerForAllDates(Globals.typeNonTradingDates,Globals.typeCurrent, shouldFailIfNotSet,
                               defaultCCY, nil, filterWeekend)
    end
  rescue => e
    handleError(e.message, "Failure: at Datepicker, next month non-clickable dates")
  end
end

Then(/^assert NON\-TRADING or DayOff Date except WeekEnd for a next months is coloured appropriately, clickable and DOESN'T appear after selection$/) do
  begin
    log "In this test we should not succeed because we try to set non trading dates"

=begin
    query = "select NODE_NAME from NODES_BIN t where institution =(select INSTITUITION from v_asd_users where email='"+@@CONFIG['SapphireUiUser'].to_s+"')"
    res =Actions.getDbQueryForSapphire(CONFIG.get['SDATA_SCHEMA'],query)
    floors = res.each.collect{|floor| floor["NODE_NAME"]}
=end
    floors = [$uiDefaults["defaultValues"]["floor"]]
    for floor in floors do
      if ($uiDefaults["floorsToExclude"].include?(floor))
        next
      end

      $panel.setFloor(floor)
      defaultCCY = $uiDefaults["defaultValues"]["ccy"]
      shouldFailIfDateNotSet = true
      weekendFilter = "-#{Globals.filterWeekend}"
      setDatePickerForAllDates(Globals.typeNonTradingDates, Globals.typeCurrent,
                               shouldFailIfDateNotSet, defaultCCY, nil, weekendFilter)
    end
  rescue => e
    handleError(e.message, "Failure: at Datepicker, next month non-clickable dates Weekends")
  end
end

Then(/^assert Trading Date for next months is coloured appropriately, clickable and appears after selection$/) do
  begin
=begin
    query = "select NODE_NAME from NODES_BIN t where institution =(select INSTITUITION from v_asd_users where email='"+@@CONFIG['SapphireUiUser'].to_s+"')"
    res =Actions.getDbQueryForSapphire(CONFIG.get['SDATA_SCHEMA'],query)
    floors = res.each.collect{|floor| floor["NODE_NAME"]}
=end
    floors = [$uiDefaults["defaultValues"]["floor"]]
    for floor in floors do
      if ($uiDefaults["floorsToExclude"].include?(floor))
        next
      end
      $panel.setFloor(floor)
      today = Date.today
      defaultCCY = $uiDefaults["defaultValues"]["ccy"]
      nonTradingDatesType = ''
      shouldFailIfDateNotSet = false
      #firstTradingDate = $panel.getClosestTradingDate("#{today.day}/#{today.month}/#{today.year}")
      setDatePickerForAllDates(Globals.typeTradingDates, nonTradingDatesType,
                               shouldFailIfDateNotSet, defaultCCY)
      #setDatePickerForNextMonths('trading_dates', today.month, today.year, $uiDefaults["defaultValues"]["ccy"], false)
    end
  rescue => e
    handleError(e.message, "Failure: at Datepicker, next month - clickable dates")
  end
end

Then /^verify that the system is locked$/ do
  begin
    $ui.verifySystemIsLockedOrUnlocked(Globals.systemIsLocked)
  rescue => e
    handleError(e.message, "Failure: at verify that the system is locked")
  end
end

Then /^verify that the system is unlocked$/ do
  begin
    $ui.verifySystemIsLockedOrUnlocked(Globals.systemIsUnlocked)
  rescue => e
    handleError(e.message, "Failure: at verify that the system is unlocked")
  end
end

Then /^verify that all header's elements exist$/ do
  begin
    verifyElements(Globals.headerElement, nil, /logout/)
  rescue => e
    handleError(e.message, "Failure: at verify that all header's elements exist")
  end
end

Then /^verify that all buttons in header are clickable$/ do
  begin
    $ui.verifySystemIsLockedOrUnlocked(Globals.systemIsUnlocked)
    verifyElements(Globals.headerElement, /Btn/, /lock|logout/, Globals.verifyClickable)
  rescue => e
    handleError(e.message, "Failure: at verify that all buttons in header are clickable")
  end
end

Then /^verify that all buttons in trade are clickable$/ do
  begin
    $ui.verifySystemIsLockedOrUnlocked(Globals.systemIsUnlocked)
    $ui.redirectTo(Globals.pageTrade)
    verifyElements(Globals.pageTrade, /Btn/, nil, Globals.verifyClickable)
  rescue => e
    handleError(e.message, "Failure: at verify that all butons in trade are clickable")
  end
end

Then /^verify that all elements in reports exist$/ do
  begin
    $ui.verifySystemIsLockedOrUnlocked(Globals.systemIsUnlocked)
    $ui.redirectTo(Globals.pageReports)
    verifyElements(Globals.pageReports, nil, nil, Globals.verifyExists)
  rescue => e
    handleError(e.message, "Failure: at verify that all elements in reports exist")
  end
end

Then /^verify that all buttons in reports are clickable$/ do
  begin
    $ui.verifySystemIsLockedOrUnlocked(Globals.systemIsUnlocked)
    $ui.redirectTo(Globals.pageReports)
    verifyElements(Globals.pageReports, /Btn/, nil,  Globals.verifyClickable)
  rescue => e
    handleError(e.message, "Failure: at verify that all buttons in reports are clickable")
  end
end

Then /^verify that all buttons in settings are clickable$/ do
  begin
    $ui.verifySystemIsLockedOrUnlocked(Globals.systemIsUnlocked)
    allSettings = $uiDefaults["allowed"]["settings"]
    testingSettings = {}
    for type in allSettings.keys do
      if (! testingSettings.has_key?(type))
        testingSettings[type] = {}
      end

      for name in allSettings[type].keys do
        if (! testingSettings[type].has_key?(name))
          testingSettings[type][name] = {}
        end

        value = allSettings[type][name]
        if (value == Globals.settingsOn)
          value = Globals.settingsOff
        else
          value = Globals.settingsOn
        end
        testingSettings[type][name] = value
      end
    end

    $ui.setSettings(testingSettings)
  rescue => e
    handleError(e.message, "Failure: at verify that all buttons in settings are clickable")

  ensure
    log "Settings are rolled back to default after checking setting's buttons"
    $ui.setSettings($uiDefaults["allowed"]["settings"])
  end

end

Then /^verify that all Deal's elements exist$/ do
  begin
    $ui.verifySystemIsLockedOrUnlocked(Globals.systemIsUnlocked)
    $ui.redirectTo(Globals.pageTrade)
    verifyElements(Globals.dealsElement)
  rescue => e
    handleError(e.message, "Failure: at verify that all Deal's elements exist")
  end
end

Then /^verify that all Orders's elements exist$/ do
  begin
    $ui.verifySystemIsLockedOrUnlocked(Globals.systemIsUnlocked)
    $ui.redirectTo(Globals.pageTrade)
    verifyElements(Globals.ordersElement)
  rescue => e
    handleError(e.message, "Failure: at verify that all Order's elements exist")
  end
end

Then /^verify that tabs Swap, Outright\/Swp, Spot, Outrights exist$/ do
  begin
    log "Started verifing that all required tabs exist (Swap ...)"
    all = $ui.allElementsWithCss(Globals.pageTrade, Globals.tabElement)
    isfound = { Globals.tabSwaps => false,
                Globals.tabOutrightSwp => false,
                Globals.tabSpot => false,
                Globals.tabOutrights => false }

    all.each do |e|
      name = $ui.getValueOrTextOrInnerHTML(e)
      name = name.to_s.downcase
      log "Verifing #{name}"
      for k in isfound.keys
        if (name.include?(k.to_s.downcase))
          log "Found in tabs"
          isfound[k] = true
        end
      end
    end

    passed = isfound[Globals.tabSwaps] && isfound[Globals.tabOutrightSwp] &&
              isfound[Globals.tabSpot] && isfound[Globals.tabOutrights]
    if (! passed)
      UiHelpers.throw "Test failed: one or more of tabs was not found"
    else
      log "All required tabs were found"
    end
  rescue => e
    handleError(e.message, "Failure: at verify that tabs exist")
  end
end

Then /^verify that there are at least 4 active panels$/ do
  begin
    $ui.redirectTo(Globals.pageTrade, Globals.tabSwaps)
    minNumOfTabs = 4
    isTestPassed = false
    arr = $panel.getAllPanels()
    if ((arr != nil) && (arr.length >= minNumOfTabs))
      isTestPassed = true
    end

    if (! isTestPassed)
      UiHelpers.throw "Test failed"
    end
  rescue => e
    handleError(e.message, "Failure: at verify that there are at least 4 active panels")
  end
end

Then /^verify that active panels can be resized to large view$/ do
  eNameBtnChangeView = "btn_panel_viewWithType"
  viewType = Globals.panelViewLarge
  $ui.redirectTo(Globals.pageTrade, Globals.tabSwaps)
  allViewsBtns = Controls.allElements(eNameBtnChangeView, $ui.getBaseElement(), viewType)
  allViewsBtns.each do |btn|
    $ui.clickOnWebElement(btn)
  end
end

Then /^verify that all required buttons in active panel number 1 are clickable$/ do
  begin
    log "First check non Rfq buttons"
    verifyElements(Globals.panelElement,/Btn$/,/(view|tenor|Rfq|floor|pricesLP)/i,Globals.verifyClickable,1)
    log "Now initiate required steps before testing Rfq buttons"

    ccy = $uiDefaults["defaultValues"]["ccy"]
    for lp in $uiDefaults["lpsWithDatepicker"].keys do
      type = $uiDefaults["lpsWithDatepicker"][lp]
      log "Checking #{ccy}, #{lp}"
      $panel.setCurrencyPair(ccy)
      $panel.setProductType(lp)
      verifyElements(Globals.panelElement,/RfqBtn$/,/(floor|pricesLP)/i,Globals.verifyClickable,1)
    end
  rescue => e
    handleError(e.message, "Failure: at verify that buttons in panel 1 are clickable")
  end
end

Then /^verify that active panel number 1 contains all required current labels$/ do
  begin
    verifyElements(Globals.panelElement,nil,/(Btn|^panel$|prices|Menu$|floor|pricesLP)/i,'',1)
  rescue => e
    handleError(e.message, "Failure: at verify that panel 1 contains labels")
  end
end

Then /^verify that all menus in active panel number 1 are clickable$/ do
  begin
    verifyElements(Globals.panelElement,/(Menu)/,/(floor|pricesLP)/i,Globals.verifyClickableMenu,1)
  rescue => e
    handleError(e.message, "Failure: at verify that all menus in panel 1 are clickable")
  end
end

Then /^verify in active panel 1 that all tenors exist$/ do
  begin
    log "In this test we only test that tenors are legal and exist," +
            " not specific tenors for specific ccy"
    errors = ""
    ccy = $uiDefaults["defaultValues"]["ccy"]
    lp  = $uiDefaults["defaultValues"]["lp"]
    $panel.setCurrencyPair(ccy)
    $panel.setProductType(lp)
    floors = getFloorsForUI()
    tenors = getTenorsByMinAndMaxTenors("menu")
    log "Found list of #{tenors.length.to_s} tenors"
    for floor in floors do
      $panel.setFloor(floor)
      panel = $panel.getActivePanelElement()
      log "Getting tenors from UI"
      tenorsValues = $panel.getPanelDDValues2(Globals.panelDDTenor)
      tenorsValues.each do |val|
        if (val != nil)
          val = $ui.trimString(val)
          log "Checking that #{val} exist in tenors"
          if (! tenors.include?(val))
            error = "#{val} was not found is tenors list"
            log error
            errors += error
          else
            log "Found"
          end
        end
      end
    end
    if (errors != "")
      UiHelpers.throw errors
    else
      log "All tenors from UI were found in tenors list"
    end
  rescue => e
    handleError(e.message, "Failure: at verify that all tenors exist at panel 1")
  end
end

Then /^verify in active panel 1 in datepicker that all tenors exist$/ do
  begin
    ccy = $uiDefaults["defaultValues"]["ccy"]
    lp = $uiDefaults["defaultValues"]["lp"]
    mainElement = "datepicker"
    $ui.redirectTo(Globals.pageTrade, Globals.tabSwaps)
    errors = ""
    $panel.setCurrencyPair(ccy)
    $panel.setProductType(lp)
    floors = getFloorsForUI()
    tenors = getTenorsByMinAndMaxTenors(mainElement)
    for floor in floors do
      $panel.setFloor(floor)
      panel = $panel.getActivePanelElement()
      $panel.openDatePickerWindow()
      for section in [Globals.panelNearLeg, Globals.panelFarLeg] do
        $ui.clickOnCss(mainElement, "#{section}Btn", 2)
        valsArr = []
        elements = $ui.allElementsWithCss(mainElement,'tenorBtns',panel, Globals.panelNearLeg)
        elements.each do |e|
          val = $ui.getValueOrTextOrInnerHTML(e)
          if (val != nil)
            val = $ui.trimString(val)
            log "Checking that #{val} exist in tenors"
            if (! tenors.include?(val))
              error = "#{val} was not found is tenors list"
              log error
              errors += error
            else
              log "Found"
            end
          end
        end
      end
      $panel.verifyDatepickerIsClosed()
    end

    if (errors != "")
      UiHelpers.throw errors
    end
  rescue => e
    handleError(e.message, "Failure: at verify that panel 1 contains all tenors in datepicker")
  end
end

Then /^verify maximum panels can be created on maximum tabs$/ do
  changeResolutionToGetMaximumPanels()
  createMaximumTabsAvailable("trade")
  base = $ui.getBaseElement()
  allTabs = $ui.getAllTabs()
  # This for is used instead of allTabs.each ,
  # since allTabs is initiated after logout/login in createMaxPanelsInTab.
  for i in 0..(allTabs.length - 1) do
    e = allTabs[i]
    tabName = $ui.getValueOrTextOrInnerHTML(e)
    tabName = $ui.trimString(tabName)
    log "Creating max panels for tab: #{tabName}"
    createMaxPanelsInTab(tabName, Globals.pageTrade)
    log "Done, getting allTabs again, since we performed logout and login"
    allTabs = $ui.getAllTabs()
  end
end

Then /^verify panels with no entitlements are found and treated$/ do
  allTabs = $ui.getAllTabs()
  allTabs.each do |t|
    tName = $ui.getValueOrTextOrInnerHTML(t)
    tName = $ui.trimString(tName)
    $ui.redirectTo(Globals.pageTrade, tName)
    log "In page: trade tab: #{tName}"
    allNotEntitledPanels = Panel.getAllNotEntitledPanels()
    for notEntitledPanelNumber in allNotEntitledPanels.keys do
      reason = allNotEntitledPanels[notEntitledPanelNumber][Globals.notEntitledPanelsMessage]
      message = "panel is NOT ENTITLED (panel number: #{notEntitledPanelNumber.to_s}, reason: #{reason})"
      log message
    end
    log "All other panels are entitled in tab #{tName}"
  end

  log "Done"
end

Then /^test get quotes in all available scenarios$/ do
  begin
    defaultCCY = $uiDefaults["defaultValues"]["ccy"]
    defaultLP = $uiDefaults["defaultValues"]["lp"]

    $ui.redirectTo(Globals.pageTrade, Globals.tabSwaps)
    puts "First testing for empty panels"
    curLP = Globals.panelLpSP
    for calcType in [Globals.panelCalcTypeFull, Globals.panelCalcTypeVWAP, Globals.panelCalcTypeLMT] do
      arr = $panel.getQuotes(defaultCCY, calcType, curLP)
    end
    curCalc = Globals.panelCalcTypeIND
    for lp in [ Globals.panelLpOT, defaultLP ] do
      arr = $panel.getQuotes(defaultCCY, curCalc, lp)
    end

    puts "Not we should flow prices to all panels"
    curLP = Globals.panelLpSP
    for calcType in [Globals.panelCalcTypeFull, Globals.panelCalcTypeVWAP, Globals.panelCalcTypeLMT] do
      arr = $panel.getQuotes(defaultCCY, calcType, curLP)
    end
    curCalc = Globals.panelCalcTypeIND
    for lp in [ Globals.panelLpOT, defaultLP ] do
      arr = $panel.getQuotes(defaultCCY, curCalc, lp)
    end

    puts "Here I should manually change ladders to continute testing"
    curLP = Globals.panelLpSP
    for calcType in [Globals.panelCalcTypeFull, Globals.panelCalcTypeVWAP, Globals.panelCalcTypeLMT] do
      arr = $panel.getQuotes(defaultCCY, calcType, curLP)
    end

    puts "Done"
    #sanityTests()
  rescue => e
    handleError(e.message, "Failure: at testing all get quotes options")
  end
end

Then /^verify that max dates matches max tenors$/ do
  panelNumber = 1
  currencyPair = $uiDefaults["defaultValues"]["ccy"]
  UIfloors = getFloorsForUI()
  lpsWithDatePicker = $uiDefaults["lpsWithDatepicker"].keys
  for floor in UIfloors do # Get floors
    $panel.setFloor(floor)
    lps = getLPs(floor, currencyPair)
    for lp in lps do
      if (! lpsWithDatePicker.include? (lp))
        next
      end
      datepickerType = $uiDefaults["lpsWithDatepicker"][lp]
      if ((datepickerType.to_s.downcase.include?("old")) && ($uiDefaults["floorsToExclude"].include?(floor)))
        next
      end
      $panel.setCurrencyPair(currencyPair)
      $panel.setProductType(lp)
      log "Finished setting CurrencyPair: #{currencyPair}, LP: #{lp}, running on each floor"
      types = [Globals.panelNearLeg, Globals.panelFarLeg]
      if (datepickerType.to_s.downcase.include?(Globals.panelDatePickerTypeOld))
        types = [Globals.panelFarLeg]
      end

      for type in types do
        maxDateInUI = nil
        maxTenorFromUI = nil
        begin
          log "Verifying maxdate and max tenor (floor: #{floor}, type: #{type})"
          maxTenorFromUI = $panel.getMaxTenorFromUI()
          $panel.openDatePickerWindow(lp)
          if (datepickerType.to_s.downcase.include?(Globals.panelDatePickerTypeNew))
            $panel.datepickerClickOnTypeBtn(type)
          end

          log "Getting max date by tenor (tenor: #{maxTenorFromUI}, type: #{type})"
          maxDateInUI = $panel.getMaxDateByTenor(maxTenorFromUI, type, nil, lp)
        rescue => e
            log "Errors were found"
            moreInfoError = "#{e.message}"
            moreInfoError = moreInfoError.sub(/\)/, ", floor: #{floor}, lp: #{lp}, currency pair: #{currencyPair})")
            UiHelpers.throw moreInfoError
        ensure
          $panel.verifyDatepickerIsClosed(lp)
        end

        log "Before verification (maxDateInUI: #{maxDateInUI}, maxTenor: #{maxTenorFromUI})"
        verifyMaxDateMatchesTenor(maxDateInUI, maxTenorFromUI, type)
        log "Verification succeed"
      end
    end
  end
end

Then /^compare amount of tradable and non-tradable dates of UI to recieved from DB$/ do
  begin
    defaultLP = $uiDefaults["defaultValues"]["lp"]
    defailtCCY = $uiDefaults["defaultValues"]["ccy"]
    $panel.setProductType(defaultLP)
    tenorName = $panel.getMaxTenorFromUI()  #"3Mth"
    $panel.openDatePickerWindow()
    datesFromUi = $panel.datepickerGetUiAllTradingAndNonTradingDates(Globals.panelNearLeg, tenorName)
    today = Date.today()
    maxDate = $panel.getMaxDateByTenor(tenorName, Globals.panelNearLeg)
    errors = ""
    for monthYear in datesFromUi.keys do
      if (monthYear =~ /(\d+)\/(\d+)$/)
        month = $1.to_s
        year = $2.to_s

        dbElements = { $uiDefaults["defaultValues"]["trading"] => [] , $uiDefaults["defaultValues"]["nonTrading"] => []}
        dbDates    = { $uiDefaults["defaultValues"]["trading"] => [] , $uiDefaults["defaultValues"]["nonTrading"] => []}
        log "Filter dates from DB (#{$ui.dateStr(today)} - #{$ui.dateStr(maxDate)})"

        for tradeType in dbElements.keys do
          log "Getting dates for #{tradeType} from DB"
          dbElements[tradeType] = $arrDates[defailtCCY][tradeType][monthYear]
          dbElements[tradeType].each do |dateElement|
            date = dateElement['date']
            dateParsed = Date.parse(date)
            if ((dateParsed >= today) && (dateParsed <= maxDate))
              dbDates[tradeType].push(date)
            else
              log "DB's #{tradeType} date #{date} was filtered..."
            end
          end

          log "Calculating DB array MINUS INTERSECTION of both arrays"
          arrIntersection = intersectArrays(dbDates[tradeType], datesFromUi[monthYear][tradeType])
          dbMinusIntersection = dbDates[tradeType] - arrIntersection
          if (dbMinusIntersection.length > 0)
            log "Found dates which are not in intersection"
            dbMinusIntersection.each do |date|
              if (tradeType == $uiDefaults["defaultValues"]["trading"])
                errors += "date:#{date} was found tradeable in DB and wasn't tradeable in UI\n"
              else
                errors += "date:#{date} was found non-tradeable in DB and was tradeable in UI\n"
              end
            end
          end

          if ((errors != nil) && (errors != ""))
            $panel.verifyDatepickerIsClosed()
            UiHelpers.throw errors
          end
        end
      end
    end

    $panel.verifyDatepickerIsClosed()
  rescue Exception=>e
    handleError(e.message, "Failure: at comparing amounts of tradeable and non-tradeable")
  end
end

Then /^assert Trading tenors are coloured appropriately, clickable and appear as selected after selection$/ do
  errors = ""
  begin
    defaultFloor = $uiDefaults["defaultValues"]["floor"]
    defaultLP = $uiDefaults["defaultValues"]["lp"]
    panelNumber = 1
    $panel.setFloor(defaultFloor)
    ccys = getCcys(defaultFloor)
    ccysToTest = $uiDefaults["tenorsExpectedResults"].keys
    for currencyPair in ccys do
      if (! ccysToTest.include?(currencyPair))
        next
      end
      $panel.setCurrencyPair(currencyPair)
      $panel.setProductType(defaultLP)
      $uiDefaults["tenorsExpectedResults"][currencyPair].each do |tenorsTest|
        near = tenorsTest[Globals.panelNearLeg]
        far = tenorsTest[Globals.panelFarLeg]
        expectedRes = tenorsTest[Globals.panelExpectedRes]
        $ui.exceptionIfNil(near, far, expectedRes)
        $panel.setDatePicker(far, near)
        setDate = $panel.getDatesPairInPanel()
        if (expectedRes != setDate)
          error = "Error: in tenors expected result does not match actual result" +
                    " (expected: #{expectedRes}, actual: #{setDate}, near: #{near}, far: #{far})\n"
          log error
          errors += error
          next
        else
          log "Passed: in tenors expected result matches actual result" +
                  " (expected: #{expectedRes}, actual: #{setDate}, near: #{near}, far: #{far})\n"

        end
      end
    end

    if (errors != "")
      UiHelpers.throw "Errors were found (#{errors})"
    end
  rescue => e
    handleError(e.message, "Failure: at verify that trading tenors are tradable")
end
end

Then /^assert NON-TRADING tenors are coloured appropriatly, not clickable and not appear as selected after selection$/ do
  errors = ""
  begin
    floor = $uiDefaults["defaultValues"]["floor"]
    lp = $uiDefaults["defaultValues"]["lp"]
    panelNumber = 1
    $panel.setFloor(floor)
    $panel.setProductType(lp)
    for currencyPair in $uiDefaults["tenorsDisabledFaliureResults"].keys do
      $panel.setCurrencyPair(currencyPair)
      $uiDefaults["tenorsDisabledFaliureResults"][currencyPair].each do |tenorsTest|
        near = tenorsTest[Globals.panelNearLeg]
        far = tenorsTest[Globals.panelFarLeg]
        $ui.exceptionIfNil(near, far)
        beforeSetDate = $panel.getDatesPairInPanel()
        begin
          $panel.setDatePicker(far, near)
        rescue
          log "Passed: date not set, which is good in this scenario "
        end

        afterSetDate = $panel.getDatesPairInPanel()
        if (afterSetDate != beforeSetDate)
          error = "Error: date was set, expected to failure on setting (before: #{beforeSetDate} after: #{afterSetDate})"
          log error
          errors += error
          next
        end
      end
    end

    if (errors != "")
      UiHelpers.throw(errors)
    else
      log "Step passed"
    end

  rescue Exception=>e
    backtrace = e.backtrace.join("\n")
    if ((!backtrace.nil?) && (!backtrace.empty?))
      Actions.v "Backtrace: #{backtrace}"
    end
    handleError(e.message, "Failure: at verify that non-trading tenors are non-tradeable")
  end
end


Then /^create screenshot before scenario is finished$/ do
  UiHelpers.createAndShowScreenshot("Before scenario is finished")
end

Then /^create order as (\w+) on order form with price ([\d\.]+) and verify in created order that properties exist$/ do
|orderType, price|
  amountOfOrders = 1
  orderType = orderType.to_s
  price = price.to_s # Since price is 1.22345, handle it as string to get pip and bigFigure
  panelNumber = panelNumber.to_i
  $ordersToSetProperties = []
  for i in 1 .. amountOfOrders do
    log "Set order in Order Forms"
    $orderFormsPanel.openOrderForms(orderType)
    bigFigure = nil
    pip = nil
    if (price =~ /(\d+\.\d{2})(\d+)/)
      bigFigure = $1.to_s
      pip = $2.to_s
    end

    if ((bigFigure == nil) || (pip == nil))
      UiHelpers.throw "Price is illegal (#{price.to_s})"
    end

    $orderFormsPanel.
        setOrderformsPanelDDMenu2(Globals.panelOrderformsPrice, {Globals.panelPriceTypeBigFigure  => bigFigure,
                                                                 Globals.panelPriceTypePip        => pip })
    currentOrderToSetProperties = $orderFormsPanel.getOpenedOrderProperties()
    $orderFormsPanel.closeOrderForms(Globals.orderFormsSend)

    log "Get order created in orders panel"
    $order = OrderItem.new($ui, 1)
    all = $order.getAllOrders()
    all.each do |orderObject|
      propertiesOfOrdersToSet = []
      propertiesOfOrderItem = []
      OrderItemProperties = orderObject.getOrderProperties()  # $ordersToSetProperties = orders came from orderForms.
      log "Create the arrays of properties (from order to set and from created order)"
      for key in OrderItemProperties.keys do
        if (key == Globals.panelOrderformsIceberg)
          next
        end
        val = OrderItemProperties[key]
        if ((val != nil) && (val != ""))
          propertiesOfOrderItem.push("#{key.to_s}:#{val.to_s}")
        end

        valOrderToSet = currentOrderToSetProperties[key]
        if ((valOrderToSet != nil) && (valOrderToSet != ""))
          propertiesOfOrdersToSet.push("#{key.to_s}:#{valOrderToSet.to_s}")
        end

      end

      log "Clear order that we finished working on"
      orderObject.removeOrder()
      log "Compare the arrays of properties (order to set should samller)"
      errors = minusIntersection(propertiesOfOrderItem, propertiesOfOrdersToSet,
                                 "Order in orders", "Order forms", "arr2-arr1")

      if (errors != "")
        UiHelpers.throw errors
      end
      log "End of order properties"
    end
  end
end

Then /^verify there are no orders before starting tests$/ do
  $order = OrderItem.new($ui, 1)
  all = $order.getAllOrders()
  maxTries = all.length + 5 # maxTries prevents endless loops in case of errors.
  while ((all.length > 0) && (maxTries > 0))
    orderObject = all[0]
    orderObject.removeOrder(true, true, true)
    all = $order.getAllOrders() # To prevent bugs caused be closed manually/automatically orders.
    if (all.length > 0)
      maxTries -= 1
    end
  end

  if (maxTries <= 0)
    UiHelpers.throw "Endless loop, allways all.length > 0"
  end
end

Then /^init order forms in panel (\d+)$/ do |panelNumber|
  $orderFormsPanel = OrderFormsPanel.new($ui, Globals.newPanelTypeNumber, panelNumber.to_i)

end

Then /^init settings of panel (\d+)$/ do |panelNumber|
  $panelSettings = SettingsPanel.new($ui, Globals.newPanelTypeNumber, panelNumber.to_i)
  $panelSettings.open()
end

Then /^change properties and verify changes exist after logout and login$/ do
  beforeChangesProperties = $panelSettings.getProperties()
  $panelSettings.close()
  log "Before changes properties: #{beforeChangesProperties.to_s}"

  steps %Q{
    Then logout and login via UI
  }
  $panelSettings.open()
  afterChangesProperties = $panelSettings.getProperties()
  log "After changes properties: #{afterChangesProperties.to_s}"
end

Then /^change properties on order with type (\w+) and verify these properties were changed$/ do |orderType|
  orderType = orderType.to_s.downcase
  if ((orderType != Globals.panelTypeBid) && (orderType != Globals.panelTypeOffer))
    UiHelper.throw "Unhandled type: #{orderType}"
  end

  $orderFormsPanel.openOrderForms(orderType)
  log "Before changing it, verifying that values are default values"
  $orderFormsPanel.setDefaultValues()
  log "Change dynamic values (floor and calculator type won't be changed here)"
  propertiesBeforeChange = $orderFormsPanel.getOpenedOrderProperties()
  $orderFormsPanel.setOrderformsPanelDDMenu2(Globals.panelDDdealtAmount, Globals.dealtAmountStr5M)
  $orderFormsPanel.setOrderformsPanelDDMenu2(Globals.panelDDpdValue, "0.5")
  $orderFormsPanel.setOrderformsPanelDDMenu2(Globals.panelOrderformsCptys,
                                              {Globals.cptyLP33 => Globals.checkboxUnchecked})
  $orderFormsPanel.setOrderformsPanelDDMenu2(Globals.panelOrderformsTif, Globals.tifDAY)
  $orderFormsPanel.setOrderformsPanelDDMenu2(Globals.panelOrderformsPriceType, Globals.typeOffer)
  $orderFormsPanel.setOrderformsPanelDDMenu2(Globals.panelOrderformsCptys,
                                              {Globals.cptyLP33 => Globals.checkboxChecked})
  log "Change price"
  $orderFormsPanel.setOrderformsPanelDDMenu2(Globals.panelOrderformsPrice,
                                             {Globals.panelPriceTypeBigFigure => "1.45",
                                              Globals.panelPriceTypePip => "789"})
  propertiesAfterChange = $orderFormsPanel.getOpenedOrderProperties()
  log "properties summery:"
  summery = ""
  for key in [Globals.panelDDdealtAmount, Globals.panelDDpdValue, Globals.panelOrderformsCptys,
              Globals.panelOrderformsTif,Globals.panelOrderformsPriceType,Globals.panelOrderformsCptys] do
    if (propertiesBeforeChange[key] != propertiesAfterChange[key])
      summery += "#{key.to_s}  before: #{propertiesBeforeChange[key]} after: #{propertiesAfterChange[key]}\n"
    else
      UiHelpers.throw "#{key.to_s} was not changed (expected to be changed)"
    end
  end
  $orderFormsPanel.closeOrderForms()
  if (summery == "")
    UiHelpers.throw "There are no changes (expected to be)"
  end
end

Then /^create (\d+) orders as (\w+) and (\d+) orders as (\w+) with price ([\d\.]+) and click on (\w+) and (\w+)$/ do
  |firstAmountOfOrders, firstOrdersType, secondsAmountOfOrders, secondOrdersType, price, firstButton, secondButton|
    orders = { firstOrdersType.to_s =>  firstAmountOfOrders.to_i, secondOrdersType.to_s => secondsAmountOfOrders.to_i}
    price = price.to_s
    buttonsToClickAfterOrdersSent = [firstButton.to_s, secondButton.to_s]

    for orderType in orders.keys do
      amount = orders[orderType]
      for i in 1 .. amount do
        $orderFormsPanel.openOrderForms(orderType)
        if (price =~ /(\d+\.\d{2})(\d+)/)
          bigFigure = $1.to_s
          pip = $2.to_s
          $orderFormsPanel.
              setOrderformsPanelDDMenu2(Globals.panelOrderformsPrice, {Globals.panelPriceTypeBigFigure  => bigFigure,
                                                                       Globals.panelPriceTypePip        => pip })
        end
        $orderFormsPanel.closeOrderForms(Globals.orderFormsSend)
      end
    end

    baseElement = $ui.getBaseElement()
    for buttonName in buttonsToClickAfterOrdersSent do
      log "Clicking on button: #{buttonName}"
      elementName = "btn_orders_#{buttonName}"
      btn = Controls.firstElement(elementName, baseElement)
      $ui.clickOnWebElement(btn)
      sleep 3
    end

    allOrders = OrderItem.new($ui, 1).getAllOrders()
    if (allOrders != nil)
      amount = allOrders.length
      if (amount > 0)
        UiHelpers.throw "Found orders after clicking SUPER OFF ALL and CLEAR (expected: 0, found: #{amount})"
      end
    end
    log "After finished step"
end

Then /init deals and get deals to blotter/ do
  $deals = Deals.new($ui, 1)
  log "SHOULD IMPLEMENT: GETTING DEALS AUTOMATICALLY"
end

Then /verify that search works correctly for deals/ do
  id = "ticketId"
  $ui.redirectTo(Globals.pageTrade)
  arr = $deals.getAllDeals()
  arrLength = arr.length
  if (arrLength == 0)
    UiHelpers.throw "Deals are required to be shown in this step"
  end
  min = 0
  max = arr.length
  prng = Random.new()
  dealIndex = prng.rand(min...max)
  log "Getting deal in index: #{dealIndex}"
  deal = arr[dealIndex]
  dealProperties = deal.getProperties(true, true, true, true)
  dealTicketId = deal.getProperty(Globals.dealItemTicketId)
  log "Deal's ticket ID: #{dealTicketId}"
  errors = ""
  for key in dealProperties.keys do
    value = dealProperties[key].to_s
    log "Searching for deal using value: #{value}"
    $deals.findDeals(value, key)
    allDeals = $deals.getAllDeals()
    foundTicketId = false
    allDeals.each do |curDeal|
      curDealTicketId = curDeal.getProperty(Globals.dealItemTicketId)  #curDeal.getProperties()[id]
      if (curDealTicketId == dealTicketId)
        foundTicketId = true
        break;
      end
    end

    if (! foundTicketId)
      error = "Deal not found (ticket id: #{dealTicketId} not found in search with value: #{value})"
      log error
      errors += "#{error}\n"
    else
      log Globals.messagePassed
    end
  end

  log "After search, closing search bar"
  $deals.closeSearchBar()
  if (errors != "")
    UiHelpers.throw errors
  end
end

Then /^verify that search works correctly in Reports page$/ do
  searchDealsInReports()
end

Then /^verify that deals in Reports page match deals DB$/ do
  eNameClearSearch = "btn_reports_searchClear"
  dealsFromDB = []
  baseElement = $ui.getBaseElement()
  if ($allErs == nil)
    UiHelpers.throw "This step requires $allErs to be declared"
  end

  if ($deals == nil)
    UiHelpers.throw "This step requires $deals to be declared"
  end

  index = $allErs[0].index("ID")
  for i in 1..($allErs.length - 1)
    curEr = $allErs[i]
    curDealID = curEr[index].dup.gsub(/'/,"")
    dealsFromDB.push(curDealID)
  end

  $ui.redirectTo(Globals.pageReports)
  btn = Controls.firstElement(eNameClearSearch, baseElement)
  if (btn != nil)
    $ui.clickOnWebElement(btn, 1)
  end
  datePeriod = Globals.datePeriod3Month
  $deals.filterDealsByDate(datePeriod)
  dealsFromUI = getDealsFromUI()
  if ((dealsFromUI == nil) || (dealsFromUI.length == 0))
    UiHelpers.throw "Error: could not get deals from UI"
  end

  errors = minusIntersection(dealsFromDB, dealsFromUI, "DB", "UI")
  if ((errors != nil)  &&  (errors != ""))
    UiHelpers.throw errors
  end
end

Then /^verify that setting columns in column picker changes columns in Deals$/ do
  columnsToSet = ["Deal Date/Time"] # Sapphire 6 fix (must have Date Date/Time)
  log "Get all special columns values"
  for key in $uiDefaults["dealsColumnsInColumnPickerRelatedToMoreThanOneColumn"].keys do
    values = $uiDefaults["dealsColumnsInColumnPickerRelatedToMoreThanOneColumn"][key]
    values.each do |val|
      columnsToSet.push(val)
    end
  end
  $ui.redirectTo(Globals.pageTrade)
  $deals.setColumns(columnsToSet)
  $deals.verifyColumns(columnsToSet)

  log "After it is done, return to default columns"
  steps %Q{
      Then set default deals columns
      Then verify that all Deal's elements exist
  }
end

Then /get chrome Downloads location from UI/ do
  iframeName = "settings"
  driver = Capybara.page.driver
  Capybara.visit "chrome:settings"
  localUi = UiHelpers.new(Capybara.page, Capybara.current_driver)
  btn = localUi.firstWithCss(Controls.get("btn_chrome_settings_advanced"), iframeName)
  driver.browser.switch_to.frame(iframeName)
  btn.click()
  sleep 1
  $downloadLocation = Controls.value2("field_chrome_settings_downloadsPath", driver.browser)
  # driver.browser.close()
end

Given /^tabs are loaded for user (\w+)$/ do |userName|
  userName = userName.to_s
  fullUsername = "#{userName}@ebs.com"
  for query in [ "DELETE SAPPHIRE2.LOM_USER_PANELS WHERE PK LIKE '#{fullUsername}%'" ,
                     "DELETE SAPPHIRE2.LOM_USER_DEFAULTS WHERE PK LIKE '#{fullUsername}%'" ,
                     "DELETE SAPPHIRE2.LOM_USER_SETTINGS WHERE PK LIKE '#{fullUsername}%'" ,
                     "INSERT INTO SAPPHIRE2.LOM_USER_PANELS (PK,DATA) SELECT REPLACE(PK,'auto1','#{userName}'),DATA " +
                     "FROM SAP_TEMPLATE_UI.LOM_USER_PANELS" ,
                     "INSERT INTO SAPPHIRE2.LOM_USER_SETTINGS (PK,DATA) select REPLACE(PK,'auto1','#{userName}'),DATA " +
                     "FROM SAP_TEMPLATE_UI.LOM_USER_SETTINGS"] do
    Actions.insertToDbWithCommit(CONFIG.get['SDATA_SCHEMA'],CONFIG.get['SDATA_SCHEMA'],query)
  end
end

def handleError(message, screenshotMessage)
  $ui.validateSapphireIsDisplayed()
  exceptionMessage = "Test failed. error: #{message}"
  UiHelpers.throw(exceptionMessage,true, true, true, true)
end

def changeResolutionToGetMaximumPanels()
  currentRes = $ui.seleniumGetCurrentResolution()
  x = currentRes[Globals.resolutionX]
  y = currentRes[Globals.resolutionY]
  x -= 1
  y -= 1
  driver = $ui.getBaseElement()
  driver.execute_script('document.body.style.zoom = "65%"')
  $ui.seleniumChangeWindowsResolution(x, y)
  x += 1
  y += 1
  $ui.seleniumChangeWindowsResolution(x, y)
  #$ui.changeResolution("highest")
end

def verifyElements(cssMainPart, onlyNamesContainRegex=nil, onlyNamesNotContainRegex=nil, type='exist', baseElement=nil)
  log "verifyElements started (#{cssMainPart}, #{onlyNamesContainRegex}, #{onlyNamesNotContainRegex}, #{type})"

  totalTested = 0
  totalPassed = 0
  errors = ""
  base = nil
  selectors = $ui.getControls().cssHash(cssMainPart,1)
  selectors.each do |name, css|
    if (  ((onlyNamesContainRegex != nil)    && (name !~ onlyNamesContainRegex))    ||
          ((onlyNamesNotContainRegex != nil) && (name =~ onlyNamesNotContainRegex)) )
            next
    end
    totalTested += 1
    message = "Testing selector:#{name}"
    log(message)
    if ((css == nil) || (css == ""))
      log("Missing css implementation for element")
      next
    end

    # baseElement in panels verification is the panel.
    base = baseElement
    if ((base != nil) && (base.is_a?(Numeric)))
       base = $panel.getActivePanelElement()
    else
      if (base == nil)
        base = $ui.getBaseElement()
      end
    end

    if (type == Globals.verifyClickableMenu)
      log("Clicking on button")
      if (name =~ /(Menu)$/)
        btnName = $`.to_s
        btnName = "#{btnName}Btn"
        log("Clicking on button (#{cssMainPart}, #{btnName})")
        $ui.clickOnCss(cssMainPart, btnName, 1)
      end
    end

    css = $ui.getControls().css(cssMainPart, name, 1)

    if ((name == "column"))
      errorsNamesRelatedToElement = verifyNamesRelatedToElement(cssMainPart, name, base, "column")
      if ((errorsNamesRelatedToElement != nil) && (errorsNamesRelatedToElement.length > 0))
        log(errorsNamesRelatedToElement)
        errors += errorsNamesRelatedToElement
        next
      end
    end

    begin
      if (type.to_s.include?(Globals.verifyClickable)) # clickable or clickableMenu
        message = "Clicking on element"
        log(message)
        locationBeforeClick = $ui.getCurrentLocation()
        beforeClickWindow = $ui.seleniumGetCurrentWindowHandle()
        begin
          $ui.clickOnElement(css, base)
        rescue => clickingError
          if (clickingError.message.to_s.downcase.include?("visible"))
            $ui.javascriptClickOnCss(css)
          end
        end

        sleep(3)
        message = "Closing popup windows if exist"
        log(message)
        $ui.closeWindowsThatAreNot(beforeClickWindow)
      end

      message = "Pass"
      log(message)
      totalPassed += 1

      if (type.to_s.include?(Globals.verifyClickable)) # clickable or clickableMenu
        message = "Returning to url before clicking (#{locationBeforeClick['url']})"
        log(message)
        $ui.setCurrentLocation(locationBeforeClick)

        elementsThatNeedExtraSleep = /(logout)/
        if (name =~ elementsThatNeedExtraSleep)
          sleep(5)
        end
      end
    rescue => e
      message = "Failed while performing the click (#{e.message})"
      log(message)
      errors += "#{e.message}\n"
    end
  end

  if (totalPassed < totalTested)
    UiHelpers.throw "Test failed (tested:#{totalTested}, passed:#{totalPassed} , errors: #{errors})"
  else
    log "Finished with success (tested:#{totalTested}, passed:#{totalPassed})"
  end

  log "verifyElements Finished"
end

def verifyNamesRelatedToElement(cssMainPart, cssSubPart, baseElement, type="column")
  errors = ""
  log "Testing all available #{type}s (#{cssMainPart})"
  all = $ui.allElementsWithCss(cssMainPart, cssSubPart, baseElement)
  if ((all == nil) || (all.length == 0))
    error = "No list of #{type}s (#{cssMainPart}, #{cssSubPart})"
    log(error)
    errors += error
    return errors
  end

  intersect = {"alreadyInUI" => [], "shouldBeInUI" => [], "intersection" => [] ,
               "errors" => ""}
  all.each do |e|
    elementWithVal = Controls.firstElement("general_column_name", e)
    val = $ui.getValueOrTextOrInnerHTML(elementWithVal)
    val = $ui.trimString(val)
    intersect["alreadyInUI"].push(val)
  end

  if (cssMainPart.downcase == Globals.pageReports)
    intersect["shouldBeInUI"] = $uiDefaults["allowed"]["columns"]["reportsPage"]
  else
    if (cssMainPart.downcase == "deals")
      intersect["shouldBeInUI"] = $uiDefaults["allowed"]["columns"]["dealsHeader"]
    end
  end
  if ((intersect["shouldBeInUI"] == nil) || (intersect["shouldBeInUI"].length == 0))
    error = "No implementation for #{cssMainPart}"
    log(error)
    errors += error
    return errors
  end

  log "Performing intersection between arrays and minus afterwards"
  intersect["intersection"] =
      intersectArrays(intersect["alreadyInUI"], intersect["shouldBeInUI"])
  for arrName in ["alreadyInUI", "shouldBeInUI"] do
    minus = intersect[arrName] - intersect["intersection"]
    minus.each do |nameNotFound|
      if (arrName == "alreadyInUI")
        error = "Error: unexpected #{type} \"#{nameNotFound}\" was found in UI"
      else
        error = "Error: #{type} \"#{nameNotFound}\" was NOT FOUND in UI"
      end

      intersect["errors"] += error
    end
  end

  if ((intersect["errors"] != nil) && (intersect["errors"].length > 0))
    errors += intersect["errors"]
  end

  return errors
end

def tradeSwapsVerifyElementsInPanel(panelNumber, cssSubPart, elementNameToShowInLogs, testType='exists')
  $ui.exceptionIfNil(panelNumber, cssSubPart, elementNameToShowInLogs)
  $ui.redirectTo(Globals.pageTrade, Globals.tabSwaps)


  log "Getting #{elementNameToShowInLogs} in panel: #{panelNumber}"

  # Since in array element number 1 is located at arr[0]
  panelNumber -= 1
  if (panelNumber < 0)
    panelNumber = 0
  end

  verifyElements('panel',/Btn$/,/(view|tenor)/,Globals.verifyClickable,panelNumber)

end

def verifyMaxDateMatchesTenor(maxDate, tenor, datepickerType='near')
  date = Date.today()
  log "Getting max date based on tenor and today's date (tenor: #{tenor})"
  if (tenor =~ /(\d+)(\w+)/)
    amount = $1.to_i
    type = $2.to_s.downcase
    case type
      when "wk"
        date = date + (amount * 7)
      when "mth"
        date = date >> amount
    end
  end

  log "Comparing maxDate with tenor's max date (maxDate: #{maxDate}, tenor: #{tenor})"
  diff = (maxDate - date).to_i
  allowedMaxDiff = 3
  if (datepickerType == "far")
    allowedMaxDiff = 4
  end

  if (diff > allowedMaxDiff)
    maxDateStr = $ui.dateStr(maxDate)
    errorMessage = "maxDate is higher than allowed by tenor " +
        "(maxDate: #{maxDateStr}, tenor: #{tenor}, type: #{datepickerType}, " +
        "diff: #{diff}, max diff allowed: #{allowedMaxDiff})"
    UiHelpers.throw errorMessage
  end
end

def intersectArrays(arr1, arr2)

  if ((arr1 == nil) || (arr2 == nil))
    return nil
  end
  require 'set'
  set1 = arr1.to_set
  set2 = arr2.to_set
  set3 = set1 & set2
  arr3 = set3.to_a
  return arr3
end

def unionArrays(arr1, arr2)
  if ((arr1 == nil) || (arr2 == nil))
    return nil
  end
  require 'set'
  set1 = arr1.to_set
  set2 = arr2.to_set
  set3 = set1 | set2
  arr3 = set3.to_a
  return arr3
end

def minusIntersectionHashes(h1, h2, h1Name = "hash1", h2Name = "hash2", direction="BOTH",
                            h1IgnoreKeys = [], h2IgnoreKeys = [])
  if (h1IgnoreKeys == nil)
    h1IgnoreKeys = []
  end
  if (h2IgnoreKeys == nil)
    h2IgnoreKeys = []
  end
  if (h1 == nil)
    UiHelpers.throw("#{h1Name} cannot be empty")
  end
  if (h2 == nil)
    UiHelpers.throw("#{h2Name} cannot be empty")
  end

  a1 = []
  for k in h1.keys
    if (h1IgnoreKeys.include?(k))
      next
    end
    a1.push([k, h1[k]])
  end
  a2 = []
  for k in h2.keys
    if (h2IgnoreKeys.include?(k))
      next
    end
    a2.push([k, h2[k]])
  end
  diffErrors = minusIntersection(a1, a2,  h1Name, h2Name, direction)
  return diffErrors
end

def minusIntersection(arr1, arr2, arr1Name="arr1", arr2Name="arr2", direction="BOTH")
  errors = ""
  if (arr1.nil? || arr1.empty?)
    raise "first array cannot be empty (#{arr1Name.to_s})"
  end
  if (arr2.nil? || arr2.empty?)
    raise "second array cannot be empty (#{arr2Name.to_s})"
  end

  log "Intersecting #{arr1.length.to_s} elements from #{arr1Name} with " +
          "#{arr2.length.to_s} elements from #{arr2Name}"
  intersection = intersectArrays(arr1, arr2)
  log "Searching for unique values which are not in intersection"
  if ((direction == "BOTH") || (direction == "arr1-arr2"))
    arr1Unique = arr1 - intersection
    arr1Unique.each do |e|
      err = "#{e} exists in #{arr1Name}, and not in #{arr2Name}"
      log err
      errors += "#{err}\n"
    end
  end

  if ((direction == "BOTH") || (direction == "arr2-arr1"))
    arr2Unique = arr2 - intersection
    arr2Unique.each do |e|
      err = "#{e} exists in #{arr2Name}, and not in #{arr1Name}"
      log err
      errors += "#{err}\n"
    end
  end

  if (errors == "")
    log "Finished, both #{arr1Name} and #{arr2Name} contain the exact same elements"
  end

  return errors
end

def getTradingDates(currency, type, month=nil, year=nil)
  if ((! currency) || (! type))
    UiHelpers.throw "Missing arguments"
  end

  isTrading = true
  if(type.to_s.include?("non"))
    isTrading = false
  end

  arr = []

  if ((month == nil) || (year == nil))
    maxMonthes = 3
    date = Date.today()
    for i in 1..maxMonthes
      arr += Actions.getTradingDates(CONFIG.get['SDATA_SCHEMA'],currency,date.year,date.month,isTrading)
      date = date.next_month()
    end
  else
    year = year.to_i
    month = month.to_i

    arr = Actions.getTradingDates(CONFIG.get['SDATA_SCHEMA'],currency,year,month,isTrading)
  end


  arrToRet = []
  arr.each do |date|
    day = -1
    month = -1
    year = -1
    if (/(\d+)[^\d]+(\d+)[^\d]+(\d+)/ =~ date)
      day = $1.to_i
      month = $2.to_i
      year = $3.to_i
      dateToRet = "#{day}/#{month}/#{year}"
      dateCellToRet = {}
      dateCellToRet['date'] = dateToRet
      dateCellToRet['typeOfTheDay'] = ""
      arrToRet.push(dateCellToRet)
    end
  end

  return arrToRet
end

def filterDatesByJumping(jumpDays, arr)
  arrToRet = []
  curDay = 0
  if (arr.length <= 2)
    log "Array length is too small to perform jump (Length: #{arr.length.to_s})"
    arrToRet = arr
  else
    if ((arr.length / jumpDays) < 2)
      log "Too little days will be left after jump"
      jumpDays = arr.length / 3
      log "Jump days was set to #{jumpDays.to_s}"
    end

    arr.each do |element|
      curDay += 1
      if ((curDay % jumpDays) == 0)
        arrToRet.push(element)
      end
    end
  end

  return arrToRet
end

def getArrayOfDates(type, currency_pair, month=nil, year=nil, filterDates=true)
  leftCurrency = nil
  rightCurrency = nil
  if (currency_pair =~ /([^\/\s]+)\s*\/\s*([^\/\s]+)/)
    leftCurrency = $1.to_s
    rightCurrency = $2.to_s
  end
  if ((leftCurrency == nil) || (rightCurrency == nil))
    UiHelpers.throw "missing / illegal currency pair (#{currency_pair})"
  end

  arrDates = intersectArrays(getTradingDates(leftCurrency, type, month, year), getTradingDates(rightCurrency, type, month, year))
  if (arrDates == nil)
    UiHelpers.throw "empty array of currency pair after intersection (#{currency_pair})"
  end

  if (type == 'non_trading_dates')
    arr = []
    arrDates.each do |date|
        curDate = date
        curDateName = Date.parse(curDate['date']).strftime("%A").downcase
        if ((curDateName == "friday") || (curDateName == "saturday") || (curDateName == "sunday"))
          curDate['typeOfTheDay'] = 'Weekend'
        else
          curDate['typeOfTheDay'] = 'Holiday'
        end
        arr.push(curDate)
    end
  else
    # Trading dates
    arr = arrDates
  end

  return arr
end

# Month is numeric (1 2 3 ... 12)
def getSpecificMonthDates(month, year, dates_source, currency_pair)
  today = Date.today
  shouldNot = false
  if (/^-/ =~ month.to_s)
    month = $'
    shouldNot = true
  end

  all = getArrayOfDates(dates_source, currency_pair, month, year)
  arrToRet = []
  all.each { |d|
    if (/^\d+[^\d]+(\d+)[^\d]+(\d+)/ =~ d['date'].to_s)
      curMonth = $1
      curYear = $2
      if (  ((! shouldNot) && (month.to_s == curMonth.to_s) && (year.to_s == curYear.to_s)) ||
            ((shouldNot) && (month.to_s != curMonth.to_s) && (year.to_s != curYear.to_s))   )
        if (Date.parse(d['date']) > today)
          arrToRet.push(d)
        end
      end
    end
  }

  return arrToRet
end

def setDatePickerForAllDates(arr_type, non_trading_type=nil, should_fail=false,
                             currency_pair = $uiDefaults["defaultValues"]["ccy"] , trading_date = nil, filter=nil)
  didnotFail = false
  begin
    date = Date.today()

    if (non_trading_type == nil)
      arrDates = getArrayOfDates(arr_type, currency_pair)
    else
      if (non_trading_type == Globals.typeCurrent)
        nextTwoDays = date.next_day(2)
        if (nextTwoDays.month != date.month)
            log "We are on the end of month, skipping this step..."
            return true
        end

        if (($arrDates[currency_pair] != nil) &&
               ($arrDates[currency_pair][arr_type] != nil) &&
               ($arrDates[currency_pair][arr_type]["#{date.month}/#{date.year}"] != nil)  )
             arrDates = $arrDates[currency_pair][arr_type]["#{date.month}/#{date.year}"]
        else
             arrDates = getSpecificMonthDates(date.month, date.year ,arr_type, currency_pair)
        end
      else
           date = date.next_month()
           if (($arrDates[currency_pair] != nil) &&
               ($arrDates[currency_pair][arr_type] != nil) &&
               ($arrDates[currency_pair][arr_type]["#{date.month}/#{date.year}"] != nil)  )
             arrDates = $arrDates[currency_pair][arr_type]["#{date.month}/#{date.year}"]
           else
             arrDates = getSpecificMonthDates(date.month, date.year ,arr_type, currency_pair)
           end
      end
    end

    if (filter != nil)
      arrDates = filterDates(arrDates, filter)
    end

    log "Filtering days by jumping (to perform less tests)"
    jumpDays = 5
    if (arr_type == Globals.typeNonTradingDates)
      jumpDays = 3
    end
    arrDates = filterDatesByJumping(jumpDays, arrDates)
    log "finished filtering"

    last_index = (arrDates.length - 1)
    if (last_index < 1)
      UiHelpers.throw("No dates to set", true, false, false, false)
    end

    if (trading_date == nil)
      for i in 1..last_index
        dateOfStartTrading = arrDates[i-1]['date']
        dateFar = arrDates[i]['date']
        $panel.verifyDatepickerIsClosed()
        $panel.setCurrencyPair(currency_pair)
        $panel.setProductType($uiDefaults["defaultValues"]["lp"])

        if (! $panel.setDatePicker(dateFar, dateOfStartTrading))
          UiHelpers.throw("Date was not set", true, false, false, false)
        end
        sleep(3)
      end
    else
      for i in 0..last_index
        dateOfStartTrading = trading_date
        dateFar = arrDates[i]['date']
        $panel.setCurrencyPair(currency_pair)
        defaultLP = $uiDefaults["defaultValues"]["lp"]
        $panel.setProductType(defaultLP)

        if (! $panel.setDatePicker(dateFar, dateOfStartTrading))
          UiHelpers.throw("Date was not set", true, false, false, false)
        end
        sleep(3)
      end
    end

    didnotFail = true
  rescue => e
    if (! should_fail)
      UiHelpers.throw(e)
    else
      log "setDatePicker failed which is good (exception returned: #{e.message})"
    end
  end

  # We didn't fail , so should check if this is ok.
  if (should_fail && didnotFail)
    UiHelpers.throw 'Date was set even though expected to fail'
  end
end

def filterDates(arrDates, filter)
  notEqual = false
  if (/^-/ =~ filter)
    filter = $'
    notEqual = true
  end
  arrToRet = []
  arrDates.each do |d|
    if ( ((! notEqual) && (d['typeOfTheDay'].to_s.downcase == filter.to_s.downcase)) ||
         ((notEqual) && (d['typeOfTheDay'].to_s.downcase != filter.to_s.downcase))    )
      arrToRet.push(d)
    end
  end

  return arrToRet
end

def createMaximumTabsAvailable(page=Globals.pageTrade)
  base = $ui.getBaseElement()
  baseName = "max"
  i = 0
  error = ""
  while (error == "")
    begin
      i += 1
      curTabName = "#{baseName}#{i.to_s}"
      $ui.setNewTab(page, curTabName)
    rescue => e
      error += "ERROR: #{e.message.to_s}"
    end
  end

  if (i > 0)
    log "Done: #{i.to_s} tabs were creaetd"
  else
    UiHelpers.throw "Error, new tab were not created (#{error})"
  end
end

def createMaxPanelsInTab(tabName, page=Globals.pageTrade)
  ccyForActivePanels = "USD/RUB"
  $ui.redirectTo(page, tabName)
  allPanels = $panel.getAllPanels(false)
  allPanels.each do |p|
    $panel.changeViewOfPanel(p, "small")
  end

  amountBefore = $panel.getAllActivePanels().length
  base = $ui.getBaseElement()
  baseCCY = $uiDefaults["defaultValues"]["ccy"]
  baseFloor =$uiDefaults["defaultValues"]["floor"]
  i = 0
  error = ""
  panel = $panel
  log "Creating panels"
  while (error == "")
    begin
      i += 1
      panel = panel.setNewPanel(baseCCY)
    rescue => e
      error += "ERROR: #{e.message.to_s}\n"
    end
  end

  amountAfter = $panel.getAllActivePanels().length

  log "Done: panels were created (amountAfter: #{amountAfter.to_s})\n" +
        "Validating that these panels exist after logout and login"
  sleep 3
  $ui.logoutFromSapphire()
  $ui.signInToSapphire(@@CONFIG['SapphireUiUser'],'',@@CONFIG['SapphireLoginUrl'])
  log "After logout and login, redirecting to page: #{page}, tab: #{tabName}"
  $ui.redirectTo(page, tabName)
  changeResolutionToGetMaximumPanels()
  sleep 3
  log "After redirection, getting the amount of panels."
  arrAllActivePanels = $panel.getAllActivePanels()
  amountAfterLogoutLogin = arrAllActivePanels.length
  if (amountAfterLogoutLogin == amountAfter)
    log "Pass, after logout and login amount is still the same (amount: #{amountAfterLogoutLogin})"
    i = 1
    arrAllActivePanels.each do |p|
      log "panel(#{i.to_s}): validating that this panel is alive"
      panelObject = Panel.new($ui, Globals.newPanelTypeNumber, i)
      panelObject.setCurrencyPair(ccyForActivePanels)
      i += 1
    end
  else
    UiHelpers.throw "Error: amount of panels before and after logout and login was changed\n" +
                    "(before logout and login: #{amountAfter}, " +
                    "after logout and login: #{amountAfterLogoutLogin})"
  end
end

def sleepBetweenFinishedTests()
  timeToSleep = $uiDefaults["minimumTimeToSleep"]["after"]["click"]
  log "After test sleeping #{timeToSleep.to_s}"
  sleep timeToSleep
end

def getCsvfileToArrayOfArrays(filePath)
  arrToRet = []
  begin
    arrToRet = CSV.read(filePath)
  rescue => e
    UiHelpers.throw "Error: cannot read csv file (#{filePath})"
    arrToRet = []
  end
  return arrToRet
end

def getDealsFromUI(waitForDeals = true)
  eNameCurrentPage = "header_currentPage"
  dealsFromUI = []
  if ($deals == nil)
    log "settings $deals"
    steps %Q{
	    Then set default deals columns
    }
  end

  begin
    sleep 3
    dealsFromUI = $deals.getAllDealsProperty(Globals.dealItemTicketId)
  rescue => e
    log "Error while getting deals from UI. (error: #{e.message})"
    dealsFromUI = []
  end
  if (waitForDeals == true)
    secondsToSleep = 10
    while (((dealsFromUI == nil) || (dealsFromUI.length == 0)) &&
        (secondsToSleep > 0))
      begin
        log "refresh trade page to get deals (sleeing time: #{secondsToSleep.to_s})"
        currentPage = Controls.value2(eNameCurrentPage, $ui.getBaseElement())
        $ui.redirectTo(Globals.pageSettings)
        $ui.redirectTo(currentPage)
        sleep secondsToSleep
        dealsFromUI = $deals.getAllDealsProperty(Globals.dealItemTicketId)
        if ((dealsFromUI == nil) || (dealsFromUI.length == 0))
          log "No deals after redirection and sleeping. (sleeping time was: #{secondsToSleep.to_s})"
          log "logging out and logging in, to get deals."
          steps %Q{
              Then logout and login via UI
            }
          $ui.redirectTo(currentPage)
          dealsFromUI = $deals.getAllDealsProperty(Globals.dealItemTicketId)
          if ((dealsFromUI != nil) && (dealsFromUI.length > 0))
            log "After logout and login, deals found. " +
                    "(sleeping time was: #{secondsToSleep.to_s}, deals found: #{dealsFromUI.length.to_s})"
          else
            message = "No deals after logout and login. (sleeping time was: #{secondsToSleep.to_s})"
            log message
            UiHelpers.createAndShowScreenshot(message)
          end
        else
          log "After redirection and sleeping, found deals. " +
                  "(sleeping time was: #{secondsToSleep.to_s}, deals found: #{dealsFromUI.length.to_s})"
        end
      rescue => e
        log "Error while getting deals from UI. (error: #{e.message})"
        dealsFromUI = []
      end
      secondsToSleep -= 1
    end
  end
  dealsFromUI = dealsFromUI.uniq()

  if (($institutionKey != nil) && ($userID != nil) && ((dealsFromUI == nil) || (dealsFromUI.length == 0)))
    begin
      log "No deals found in UI, getting debug data to log (getting deals from v_sap_tickets)"
      sqlDebugFile = File.open("#{$sqlFilesPath}/getDealsFromDealBlotter.sql")
      sqlDebug = sqlDebugFile.read
      sqlDebugFile.close
      sqlDebug = sqlDebug.gsub(/(FP_INSTITUTION_KEY\s*=\s*)\d+/i, "\\1#{$institutionKey}")
      sqlDebug = sqlDebug.gsub(/(FP_TRADER\s*=\s*['"]+)[^'"]+(['"])/i, "\\1#{$userID}\\2")
      res = Actions.getDbQueryResults(CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SCHEMA'],sqlDebug)
      if (res == nil)
        res = []
      end
      resLength = res.length
      log "SQL EXECUTED: \n#{sqlDebug}\n\n" +
              "DEBUG RESULTS FROM DB (v_sap_tickets): \n" +
              "(AMOUNT IN DB: #{resLength.to_s}, DATA: #{res.to_s})"
    rescue
    end
  end
  return dealsFromUI
end

def searchDealsInReports()
  if ($uiDefaults == nil)
    UiHelpers.throw "$uiDefaults is required to be declared"
  end
  searchableFields = $uiDefaults["allowed"]["searchableColumns"]["reportsPage"]
  dealPropertiesNamesInReports = $uiDefaults["allowed"]["dealsProperties"]["reportsPage"]
  if ((searchableFields == nil) || (searchableFields.length == 0))
    UiHelpers.throw("No searchable fields found", true, true, true,true)
  end
  if ((dealPropertiesNamesInReports == nil) || (dealPropertiesNamesInReports.length == 0))
    UiHelpers.throw("No deal properties names in reports", true, true, true, true)
  end
  $ui.redirectTo(Globals.pageReports)
  if ($deals == nil)
    $deals = Deals.new($ui, 1)
  end

  $deals.filterDealsByDate(Globals.datePeriod3Month)
  allDeals = $deals.getAllDeals()
  baseDealIndex = Random.new().rand(0...allDeals.length)
  baseDeal = allDeals[baseDealIndex]
  baseDealProperties = baseDeal.getProperties()
  baseDealTicketID = baseDealProperties[Globals.dealItemTicketId]
  log "baseDeal: index = #{baseDealIndex}, ticketID = #{baseDealTicketID}"
  errors = ""
  searchableFields.each do |searchableField|
    type = dealPropertiesNamesInReports[searchableField]
    value = baseDealProperties[type]
    log "Searching value: #{value} type: #{searchableField}"
    $deals.findDeals(value, searchableField)
    dealsTicketIds = $deals.getAllDealsProperty(Globals.dealItemTicketId)
    if (! dealsTicketIds.include?(baseDealTicketID))
      error = "deal was not found using search (value: #{value}, type: #{searchableField}," +
                " currentTicketIDs: #{dealsTicketIds.to_s})"
      log errors
      errors += "#{error}\n"
    end
  end

  if (errors != "")
    UiHelpers.throw(errors, true, true, true, true)
  end
end

def performBeforeMslAndGwTests(confirmOnSend)
  if ($ui.nil? || $deals.nil?) then UiHelpers.throw("$ui and $deals should be declared"); end
  $ui.setSettings({Globals.generalToAllElements => {"ConfirmOnSend" => confirmOnSend}})
  $deals.verifyThereAreNoDealsInBlotter()
  $orderItem = OrderItem.new($ui, 1)
  OrderItem.removeAllOrders()
end

def diffLogsToUI(logsProperties, sentOrders, afterClickLogsPrefix, productType)
  for logCategory in logsProperties.keys
    properties = logsProperties[logCategory]
    properties["dataToCompareWith"] = sentOrders
    properties["filenames"].each do |logFile|
      logsDiff = $deals.getLogsDiff(logFile, properties["regexBefore"],
                                    properties["regexAfter"], afterClickLogsPrefix, productType)
      if ((logsDiff.nil?) || (logsDiff.empty?))
        errMsg = properties["errorMessageNoLogData"]
        if (properties["failWhenNoDataFound"])
          log "No data error, category: #{logCategory}, file: #{logFile}, errors: #{errMsg}"
          UiHelpers.throw(errMsg, true, false, true, true)
        else
          log(errMsg)
          next
        end
      end
      if (productType == Globals.panelLpSW)
        toIgnore = [Globals.dealItemPrice]
        properties["dataToCompareWith"] = []
        for i in 0..(sentOrders.length - 1)
          properties["dataToCompareWith"].push(sentOrders[i].select {|k,v|  (! toIgnore.include?(k))})
        end
        for i in 0..(logsDiff.length - 1)
          logsDiff[i] = logsDiff[i].select {|k,v| (! toIgnore.include?(k))}
        end
      end
      if (logsDiff.length != properties["dataToCompareWith"].length)
        diffErrors = "different lengths (logs: #{logsDiff.length.to_s}, " +
                      "data: #{properties["dataToCompareWith"].length.to_s})"
      else
        diffErrors = ""
        for i in 0..(logsDiff.length - 1)
          curDiffErrors = minusIntersectionHashes(logsDiff[i], properties["dataToCompareWith"][i],
                                               properties["diffLogName"], properties["diffUiName"],
                                               properties["cmpDirection"], properties["diffLogIgnore"],
                                               properties["diffUiIgnore"]).to_s
          if (! curDiffErrors.empty?)
            diffErrors += "#{curDiffErrors}\n"
          end
        end
      end
      if (! diffErrors.empty?)
        log "Diff errors, category: #{logCategory}, file: #{logFile}, errors: #{diffErrors}"
        UiHelpers.throw(diffErrors)
      end
    end
  end
end

def diffPanelSettingsLpsToOrderLps(orderTransactions)
  if ($orderItem.nil? || $panelSettings.nil?) then UiHelpers.throw("$orderItem and $panelSettings are required"); end
  log "Comparing panel's allowed lps with actual made order's lps"
  orderLPs = $orderItem.filterLPsOnFromTransaction(orderTransactions)
  lpsOn = $panelSettings.getLPsOn(true, true)
  diff = (orderLPs.sort.uniq - lpsOn.sort.uniq)
  if (! diff.empty?)
    UiHelpers.throw("Found LPs that are not allowed for trading (results: #{diff.join(', ')})")
  else
    log Globals.messagePassed
  end
end

def diffOrderToDealBlotter(sentOrderHash, orderTransactions, productType)
  if ($deals.nil?) then UiHelpers.throw("$deals is required"); end
  log "Verifying deals (in deals blloter) match details of order (in orders panel)"
  $deals.verifyDealsRecievedInDealblotter(sentOrderHash, orderTransactions, true, productType)
end

def verifyInBackendEnvThatGcMockDebugOutputsToFiles()
  $nodeDebugDefaultValues = nil
  vals = ["simple-oracledb","EBS:TestAutomation-FULL","EBS:TestAutomation-VWAP","EBS:TestAutomation-LMT",
          "EBS:TestAutomation-RFQ","EBS:TestAutomation-IND"]
  ip = CONFIG.get['APP_HOST_IP']
  user = CONFIG.get['APP_HOST_USER']
  pwd = CONFIG.get['APP_HOST_PWD']
  baseF = "#{CONFIG.get['REMOTE_HOME']}/#{CONFIG.get['APP_HOST_USER']}/sapphire_remote/env/backend-env.json"
  tempF = "/tmp/backend-env.json"
  cmdGetCurrent = "cat #{baseF} | grep '\"NODE_DEBUG\"' | awk -F '\"' '{print $4}'"
  res = Actions.SSH_NO_FAIL(ip, user, pwd, cmdGetCurrent, 15)
  if (! res.to_s.empty?)
    $nodeDebugDefaultValues = res.to_s.gsub(/\s*$/, "").split(",")
    vals = ($nodeDebugDefaultValues + vals).uniq
    if (vals != $nodeDebugDefaultValues)
      vals = vals.join(",")
      cmdReplace = "cat #{baseF} | " +
          " sed -e 's/\\(\\\"NODE_DEBUG\\\": \\).*/\\1\\\"#{vals}\\\",/' > #{tempF}"
      res = Actions.SSH_NO_FAIL(ip, user, pwd, cmdReplace, 15)
      cmdReplace2 = "(grep '.' #{tempF} 1>/dev/null 2>&1) && mv #{tempF} #{baseF}"
      res = Actions.SSH_NO_FAIL(ip, user, pwd, cmdReplace2, 15)
    end
  end
end

def verifyInBackendEnvThatGcMockDebugNotOutputsToFiles()
  vals = $nodeDebugDefaultValues rescue nil
  if (vals != nil)
    vals = vals.join(",")
    ip = CONFIG.get['APP_HOST_IP']
    user = CONFIG.get['APP_HOST_USER']
    pwd = CONFIG.get['APP_HOST_PWD']
    baseF = "#{CONFIG.get['REMOTE_HOME']}/#{CONFIG.get['APP_HOST_USER']}/sapphire_remote/env/backend-env.json"
    tempF = "/tmp/backend-env.json"
    cmdReplace = "cat #{baseF} | " +
        " sed -e 's/\\(\\\"NODE_DEBUG\\\": \\).*/\\1\\\"#{vals}\\\",/' > #{tempF}"
    res = Actions.SSH_NO_FAIL(ip, user, pwd, cmdReplace, 15)
    cmdReplace2 = "(grep '.' #{tempF} 1>/dev/null 2>&1) && mv #{tempF} #{baseF}"
    res = Actions.SSH_NO_FAIL(ip, user, pwd, cmdReplace2, 15)
  end
end