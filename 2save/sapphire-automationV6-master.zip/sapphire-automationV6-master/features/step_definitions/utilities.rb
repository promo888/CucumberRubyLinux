Given /^MSL is up and running$/ do
  Actions.isIpValidInParams

  cmd = 'uptime'
  res = Actions.SSH(CONFIG.get['MSL_HOST_CUSTOM_IP'], CONFIG.get['MSL_HOST_USER'], CONFIG.get['MSL_HOST_PWD'], cmd, 15, true, '')
  if (res.nil? || res.to_s.empty?)
    @@scenario_fails.push('Error: MSL is probably not up')
    fail('Error: cannot connect to given MSL '+CONFIG.get['MSL_HOST_CUSTOM_IP']+', check that the machine is up')
  end
  Actions.v 'Output of uptime check: '+res

  cmd = 'ps -aef|grep postgres|grep -v grep'
  res = Actions.SSH(CONFIG.get['MSL_HOST_CUSTOM_IP'], CONFIG.get['MSL_HOST_USER'], CONFIG.get['MSL_HOST_PWD'], cmd, 15, true, '')
  if (res.nil? || res.to_s.empty?)
    @@scenario_fails.push('Error: postgres is not running')
    fail('Error: cannot find running postgres on the given MSL '+CONFIG.get['MSL_HOST_CUSTOM_IP']+', check that the service is launched')
  end
  Actions.v 'Output of ps check: '+res
end


Then /^MSL is cleaned$/ do
  Actions.createLocalDirsTemplatesLogs
  createDirForUser(CONFIG.get['MSL_HOST_CUSTOM_IP'], CONFIG.get['MSL_HOST_USER'], CONFIG.get['MSL_HOST_PWD'], 'Automation_utilities')
  Actions.cleanupMslCustom(CONFIG.get['MSL_HOST_CUSTOM_IP'], 'Automation_utilities')
end


def isMslRunning?(mslIP)
  Actions.v 'Checking MSL '+mslIP+' uptime...'
  cmd = 'uptime'
  res = Actions.SSH(mslIP, CONFIG.get['MSL_HOST_USER'], CONFIG.get['MSL_HOST_PWD'], cmd, 15, true, '')
  if (res.nil? || res.to_s.empty?)
    @@scenario_fails.push('Error: MSL is probably not up')
    fail('Error: cannot connect to given MSL '+mslIP+', check that the machine is up')
  end
  Actions.v 'Output of MSL '+mslIP+' uptime check: '+res

  Actions.v 'Checking MSL '+mslIP+' postgres processes...'
  cmd = 'ps -aef|grep postgres|grep -v grep'
  res = Actions.SSH(mslIP, CONFIG.get['MSL_HOST_USER'], CONFIG.get['MSL_HOST_PWD'], cmd, 15, true, '')
  if (res.nil? || res.to_s.empty?)
    @@scenario_fails.push('Error: postgres is not running')
    fail('Error: cannot find running postgres on the given MSL '+mslIP+', check that the service is launched')
  end
  Actions.v 'Output of MSL '+mslIP+' ps check: '+res
end


Given /^test report is opened$/ do
  @localPath=Dir.getwd.gsub('/', '\\')+'\report.html'
  @localPathOrig=Dir.getwd.gsub('/', '\\')+'\report_orig.html'
  @localWebPage='file:///'+Dir.getwd+'/report.html'

  puts 'Opening web page "'+@localWebPage+'"'

  begin
    visit @localWebPage
  rescue Exception=>e
    fail('Error: cannot open web page "'+@localWebPage+'"')
  end

  sleep 1
end


Then /^original test report is saved$/ do
  puts 'Saving original web page as "'+@localPathOrig+'"'

  begin
    File.open(@localPathOrig, 'w') { |file|
      file.write(save_page(@localPathOrig))
    }
  rescue Exception=>e
    fail('Error while writing to file "'+@localPathOrig+'"')
  end
end


Then /^errors backtrace is removed$/ do
  cssToRemove1='div.backtrace'
  cssToRemove2='pre.ruby'

  puts 'Removing css elements "'+cssToRemove1+'", "'+cssToRemove2+'"'

  begin
    Capybara.page.execute_script("$('#{cssToRemove1}').remove();")
    Capybara.page.execute_script("$('#{cssToRemove2}').remove();")
  rescue Exception=>e
    fail('Error: cannot execute JS on the web page "'+@localWebPage+'"')
  end

  sleep 1
end


Then /^updated test report is saved$/ do
  puts 'Saving updated web page as "'+@localPath+'"'

  begin
    File.open(@localPath, 'w') { |file|
      file.write(save_page(@localPath))
    }
  rescue Exception=>e
    fail('Error while writing to file "'+@localPath+'"')
  end

  begin
    filepath=Dir.getwd.gsub('/', '\\').to_s[0...-9]+'\nextBuildNumber'
    file = File.open(filepath, 'rb')
    fileContents = file.read.chomp
    buildNumber=fileContents.to_i - 1
    puts 'Calculated current build number from "'+filepath+'" - '+buildNumber.to_s
  rescue Exception=>e
    fail('Error while calculating current build number')
  end

  begin
    puts 'Calculating target html report dir'
    targetPath=Dir.getwd.gsub('/', '\\').to_s[0...-9]+'builds'+'\\'+buildNumber.to_s+'\htmlreports\HTML_Report'
  rescue Exception=>e
    fail('Error while calculating target html report dir')
  end

  begin
    puts 'Copying updated test report to "'+targetPath+'"'
    Actions.WINCMD('copy /Y '+@localPath+' '+targetPath, 25, 'file')
  rescue Exception=>e
    fail('Error while copying updated test report')
  end

  begin
    puts 'Copying original test report to "'+targetPath+'"'
    Actions.WINCMD('copy /Y '+@localPathOrig+' '+targetPath, 25, 'file')
  rescue Exception=>e
    fail('Error while copying original test report')
  end
end