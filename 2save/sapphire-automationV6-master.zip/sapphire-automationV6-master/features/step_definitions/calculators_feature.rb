require 'cucumber'
require 'capybara'
require "capybara/dsl"
require 'capybara/cucumber'
require 'capybara/session'
require 'capybara/selenium/driver'
require 'selenium/webdriver'
require 'capybara-screenshot'
#require 'rspec'
require 'capybara/rspec'

#require File.expand_path('../../../support/custom_config', __FILE__)
include CONFIG
begin
  require '../../features/helpers/Actions'
  require Dir.getwd+'/features/helpers/UiHelpers'
  require Dir.getwd+'/features/helpers/Controls'
rescue LoadError
end
# encoding: utf-8


Given /^Sapphire App is deployed$/  do
  stopSapphireApp(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
  moveSapphireLogs(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
  steps %Q{
            Given Optional Sdata schema and Optional Ptrade schema and App are built for LAB
            Given Automation dir exists on sapphire server for user sapphire
            Given Scripts are uploaded to sapphire server for user sapphire
            Given DB Schema is deployed for user sapphire
            Given App is deployed for user sapphire
          }
  Actions.createLocalDirsTemplatesLogsSapphire
  Actions.removeOldOutput
end


Given /^Sapphire App is deployed with Sap schemas$/  do
  if ENV['WITHOUT_DEPLOYMENT_AND_STOP'].to_s.downcase != 'true'
    steps %Q{
              Given Optional Sdata Sap schema and Optional Ptrade Sap schema and App are built for LAB
              Given Automation dir exists on sapphire server for given sapphire user
              Given Scripts are uploaded to sapphire server for given sapphire user
              Given DB Sap Schema is deployed for given sapphire user
              Given App is deployed for given sapphire user
            }
  elsif ENV['WITHOUT_DEPLOYMENT_AND_STOP'].to_s.downcase == 'true'
    Actions.v 'Continuing without deploying Sapphire and optional SDATA/PTRADE'
  end
  Actions.removeOldOutput
end


Given /^Sapphire release is defined$/  do
  matchSchemasWithReleases
end


Given /^Sapphire release is defined for a custom job without SAP_RELEASE_NUMBER$/  do
  matchSchemasWithReleases(false)
end


Given /^config is matched$/  do
  matchConfigSapphire
end


Given /^pre-install operations for ESP$/  do
  stopSapphireApp(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
  moveSapphireLogs(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
  Actions.createLocalDirsTemplatesLogsSapphire
end


Given /^pre-install operations for ESP without deployment$/  do
  stopSapphireApp(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
  moveSapphireLogs(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
  Actions.createLocalDirsTemplatesLogsSapphire
end


Given /^pre-install operations for RFQ$/  do
  stopSapphireApp(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
  moveSapphireLogs(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
  Actions.createLocalDirsTemplatesLogsSapphireRfq
end


Given /^pre-install operations for RFQ without deployment$/  do
  stopSapphireApp(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
  moveSapphireLogs(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
  Actions.createLocalDirsTemplatesLogsSapphireRfq(false)
end


Given /^pre-install operations for UI tests without deployment$/  do
  stopSapphireApp(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
  moveSapphireLogs(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
  Actions.createLocalDirsTemplatesLogsSapphireUI(false)
end


Then /^user panels data is copied to Sapphire DB from "(.*?)"$/  do |templateSchema|
  if ENV['WITHOUT_DEPLOYMENT_AND_STOP'].to_s.downcase != 'true'
    Actions.v 'Copying user data to Sapphire DB schema "'+CONFIG.get['SAPPHIRE_SCHEMA'].to_s+'" from schema "'+templateSchema+'" at '+CONFIG.get['ORACLE_HOST_IP'].to_s+'...'
    begin
      sql = 'DELETE FROM '+CONFIG.get['SAPPHIRE_SCHEMA']+'.LOM_USER_PANELS'
      insertToSapphireCustomDb(sql, CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SCHEMA'])
      sql = 'DELETE FROM '+CONFIG.get['SAPPHIRE_SCHEMA']+'.LOM_USER_SETTINGS'
      insertToSapphireCustomDb(sql, CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SCHEMA'])
      sql = 'INSERT INTO '+CONFIG.get['SAPPHIRE_SCHEMA'].to_s.upcase+'.LOM_USER_PANELS (PK,DATA) select PK,DATA FROM '+templateSchema.to_s+'.LOM_USER_PANELS'
      insertToSapphireCustomDb(sql, CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SCHEMA'])
      sql = 'INSERT INTO '+CONFIG.get['SAPPHIRE_SCHEMA'].to_s.upcase+'.LOM_USER_SETTINGS (PK,DATA) select PK,DATA FROM '+templateSchema.to_s+'.LOM_USER_SETTINGS'
      insertToSapphireCustomDb(sql, CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SCHEMA'])
    rescue Exception => e
      fail('Error while copying user data into Sapphire DB (query "'+sql+'") from schema "'+templateSchema+'"'+"\n"+e.message)
    end
  elsif ENV['WITHOUT_DEPLOYMENT_AND_STOP'].to_s.downcase == 'true'
    Actions.v 'Continuing without copying from DB'
  end
end


Then /^user panels for RFQ are changed in Sapphire DB$/  do
  Actions.v 'Changing user panels for RFQ in Sapphire DB at '+CONFIG.get['ORACLE_HOST']+'...'
  sql = 'DELETE FROM LOM_USER_PANELS'
  insertToSapphireCustomDb(sql,CONFIG.get['SAPPHIRE_SCHEMA'],CONFIG.get['SAPPHIRE_SCHEMA'])
  sql = 'DELETE FROM LOM_USER_SETTINGS'
  insertToSapphireCustomDb(sql,CONFIG.get['SAPPHIRE_SCHEMA'],CONFIG.get['SAPPHIRE_SCHEMA'])
  sql = 'INSERT INTO '+CONFIG.get['SAPPHIRE_SCHEMA'].to_s.upcase+'.LOM_USER_PANELS (PK,DATA) select PK,DATA FROM sap_rfq_template.LOM_USER_PANELS'
  insertToSapphireCustomDb(sql,CONFIG.get['SAPPHIRE_SCHEMA'],CONFIG.get['SAPPHIRE_SCHEMA'])
  sql = 'INSERT INTO '+CONFIG.get['SAPPHIRE_SCHEMA'].to_s.upcase+'.LOM_USER_SETTINGS (PK,DATA) select PK,DATA FROM sap_rfq_template.LOM_USER_SETTINGS'
  insertToSapphireCustomDb(sql,CONFIG.get['SAPPHIRE_SCHEMA'],CONFIG.get['SAPPHIRE_SCHEMA'])
end


Then /^mock data is updated$/  do
  Actions.v 'Updating mock data for user "'+CONFIG.get['APP_HOST_USER']+'"...'

  # mock_data_dir = CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_remote/backend/server/node_modules/ebs/test/helpers/gc/data'
  mock_data_dir = CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_remote/backend/server/node_modules/ebs-mocks/lib/data'
  cmd = 'cd '+mock_data_dir+' && rm -f *'
  res = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15)
  uploadDir2RemoteAutomationFolder(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], Dir.getwd+'/templates/sap_app_mock_data', mock_data_dir)

  envName='EBS_MOCK_FEED_AUTOSTART'
  envVal='\""false"\"'
  cmd = 'if grep -q "export '+envName+'=" /export/home/'+CONFIG.get['APP_HOST_USER']+'/.bashrc 2>/dev/null; then'+"\n"\
		+'sed -i -e "s/export '+envName+'=.*/export '+envName+'='+envVal+'/g" /export/home/'+CONFIG.get['APP_HOST_USER']+'/.bashrc'+"\n"\
		+'source /export/home/'+CONFIG.get['APP_HOST_USER']+'/.bashrc'+"\n"\
	+'else'+"\n"\
		+'echo "export '+envName+'='+envVal+'" >> /export/home/'+CONFIG.get['APP_HOST_USER']+'/.bashrc'+"\n"\
		+'source /export/home/'+CONFIG.get['APP_HOST_USER']+'/.bashrc'+"\n"\
	+'fi'
  Actions.v 'Executing cmd: ' +cmd
  res = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15, true, '')
end


Then /^Sapphire App is launched$/  do
  cmd = CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_remote/env/sapphire-dev stop'
  res = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15, true, '')
  Actions.v 'Sapphire app stopped: '+res

  sleepTime = 15
  Actions.v 'Sleeping '+sleepTime.to_s+' seconds'
  sleep sleepTime.to_i

  Actions.v 'Sapphire processes for user "'+CONFIG.get['APP_HOST_USER']+'":'
  cmd = 'ps -f -U '+CONFIG.get['APP_HOST_USER']+'|grep node|grep -v grep'
  res = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15, true, '')
  # Actions.v 'ps_node after stop: '+res
  Actions.f 'Node processes found for current user after stopping Sapphire: '+"\n"+res.to_s.strip if(!res.to_s.strip.empty?)

  cmd = 'ps -f -U '+CONFIG.get['APP_HOST_USER']+'|grep redis|grep -v grep'
  res = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15, true, '')
  Actions.v 'ps_redis for current user after stopping Sapphire: '+res

  cmd = 'ps -aef'+'|grep node|grep -v grep'
  res = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15, true, '')
  # Actions.v 'ps_node after stop for all users: '+res
  Actions.f 'Node processes of some user(s) found after stopping Sapphire: '+"\n"+res.to_s.strip if(!res.to_s.strip.empty?)

  cmd = 'cd '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_remote/env && chmod 755 *'
  res = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15)
  sleep 5
  cmd = 'source /etc/profile; source ~/.bash_profile; source ~/.bashrc; '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_remote/env/sapphire-dev start'
  res = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 60, true, '')
  # cmd = CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_remote/env/sapphire-dev start'
  # res = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15, true, '')
  Actions.v 'Sapphire app launched: '+res

  timeToSleep = 300
  cmd = "ps -ef | grep node | grep order | grep -v grep | awk '{ print $2 }'" #taken from ps_sapphire.sh
  resultForLastProcess = nil
  while ( (timeToSleep > 0) &&
          ((resultForLastProcess == nil) || (resultForLastProcess == "")))
    Actions.v 'Waiting for Sapphire UI to be loaded'
    sleep 5
    timeToSleep -= 5
    resultForLastProcess = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'],
                                         CONFIG.get['APP_HOST_PWD'], cmd, 60, true, '')
  end
  if (timeToSleep <= 0)
    Actions.f "Sapphire UI processes wasn't loaded"
  end

  Actions.v 'Sapphire processes for user "'+CONFIG.get['APP_HOST_USER']+'":'
  cmd = 'ps -f -U '+CONFIG.get['APP_HOST_USER']+'|grep node|grep -v grep'
  res = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15, true, '')
  Actions.v 'ps_node after launching: '+res

  cmd = 'ps -f -U '+CONFIG.get['APP_HOST_USER']+'|grep redis|grep -v grep'
  res = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15, true, '')
  Actions.v 'ps_redis after launching: '+res

  cmd = 'ps -aef'+'|grep node|grep -v grep'
  res = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15, true, '')
  Actions.v 'ps_node after launching for all users: '+res
end


Then /^requests to play ESP mock data once are sent$/  do
  sleep 3

  begin
    uri = URI('http://'+CONFIG.get['APP_HOST_IP'].to_s+':'+CONFIG.get['SAPPHIRE_MOCK_FEEDER_PORT'].to_s+'/run?feeder=EURUSD_SPOT_SWEEP&actionType=once&param1=')
    Net::HTTP.get(uri)
    uri = URI('http://'+CONFIG.get['APP_HOST_IP'].to_s+':'+CONFIG.get['SAPPHIRE_MOCK_FEEDER_PORT'].to_s+'/run?feeder=EURUSD_SPOT_FULL&actionType=once&param1=')
    Net::HTTP.get(uri)
  rescue Exception=>e
    fail('Error: problem while sending request to Sapphire mock feeder "'+CONFIG.get['APP_HOST_IP'].to_s+':'+CONFIG.get['SAPPHIRE_MOCK_FEEDER_PORT'].to_s+'"'+"\n"+e.message)
  end
end



Then /^requests to play RFQ mock data once are sent$/  do
  sleep 3

  begin
    uri = URI('http://'+CONFIG.get['APP_HOST_IP'].to_s+':'+CONFIG.get['SAPPHIRE_MOCK_FEEDER_PORT'].to_s+'/run?feeder=EURUSD_SPOT_SWEEP&actionType=once&param1=')
    Net::HTTP.get(uri)
    uri = URI('http://'+CONFIG.get['APP_HOST_IP'].to_s+':'+CONFIG.get['SAPPHIRE_MOCK_FEEDER_PORT'].to_s+'/run?feeder=EURUSD_SPOT_FULL&actionType=once&param1=')
    Net::HTTP.get(uri)
  rescue Exception=>e
    fail('Error: problem while sending request to Sapphire mock feeder "'+CONFIG.get['APP_HOST_IP'].to_s+':'+CONFIG.get['SAPPHIRE_MOCK_FEEDER_PORT'].to_s+'"'+"\n"+e.message)
  end
end


Given /^ESP LPA simulator is launched$/  do
  Actions.v 'Launching ESP simulator...'
  cmd = 'cd '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/simESP/target/bin && nohup runSimRedirect.sh 1 1 /export/home/nui/simESP/target/data'
  res = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15)
end

Then /^verify ESP LPA simulator is launched$/  do
  simESP = CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/simESP'
  simEspTarget = "#{simESP}/target"
  Actions.v 'Launching ESP simulator...'
  cmd = " ps -ef | grep \"#{simEspTarget}\" | grep -v grep || " +
          "nohup #{simEspTarget}/bin/runSimRedirect.sh 1 1 #{simEspTarget}/data"
  res = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15)
end

Given /^RFQ LPR simulator is launched$/  do
  Actions.v 'Launching RFQ simulator...'
  cmd = 'cd '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/simESP/target/bin && nohup runSimRedirect.sh 1 1 /export/home/nui/simRFQ/target/data'
  res = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15)
end


Then /^ESP calculators files are cleaned$/  do
  Actions.v 'Cleaning ESP calculators files...'
  cmd = 'cd '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_local/logs/app-server && > PMDP_VWAP.log && > PMDP_LMT.log && > PMDP_FULL.log'
  res = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15)
end


Then /^RFQ calculators files are cleaned$/  do
  Actions.v 'Cleaning RFQ calculators files...'
  cmd = 'cd '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_local/logs/app-server && > PMDP_RFQ.log'
  res = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15)
end


Then /^ESP calculators files are downloaded$/  do
  steps %Q{
      Then ESP calculators files are cleaned
  }

  # sleep CONFIG.get['WaitForSimulator'].to_i
  Actions.rigthsForFile(CONFIG.get['APP_HOST_IP'],CONFIG.get['APP_HOST_USER'],CONFIG.get['APP_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/Automation','parse_sim_log.sh','755')
  cmd = 'cd '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/Automation && ./parse_sim_log.sh /export/home/nui/Automation/ESP_runSimRedirect.log'
  res = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 180, true, '')
  Actions.v res

  sleep 2
  Capybara.save_and_open_page_path = Dir.getwd + '/screenshots/'+@@time_stamp
  screenshot_and_save_page
  sleep 3

  Actions.v 'Downloading ESP calculators files...'
  downloadFileFromRemote(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], Dir.getwd+'/templates/new_sap_calculators', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_local/logs/app-server', 'PMDP_VWAP.log')
  downloadFileFromRemote(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], Dir.getwd+'/templates/new_sap_calculators', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_local/logs/app-server', 'PMDP_FULL.log')
  downloadFileFromRemote(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], Dir.getwd+'/templates/new_sap_calculators', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_local/logs/app-server', 'PMDP_LMT.log')
end


Then /^ESP calculators files with mock data are downloaded$/  do
  sleep 10
  UiHelpers.createAndShowScreenshot('Screenshot after Login,with expected prices')
  sleep 3

  Actions.v 'Downloading ESP calculators files...'
  sourceDir=Dir.getwd+'/templates/new_sap_calculators'
  targetDir=CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_local/logs/app-server'
  filesArr=['PMDP_VWAP.log','PMDP_FULL.log','PMDP_LMT.log']
  filesArr.each do |fileCurr|
    begin
      downloadFileFromRemote(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], sourceDir, targetDir, fileCurr)
    rescue Exception=>e
      fail('Failed to download "'+sourceDir+'/'+file+'" from '+CONFIG.get['APP_HOST_IP']+' as user "'+CONFIG.get['APP_HOST_USER']+'"'+"\n"+e.message)
    end
  end
end


Then /^RFQ calculators files are downloaded$/  do
  sleep 10
  UiHelpers.createAndShowScreenshot('Screenshot after login, with expected prices')
  sleep 3

  Actions.v 'Downloading RFQ calculators files...'
  sourceDir=Dir.getwd+'/templates/new_sap_calculators_rfq'
  targetDir=CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_local/logs/app-server'
  filesArr=['PMDP_RFQ.log']
  filesArr.each do |fileCurr|
    begin
      downloadFileFromRemote(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], sourceDir, targetDir, fileCurr)
    rescue Exception=>e
      fail('Failed to download "'+sourceDir+'/'+file+'" from '+CONFIG.get['APP_HOST_IP']+' as user "'+CONFIG.get['APP_HOST_USER']+'"'+"\n"+e.message)
    end
  end
end


Then /^user is logged in via UI$/  do
  loginToSapphireUI
end


Then /^for each price panel RFQ button is pressed, calculator file is cleaned, request to send RFQ mock data is sent$/  do
  counterPanels=0

  begin
    hashPricePanels = Panel.getPricePanelsHash
  rescue Exception=>e
    @@scenario_fails.push('Error while getting price panels data (getPricePanelsHash)')
    fail('Error while getting price panels data (getPricePanelsHash)'+' '+e.message)
  end
  hashPricePanels.each do |panelArrHash|
    # getting each panel's properties
    panelId=panelArrHash[1]['panelId'].to_s
    panelNodeElem=panelArrHash[1]['panelNodeElement']
    panelCcyPair=panelArrHash[1]['ccyPair'].to_s
    panelProductType=panelArrHash[1]['productType'].to_s
    panelPriceModel=panelArrHash[1]['priceModel'].to_s

    # clicking on RFQ button in each panel
    begin
      Panel.clickBtnRfqInPanel(panelNodeElem)
      counterPanels+=1
    rescue Exception=>e
           UiHelpers.createAndShowScreenshot('RFQ button is Not Found - Test Failed' , true)
           fail('Error while clicking on RFQ button in '+panelCcyPair+'-'+panelProductType+'-'+panelPriceModel+' panel with id "'+panelId+'"'+"\n"+e.message)
    end
  end

  sleep 10
  Actions.v 'Cleaning RFQ calculators files...'
  cmd = 'cd '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_local/logs/app-server && > PMDP_RFQ.log'
  res = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 15)

  sleep 5

  instrName='EURUSD_SPOT_FULL_RFQ'
  counter=0
  while counter!=counterPanels
    counter+=1
    begin
      uri = URI('http://'+CONFIG.get['APP_HOST_IP'].to_s+':'+CONFIG.get['SAPPHIRE_MOCK_FEEDER_PORT'].to_s+'/run?feeder=RFQ%3A'+instrName+'%3A'+counter.to_s+'&actionType=once&param1=')
      Net::HTTP.get(uri)
    rescue Exception => e
      fail('Error: problem while sending request for "'+instrName+'" to Sapphire mock feeder "'+CONFIG.get['APP_HOST_IP'].to_s+':'+CONFIG.get['SAPPHIRE_MOCK_FEEDER_PORT'].to_s+'"'+"\n"+e.message)
    end
  end
end


Then /^Sapphire App is stopped$/  do
   stopSapphireApp(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
end


Then /^templated ESP calculators files are compared vs given version$/  do
    compareCalculators(Dir.getwd+'/templates/old_sap_calculators',Dir.getwd+'/templates/new_sap_calculators/'+@@time_stamp)
end


Then /^templated RFQ calculators files are compared vs given version$/  do
   compareCalculators(Dir.getwd+'/templates/old_sap_calculators_rfq',Dir.getwd+'/templates/new_sap_calculators_rfq/'+@@time_stamp)
end


Then /^Setup DEFAULT entitlements in DB$/ do
  setupDefaultEntitlements()                   # Bug fix
end                                            # Somehow there are executions which don't recognize
                                               # Then /^Setup DEFAULT entitlements in DB$/ do
Then(/^setup DEFAULT entitlements in DB$/) do  # and need
  setupDefaultEntitlements()                   # Then(/^Setup DEFAULT entitlements in DB$/) do
end

Then /^setup entitlements in DB$/  do
  #user_index = ''
  #user_index = ENV['SAPPHIRE_SCHEMA'][-1,1] if(ENV['SAPPHIRE_SCHEMA'][-1,1].is_number?)
  user_index=$schema_index
  sapphireVersion = ENV["SAP_RELEASE_NUMBER"]
  $userUI=ENV['SapphireUiUser'] #'auto1@ebs.com'
  MARKET_TYPE_DIRECT = '0'
  MARKET_TYPE_MARKET = '1'
  MARKET_TYPE_WHITELABEL = '2'

  $current_sdata_schema='sdata'+user_index # @@CONFIG['SDATA_SCHEMA']
  $setup_ents= Actions.getHashMapFromCsvFile(Dir.getwd+'/features/support/entitlements.csv',true)

  Entitlements.deleteInstrumentsSdata($current_sdata_schema,$userUI)
  Entitlements.setupInstrumentsSdata($current_sdata_schema,$setup_ents)
  Entitlements.loadJsonEntitlements($current_sdata_schema,$userUI,ENV['SAP_RELEASE_NUMBER'])
  Entitlements.getAllDbListingsSdata($current_sdata_schema)
  $all_db_tenors = Entitlements.getAllDbTenorsSdata

  $user_ents=Actions.getDbQueryResults4Clob('sdata'+user_index,"select asd_util_pkg.getUserEntitlement('"+$userUI+"', "+MARKET_TYPE_DIRECT+")from dual") if sapphireVersion.to_i==5
  if sapphireVersion.to_i==6 #Sapphire version
    $user_ents_direct=Actions.getDbQueryResults4Clob('sdata'+user_index,"select asd_util_pkg.getUserEntitlement2('"+$userUI+"', "+MARKET_TYPE_DIRECT+")from dual")
    $user_ents_market=Actions.getDbQueryResults4Clob('sdata'+user_index,"select asd_util_pkg.getUserEntitlement2('"+$userUI+"', "+MARKET_TYPE_MARKET+")from dual")
  end

  Entitlements.compareJsonUiVsDB(true)
end


Then /^entitlements setup is matched for floors-products-currencies-calculators-tenors$/  do
  #UiHelpers.setHowToHandleFailure()
  panel_number = 1
  $panel = Panel.new($ui, "number", panel_number)
  $current_ui_user = ENV['SapphireUiUser']
  $db_floors=$setup_ents.uniq{|e| e['FLOOR']}.collect{|e| e['FLOOR']}


  ui_floors = $panel.getPanelDDValues2(Globals.panelDDFloor)
  Actions.v 'ui_floors: '+ ui_floors.to_s if !ui_floors.nil?
  Actions.v 'db_floors: '+ $db_floors.to_s if !$db_floors.nil?
  if(ui_floors!=$db_floors)
    Actions.f 'ui_floors: '+ui_floors.to_s if !ui_floors.nil?
    Actions.f 'db_floors: '+$db_floors.to_s if !$db_floors.nil?
    #UiHelpers.createAndShowScreenshot("Mismatch between db_floors and ui calculators",true)
    next
  end
  ui_floors.each{|floor|
    Actions.v 'Setting FLOOR: ' + floor
    $panel.setFloor(floor)
    ui_ccys = $panel.getPanelDDValues2(Globals.panelDDCCY)
    Actions.v 'ui_ccys: '+ui_ccys.to_s if !ui_ccys.nil?
    $db_ccys=$setup_ents.select{|e| e['FLOOR']==floor}.collect{|e| e['BASE_CCY']+"/"+e['COUNTER_CCY']}.uniq
    Actions.v 'db_ccys: '+$db_ccys.to_s if !$db_ccys.nil?
    ui_ccys_sorted=ui_ccys.sort{ |a,b| a <=> b }
    $db_ccys=$db_ccys.sort{ |a,b| a <=> b }
    if(ui_ccys_sorted!=$db_ccys)
      Actions.f 'ui_ccys: '+ui_ccys_sorted.to_s+" - #{floor} " if !ui_ccys_sorted.nil?
      Actions.f 'db_ccys: '+$db_ccys.to_s+" - #{floor} " if !$db_ccys.nil?
      #UiHelpers.createAndShowScreenshot("Mismatch between db_ccys and ui_ccys",true)
      #next
    end

    ui_ccys.each{|ccy|

      Actions.v 'Setting CCY: ' + ccy
      $panel.setCurrencyPair(ccy)
      selected_ccy_pair = $panel.getCurrentClosedDDValue2(Globals.panelDDCCY).split("/")
      selected_product_type = $panel.getCurrentClosedDDValue2(Globals.panelDDProductType)
      selected_product_type = Entitlements.getDbProductTypeFromUiProductType(selected_product_type)
      current_panel_entitled=Entitlements.getSetupEntitlements($setup_ents,floor,selected_product_type,selected_ccy_pair[0],selected_ccy_pair[1],$current_ui_user)
      if(!current_panel_entitled)
        message_appear=Entitlements.isPanelNotEntitledMessageAppear?(panel_number.to_s)
        if(!message_appear)
          err_msg = 'floor: '+floor+' ccy_pair: '+selected_ccy_pair[0]+'/'+selected_ccy_pair[1]+' product: '+selected_product_type+' - should NOT be entitled '
          Actions.f(err_msg)
          UiHelpers.createAndShowScreenshot("Message 'NOT ENTITLED' SHOULD appear",true)
        else
          if(message_appear && current_panel_entitled)
            err_msg = 'floor: '+floor+' ccy_pair: '+selected_ccy_pair[0]+'/'+selected_ccy_pair[1]+' product: '+selected_product_type+' - SHOULD be entitled '
            Actions.f(err_msg)
            UiHelpers.createAndShowScreenshot("Message 'NOT ENTITLED' should NOT appear",true)
          else
            Actions.v "'Not Entitled' message is validated for floor: "+floor+' ccy_pair: '+selected_ccy_pair[0]+'/'+selected_ccy_pair[1]+' product: '+selected_product_type
          end
        end
        next
      else
        panel=Entitlements.getSetupEntitlements($setup_ents,floor,selected_product_type,selected_ccy_pair[0],selected_ccy_pair[1],$userUI)
        ui_calculators = $panel.getPanelDDValues2(Globals.panelDDCalcType)
        ui_calculators.delete_if{|v| v.to_s.upcase=="IND"}
        ui_calculators_sorted=ui_calculators.sort{ |a,b| a <=> b }
        Actions.v 'ui_calculators: '+ui_calculators_sorted.to_s if !ui_calculators_sorted.nil?
        db_calculators=Entitlements.getSetupEntitledPriceModelArray(panel)
        Actions.v 'db_calculators: '+db_calculators.to_s if !db_calculators.nil?
        if(ui_calculators!=db_calculators)
          Actions.f 'ui_calculators: '+ui_calculators_sorted.to_s+" - #{floor} , #{selected_product_type} , #{selected_ccy_pair.to_s}" if !ui_calculators_sorted.nil?
          Actions.f 'db_calculators: '+db_calculators.to_s+" - #{floor} , #{selected_product_type} , #{selected_ccy_pair.to_s}" if !db_calculators.nil?
          #UiHelpers.createAndShowScreenshot("Mismatch between db_calculators and ui_calculators",true)
          #next
        end

        ui_calculators.each{|calc|
          next if calc.to_s.upcase=="IND"
          selected_calc_type = $panel.getCurrentClosedDDValue2(Globals.panelDDCalcType)
          Actions.v 'selected_calc_type: ' +selected_calc_type
          if calc!=selected_calc_type
            Actions.v 'Setting calculator: '+calc.to_s if !calc.nil?
            $panel.setPanelDDMenu(Globals.panelDDCalcType,calc)
          end
          err_msg = 'calculator: '+calc+'floor: '+floor+' ccy_pair: '+selected_ccy_pair[0]+'/'+selected_ccy_pair[1]+' product: '+selected_product_type+' - SHOULD be entitled '
          Entitlements.displayErrorIfNotEntitledMessageAppear(panel_number.to_s,err_msg)
          Entitlements.isCalcTypeEntitled?(panel,calc,true)
        }

        ui_products = $panel.getPanelDDValues2(Globals.panelDDProductType)
        Actions.v 'ui_products: '+ui_products.to_s if !ui_products.nil?
        db_products = Entitlements.getAvailableProductTypesArray($setup_ents,floor,selected_ccy_pair[0],selected_ccy_pair[1],selected_ccy_pair[0]+'/'+selected_ccy_pair[1])
        Actions.v 'db_products: '+db_products.to_s if !db_products.nil?
        ui_products_converted=ui_products.sort{ |a,b| a <=> b }
        ui_products_converted= ui_products_converted.collect{|ui_product| ui_product=Entitlements.getDbProductTypeFromUiProductType(ui_product) }
        Actions.v 'ui_products_converted: '+ui_products_converted.to_s if !ui_products_converted.nil?
        db_products=db_products.sort{ |a,b| a <=> b }
        if(ui_products_converted!=db_products)
          Actions.f 'ui_products: '+ui_products_converted.to_s+" - #{floor} , #{selected_product_type} , #{selected_ccy_pair.to_s}" if !ui_products_converted.nil?
          Actions.f 'db_products: '+db_products.to_s+" - #{floor} , #{selected_product_type} , #{selected_ccy_pair.to_s}" if !db_products.nil?
          #UiHelpers.createAndShowScreenshot("Mismatch between db_products and ui_products",true)
          #next
        end
        ui_products.each_with_index { |product,index|
          if Entitlements.getUiProductTypeFromDbProductType(selected_product_type)!=product
            Actions.v 'Selecting product: '+product
            $panel.setPanelDDMenu2(Globals.panelDDProductType,product)
          end

          selected_product_type = $panel.getCurrentClosedDDValue2(Globals.panelDDProductType)
          selected_product_type = Entitlements.getDbProductTypeFromUiProductType(selected_product_type)
          current_panel=Entitlements.getSetupEntitlements($setup_ents,floor,selected_product_type,ccy.split("/")[0],ccy.split("/")[1],$current_ui_user)
          Entitlements.clickAndCancelRfqIfEntitled(panel_number.to_s,current_panel,$ui,'')

          selected_product_type = $panel.getCurrentClosedDDValue2(Globals.panelDDProductType)
          ui_tenors = $panel.getPanelDDValues2(Globals.panelDDTenor,['More...'])
          Actions.v 'ui_tenors: '+ui_tenors.to_s if !ui_tenors.nil?
          db_product_type = Entitlements.getDbProductTypeFromUiProductType(selected_product_type)
          panel=Entitlements.getSetupEntitlements($setup_ents,floor,db_product_type,selected_ccy_pair[0],selected_ccy_pair[1],$userUI)
          db_tenors=Entitlements.getSetupEntitledTenorsArray($all_db_tenors,panel)
          db_tenors=db_tenors.flatten if(!db_tenors.nil?)
          Actions.v 'db_tenors: '+db_tenors.to_s if(!db_tenors.nil?)
          if(ui_tenors!=db_tenors)
            Actions.f 'ui_tenors: '+ui_tenors.to_s+" - #{floor} , #{selected_product_type} , #{selected_ccy_pair.to_s}" if !ui_tenors.nil?
            Actions.f 'db_tenors: '+db_tenors.to_s+" - #{floor} , #{selected_product_type} , #{selected_ccy_pair.to_s}" if !db_tenors.nil?
            #UiHelpers.createAndShowScreenshot("Mismatch between db_tenors and ui_tenors",true)
            #next
          end
          ui_tenors.each_with_index{|tenor,index|
            next if tenor==ui_tenors.to_a.last
            if index>0
              Actions.v 'Setting tenor: ' + tenor.to_s
              $panel.setPanelDDMenu2('tenors',tenor)
            end
            if(db_tenors.to_a.include?(tenor))
              err_msg = 'tenor: '+tenor+' floor: '+floor+' ccy_pair: '+selected_ccy_pair[0]+'/'+selected_ccy_pair[1]+' product: '+selected_product_type+' - SHOULD be entitled '
              Entitlements.displayErrorIfNotEntitledMessageAppear(panel_number.to_s,err_msg)
            end
            if(!db_tenors.to_a.include?(tenor))
              err_msg = 'tenor: '+tenor+' floor: '+floor+' ccy_pair: '+selected_ccy_pair[0]+'/'+selected_ccy_pair[1]+' product: '+selected_product_type+' - should NOT be entitled '
              Entitlements.displayErrorIfNotEntitledMessageDoesntAppear(panel_number.to_s,err_msg)
            end
            selected_product_type = $panel.getCurrentClosedDDValue2(Globals.panelDDProductType)
            selected_product_type = Entitlements.getDbProductTypeFromUiProductType(selected_product_type)
            current_panel=Entitlements.getSetupEntitlements($setup_ents,floor,selected_product_type,ccy.split("/")[0],ccy.split("/")[1],$current_ui_user)
            Entitlements.clickAndCancelRfqIfEntitled(panel_number.to_s,current_panel,$ui,tenor)
          }
        }
      end
    }
  }

end


def compareCalculators(template_dir_path,target_dir_path)
  # template_dir_path = Dir.getwd+'/templates/old_sap_calculators' #"C:/Sap_Calc_Files"
  # target_dir_path = Dir.getwd+'/templates/new_sap_calculators/'+@@time_stamp #+ '/'+@@timestamp  #'C:\Automation\pmdp'
  template_dir = Dir.entries(template_dir_path)
  target_dir = Dir.entries(target_dir_path)

  fail('No files found in template dir: '+template_dir_path) if(template_dir.nil? || template_dir.length==0)
  fail('No files found in target dir: '+target_dir_path) if(target_dir.nil? || target_dir.length==0)

  Actions.f 'Removed files '+(template_dir-target_dir).to_s if(template_dir.length > target_dir.length)
  Actions.f 'Added files '+(target_dir-template_dir).to_s if(target_dir.length > template_dir.length)

  exclusion = @@CONFIG['SAPPHIRE_JSON_EXCLUDED_FIELDS']
  Actions.c '<b>Comparing Sapphire panels...</b>'
  Actions.c('Excluded fields in compare: '+exclusion.to_s)

  struct_str=''
  if !CONFIG.get['SAPPHIRE_JSON_EXCLUDED_OBJECTS'].to_s.empty?
    struct_str<< '<table style="border: 100px;">'
    struct_str<< '<tr><td><b>Objects</b></td>'
    struct_str<< '<td><b>Excluded fields</b></td></tr>'

    CONFIG.get['SAPPHIRE_JSON_EXCLUDED_OBJECTS'].each {|elCurr|
      if !elCurr.to_s.empty?
        addition='all fields'

        struct_str<< '<tr><td><b>"'+elCurr[0].to_s+'"</b></td>'
        addition = addition+' except '+elCurr[1].to_s if(!elCurr[1].to_s.empty?)
        struct_str<< '<td><b>'+addition+'</b></td></tr>'
      end
    }
    struct_str<< '</table>'
    Actions.c('Objects with excluded fields:'+"\n"+struct_str)
  end

  Actions.c 'Source files'
  Actions.displayFilesForDownloadInFolder(template_dir_path)
  Actions.c 'Target files'
  Actions.displayFilesForDownloadInFolder(target_dir_path)

  (template_dir & target_dir).each { |file|
    @@json_fails=[]
    Actions.v 'Comparing '+file+' file' if (!File.directory?(file))
    Actions.compareSapphireOutputJsons2(template_dir_path+'/'+file, target_dir_path+'/'+file) if(!File.directory?(file))
  }
end


def loginToSapphireUI(killingBrowser=true)
  # killingBrowser=false if ENV['debug'].to_bool
  # if killingBrowser
  #   WINCMD("taskkill -f -im chrome.exe", 10, '')
  #   WINCMD("taskkill -f -im chromedriver.exe", 10, '')
  # end

  begin
    $ui = UiHelpers.new(Capybara.page, Capybara.current_driver)
    Capybara.app_host = @@CONFIG['SapphireLoginUrl'] #'https://10.20.42.87:8900/' 87/88
    username = @@CONFIG['SapphireUiUser'] #'auto1@ebs.com' 'shay@ebs.com' 'andrey@ebs.com'
    $ui.signInToSapphire(username,'',Capybara.app_host)
    sleep 5
  rescue Exception=>e
    UiHelpers.createAndShowScreenshot('Unable to login: test failed', true)
    @@scenario_fails.push('Error: user is not logged in (logout button not found)')
    fail('Error: user is not logged in (logout button not found)'+"\n"+e.message)
  end

  begin
    find(Controls.get('btnLogout'))
  rescue Exception=>e
    UiHelpers.createAndShowScreenshot('Unable to find logout button after login', true)
    @@scenario_fails.push('Error: logout button not found after login')
    fail('Error: logout button not found after login'+"\n"+e.message)
  end
end


def insertToSapphireDb(query)
  Actions.insertToDbWithCommit('sapphire','sapphire',query)
end


def insertToSapphireCustomDb(query, schema, passwd)
  Actions.insertToDbWithCommit(schema,passwd,query)
end


def WINCMD(cmd, timeout_sec, expected_output)
  Actions.v 'Executing local win command ' + cmd + (!expected_output.to_s.empty? ? ' expected_output - ' + expected_output : '')
  begin
    session_timeout = Integer(timeout_sec) rescue nil
    $cmd_output =[]
    if (session_timeout)
      timeout session_timeout do
        IO.popen(cmd).each do |line|
          #p line.chomp
          $cmd_output  << line.chomp
        end
      end
    else
      IO.popen(cmd).each do |line|
        p line.chomp
        $cmd_output  << line.chomp
      end
    end
    #Actions.c  ('WinCMD  Response: ' + $cmd_output.to_s)
    fail('Expected Regex Not Found in CMD output: ' + expected_output ) if (!expected_output.to_s.empty? && !$cmd_output.to_s =~ expected_output.to_s)

  rescue Exception => e
    @@scenario_fails.push(e.message)
    Actions.f "Local WinCmd Error: " + e.to_s if (e!=nil)
    fail("Local WinCmd Error: " + e.to_s ) if (e!=nil)
  ensure
    #IO.close
  end


  fail('Local WinCmd  FAILED - ' + $cmd_output.to_s) if ( $cmd_output.to_s.downcase.include?('not found') || $cmd_output.to_s.downcase.include?('error')  || $cmd_output.to_s.downcase.include?('not recognized'))

  return $cmd_output

end

def setupDefaultEntitlements()
  if (ENV["SAP_RELEASE_NUMBER"].to_s == "6")
    csvFilename = Dir.getwd+'/features/support/default_entitlements.csv'
  else
    csvFilename = Dir.getwd+'/features/support/default_entitlements_ver5.csv'
  end
  sleep 3
  $userUI=ENV['SapphireUiUser'] #'auto1@ebs.com'
  $current_sdata_schema='sdata'+$schema_index #from step Config is matched

  $default_setup_ents= Actions.getHashMapFromCsvFile(csvFilename,true)

  Entitlements.deleteInstrumentsSdata($current_sdata_schema,$userUI)
  Entitlements.setupInstrumentsSdata($current_sdata_schema,$default_setup_ents)
  Entitlements.loadJsonEntitlements($current_sdata_schema,$userUI,ENV['SAP_RELEASE_NUMBER'])
  Entitlements.getAllDbListingsSdata($current_sdata_schema)
  $all_db_tenors = Entitlements.getAllDbTenorsSdata
end