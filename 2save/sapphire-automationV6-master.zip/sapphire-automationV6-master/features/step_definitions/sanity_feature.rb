require 'cucumber'
require 'net/ssh'
require 'net/scp'
require 'time'
require 'thread'
require 'thwait'

begin
  require '../../features/helpers/Actions'
  require Dir.getwd+'/features/helpers/UiHelpers'
rescue LoadError
end

@@config_sql_templates = '\\\\10.20.30.168\\Config_Sql_Templates'


Given /^Optional Sdata schema and Optional Ptrade schema and App are built for LAB$/ do
  Actions.isIpValidInParams
  CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']
  CONFIG.get['CORE_HOST'] = CONFIG.get['CORE_HOST_IP']

  ENV['PTRADE_NEW_APP_VERSION_OU'] = ENV['PTRADE_NEW_SCHEMA_VERSION_OU'] if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)

  steps %Q{
      Given beforeDeploymentScenarioSteps
  }

  Actions.createLocalDirsTemplatesLogsDb

  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    CONFIG.get['SDATA_SCHEMA'] = 'sdata' if(CONFIG.get['SAPPHIRE_SCHEMA']=='sapphire')
    CONFIG.get['SDATA_SCHEMA'] = 'sdata1' if(CONFIG.get['SAPPHIRE_SCHEMA']=='sapphire1')

    steps %Q{
      Given Automation dir exists on oracle server2
      Given DB Sdata Custom Schema is built for LAB
    }

    CONFIG.get['PTRADE_SCHEMA'] = 'ptrade' if(CONFIG.get['SAPPHIRE_SCHEMA']=='sapphire')
    CONFIG.get['PTRADE_SCHEMA'] = 'ptrade1' if(CONFIG.get['SAPPHIRE_SCHEMA']=='sapphire1')

    if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
      displayDbSchemaVersion2('SDATA')
    elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
      displayDbSchemaVersion2('SDATA1')
    end
  else
    Actions.c '<b>NOT deploying SDATA from scratch</b>'
  end


  if(!CONFIG.get['DEPLOY_PTRADE'].nil? && CONFIG.get['DEPLOY_PTRADE'].to_s.downcase=='true')
    steps %{
      Given Automation dir exists on oracle server2
      Given Automation dir exists on ptrade server2
   }

    if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
      displayDbSchemaVersion2('SDATA')
    elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
      displayDbSchemaVersion2('SDATA1')
    end

    stopRegularPtradeServiceNoFails(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
    if(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
      customPtradeSchemaDeployLab(nil)
    else
      customPtradeSchemaDeployLab(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'])
    end
    displayDbSchemaVersion2('PTRADE')

    if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)
      customPtradeAppDeployLab(nil)
    else
      customPtradeAppDeployLab(ENV['PTRADE_NEW_APP_VERSION_OU'])
    end
    displayPtradeAppOnlyVersion2(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  else
    Actions.v '<b>NOT deploying PTRADE from scratch</b>'
  end

end


Given /^Optional Sdata Sap schema and Optional Ptrade Sap schema and App are built for LAB$/ do
  Actions.isIpValidInParams
  CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']
  CONFIG.get['CORE_HOST'] = CONFIG.get['CORE_HOST_IP']

  ENV['PTRADE_NEW_APP_VERSION_OU'] = ENV['PTRADE_NEW_SCHEMA_VERSION_OU'] if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)

  steps %Q{
      Given beforeDeploymentScenarioSteps
  }

  Actions.createLocalDirsTemplatesLogsDb

  sdataInstall=true
  if CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true'
    Actions.c '<b>Installing SDATA...</b>'
    Actions.c 'SDATA_SCHEMA: <b>'+CONFIG.get['SDATA_SCHEMA']+'</b>, SDATA_SQL_TEMPLATE: <b>'+CONFIG.get['SDATA_SQL_TEMPLATE']+'</b>'

    path_config = @@config_sql_templates
    cmd = 'IF exist '+ @@config_sql_templates +'\ ( echo Dir exists ) ELSE ( echo Dir DOES NOT exist )'
    res = Actions.WINCMD(cmd, 20, 'Dir')
    # if res.to_s.strip == 'Dir exists'
    if res.to_s.strip.include?('Dir exists')
      Actions.WINCMD('copy /Y '+path_config+'\\'+CONFIG.get['SDATA_SQL_TEMPLATE']+' '+Dir.getwd.gsub('/','\\')+'\templates\bash', 20 ,'file')
    else
      fail('Error: sql config directory "'+path_config+'" not found, exiting')
    end

    if (CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
      storagePath = '/export/home/oracle/build_server/Releases/db_sdata'
      tarFilter1 = 'db_sdata_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['MOUNT_HOST'], CONFIG.get['MOUNT_USER'], CONFIG.get['MOUNT_PWD'], cmd, 45, true, '')
      @@CONFIG['SDATA_NEW_SCHEMA_VERSION_OU'] = res.to_s.strip
    end
    Actions.setBuildProperty('SDATA_SCHEMA_VERSION',CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])
    Actions.setBuildProperty('SDATA_SCHEMA_VERSION_packageName',CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])
    Actions.c 'Given SDATA_SCHEMA_VERSION: "'+CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s+'"'

    steps %Q{
      Given DB Sdata Sap Custom Schema is built for LAB
    }
  else
    Actions.p '<b>NOT installing SDATA</b>'
    sdataInstall=false
  end

  ### temporary fix from Raz for sdata 6 ###
    Actions.v 'Temporary fix for SDATA'

    fixScript = %q(
    begin
    update schema_version set version_id=63;
    commit;
    end;
  )
    Actions.insertToDbWithCommit(CONFIG.get['SDATA_SCHEMA'].to_s.downcase, CONFIG.get['SDATA_SCHEMA'].to_s.downcase, fixScript)
  ### end of temporary fix from Raz for sdata 6 ###

  displayDbSchemaVersion4(CONFIG.get['SDATA_SCHEMA'])
  if sdataInstall==false
    if !Actions.getBuildProperty('SDATA_SCHEMA_VERSION').nil?
      sdataSchemaVersion=Actions.getBuildProperty('SDATA_SCHEMA_VERSION')
      sdataSchemaVersion=sdataSchemaVersion.to_s.downcase.gsub('sdata', '') if(sdataSchemaVersion.to_s.downcase.include?('sdata'))
      sdataSchemaVersion=sdataSchemaVersion.to_s.downcase.gsub('ver', '') if(sdataSchemaVersion.to_s.downcase.include?('ver'))
      Actions.setBuildProperty('SDATA_SCHEMA_VERSION_packageName',sdataSchemaVersion)
    else
      Actions.v 'Cannot find "SDATA_SCHEMA_VERSION" in build.properties'
      Actions.setBuildProperty('SDATA_SCHEMA_VERSION_packageName','UNKNOWN')
    end
  end

  if CONFIG.get['DEPLOY_PTRADE'].to_s.downcase=='true'
    Actions.c '<b>Installing PTRADE...</b>'
    Actions.c 'PTRADE_SCHEMA: <b>'+CONFIG.get['PTRADE_SCHEMA']+'</b>, PTRADE_SQL_TEMPLATE: <b>'+CONFIG.get['PTRADE_SQL_TEMPLATE']+'</b>'
    cmd = 'copy /Y ' + @@config_sql_templates +'\\'+CONFIG.get['PTRADE_SQL_TEMPLATE']+' '+Dir.getwd.gsub('/','\\')+'\templates\bash'
    Actions.WINCMD(cmd, 20 ,'file')

    displayDbSchemaVersion2(CONFIG.get['SDATA_SCHEMA'])

    stopRegularPtradeServiceNoFails(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

    if (CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
      storagePath = '/export/home/oracle/build_server/Releases/PTS'
      tarFilter1 = 'PTS_MAIN'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['MOUNT_HOST'], CONFIG.get['MOUNT_USER'], CONFIG.get['MOUNT_PWD'], cmd, 45, true, '')
      @@CONFIG['PTRADE_NEW_SCHEMA_VERSION_OU'] = res.to_s.strip
    end
    Actions.setBuildProperty('PTRADE_SCHEMA_VERSION',CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'])
    Actions.c 'Given PTRADE_SCHEMA_VERSION: "'+CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s+'"'

    if(CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
      customPtradeSchemaDeployLab(nil,CONFIG.get['PTRADE_SCHEMA'],CONFIG.get['PTRADE_SQL_TEMPLATE'])
      customPtradeAppDeployLab(nil,CONFIG.get['PTRADE_SCHEMA'])
    else
      customPtradeSchemaDeployLab(CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'],CONFIG.get['PTRADE_SCHEMA'],CONFIG.get['PTRADE_SQL_TEMPLATE'])
      customPtradeAppDeployLab(CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'],CONFIG.get['PTRADE_SCHEMA'])
    end
  else
    Actions.p '<b>NOT installing PTRADE</b>'
  end

  displayDbSchemaVersion4(CONFIG.get['PTRADE_SCHEMA'])
  displayPtradeAppOnlyVersion3(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end


Given /^Sapphire Schema and App are built for LAB$/ do
  Actions.isIpValidInParams
  CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']

  ENV['SAPPHIRE_APP_VERSION'] = ENV['SAPPHIRE_APP_VERSION'] if(ENV['SAPPHIRE_APP_VERSION'].nil? && ENV['SAPPHIRE_APP_VERSION'].to_s.empty?)
  steps %Q{
      Given beforeScenarioSteps
  }

  Actions.createLocalDirsTemplatesLogsDb
  steps %Q{
    Given Automation dir exists on oracle server2
  }

  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    steps %Q{
      Given DB Sdata Custom Schema is built for LAB
    }
  else
    Actions.c '<b>NOT deploying SDATA from scratch</b>'
  end
  displayDbSchemaVersion2('SDATA')


  if(!CONFIG.get['DEPLOY_PTRADE'].nil? && CONFIG.get['DEPLOY_PTRADE'].to_s.downcase=='true')
    steps %{
     Given Automation dir exists on ptrade server2
   }
    stopRegularPtradeServiceNoFails(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
    if(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
      customPtradeSchemaDeployLab(nil)
    else
      customPtradeSchemaDeployLab(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'])
    end
    displayDbSchemaVersion2('PTRADE')

    if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)
      customPtradeAppDeployLab(nil)
    else
      customPtradeAppDeployLab(ENV['PTRADE_NEW_APP_VERSION_OU'])
    end
    displayPtradeAppOnlyVersion2(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  else
    Actions.v '<b>NOT deploying PTRADE from scratch</b>'
  end

end


Given /^Config is Updated by Automation for user sapphire$/ do
  Actions.v 'Updating Environments.yml for user sapphire...'
  fail('Missing App or DB credentials [ip,port,service - ???]') if @@CONFIG['APP_HOST_IP'].nil? || @@CONFIG['APP_HOST_IP'].to_s.empty? || @@CONFIG['ORACLE_HOST'].nil? || @@CONFIG['ORACLE_HOST'].to_s.empty? || @@CONFIG['ORACLE_HOST_PORT'].nil? || @@CONFIG['ORACLE_HOST_PORT'].to_s.empty? || @@CONFIG['ORACLE_HOST_SERVICE'].nil? || @@CONFIG['ORACLE_HOST_SERVICE'].to_s.empty?
  @@CONFIG['IdmLogoutUrl']='//'+@@CONFIG['APP_HOST_IP']+':8900'
  @@CONFIG['GatewayURLs']='//'+@@CONFIG['APP_HOST_IP']+':9000'
  @@CONFIG['OracleTns']='(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST='+@@CONFIG['ORACLE_HOST'].to_s+')(PORT='+@@CONFIG['ORACLE_HOST_PORT'].to_s+'))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME='+@@CONFIG['ORACLE_HOST_SERVICE'].to_s+')))'
end


Given /^Config is Updated by Automation for user sapphire1$/ do
  Actions.v 'Updating Environments.yml for user sapphire1...'
  fail('Missing App or DB credentials [ip,port,service - ???]') if @@CONFIG['APP_HOST_IP'].nil? || @@CONFIG['APP_HOST_IP'].to_s.empty? || @@CONFIG['ORACLE_HOST'].nil? || @@CONFIG['ORACLE_HOST'].to_s.empty? || @@CONFIG['ORACLE_HOST_PORT'].nil? || @@CONFIG['ORACLE_HOST_PORT'].to_s.empty? || @@CONFIG['ORACLE_HOST_SERVICE'].nil? || @@CONFIG['ORACLE_HOST_SERVICE'].to_s.empty?
  @@CONFIG1['IdmLogoutUrl']='//'+@@CONFIG['APP_HOST_IP']+':8900'
  @@CONFIG1['GatewayURLs']='//'+@@CONFIG['APP_HOST_IP']+':9000'
  @@CONFIG1['OracleTns']='(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST='+@@CONFIG1['ORACLE_HOST'].to_s+')(PORT='+@@CONFIG1['ORACLE_HOST_PORT'].to_s+'))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME='+@@CONFIG1['ORACLE_HOST_SERVICE'].to_s+')))'

  @@CONFIG1['OracleUser']='sapphire1'
  @@CONFIG1['OraclePassword']='sapphire1'
  @@CONFIG1['ManualDefaultsFile']='/export/home/nui1/sapphire-installer.json'
  @@CONFIG1['SapphirePostTradeRedisPort']=@@CONFIG1['SAPPHIRE_REDIS1_HOST1_MONITOR_PORT']
  @@CONFIG1['PfxFilePath']='/export/home/nui1/sapphire_remote/env/dev.pfx'
end


Given /^Automation dir exists on sapphire server for user sapphire$/ do
  Actions.v 'Creating Automation dir on sapphire server for user "sapphire"...'
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_APP_TEMPLATE_DIR_PATH']
  res = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 10, true, '')
end


Given /^Automation dir exists on sapphire server for given sapphire user$/ do
  Actions.v 'Creating Automation dir on sapphire server for user "'+CONFIG.get['APP_HOST_USER']+'"...'
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_APP_TEMPLATE_DIR_PATH']
  res = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 10, true, '')
end


Given /^Automation dir exists on sapphire server for user sapphire1$/ do
  Actions.v 'Creating Automation dir on sapphire server for user "sapphire1"...'
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_APP_TEMPLATE_DIR_PATH']
  res = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER1'], CONFIG.get['APP_HOST_PWD'], cmd, 10, true, '')
end


Given /^Scripts are uploaded to sapphire server for user sapphire$/ do
  Actions.v 'Uploading bash scripts on sapphire server for user "sapphire"...'
  uploadDir2RemoteAutomationFolder(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], Dir.getwd+'/templates/bash_sapphire', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/Automation')
end


Given /^Scripts are uploaded to sapphire server for sapphire user$/ do
  Actions.v 'Uploading bash scripts on sapphire server...'
  cmd = 'copy /Y ' + @@config_sql_templates +'\\'+CONFIG.get['SAPPHIRE_SQL_TEMPLATE']+' '+Dir.getwd.gsub('/','\\')+'\templates\bash_sapphire'
  Actions.WINCMD(cmd, 20 ,'file')
  uploadDir2RemoteAutomationFolder(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], Dir.getwd+'/templates/bash_sapphire', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/Automation')
end


Given /^Scripts are uploaded to sapphire server for given sapphire user$/ do
  Actions.v 'Uploading bash scripts on sapphire server for user "'+CONFIG.get['APP_HOST_USER']+'"...'
  cmd = 'copy /Y ' + @@config_sql_templates  + '\\'+CONFIG.get['SAPPHIRE_SQL_TEMPLATE']+' '+Dir.getwd.gsub('/','\\')+'\templates\bash_sapphire'
  Actions.WINCMD(cmd, 20 ,'file')
  uploadDir2RemoteAutomationFolder(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], Dir.getwd+'/templates/bash_sapphire', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/Automation')
end


Given /^Scripts uploaded sapphire server for user sapphire1$/ do
  Actions.v 'Uploading bash scripts on sapphire server for user "sapphire1"...'
  uploadDir2RemoteAutomationFolder(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER1'], CONFIG.get['APP_HOST_PWD'], Dir.getwd+'/templates/bash_sapphire', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/Automation')
end


Given /^App config is updated for user sapphire$/ do
  Actions.v 'Updating app config for user "sapphire"...'
  # updateSapphireAppConfigBackend(CONFIG.get['APP_HOST_USER'],@@CONFIG,Dir.getwd+'/templates/new_sapphire_config/backend-env.json')
  # updateSapphireAppConfigFrontend(CONFIG.get['APP_HOST_USER'],@@CONFIG,Dir.getwd+'/templates/new_sapphire_config/frontend-env.json')
  uploadDir2RemoteAutomationFolder(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], Dir.getwd+'/templates/sap_app_config', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_remote/env')
end


Given /^App mock config is updated$/ do
  Actions.v 'Updating app config for user "'+CONFIG.get['APP_HOST_USER']+'"...'
  # updateSapphireAppConfigBackend(CONFIG.get['APP_HOST_USER'],@@CONFIG,Dir.getwd+'/templates/new_sapphire_config/backend-env.json')
  # updateSapphireAppConfigFrontend(CONFIG.get['APP_HOST_USER'],@@CONFIG,Dir.getwd+'/templates/new_sapphire_config/frontend-env.json')
  uploadDir2RemoteAutomationFolder(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], Dir.getwd+'/templates/sap_app_config_mock', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_remote/env')

  cmd = 'chmod -R 755 '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER']+'/sapphire_remote/env'
  res = Actions.SSH(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'], cmd, 25, true, '')
end


Given /^App config is updated for user sapphire1$/ do
  Actions.v 'Updating app config for user "sapphire1"...'
  # updateSapphireAppConfigBackend(CONFIG.get['APP_HOST_USER1'],@@CONFIG1,Dir.getwd+'/templates/old_sapphire_config/backend-env.json')
  # updateSapphireAppConfigFrontend(CONFIG.get['APP_HOST_USER1'],@@CONFIG1,Dir.getwd+'/templates/old_sapphire_config/frontend-env.json')
  uploadDir2RemoteAutomationFolder(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER1'], CONFIG.get['APP_HOST_PWD'], Dir.getwd+'/templates/sap1_app_config', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['APP_HOST_USER1']+'/sapphire_remote/env')
end


Given /^DB Schema is deployed for user sapphire$/ do
  fail('Please define missing param "ORACLE_HOST_IP"') if (CONFIG.get['ORACLE_HOST_IP'].nil?)
  fail('Please specify branch for download as sapphire-release-beta[2,3,4] ...etc') if @@CONFIG['SAPPHIRE_JOB_NAME'].nil?
  Actions.v 'Deploying schema for user "sapphire"...'

  CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']

  sapphireSchemaDeployLab(nil) if(CONFIG.get['SAPPHIRE_APP_VERSION'].nil? && CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)
  sapphireSchemaDeployLab(CONFIG.get['SAPPHIRE_APP_VERSION']) if(!CONFIG.get['SAPPHIRE_APP_VERSION'].nil? && !CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)

  displayDbSchemaVersion3(CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SCHEMA'])
end


Given /^DB Sap Schema is deployed for user sapphire$/ do
  fail('Please define missing param "ORACLE_HOST_IP"') if (CONFIG.get['ORACLE_HOST_IP'].nil?)
  fail('Please specify branch for download as sapphire-release-beta[2,3,4] ...etc') if @@CONFIG['SAPPHIRE_JOB_NAME'].nil?

  Actions.c 'SAPPHIRE_SCHEMA: <b>'+CONFIG.get['SAPPHIRE_SCHEMA']+'</b>, SAPPHIRE_SQL_TEMPLATE: <b>'+CONFIG.get['SAPPHIRE_SQL_TEMPLATE']+'</b>'

  CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']

  if (CONFIG.get['SAPPHIRE_APP_VERSION'].nil? || CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)
    storagePath = '/export/home/oracle/build_server/Releases/EBS-UI/'+CONFIG.get['SAPPHIRE_JOB_NAME']
    tarFilter1 = 'sapphire_full_'
    tarFilter2 = '.tar.gz'
    cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
    res = Actions.SSH(CONFIG.get['MOUNT_HOST'], CONFIG.get['MOUNT_USER'], CONFIG.get['MOUNT_PWD'], cmd, 45, true, '')
    @@CONFIG['SAPPHIRE_APP_VERSION'] = res.to_s.strip
  end

  sapphireSchemaDeployLab(nil,CONFIG.get['SAPPHIRE_SCHEMA'],CONFIG.get['SAPPHIRE_SQL_TEMPLATE']) if(CONFIG.get['SAPPHIRE_APP_VERSION'].nil? && CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)
  sapphireSchemaDeployLab(CONFIG.get['SAPPHIRE_APP_VERSION'],CONFIG.get['SAPPHIRE_SCHEMA'],CONFIG.get['SAPPHIRE_SQL_TEMPLATE']) if(!CONFIG.get['SAPPHIRE_APP_VERSION'].nil? && !CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)

  displayDbSchemaVersion3(CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SCHEMA'])
end


Given /^DB Sap Schema is deployed for given sapphire user$/ do
  fail('Please define missing param "ORACLE_HOST_IP"') if (CONFIG.get['ORACLE_HOST_IP'].nil?)
  fail('Please specify branch for download as sapphire-release-beta[2,3,4] ...etc') if @@CONFIG['SAPPHIRE_JOB_NAME'].nil?

  if ENV['DEPLOY_SAPPHIRE_DB'].to_s.downcase != 'false'
    Actions.c '<b>Installing SAPPHIRE...</b>'
    Actions.c 'SAPPHIRE_SCHEMA: <b>'+CONFIG.get['SAPPHIRE_SCHEMA']+'</b>, SAPPHIRE_SQL_TEMPLATE: <b>'+CONFIG.get['SAPPHIRE_SQL_TEMPLATE']+'</b>'

    CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']

    if (CONFIG.get['SAPPHIRE_APP_VERSION'].nil? || CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)
      Actions.v 'Getting the latest package name...'
      storagePath = '/export/home/oracle/build_server/Releases/EBS-UI/'+CONFIG.get['SAPPHIRE_JOB_NAME']
      tarFilter1 = 'sapphire_full_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['MOUNT_HOST'], CONFIG.get['MOUNT_USER'], CONFIG.get['MOUNT_PWD'], cmd, 45, true, '')
      @@CONFIG['SAPPHIRE_APP_VERSION'] = res.to_s.strip
    end
    Actions.setBuildProperty('SAP_APP_VERSION', CONFIG.get['SAPPHIRE_APP_VERSION'])
    Actions.setBuildProperty('SAP_APP_VERSION_packageName', CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.downcase.gsub('sapphire_full_', 'sapphire_').gsub('.tar.gz', ''))
    Actions.p 'SAP_APP_VERSION: "'+CONFIG.get['SAPPHIRE_APP_VERSION'].to_s+'"'

    sapphireSchemaDeployLab(nil, CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SQL_TEMPLATE']) if (CONFIG.get['SAPPHIRE_APP_VERSION'].nil? && CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)
    sapphireSchemaDeployLab(CONFIG.get['SAPPHIRE_APP_VERSION'], CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SQL_TEMPLATE']) if (!CONFIG.get['SAPPHIRE_APP_VERSION'].nil? && !CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)
  else
    Actions.p '<b>NOT deploying Sapphire DB</b>'
  end

  displayDbSchemaVersion3(CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SCHEMA'])
end


Given /^DB Schema is deployed for user sapphire1$/ do
  fail('Please specify branch for download as sapphire-release-beta[2,3,4] ...etc') if @@CONFIG1['SAPPHIRE_JOB_NAME'].nil?
  Actions.v 'Deploying schema for user "sapphire1"...'

  sapphireSchemaDeployLab(nil) if(CONFIG.get['SAPPHIRE_APP_VERSION'].nil? && CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)
  sapphireSchemaDeployLab(CONFIG.get['SAPPHIRE_APP_VERSION']) if(!CONFIG.get['SAPPHIRE_APP_VERSION'].nil? || !CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)

  displayDbSchemaVersion2('SAPPHIRE1')
end


Given /^App is deployed for user sapphire$/ do
  fail('Please specify branch for download as sapphire-release-beta[2,3,4] ...etc') if @@CONFIG['SAPPHIRE_JOB_NAME'].nil?
  Actions.v 'Deploying App for user "sapphire"...'

  sapphireAppDeployLab(nil) if(CONFIG.get['SAPPHIRE_APP_VERSION'].nil? && CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)
  sapphireAppDeployLab(CONFIG.get['SAPPHIRE_APP_VERSION']) if(!CONFIG.get['SAPPHIRE_APP_VERSION'].nil? || !CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)

  Actions.displaySapphireAppOnlyVersion2(CONFIG.get['APP_HOST_IP'],CONFIG.get['APP_HOST_USER'],CONFIG.get['APP_HOST_PWD'])
end


Given /^App is deployed for given sapphire user$/ do
  fail('Please specify branch for download as sapphire-release-beta[2,3,4] ...etc') if @@CONFIG['SAPPHIRE_JOB_NAME'].nil?

  if ENV['DEPLOY_SAPPHIRE_APP'].to_s.downcase != 'false'
    Actions.c 'Deploying App for user "'+CONFIG.get['APP_HOST_USER']+'"...'

    @@CONFIG['SAPPHIRE_DB_EXTRACT_FOLDER']=''
    @@CONFIG['SAPPHIRE_APP_INSTALL_FOLDER']=CONFIG.get['REMOTE_APP_TEMPLATE_DIR_PATH']+'/sapphire_installed'

    sapphireAppDeployLab(nil) if (CONFIG.get['SAPPHIRE_APP_VERSION'].nil? && CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)
    sapphireAppDeployLab(CONFIG.get['SAPPHIRE_APP_VERSION']) if (!CONFIG.get['SAPPHIRE_APP_VERSION'].nil? || !CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)
  else Actions.p '<b>NOT deploying Sapphire App</b>'
  end

  Actions.displaySapphireAppOnlyVersion2(CONFIG.get['APP_HOST_IP'],CONFIG.get['APP_HOST_USER'],CONFIG.get['APP_HOST_PWD'])
end


Given /^App is deployed for user sapphire1$/ do
  fail('Please specify branch for download as sapphire-release-beta[2,3,4] ...etc') if @@CONFIG1['SAPPHIRE_JOB_NAME'].nil?
  Actions.v 'Deploying App for user "sapphire1"...'

  sapphireAppDeployLab(nil) if(CONFIG.get['SAPPHIRE_APP_VERSION'].nil? && CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)
  sapphireAppDeployLab(CONFIG.get['SAPPHIRE_APP_VERSION']) if(!CONFIG.get['SAPPHIRE_APP_VERSION'].nil? || !CONFIG.get['SAPPHIRE_APP_VERSION'].to_s.empty?)

  Actions.displaySapphireAppOnlyVersion2(CONFIG.get['APP_HOST_IP'],CONFIG.get['APP_HOST_USER1'],CONFIG.get['APP_HOST_PWD'])
end



def updateSapphireAppConfigBackend(user,config,file_path)
  Actions.v 'Updating backend-env.json for user '+user
  backend=nil
  backend=Actions.getHashFromJsonFile(file_path) if user==CONFIG.get['APP_HOST_USER1']
  backend=Actions.getHashFromJsonFile(file_path) if user==CONFIG.get['APP_HOST_USER']
  fail('Invalid user: '+user+' ONLY '+CONFIG.get['APP_HOST_USER']+' or '+CONFIG.get['APP_HOST_USER1']+' permitted') if(backend.nil?)

  begin
    b=JSON.parse(backend, :quirks_mode => true)
    b['config']['backend-node']['data']['redis']['host']=config['APP_HOST_IP']
    f=File.open(file_path,'w')
    f.write(b.to_json)
  rescue Exception=>e
    fail('JSON file Exception: '+e.to_s) if(!e.nil? && !e.to_s.empty?)
  ensure
    f.close if(!f.nil?)
  end

end


def updateSapphireAppConfigFrontend(user,config,file_path)
  Actions.v 'Updating frontend-env.json for user '+user
  frontend=nil
  frontend=Actions.getHashFromJsonFile(file_path) if user==CONFIG.get['APP_HOST_USER1']
  frontend=Actions.getHashFromJsonFile(file_path) if user==CONFIG.get['APP_HOST_USER']
  fail('Invalid user: '+user+' ONLY '+CONFIG.get['APP_HOST_USER']+' or '+CONFIG.get['APP_HOST_USER1']+' permitted') if(frontend.nil?)

  begin
    b=JSON.parse(frontend, :quirks_mode => true)
    b['config']['backend-node']['data']['redis']['host']=config['APP_HOST_IP']
    f=File.open(file_path,'w')
    f.write(b.to_json)
  rescue Exception=>e
    fail('JSON file Exception: '+e.to_s) if(!e.nil? && !e.to_s.empty?)
  ensure
    f.close if(!f.nil?)
  end

end