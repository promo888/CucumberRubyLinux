require 'cucumber'
require 'net/ssh'
require 'net/scp'
require 'time'

require 'cucumber'
require 'capybara'
require 'capybara/dsl'
require 'capybara/cucumber'
require 'capybara/session'
require 'capybara/selenium/driver'
require 'selenium/webdriver'
require 'capybara-screenshot'
#require 'rspec'
require 'capybara/rspec'

begin
  require '../../features/helpers/Actions'
  require '../../features/helpers/Config.rb'
  require Dir.getwd+'/features/helpers/UiHelpers'
  include Config
rescue LoadError
end

Given /^Code Tested$/  do



end