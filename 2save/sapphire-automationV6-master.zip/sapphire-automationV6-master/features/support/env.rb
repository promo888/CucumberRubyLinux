require 'time'
require 'cucumber'
require 'capybara'
require 'capybara/dsl'
require 'capybara/cucumber'
require 'capybara/session'
require 'capybara/selenium/driver'
require 'selenium/webdriver'
begin
  require '../../features/helpers/Actions'
rescue LoadError
end

automation_log_counter=0
Before do
  $world = self

  $dunit ||= false
  # return 0 if($dunit)

  if !$dunit
    @@email_properties = {}
    time = Time.new
    @@time_stamp= time.day.to_s+'-'+time.month.to_s+'-'+time.year.to_s+'_'+time.hour.to_s+'-'+time.min.to_s+'-'+time.sec.to_s #Time.now.to_i.to_s
    @@automation_log_file='automation_log_'+automation_log_counter.to_s+'.html'
    automation_log_counter+=1
    @@automation_logs_folder_path=Dir.getwd+'/logs'
    Actions.WINCMD_NO_FAIL('mkdir '+@@automation_logs_folder_path, 10)
    @@automation_log_file_path=Dir.getwd+'/logs/'+@@automation_log_file
    @@automation_build_file_path=Dir.getwd+'/config/build.properties'
    @@run_fails = []
    # @@scenario_fails = []

    killingBrowser=false if(ENV['debug'].to_s.downcase=='true')
    if killingBrowser
      WINCMD("taskkill -f -im chrome.exe", 10, '')
      WINCMD("taskkill -f -im chromedriver.exe", 10, '')
    end

    File.open(@@automation_log_file_path, 'w')
    File.open(@@automation_build_file_path, 'w')
    Actions.setBuildProperty('SAP_APP_VERSION','Failed')
    Actions.setBuildProperty('SAP_APP_VERSION_packageName','Failed')
    Actions.setBuildProperty('SDATA_SCHEMA_VERSION_packageName','Failed')
    Actions.setBuildProperty('SDATA_SCHEMA_VERSION','Failed')
    Actions.setBuildProperty('PTRADE_SCHEMA_VERSION','Failed')
    Actions.setBuildProperty('PTRADE_APP_VERSION','Failed')
    Actions.setBuildProperty('DEPLOY','Failed')
    Actions.setBuildProperty('STATUS','Failed')

    $dunit = true
  end
end
World(Capybara::DSL)


Before do |scenario|
  $world = self
  time = Time.new
  @@time_stamp= time.day.to_s+'-'+time.month.to_s+'-'+time.year.to_s+'_'+time.hour.to_s+'-'+time.min.to_s+'-'+time.sec.to_s #Time.now.to_i.to_s
  @@automation_log_file='automation_log_'+automation_log_counter.to_s+'.html'
  automation_log_counter+=1
  @@automation_log_file_path=Dir.getwd+'/logs/'+@@automation_log_file
  @@automation_build_file_path=Dir.getwd+'/config/build.properties'
  @@current_scenario_tag = scenario.source[1].tags[0].name.to_s
  @@scenario_fails = []
  # @@run_fails = []
  @@entitlements = {}

  File.open(@@automation_log_file_path, 'w')

  Capybara.register_driver :selenium do |app|
    caps = Selenium::WebDriver::Remote::Capabilities.chrome("chromeOptions" => {"args" => ["--start-maximized", "--disable-web-security", "--window-size=1920,1080", "--disable-popup-blocking"]})
    Capybara::Selenium::Driver.new(app, {:browser => :chrome, :desired_capabilities => caps})
  end
  @@session = Capybara::Session.new :chrome
  Capybara.default_driver = :selenium
  Capybara.current_driver = :selenium
  Capybara.default_wait_time = 120
  Capybara.default_selector = :css
  Capybara.javascript_driver = :chrome
  @@WebPageDriver=Capybara.page.driver
  @@screenshots_path = Dir.getwd+'/screenshots/'+@@time_stamp
  Capybara.save_and_open_page_path = @@screenshots_path
  #Capybara.current_session.driver.browser.manage.window.resize_to(1680, 1050)

  $VERBOSE = nil

  if ((scenario.source[1].tags[0].name.to_s.include?('--ui')) &&
      (ENV['WITHOUT_DEPLOYMENT_AND_STOP'].to_s != "true"))
    # stopSapphireApp(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
    stopSapphireAppAsRoot(ENV['APP_HOST_IP'])
    #TODO kill Simulator proc
  end
end


After do |scenario|

  Actions.v 'Starting post-scenario tasks...'

  #saving versions to file for email
  # Actions.v 'Saving build versions for emailing'
  # file = File.new(Dir.getwd+'/config/build.properties','w+')
  # @@email_properties.each_key{|key,value|
  #   begin
  #     file.puts "#{key}=#{@@email_properties[key]}\n"
  #   rescue Exception=>e
  #     self.f('ERROR on write build properties '+ e.message)
  #   end
  # }

  #sapphire calculators
  if scenario.source[1].tags[0].name.to_s.include?('--ui')
    if ENV['debug'].to_s.downcase != 'true'
      stopSapphireApp(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'])
      #TODO kill Simulator proc
     else
       Actions.v 'Not stopping Sapphire: found "--ui" in the tag, but debug = true'
    end
  end

  # if scenario.source[1].tags[0].name.to_s.include?('@sapphire_calculators_esp_mock')
    #unsetting Sapphire env var
    #Actions.setEnvVar(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'], CONFIG.get['APP_HOST_PWD'],'AUTOMATION_PACKAGE_NAME_SAP_APP_'+CONFIG.get['APP_HOST_USER'],'NOT_SET')
  # end

  begin
    Capybara.page.driver.quit
  rescue Exception=>e
    Actions.v 'Unable to close Capybara page driver in After scenario of ' +scenario.to_s
  end

  if Dir.getwd.include?(@@CONFIG['JENKINS_JOB_NAME'])
    log_file_path = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME'].to_s+'/ws/logs/'+@@automation_log_file
  else
    log_file_path = Dir.getwd+'/logs/'+@@automation_log_file
  end
  Actions.p "<a href='"+log_file_path.to_s+"'>Click to view detailed execution log: "+@@automation_log_file+'</a>'

  Actions.v '@@scenario_fails: "'+@@scenario_fails.to_s+'"'
  Actions.v '@@run_fails: "'+@@run_fails.to_s+'"'
  if !@@scenario_fails.empty?
    @@run_fails.push('Scenario "'+scenario.source[1].tags[0].name.to_s+'" failed')
    Actions.f('Scenario failed. See errors in red')
  end

  if !scenario.source[1].tags[1].nil?
    if scenario.source[1].tags[1].name.to_s.include?('@final')
      Actions.v 'Final post-scenario'
      Actions.v '@@scenario_fails: "'+@@scenario_fails.to_s+'"'
      Actions.v '@@run_fails: "'+@@run_fails.to_s+'"'
      failed = Actions.isBuildPropertyFailed?(['SAP_APP_VERSION', 'SAP_APP_VERSION_packageName', 'SDATA_SCHEMA_VERSION', 'SDATA_SCHEMA_VERSION_packageName', 'PTRADE_SCHEMA_VERSION', 'PTRADE_APP_VERSION'])
      Actions.setBuildProperty('DEPLOY', 'Passed') if (!failed)
      Actions.setBuildProperty('STATUS', 'Passed') if (@@run_fails.empty? && Actions.getBuildProperty('DEPLOY').to_s.downcase == 'passed')
      Actions.setBuildProperty('STATUS', 'Diff or error found') if (!@@run_fails.empty? && Actions.getBuildProperty('DEPLOY').to_s.downcase == 'passed') #TODO: @@errors_found
      Actions.setBuildProperty('STATUS', 'Setup failed') if (Actions.getBuildProperty('DEPLOY').to_s.downcase == 'failed')
    end
  end

  if !@@scenario_fails.empty?
    UiHelpers.createAndShowScreenshot('Errors list: ' +@@scenario_fails.to_s,true)
    scenario.fail('')
  end
end


# After do #after(:all)
# end


Around('@test') do |scenario, block|
  Timeout.timeout(600) do
    block.call
   # puts '@test TIMEOUT'
  end
end

Around('@sanity') do |scenario, block|
  Timeout.timeout(3600) do
    block.call
  end
end

Around('@calculators_esp_mock') do |scenario, block|
  Timeout.timeout(1200) do
    block.call
  end
end

Around('@calculators_rfq_mock_without_deployment') do |scenario, block|
  Timeout.timeout(600) do
    block.call
  end
end

Around('@datepicker') do |scenario, block|
  Timeout.timeout(600) do
    block.call
  end
end

Around('@sapphire_calculators') do |scenario, block|
  Timeout.timeout(1200) do
    block.call
  end
end


Around('@sanity-sdata-only') do |scenario, block|
  #Actions.displaySanityLogs(true, true, false, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(1200) do
    block.call
  end
end

Around('@sanity-with-sdata-oldAndNewVsUpgrade2') do |scenario, block|
  #Actions.displaySanityLogs(true, true, true, true) if(!@@scenario_fails.empty?)
  Timeout.timeout(1800) do
    block.call
  end
end

### Custom Builds

Around('@sdata_and_ptrade_lab') do |scenario, block|
  #Actions.displaySanityLogs(true, false, true, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i) do
    block.call
  end
end

Around('@sdata_lab') do |scenario, block|
  #Actions.displaySanityLogs(true, false, true, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i) do
    block.call
  end
end

Around('@ptrade_lab') do |scenario, block|
  #Actions.displaySanityLogs(true, false, true, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i) do
    block.call
  end
end

Around('@ptrade_upgrade_lab') do |scenario, block|
  #Actions.displaySanityLogs(true, false, false, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i) do
    block.call
  end
end

Around('@ptrade_scratch_and_upgrade_lab') do |scenario, block|
  #Actions.displaySanityLogs(true, false, false, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i) do
    block.call
  end
end