SELECT "dealDate", "instrument", "executionCpty", "cpAccount", "bs", "tenor", "tenorValue", "valueDate", "dealtCcy", "contraCcy", "dealtAmount", "dealtAmountExp", "contraAmount", "contraAmountExp", "price", "priceExp", "fwdPoints", "fwdPointsExp", "points", "pointsExp", "tradeDate", "ticketId", "id", "product", "floor", "fundCode", "traderId", "ecn", "segment", "mt", "cptyTraderId", "fixDate", "orderId", "institutionKey", "domain", "legType", "scn_id" 
FROM (
      SELECT rownum r, t.* 
      from (
           SELECT TXN_TIME as "dealDate", INSTR_SYMBOL as "instrument", ECP_ACCOUNT as "executionCpty", CP_ACCOUNT as "cpAccount", FP_SIDE as "bs", TENOR_TYPE as "tenor", TENOR_VALUE as "tenorValue", DATE_SETTLEMENT as "valueDate", CCY_DEALT as "dealtCcy", CCY_CONTRA as "contraCcy", QTY_DEALT as "dealtAmount", QTY_DEALT_EXP as "dealtAmountExp", QTY_CNTR as "contraAmount", QTY_CNTR_EXP as "contraAmountExp", PX_EFFECTIVE as "price", PX_EFFECTIVE_EXP as "priceExp", PX_FWDP_ALLIN as "fwdPoints", PX_FWDP_EXP as "fwdPointsExp", PX_SWAP_POINTS as "points", POINTS_EXP as "pointsExp", TRADE_DATE as "tradeDate", TICKET_ID as "ticketId", EXEC_ID as "id", INSTR_PRODUCT_TYPE as "product", FP_FLOOR as "floor", UDF_DESIGNATED_FUND as "fundCode", FP_TRADER as "traderId", ECN as "ecn", ALGO_TYPE as "segment", FP_EXEC_SIDE as "mt", CP_TRADER as "cptyTraderId", DATE_MATURITY as "fixDate", EFP_EBS_ORDER_ID as "orderId", FP_INSTITUTION_KEY as "institutionKey", DOMAIN_ID as "domain", LEG_TYPE as "legType", dbms_flashback.get_system_change_number as "scn_id" 
           FROM V_SAP_TICKETS 
           WHERE (FP_INSTITUTION_KEY = 1227 AND DOMAIN_ID = 0 AND FP_TRADER = 'IK5') 
           ORDER BY TXN_TIME DESC) t 
      WHERE rownum <= 201) 
WHERE r > 0
