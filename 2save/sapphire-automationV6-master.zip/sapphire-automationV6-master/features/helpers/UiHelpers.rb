require 'cucumber'
require 'capybara'
require 'capybara/dsl'
require 'capybara/cucumber'
require 'capybara-screenshot'
require 'capybara/rspec'
require 'date'
#require 'selenium/webdriver'

  begin
  require_relative('Controls')
  require_relative('Actions')
  require_relative('Globals')
rescue LoadError
  raise "Couldn't load Controls.rb\n"
end

class UiHelpers
  #include "capybara/dsl"

  @@logFilenameHTML = 'log.html'
  @@messagesToLogHTML = []
  @page = nil
  @driver = nil
  @capybara_driver = nil

  def initialize(page, capybara_driver)
    @capybara_driver = capybara_driver
    @page = page
    @driver = @page.driver

    $c = Controls.new()
    $panelNumById = {}
    log "New UiHelpers created"
  end

  def log(message)
    parentFunc =  caller_locations(1).first.label
    Controls.log(message, File.basename(__FILE__), parentFunc.to_s)
  end

  def UiHelpers.setHowToHandleFailure(onFailureRaiseException = true, onFailureAddToScenarioFails = false,
                                      onFailureWriteToActionsF = false, onFailureCreateScreenshot = false)
    $onFailureRaiseException      = onFailureRaiseException
    $onFailureAddToScenarioFails  = onFailureAddToScenarioFails
    $onFailureWriteToActionsF     = onFailureWriteToActionsF
    $onFailureCreateScreenshot    = onFailureCreateScreenshot
  end

  def UiHelpers.throw(message, onFailureRaiseException = nil, onFailureAddToScenarioFails = nil,
                      onFailureWriteToActionsF = nil, onFailureCreateScreenshot = nil)

    if (onFailureCreateScreenshot == nil)
      onFailureCreateScreenshot = $onFailureCreateScreenshot
    end
    if (onFailureCreateScreenshot == true)
      UiHelpers.createAndShowScreenshot(message)
    end

    if (onFailureAddToScenarioFails == nil)
      onFailureAddToScenarioFails = $onFailureAddToScenarioFails
    end
    if (onFailureAddToScenarioFails == true)
      @@scenario_fails.push(message)
    end

    if (onFailureWriteToActionsF == nil)
      onFailureWriteToActionsF = $onFailureWriteToActionsF
    end
    if (onFailureWriteToActionsF == true)
      Actions.f message
    end

    if (onFailureRaiseException == nil)
      onFailureRaiseException = $onFailureRaiseException
    end
    if (onFailureRaiseException == true)
      parentFunc =  caller_locations(1).first.label
      Controls.log("Exception in #{parentFunc}, #{message}", File.basename(__FILE__), parentFunc.to_s)
      raise message
    end
  end

  def UiHelpers.createAndShowScreenshot(description=' ',error=false)
    screenshotPath = Dir.getwd+'/screenshots/'+@@time_stamp
    log "Saving screenshot to: #{screenshotPath}"
    Capybara.save_and_open_page_path = screenshotPath
    #Capybara::Screenshot.screenshot_and_save_page
    #Actions.displayScreenshotsInFolder(screenshotPath)
    screenshot_file = "#{Time.now.strftime('%Y-%m-%d %H-%M-%S')}.png"
    Capybara.page.save_screenshot(screenshotPath+'/'+screenshot_file)
    sleep 0.3
    Actions.displayScreenshotsAsLinksInReport(screenshotPath+'/'+screenshot_file,description,error)
  end

  def UiHelpers.verifyThereAreNoErrorsAfterLogin()
    maxTimeToVerify = 3
    foundConnectionDown = false
    for i in 1 .. maxTimeToVerify
      bodyText = Capybara.page.all(:css, "body")[0].text
      if (bodyText =~ /CONNECTION DOWN/i)
        UiHelpers.throw("CONNECTION DOWN message", false, false, true, true)
        foundConnectionDown = true
      end
      sleep 1
    end

    if (foundConnectionDown)
      UiHelpers.throw("CONNECTION DOWN message was found, verify that gateway is up", true, true, true, true)
    end
  end

  def UiHelpers.convertAmount(amount, option = Globals.convertAmountShortString)
    case option
      when Globals.convertAmountShortString
        amount = amount.gsub(/[\,\s]/, "") # 5 , 000 , 000 -> 5000000
        amount = (amount.to_f) / 1000000   # 5000000 -> 5
        if (amount >= 1)                   # 5 -> 5M , 0.5 -> 0.5M
          amount = amount.to_i
        end
        amount = amount.to_s + "M"
      when Globals.convertAmountLongNumberWithCommas
        amount = amount.gsub(/M/, "")     # 3M -> 3 , 0.5M -> 0.5
        amount = (amount.to_i) * 1000000  # 3 -> 3000000, 0.5 -> 500000
        amount = amount.to_s.reverse.gsub(/(\d\d\d)/, '\1,').sub(/\,$/, "").reverse
                                            # 3000000 -> 3,000,000   500000  -> 500,000
    end

    return amount
  end

  def UiHelpers.replaceInFile(filePath, string, newString)
    lines = IO.readlines(filePath)
    for line in lines
      if (line[string])
        line[string] = newString
      end
    end
    f = File.open(filePath, "w")
    for line in lines
      f.puts(line)
    end
    f.close
  end

  def UiHelpers.getChromeDownloadLocationBasedOnPropertiesFile()
    defaultDirectory = "#{ENV['UserProfile']}\\Downloads"
    begin
      if (ENV['UserProfile'] != nil)
        log "In Winodws, getting default location from settings file"
        chromeSettingsPath = "#{ENV['UserProfile']}\\AppData\\Local\\Google\\chrome\\User Data\\default\\Preferences"
        f = File.open(chromeSettingsPath)
        textFromFile = f.read
        f.close()
        if (textFromFile != nil)
          defaultDirectory = JSON.parse(textFromFile)["download"]["default_directory"]
        end
      end
    rescue
      defaultDirectory = "#{ENV['UserProfile']}\\Downloads"
    end

    return defaultDirectory
  end

  def UiHelpers.filterFromArrayOfHashes(arrayOfHashes, keysToFilter, includeKeys = true, clone = true)
    toReturn = arrayOfHashes
    if (clone)
      toReturn = toReturn.clone
    end
    if (includeKeys)
      toReturn = toReturn.map {|h| h.select {|k,v| keysToFilter.include?(k)}}
    else
      toReturn = toReturn.map {|h| h.select {|k,v| (! keysToFilter.include?(k))}}
    end
    return toReturn
  end

  def sleepSeconds(seconds)
    begin
      sleep seconds
    rescue => e
      UiHelpers.throw("sleep failed (error: #{e.message.to_s})", true, true, true, true)
    end
  end

  def getValueOrTextOrInnerHTML(element, getInnerHTMLIfOtherNotFound = true)
    exceptionIfNil(element)

    textVal = ""
    begin
    textVal = element.text
    rescue
    end

    if (textVal == "")
      begin
        textVal = getAttribute(element, "value")
        if ((textVal == "") && (getInnerHTMLIfOtherNotFound))
          textVal = getInnerHTML(element)
        end
      rescue
      end
    end

    return textVal
  end

  def getControls()
    return $c
  end

  def getDriver()
    return @driver
  end

  def dragAndDrop(sourceWebElement, targetWebElement)
    driver = getBaseElement()
    driver.mouse.down(sourceWebElement)
    sleep 1
    driver.mouse.move_to(targetWebElement, 0, 10)
    driver.mouse.up
  end

  def doubleClick(webElement)
    driver = getDriver()
    driver.browser.action.double_click(webElement).perform()
  end

  def waitForElementWithCss(css, baseElement, messageWhileWaiting = Globals.messageWaitingForElement,
                            messageIfNotFound=Globals.messageElementNotFound,
                            messageIfFound=Globals.messageElementFound)
    exceptionIfNil(css, baseElement)

    e = nil
    for numberOfSecondsToWait in 1..4 do
      begin
        e = firstWithCss(css, nil, baseElement)
      rescue
      end

      if ((e == nil) || (e == ""))
        log(messageWhileWaiting)
      else
        log(messageIfFound)
        break
      end

      sleep numberOfSecondsToWait
    end
    if (e == nil)
      UiHelpers.throw messageIfNotFound
    end

    return e
  end

  def seleniumGetCurrentWindowHandle()
    return @driver.browser.window_handle
  end

  def seleniumChangeWindowsResolution(x, y)
    driver = getBaseElement()
    driver.manage.window.resize_to(x, y)
  end

  def seleniumGetCurrentResolution()
    driver = getBaseElement()
    objectDimention = driver.manage.window.size
    y = objectDimention.height.to_i
    x = objectDimention.width.to_i
    return {Globals.resolutionX => x, Globals.resolutionY => y}
  end

  def javascriptIsElementVisible(webElement)
    isVisible = false
    res = nil
    begin
      driver = getBaseElement()
      res = driver.execute_script("return arguments[0].offsetParent", webElement)
    rescue => e
      log "Error found: #{e.message}"
    end

    if (res != nil)
      isVisible = true
    end

    return isVisible
  end

  def changeResolution(direction=Globals.resolutionHigher)
    x = Globals.resolutionX
    y = Globals.resolutionY
    currentRes = seleniumGetCurrentResolution()
    currentResX = currentRes[x]
    currentResY = currentRes[y]
    arr = $uiDefaults["windowSize"]
    resToSet = nil

    case direction
      when Globals.resolutionHighest
        resToSet = arr[arr.length - 1]
      when Globals.resolutionLowest
        resToSet = arr[0]
      else
        arr.each do |res|
          resX = res[x].to_i
          resY = res[y].to_i
          if (((direction == Globals.resolutionHigher) && (resX > currentResX) && (resY > currentResY)) ||
              ((direction == Globals.resolutionLower)  && (resX < currentResX) && (resY < currentResY)) )
            resToSet = res
            break
          end
        end
    end

    if (resToSet != nil)
      seleniumChangeWindowsResolution(resToSet[x], resToSet[y])
    else
      UiHelpers.throw Globals.messageNoResolutionToSet
    end
  end

  def closeWindowsThatAreNot(windowHandleToExclude)
    if (windowHandleToExclude == nil)
      UiHelpers.throw Globals.messageMissingParams
    end
    arr = @driver.browser.window_handles
    arr.each do |h|
      if (h == windowHandleToExclude)
        log Globals.messageExcludeWindow
        next
      end

      log Globals.messageCloseWindow
      @driver.browser.switch_to.window h
      @driver.browser.close
      @driver.browser.switch_to.window windowHandleToExclude
    end
  end

  def getBaseElement()
    return @driver.browser
  end

  def getFloorsFromDB()
      query = "select NODE_NAME from NODES_BIN t where institution =(select INSTITUITION from v_asd_users where email='"+@@CONFIG['SapphireUiUser'].to_s+"')"
      res =Actions.getDbQueryForSapphire(CONFIG.get['SDATA_SCHEMA'],query)
      floors = res.each.collect{|floor| floor["NODE_NAME"]}
      return floors
  end

  def getAllowedRfqLPsFromDB()
    defaultAllowedLPs = getLPsOnFromDefaultEntitlements()
    query = "select node_name from  nodes_bin WHERE is_rfq_lp_floor = 1"
    res = Actions.getDbQueryForSapphire(CONFIG.get['SDATA_SCHEMA'],query)
    lps = res.each.collect{|lp| lp["NODE_NAME"]}
    lps = lps & defaultAllowedLPs
    return lps
  end

  def getLPsOnFromDefaultEntitlements()
    lps = getLPsHashFromDefaultEntitlements()
    res = lps.select{|k,v|  v == "on"}.keys
    return res
  end

  def getLPsHashFromDefaultEntitlements()
    if (! $uiDefaults)
      UiHelpers.throw("$uiDefault is required in this method")
    end
    res = $uiDefaults['allowed']['settings']['liquiditySources']
    return res
  end

  def getFloorKeyFromDB(floorName)
    query = "select FLOOR_KEY from NODES_BIN t WHERE NODE_NAME = '#{floorName.to_s}'"
    res =Actions.getDbQueryForSapphire(CONFIG.get['SDATA_SCHEMA'],query)
    floorKey = res[0].values[0]
    return floorKey
  end

  def getUsersDataDB(dataToSearch = "*")
    sql = "SELECT #{dataToSearch} FROM v_asd_users WHERE user_name = '#{ENV["SapphireUiUser"]}'"
    data = Actions.getDbQueryResults(CONFIG.get['SDATA_SCHEMA'], CONFIG.get['SDATA_SCHEMA'], sql)
    if (data.nil? || data.empty?)
      UiHelpers.throw "No data from DB"
    end
    return data
  end

  # Searches inside base element for first element with css .
  # When found, gets its Value.
  # if value is empty gets its text.
  # if text is empty gets its innerHTML.
  # if innerHTML is empty returns nil.
  def valueOrTextOrInnerHTMLOrNil(css, baseElement)
    valueToRet = nil
    e = firstWithCss(css, nil, baseElement)
    if (e != nil)
      valueToRet = getValueOrTextOrInnerHTML(e)
      if (valueToRet == "")
        valueToRet = nil
      else
        valueToRet = valueToRet.to_s
      end
    end

    return valueToRet
  end

  def allElementsWithCss(cssMainPart, cssSubPart, baseElement=nil, text=nil)
    css = $c.css(cssMainPart, cssSubPart, -1, text)
    if (css == nil)
      UiHelpers.throw "#{Globals.messageNoCssImplemented} #{cssMainPart} #{cssSubPart}"
    end

    base = @driver.browser
    if (baseElement != nil)
      base = baseElement
    end

    elements = base.find_elements(:css, css)
    return elements
  end

  # Returns only the loc element with that cssSelector
  # IMPORTANT: loc =  1.. max (not like index which is 0.. )
  # allows to search in iframe (using id or name for iframe)
  # if nothing was found, returns ""
  def elementWithCssOnLoc(cssSelector, loc=1, iframe_name_or_id = nil, baseElement = nil)
    element_to_ret = ""
    loc = loc - 1 # Since array contains from 0..
    if (loc < 0)
      loc = 0
    end

    base = @driver.browser
    if (baseElement != nil)
      base = baseElement
    end

    begin
      if (	(iframe_name_or_id != nil) &&
          (iframe_name_or_id != ""))
        base.switch_to.frame iframe_name_or_id
      end

      elements = base.find_elements(:css, cssSelector)
      if (elements)
        element_to_ret = elements[loc]
      end

      if ( 	(iframe_name_or_id != nil) &&
          (iframe_name_or_id != ""))
        base.switch_to.default_content
      end
    rescue
      # Should not handle exceptions here
      # since there are times where the element was in iframe
      # and was moved out of that iframe.
    end
    return element_to_ret;
  end

  def JavaScriptClickOnElement(cssSelector)
    begin
      if ((cssSelector == nil) || (cssSelector == ""))
        UiHelpers.throw Globals.messageNoCss
      end
      @driver.execute_script("document.querySelector(#{cssSelector}).click")
    rescue
      UiHelpers.throw Globals.messageJavaScriptClickFailed
    end
  end

  def clickOnWebElement(webElement, sleepAfterClick = 1)
    clickWasDoneWith = ""
    begin
      webElement.click()
      clickWasDoneWith = "regular click"
    rescue
      base = getBaseElement()
      base.execute_script("arguments[0].click()", webElement)
      clickWasDoneWith = "JavaScript"
    end

    if ((clickWasDoneWith != "") && (sleepAfterClick > 0))
      sleep sleepAfterClick
    end

    log "#{Globals.messagePassed} (#{clickWasDoneWith})"
  end

  def waitForElementToBecomeAccessible(element, secondsToWait)
    accessibleElement = nil
    for i in 1 .. secondsToWait do
      if (isElementAccessible(element))
        accessibleElement = element
        break
      end

      log Globals.messageWaitingForAccessibleElement
      sleep i
    end

    if (accessibleElement == nil)
      UiHelpers.throw "#{Globals.messageElementNotAccessible}, after #{secondsToWait} seconds"
    end

    return accessibleElement
  end


  def clickOnElement(cssSelector, baseElement=nil)
    log "Started (cssSelector=#{cssSelector.to_s}, baseElement=#{baseElement.to_s})"
    if (baseElement == nil)
      baseElement = @driver.browser
    end
    e = firstWithCss(cssSelector, nil, baseElement)
    log "Element: #{e.to_s}"
    log Globals.messageRegularClick
    begin
      e.click()
    rescue => ex
      log Globals.messageFailed
      log Globals.messageJavaScriptClick
      begin
        javascriptClickOnCss(cssSelector)
      rescue => exJavaScript
        log Globals.messageJavaScriptClickFailed
        UiHelpers.throw "#{exJavaScript.message}"
      end
    end
    log "Finished"
  end

  def clickOnCss(cssMainPart, cssSubPart, sleepTime = 1, loc = 1, iframe=nil , baseElement = nil)
    parent_func = caller_locations(1).first.label

    css = $c.css(cssMainPart, cssSubPart)
    if ((css == nil) || (css == ""))
      UiHelpers.throw "#{parent_func}: #{Globals.messageNoCss}"
    end

    clickOnElement(css, baseElement)
    sleepSeconds(sleepTime)
  end

  def clickOnCssIfFound(cssMainPart, cssSubPart, sleepTime = 1, loc = 1, iframe=nil , baseElement = nil)
    begin
      clickOnCss(cssMainPart, cssSubPart, sleepTime, loc, iframe, baseElement)
    rescue
    end
  end

  def getInnerElementWithFoundText(text, elementsArray, locationsBefore = 0, ignoreSpaces="", include=false)
    found = nil
    text = text.to_s.downcase
    if (ignoreSpaces == Globals.ignoreAllSpaces)
      text = text.gsub(/\s/, '')
    end

    curLoc = 0
    foundLoc = -1
    elementsArray.each do |e|
      val = getValueOrTextOrInnerHTML(e)
      if (ignoreSpaces == "all")
        val = val.gsub(/\s/, '')
      end

      if ( ((! include) && (val.to_s.downcase == text)) ||
            ((include) && (val.to_s.downcase.include?(text))))
        foundLoc = curLoc
        break
      end

      curLoc += 1
    end

    if (foundLoc >= 0)
      log "found on loc: #{foundLoc}"
      if (locationsBefore > 0)
        log "Should return #{locationsBefore} cells backwords"
        foundLoc = foundLoc - locationsBefore
        if (foundLoc < 0)
          UiHelpers.throw "required element is on position: #{foundLoc}" +
                           " since we returned #{locationsBefore} steps backwords"
        end
      end

      found = elementsArray[foundLoc]
    end
    return found
  end

  def clickOnElementWithTextFromCssList(cssMain, cssSub, textToSearch, baseElement=nil)
    timeToSleep = $uiDefaults["minimumTimeToSleep"]["after"]["click"]
    textToSearch = textToSearch.to_s
    elementClicked = nil
    if (baseElement == nil)
      list = @page.all(:css, $c.css(cssMain, cssSub))
    else
      list = baseElement.all(:css, $c.css(cssMain, cssSub))
    end

    if ((list.nil?) || (list.empty?))
      UiHelpers.throw Globals.messageCannotClickOnEmptyList
    end

    list.each do |element|
      if (element.text == textToSearch)
        if (! isElementAccessible(element))
          UiHelpers.throw "#{Globals.messageElementNotAccessible} #{textToSearch}"
        end

        clickOnWebElement(element, timeToSleep)
        elementClicked = element
        break
      end
    end
    return elementClicked
  end

  # Excepcts hash (like the one that is returned from getCurrentLocation)
  def setCurrentLocation(location)
    begin
      url = location[Globals.locationURL]
      if (url != nil)
        curUrl = @driver.browser.current_url
        if (curUrl != url)
          @driver.visit url
          handleJavascriptAlert(Globals.messageOK)
          sleepSeconds(5)
          validateSapphireIsDisplayed()
        else
          log "Sapphire no longer supports redirect to the same page"
          if (curUrl.to_s.end_with?("/"))
            log "From main page, redirect to somewhere else"
            redirectTo(Globals.pageSettings)
          end
        end
      end
    rescue
    end

    begin
      pageName  = location[Globals.locationPageName]
      tabName   = location[Globals.locationTabName]
      redirectTo(pageName, tabName)
      sleepSeconds(3)
    rescue
    end
  end

  def getCurrentLocation()
    validateSapphireIsDisplayed()
    current = {}
    current[Globals.locationURL]  = @driver.browser.current_url
    cssPage = $c.css(Globals.cssMainHeader, Globals.cssSubCurrentPage)
    if (cssPage == nil)
      UiHelpers.throw "#{Globals.messageNoCssImplemented} (#{Globals.cssMainHeader}, #{Globals.cssSubCurrentPage})"
    end

    skipSettingsPageValues  = false
    current[Globals.locationPage] = firstWithCss(cssPage)
    if (current[Globals.locationPage] == nil)
      log "Page not found, testing if we are in settings page"
      settingsElement = firstWithCss($c.css(Globals.pageSettings, Globals.cssSubcurrentTab))
      if (settingsElement != nil)
        log Globals.messageInRequestedPage
        current[Globals.locationPage] = settingsElement
        current[Globals.locationPageName] = Globals.pageSettings.to_s.capitalize
        current[Globals.locationPageNameLowerCase] = current[Globals.locationPageName].downcase
        skipSettingsPageValues = true
      else
        log Globals.messageNotInRequestedPage
        log "this is an error"
        UiHelpers.throw "Could not find element with css (#{Globals.cssMainHeader}, #{Globals.cssSubCurrentPage})"
      end
    end

    if (! skipSettingsPageValues)
      current[Globals.locationPageName] = current[Globals.locationPage].text
      current[Globals.locationPageNameLowerCase] = current[Globals.locationPageName].downcase
    end

    cssTab = $c.css(current[Globals.locationPageNameLowerCase], Globals.cssSubcurrentTab)
    if (cssTab == nil)
      UiHelpers.throw "#{Globals.messageNoCssImplemented}" +
                      " (#{current[Globals.locationPageNameLowerCase]}, #{Globals.cssSubcurrentTab})"
    else
      log "#{Globals.messageFoundCss}" +
          " (#{current[Globals.locationPageNameLowerCase]}, #{Globals.cssSubcurrentTab})"
    end
    current[Globals.locationTab] = firstWithCss(cssTab)
    if (current[Globals.locationTab] == nil)
      UiHelpers.throw "#{Globals.messageElementNotFound}" +
                      " (#{current[Globals.locationPageNameLowerCase]}, #{Globals.cssSubcurrentTab})"
    end

    current[Globals.locationTabName] = current[Globals.locationTab].text
    current[Globals.locationTabNameLowerCase] = current[Globals.locationTabName].downcase
    return current
  end

  def setField(element, value, shouldClickOnField = true)
    log "#{Globals.messageMethodStarted} (element:#{element}, value:#{value})"
    backspaces = [:backspace] * 20
    element.send_keys(backspaces)
    if (shouldClickOnField)
      element.click()
    end
    element.send_keys(value)
    sleepSeconds(1)
    log Globals.messageMethodFinished
  end

  def setCheckBox(element, value = Globals.checkboxChecked)
    eNameSelected     = "classCheckboxSelected"
    eNameNotSelected  = "classCheckboxNotSelected"
    classSelected     = Controls.get(eNameSelected)
    classNotSelected  = Controls.get(eNameNotSelected)
    classNameOfElement = getAttribute(element, "class")
    if ( ((classNameOfElement.include?(classSelected))    && (value == Globals.checkboxUnchecked)) ||
         ((classNameOfElement.include?(classNotSelected)) && (value == Globals.checkboxChecked)) )
      clickOnWebElement(element)
    end
  end

  # Returns only first element
  def firstWithCss(cssSelector, iframe_name_or_id = nil, baseElement = nil)
    return elementWithCssOnLoc(cssSelector, 1, iframe_name_or_id, baseElement)
  end


  # Throws exception if one of the elements is missing.
  def exceptionIfNil(*elements)
    for i in 0..(elements.length-1)
      if (elements[i] == nil)
        begin
          parent_func = caller_locations(1).first.label
          parentFunc = parentFunc.gsub(/^.*\W(\w+)$/,'\1')
          if ((parentFunc.include?("block")) &&  (parentFunc.include?("in")))
            parentFunc = "main"
          end
        rescue
          parent_func = "default"
        end

        exception = parent_func.to_s + ": #{Globals.messageElementIsRequired} (#{i.to_s})"
        UiHelpers.throw exception
      end
    end
  end

  def javascriptClickOnCss(css)
    if (css.nil? || css.empty?)
      UiHelpers.throw "css cannot be empty"
    end

    jsToExecute = <<-EOF
      retValue = ""
      e = $("#{css}");
      if ((! e) || (e.length == 0))
      {
        retValue = "not found"
      }
      else
      {
        elementsReturnedArr = e.click()
        if (elementsReturnedArr.length <= 0)
        {
          retValue = "not clicked"
        }
      }

      return retValue
    EOF

    javascriptReturned = @page.execute_script(jsToExecute)
    if (javascriptReturned != "")
      UiHelpers.throw "javascript click failed. exception:#{javascriptReturned.to_s}"
    end
  end


  def javascriptClickOnElementByPosition(element)
    loc = element.location
    x = loc.x
    y = loc.y
    size = element.size
    width = size.width
    height = size.height
    javascriptClickPosition(x,y,width,height)
  end


  def moveToElementAndClick(element)
    @driver.browser.action.move_to(element, -element.size.width, -(element.size.height * 2)).click.perform
  end

  def javascriptGetPosition(selector)
    @page.execute_script <<-EOS
      var e = document.querySelector('#{selector}')
      var loc = e.getBoundingClientRect();
      return [loc.left, loc.top, loc.width, loc.height];
    EOS
  end

  def javascriptClickPosition(x,y, width, height)
    @page.execute_script <<-EOS
      $(document.elementFromPoint(#{x - width}, #{y - (2 * height)})).click();
    EOS
  end


  # Gets attribute of element
  # using Selenium's style.
  # if nothing was found, returns ""
  def getAttribute(element, attribute)
    to_ret = ""
    if ((element != nil) && (attribute != nil))
      to_ret = element[attribute]
      if (to_ret == nil)
        to_ret = ""
      end
    end
    return to_ret
  end


  # Gets innerHTML of element (using getAttribute)
  def getInnerHTML(element)
    return getAttribute(element, Globals.attributeInnerHTML);
  end


  # Gets value of element (using getAttribute)
  def getValueOfElement(element)
    return getAttribute(element, Globals.attributeValue);
  end


  # Returns whether an element is accessible (visible, not disabled) or not.
  def isElementAccessible(element)
    to_ret = false
    if (element != nil)
      begin
        disabled_attribute = getAttribute(element, Globals.attributeDisabled)
        if ((disabled_attribute == nil) ||
            (disabled_attribute == "") ||
            (disabled_attribute == "false"))

          class_of_element = getAttribute(element, 'class')
          if ( (class_of_element != nil) &&
               (! class_of_element.downcase.include?(Globals.attributeDisabled)) )
            to_ret = true
          end
        end
      end
    end
    return to_ret
  end


  # Handles a case where JavaScript popup alert is shown.
  # if answer is ok,accept or true accepts the message in the popup.
  # otherwise declines it.
  def handleJavascriptAlert(answer_to_alert)
    begin
      log "#{Globals.messageMethodStarted} (answer_to_alert:#{answer_to_alert}"
      answer_to_alert = answer_to_alert.downcase
      is_ok = false
      if ((answer_to_alert.include? Globals.javascriptAlertTrue) ||
          (answer_to_alert.include? Globals.javascriptAlertAccept) ||
          (answer_to_alert.include? Globals.javascriptAlertOK)      )
        is_ok = true
      end

      if (is_ok == true)
        @driver.browser.switch_to.alert.accept
      else
        @driver.browser.switch_to.alert.dismiss
      end
      log Globals.messageMethodFinished
    end
  end

  def getCurrentTagName(webElement)
    driver = getBaseElement()
    retVal = driver.execute_script("return arguments[0].tagName", webElement).to_s.downcase
    return retVal
  end

  def javascriptSelectFromDD(webElement, toSelect)
    driver = getBaseElement()
    driver.execute_script("arr = arguments[0].childNodes;" +
                          " for (i=0; i<arr.length; i++){ " +
                              "if(arr[i].innerHTML == '" + toSelect  + "')" +
                                "{arr[i].selected = true;" +
                                " arguments[0].dispatchEvent(new Event('change'));" +
                                " break;}" +
                          "}" +
                          "if (i < arr.length){return true;} return false;", webElement)
  end

  # If the element if dropdown menu,
  # it selects the item from it, based on the text
  def selectFromDropdownMenu(element, text_of_what_to_select, isList=false)
    defaultDD = "dropdownOption3"
    dd1 = "dropdownOption2"
    dd2 = "dropdownOption1"

    exceptionIfNil(element, text_of_what_to_select)
    log "Should select:#{text_of_what_to_select}"
    text_of_what_to_select = trimString(text_of_what_to_select)
    if (getCurrentTagName(element) != "select") #default
      cssMain = Globals.generalToAllElements
      cssSub = defaultDD
      if (element != nil)
        if (! isList)
          cssSub = dd1
        end

        optionSelected = clickOnElementWithTextFromCssList(cssMain, cssSub, text_of_what_to_select, element)
        if (optionSelected == nil)
          log "Could not click on option using #{cssSub}"
          cssSub = dd2
          log "New try with #{cssSub}"
          optionSelected = clickOnElementWithTextFromCssList(cssMain, cssSub, text_of_what_to_select, element)
        end

        if (optionSelected == nil)
          UiHelpers.throw Globals.messageNoOptionSelected
        else
          log Globals.messageOptionSelected
        end
      end
    else # select.
      javascriptSelectFromDD(element, text_of_what_to_select)
    end
  end


  # Removes spaces from start and end of string.
  def trimString(string)
    if (string != nil)
      string = string.gsub(/^\s+/, '')
      string = string.gsub(/\s+$/, '')
    else
      log Globals.messageEmptyStringNotAllowed
    end
    return string
  end

  def getAllTabs()
    return Controls.allElements("trade_noedit_tab", getBaseElement())
  end

  # Right clicks the element,
  # assumes there is a popup menu (on the same page)
  # and selects an option from it based on given text.
  # IMPORTANT: uses contain/include to work also with extra spaces
  def selectFromOpenedMenuOnMouseRightClick(element, option_to_choose)
    log "Should select:#{option_to_choose}"
    if ((element != nil) && (option_to_choose != nil))
      element.right_click
      clicked = clickOnElementWithTextFromCssList(Globals.generalToAllElements, 'rightClickOption', option_to_choose)
      if (clicked != nil)
        log Globals.messagePassed
      else
        log Globals.messageFailed
      end
    end
  end

  def minusIntersectionHashes(h1, h2, h1Name = "hash1", h2Name = "hash2", direction="BOTH",
                              h1IgnoreKeys = [], h2IgnoreKeys = [])
    if (h1IgnoreKeys == nil)
      h1IgnoreKeys = []
    end
    if (h2IgnoreKeys == nil)
      h2IgnoreKeys = []
    end
    if (h1 == nil)
      UiHelpers.throw("#{h1Name} cannot be empty")
    end
    if (h2 == nil)
      UiHelpers.throw("#{h2Name} cannot be empty")
    end

    a1 = []
    for k in h1.keys
      if (h1IgnoreKeys.include?(k))
        next
      end
      a1.push([k, h1[k]])
    end
    a2 = []
    for k in h2.keys
      if (h2IgnoreKeys.include?(k))
        next
      end
      a2.push([k, h2[k]])
    end
    diffErrors = minusIntersection(a1, a2,  h1Name, h2Name, direction)
    return diffErrors
  end

  def minusIntersection(arr1, arr2, arr1Name="arr1", arr2Name="arr2", direction="BOTH")
    errors = ""
    if (arr1.nil? || arr1.empty?)
      raise "first array cannot be empty (#{arr1Name.to_s})"
    end
    if (arr2.nil? || arr2.empty?)
      raise "second array cannot be empty (#{arr2Name.to_s})"
    end

    log "Intersecting #{arr1.length.to_s} elements from #{arr1Name} with " +
            "#{arr2.length.to_s} elements from #{arr2Name}"
    intersection = intersectArrays(arr1, arr2)
    log "Searching for unique values which are not in intersection"
    if ((direction == "BOTH") || (direction == "arr1-arr2"))
      arr1Unique = arr1 - intersection
      arr1Unique.each do |e|
        err = "#{e} exists in #{arr1Name}, and not in #{arr2Name}"
        log err
        errors += "#{err}\n"
      end
    end

    if ((direction == "BOTH") || (direction == "arr2-arr1"))
      arr2Unique = arr2 - intersection
      arr2Unique.each do |e|
        err = "#{e} exists in #{arr2Name}, and not in #{arr1Name}"
        log err
        errors += "#{err}\n"
      end
    end

    if (errors == "")
      log "Finished, both #{arr1Name} and #{arr2Name} contain the exact same elements"
    end

    return errors
  end

  #############################################################################
  #############################################################################
  #############################################################################
  #############################################################################
  def removeOldFiles()
    cmd = 'find ~/sapphire_archive/ -name "*archive*.tar.gz" -exec rm -f {} \;'
    res = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'],
                              CONFIG.get['APP_HOST_PWD'], cmd, 1)
  end


  def verifySapphireIsUp(seconds = 25)
    loginURL = @@CONFIG['SapphireLoginUrl'] #https://10.20.42.87:8900/
    cmd = "wget -qO - #{loginURL} --no-check-certificate | grep Sapphire"
    res = ""
    while ((res.nil? || res.empty?) && (seconds > 0))
      res = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'],
                        CONFIG.get['APP_HOST_PWD'], cmd, 1)
      if ((! res.nil?) && (! res.empty?))
        log "Sapphire is up"
        break
      else
        log "Sapphire is down, waiting #{seconds} seconds..."
        sleep seconds
      end

      seconds -= 1
    end

    if (res.nil? || res.empty?)
      UiHelpers.throw("Sapphire is down",false, false, true, true)
    end
  end


  # Signin to the system
  def signInToSapphire(username, password='',sapphire_host)
    log "#{Globals.messageMethodStarted}" +
            " (username:#{username}, password:#{password}, sapphire_host:#{sapphire_host})"
    removeOldFiles()    # Remark it if you need the archive files of Sapphire app.
    verifySapphireIsUp()
    @driver.visit sapphire_host

    begin
      Capybara.page.driver.browser.switch_to.alert.accept
    rescue
    end

    fieldSigninUsername   = 'signin_username'
    btnSignInElementName  = 'btn_signin_signin'
    btnContinueSignInElementName  = 'btn_signin_continueAnyway'

    setField(firstWithCss(Controls.get(fieldSigninUsername)), username)
    btn = Controls.firstElement(btnSignInElementName, @driver.browser)
    clickOnWebElement(btn, 3)

    # Only if already logged in somewhere else.
    elementContinue = firstWithCss(Controls.get(btnContinueSignInElementName))
    if (elementContinue)
      clickOnWebElement(elementContinue, 10)
    end

    currentLoc = getCurrentLocation()
    if (currentLoc == nil)
      UiHelpers.throw "No current location"
    end

    current_url = currentLoc[Globals.locationURL]
    if (/error/i =~ current_url)
      UiHelpers.throw 'Error in login'
    else if (firstWithCss($c.css(Globals.cssMainRedirectTo, Globals.pageTrade)) == nil)
           UiHelpers.throw 'Error: login didn\'t redirect to panels page'
         end
    end
    log Globals.messageMethodFinished

  end


  def setNewTab(page, newTabName)
    if (page.to_s.downcase.include?(Globals.pageTrade))
      base = getBaseElement()
      redirectTo(Globals.pageTrade)
      eNameBtnAddNewTab = 'btn_trade_addNewTab'
      eNameAcceptAddNewTab = "btn_trade_addNewTabName_accept"
      btn = Controls.firstElement(eNameBtnAddNewTab, base)
      clickOnWebElement(btn)
      eName = "input_trade_addNewTabName"
      e = Controls.firstElement(eName, base)
      if (e == nil)
        UiHelpers.throw "field element was not found (#{eName})"
      end

      setField(e, newTabName, false)
      sleep $uiDefaults["minimumTimeToSleep"]["after"]["click"]
      btn = Controls.firstElement(eNameAcceptAddNewTab, base)
      clickOnWebElement(btn)
    else
      UiHelpers.throw "#{Globals.messageNotImplementedYet} page: #{page}"
    end
  end

  def removeExistingTab(tabName)
    base = getBaseElement()
    tabName = trimString(tabName)
    tabToDelete = nil
    eNameTradeTab = "trade_tab"
    eNameDeleteTab = "btn_general_tabDelete"
    eNameConfirmDeleteTab = "btn_trade_confirmToDelete"
    all = Controls.allElements(eNameTradeTab, base)
    all.each do |tab|
      text = getValueOrTextOrInnerHTML(tab)
      text = trimString(text)
      if (text == tabName)
        tabToDelete = tab
        break
      end
    end

    if (tabToDelete == nil)
      UiHelpers.throw "No tab found with name: #{tabName}"
    end

    btnDelete = firstWithCss(Controls.get(eNameDeleteTab), nil, tabToDelete)
    if (btnDelete == nil)
      UiHelpers "No Delete button in tab: #{tabToDelete.text.to_s}"
    end

    clickOnWebElement(btnDelete)
    btnConfirmDelete = Controls.firstElement(eNameConfirmDeleteTab, base)
    clickOnWebElement(btnConfirmDelete, 1)
  end

  def logoutFromSapphire()
    eNameBtnLogout = "btn_header_logout"
    eNameBtnConfirm = "btn_logout_confirm"
    base = getBaseElement()
    sleep 5
    btnLogout = Controls.firstElement(eNameBtnLogout, base)
    clickOnWebElement(btnLogout)
    btnConfirmLogout = Controls.firstElement(eNameBtnConfirm, base)
    clickOnWebElement(btnConfirmLogout)
  end

  # Redirects to the required place(Trade, Reports, ... and/or specific tab(Swaps, Outright/Swp, Spot, Outrights .. ))
  # tab ican be number or name.
  def redirectTo(page, tab=nil)
    validateSapphireIsDisplayed()
    currentUrl = getCurrentLocation()["url"]
    currentUrl = currentUrl.to_s.downcase

    params = {}
    cssElementname = {}
    if (page != nil)
      pageLowerCase = page.delete("[\s\/]").to_s.downcase
      params[Globals.locationPage] = pageLowerCase
      cssElementname[Globals.locationPage] = "btn_header_#{pageLowerCase}"
      if (tab != nil)
        tabLowerCase = tab.delete("[\s\/]").to_s.downcase
        params[Globals.locationTab] = tabLowerCase
        cssElementname[Globals.locationTab] = "btn_#{pageLowerCase}_tab_#{tabLowerCase}"
      end
    else
      UiHelpers.throw "No page parameter"
    end

    base = getBaseElement()
    for type in params.keys do #page/tab
      log "Should redirect to (#{type}:#{params[type]})"
      if (type == Globals.locationPage)
        if (currentUrl.end_with?(params[type]))
          log "Already in page according to url, skipping redirection using clicks (page: #{page}, url: #{currentUrl})"
          next
        end
      end
      log "searching for button element of #{type}"
      begin
        css = Controls.get(cssElementname[type])
        if ((cssElementname[type] != nil) && (css == nil))
          raise "No css, for controls element name: #{cssElementname[type]}"
        end
        element = Controls.validateElementExists(cssElementname[type], base)
      rescue => ex
        log "Cannot get tab button from Controls, based on its direct css selector"
        if (type == Globals.locationTab)
          log "searching element based on its name"
          foundTab = nil
          i = 0
          allTabs = Controls.allElements("trade_tab", base)
          allTabs.each do |t|
            i += 1
            tText = getValueOrTextOrInnerHTML(t)
            tText = tText.delete("[\s\/]").to_s.downcase
            if (cssElementname[type].to_s.end_with?("_#{tText}"))
              foundTab = i
              break
            end
          end
          if (foundTab != nil)
            log "Tab was found based on its name"
            css = Controls.get("btn_trade_tab", nil, foundTab)
            element = firstWithCss(css)
          else
            UiHelpers.throw "Tab was not found even by its name"
          end
        end
      end

      log "clicking on found element"
      clickOnWebElement(element, 2)

      log "After clicking waiting for system to be shown"
      validateSapphireIsDisplayed()
    end

    log "Finished"
  end

  def validateSapphireIsDisplayed()
    return Controls.validateElementExists("header_middlePanel",@driver.browser,
                                          "Waiting for sapphire header to be displayed",
                                          "Sapphire header is not displayed properly, verify setup is ok.",
                                          "Sapphire header is displayed properly")
  end


  def checkBtnStatus(btnElement)
    btnStatus = ""
    if (btnElement)
      foundSwitchOff = firstWithCss("[class *= switch-off]", nil, btnElement)
      if (foundSwitchOff)
        btnStatus = Globals.settingsOff
      else
        btnStatus = Globals.settingsOn
      end
    end

    return btnStatus
  end

  # Sets btn in settings line
  def setSettingsBtn(elementName, btnName, btnStatus="on", ignoreIfNotFound = false)
    eNameBtn = "general_switch"
    errors = ""
    exceptionIfNil(elementName, btnName, btnStatus)
    log "#{Globals.messageMethodStarted}, searching for all elements with name: #{elementName}"
    all = Controls.allElements(elementName, @driver.browser)
    exceptionIfNil(all)
    log "Found #{all.length.to_s} elements, searching for line with #{btnName}"
    foundLineElement = getInnerElementWithFoundText(btnName, all, 0, "all", true)
    if (foundLineElement != nil)
      log "Found line with #{btnName}, getting button from that line"
      btnElement = firstWithCss(Controls.get(eNameBtn), nil, foundLineElement)
      exceptionIfNil(btnElement)
      log "Found button, clicking on it"
      if (checkBtnStatus(btnElement) != btnStatus)
        timeToSleep = $uiDefaults["minimumTimeToSleep"]["after"]["click"]
        clickOnWebElement(btnElement, timeToSleep)
      end
      log Globals.messageMethodFinished
    else
      message = "line with #{btnName} was not found"
      log message
      if (! ignoreIfNotFound)
        errors += "#{message}\n"
      end
    end

    if (errors != "")
      UiHelpers.throw errors
    end
  end


  # Sets settings on settings page.
  def setSettings(settingsHash, ignoreIfNotFound = false)
    eNameDoneBtn = "btn_settings_Done"

    for settingsType in settingsHash.keys do #general/liquiditySources
      redirectTo(Globals.pageSettings, settingsType)
      lineElementName = $uiDefaults["defaultValues"]["settingsLine"][settingsType]
      btnsHash = settingsHash[settingsType]
      for btn in btnsHash.keys do  # AutoClear... /Lp32...
        btnRequiredStatus = btnsHash[btn]
        setSettingsBtn(lineElementName, btn, btnRequiredStatus, ignoreIfNotFound)
      end

      btn = Controls.firstElement(eNameDoneBtn, @driver.browser)
      clickOnWebElement(btn)
    end
  end

  def dateStr(dateElement)
    return dateElement.strftime('%-d/%-m/%Y')
  end


  def dateStrWithLeadingZeros(dateElement)
    if (dateElement.is_a?(String))
      dateElement = Date.parse(dateElement)
    end
    return dateElement.strftime('%d/%m/%Y')
  end

  def getMonthNumber(monthName)
    return Date::MONTHNAMES.index(monthName)
  end

  def getMonthName(month_in_number)
    month = month_in_number.to_i
    if ((month != month_in_number) || (month <= 0) || (month > 12))
      return nil
    end
    return Date::MONTHNAMES[month]
  end

  def getMonthAbbr(month_in_number)
    month = month_in_number.to_i
    if ((month != month_in_number) || (month <= 0) || (month > 12))
      return nil
    end
    return Date::ABBR_MONTHNAMES[month]
  end

  def getTraderIdFromHeader()
    traderId = ""
    begin
      value = Controls.value("header_currentUserId", getBaseElement())
      if (value.to_s =~ /\(([^\)]+)\)/)
        traderId = $1.to_s
      end
    rescue => ex
      log "Error: #{ex.message}"
    end
    return traderId
  end

  def verifySystemIsLockedOrUnlocked(test = Globals.systemIsLocked)
    eNameLock = "btn_header_lock"
    if (test == Globals.systemIsUnlocked)
      if (isSystemLocked())
        log Globals.messageUnlocking
        btn = Controls.firstElement(eNameLock, @driver.browser)
        clickOnWebElement(btn)
      end

      if (isSystemLocked())
        UiHelpers.throw Globals.messageErrorSystemInLocked
      end
    else # We should verify that system is locked.
      if (! isSystemLocked())
        log Globals.messageLocking
        btn = Controls.firstElement(eNameLock, @driver.browser)
        clickOnWebElement(btn)
      end

      if (! isSystemLocked())
        UiHelpers.throw Globals.messageErrorSystemIsUnlocked
      end
    end
  end

  def isSystemLocked()
    isLocked = false
    css = Controls.get("locked_system")
    lockedElement = firstWithCss(css)
    if (lockedElement != nil)
      isLocked = true
    end

    return isLocked
  end

  def UiHelpers.getTextByCss(elem,css)
    if elem.has_css?(css, wait: false) # assuming panels aren't dynamically loaded
      res = elem.find(:css, css).text
    else
      res = Globals.messageNotFound
    end
    return res
  end


  def UiHelpers.getTextByCssAfterClick(elem,cssToCheck, cssToClick, cssToFindText)
    if elem.has_css?(cssToCheck, wait: false) # assuming panels aren't dynamically loaded
      c = elem.find(:css, cssToClick)
      c.click
      res = elem.find(:css, cssToFindText).text
    else
      res = Globals.messageNotFound
    end
    return res
  end


  def UiHelpers.getValueByCss(elem,css)
    if elem.has_css?(css, wait: false) # assuming panels aren't dynamically loaded
      res = elem.find(:css, css).value
    else
      res = Globals.messageNotFound
    end
    return res
  end

  def UiHelpers.requestGcMockRfq(counter = 1,
                                  instrName='EURUSD_SPOT_FULL_RFQ',
                                  ip = CONFIG.get['APP_HOST_IP'],
                                  user = CONFIG.get['APP_HOST_USER'],
                                  pwd = CONFIG.get['APP_HOST_PWD'],
                                  port = CONFIG.get['SAPPHIRE_MOCK_FEEDER_PORT'])
    gcMockURL = "http://#{ip.to_s}:#{port.to_s}/run?feeder=RFQ%3A#{instrName}%3A" +
        "#{counter.to_s}&actionType=once&param1="
    failMsgSendUri = "Error: problem while sending request for #{instrName} " +
        "to Sapphire mock feeder #{ip.to_s}:#{port.to_s}\n"
    begin
      uri = URI(gcMockURL)
      Net::HTTP.get(uri)
    rescue Exception => e
      fail(failMsgSendUri + e.message)
    end
  end

  def UiHelpers.getGcMockOptions(whatToSearch = "RFQ")
    url = "http://10.20.42.61:5499/run?feeder"
    elementContainingData = "option.*value"
    cmd = "wget -qO - #{url} | grep #{elementContainingData}  | " +
            "perl -ne 'print \"$1\\n\" while ($_ =~ s/value=\"([^\"]+)\"//);' | " +
            "grep #{whatToSearch} | sort"
    res = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['APP_HOST_USER'],
                              CONFIG.get['APP_HOST_PWD'], cmd, 1)
    return res.to_s.split("\n")
  end
end