require_relative('UiHelpers')

class OrderItem
  @@baseElementName = "orderItem"

  def initialize(ui, num, orderElement = nil)
    @ui = ui
    @num = num
    @orderElement = orderElement
  end

  def OrderItem.convertOperationTypeToPriceType(operationType)
    priceType = ""
    case operationType.to_s.downcase
      when Globals.orderItemSell
        priceType = Globals.panelOrderformsOffer
      when Globals.orderItemBuy
        priceType = Globals.panelOrderformsBid
    end
  end

  def OrderItem.removeAllOrders(exceptionOnFailure = false, ui = $ui)
    begin
      if (ui == nil)
        UiHelpers.throw "ui refference is required for this method " +
                            "(define $ui, or send alternative ui as a parameter to this method)"
      end
      o = OrderItem.new(ui, 1)
      if ((o == nil) && (exceptionOnFailure))
        UiHelpers.throw "Cannot create order item"
      else
        all = o.getAllOrders()
        all.each do |orderItem|
          orderItem.removeOrder()
        end
      end
    rescue => ex
      if (exceptionOnFailure)
        UiHelpers.throw(ex.message)
      end
    end
  end

  def OrderItem.isStuckOrderExist(exceptionOnFailure = false, ui = $ui)
    stuckedOrderElement = nil
    begin
      if (ui == nil)
        UiHelpers.throw "ui refference is required for this method " +
                            "(define $ui, or send alternative ui as a parameter to this method)"
      end
      stuckedOrderEname = "orderItem_stuckIcon"
      stuckedOrderElement = Controls.firstElement(stuckedOrderEname, ui.getBaseElement())
    rescue => ex
      if (exceptionOnFailure)
        UiHelpers.throw(ex.message)
      end
    end
    return (stuckedOrderElement != nil)
  end

  def log(message)
    parentFunc =  caller_locations(1).first.label
    Controls.log(message, File.basename(__FILE__), parentFunc.to_s)
  end

  def getOrderNumber()
    return @num
  end

  def getWebElement()
    return @orderElement
  end

  def getAllOrders()
    arrToRet = []
    driver = @ui.getBaseElement()
    all = Controls.allElements("#{@@baseElementName}", driver)
    i = 0
    all.each do |orderElement|
      i += 1
      order = OrderItem.new(@ui, i, orderElement)
      arrToRet.push(order)
    end
    return arrToRet
  end

  def getActiveOrderElement(onFailureRaiseException = true,
                            onFailureAddToScenarioFails = false,
                            onFailureWriteToActionsF = false,
                            onFailureCreateScreenshot = false)
    if ((@orderElement == nil) || (! @ui.isElementAccessible(@orderElement)))
      all = getAllOrders()
      if ((@num > all.length ) || (@num < 1))
        UiHelpers.throw("#{@num.to_s} is out of limits of array (array length: #{all.length.to_s})",
                        onFailureRaiseException,
                        onFailureAddToScenarioFails,
                        onFailureWriteToActionsF,
                        onFailureCreateScreenshot)
      end
      element = all[@num - 1]
      if (! element.class.to_s.downcase.include?("selenium"))
        element = element.getWebElement()
      end
      @orderElement = element
    end
    return @orderElement
  end

  def removeOrder(setOff = true, clickClear = true, clickDelete = true, onFailureRaiseException = true,
                  onFailureAddToScenarioFails = false,
                  onFailureWriteToActionsF = false,
                  onFailureCreateScreenshot = false)
    shouldClicks = {"off" => setOff, "clear" => clickClear, "delete" => clickDelete}
    timeToSleepAfterClick = { "off" => 5, "clear" => 1, "delete" => 1}
    eNames = {}
    orderElement = getActiveOrderElement(onFailureRaiseException,
                                         onFailureAddToScenarioFails,
                                         onFailureWriteToActionsF,
                                         onFailureCreateScreenshot)
    for elementName in shouldClicks.keys do
      eNames[elementName] = "btn_#{@@baseElementName}_#{elementName}"
      if (shouldClicks[elementName])
        begin
          btn = Controls.firstElement(eNames[elementName], orderElement)
          if (btn != nil)
            @ui.clickOnWebElement(btn, timeToSleepAfterClick[elementName])
          end
        rescue
          log "Cannot click on #{eNames[elementName]}, maybe order item was alreay removed"
        end
      end
    end
  end

  def getOrderProperties(onFailureRaiseException = true,
                         onFailureAddToScenarioFails = false,
                         onFailureWriteToActionsF = false,
                         onFailureCreateScreenshot = false, specificProperties = nil)
    eNameBtnExpand  = "btn_#{@@baseElementName}_expand"
    eNameBtnLock    = "btn_#{@@baseElementName}_lock"
    eNameExpadedData = "#{@@baseElementName}_expanded_data"
    eNameExpadedDataLine = "#{@@baseElementName}_expanded_data_line"
    activeElement = getActiveOrderElement(onFailureRaiseException,
                                          onFailureAddToScenarioFails,
                                          onFailureWriteToActionsF,
                                          onFailureCreateScreenshot)
    btn = Controls.firstElement(eNameBtnLock, activeElement)
    @ui.clickOnWebElement(btn, $uiDefaults["minimumTimeToSleep"]["after"]["click"])
    btn = Controls.firstElement(eNameBtnExpand, activeElement)
    @ui.clickOnWebElement(btn, $uiDefaults["minimumTimeToSleep"]["after"]["click"])

    maxTriesBeforeFailure = 3
    hashProperties = {}

    if (activeElement == nil)
      UiHelpers.throw("No active element", onFailureRaiseException,
                      onFailureAddToScenarioFails,
                      onFailureWriteToActionsF,
                      onFailureCreateScreenshot)
    end
    if (specificProperties == nil)
      specificProperties = [Globals.orderItemCurrencyPair, Globals.orderItemProductType, Globals.orderItemDate,
                            Globals.orderItemTraderID, Globals.orderItemAction, Globals.orderItemdealtAmount,
                            Globals.panelDDdealtCCY, Globals.panelOrderformsPrice,
                            Globals.orderItemEcn, Globals.orderItemTifOrSummery]
    end
    for endElementName in specificProperties do
      eName = "#{@@baseElementName}_#{endElementName}"
      for i in 1 .. maxTriesBeforeFailure do
        value = Controls.value2(eName, activeElement, false, false, false, false)
        if ((value != nil) && (value != ""))
          break
        end
      end

      if ((value != nil) && (value != ""))
        case endElementName
          when Globals.orderItemAction
            hashProperties[Globals.panelOrderformsPriceType] =
                    OrderItem.convertOperationTypeToPriceType(value)
        end
        hashProperties[endElementName] = value
      else
        UiHelpers.throw("Failed to get value for #{endElementName}", onFailureRaiseException,
                        onFailureAddToScenarioFails,
                        onFailureWriteToActionsF,
                        onFailureCreateScreenshot)
      end
    end

    log "Get all elements without specific selector (children of lineElement)"
    expandedData = ""
    Controls.allElements(eNameExpadedDataLine, activeElement).each do |lineElement|
      line = lineElement.text
      if (line =~ /([0-9A-Z\-]+)\s*(LC[A-Z]+)\s*([A-Z0-9\,\s\+]+)/)
        hashProperties[Globals.panelOrderformsOrderID] = $1
        hashProperties[Globals.panelDDFloor] = $2
        hashProperties[Globals.panelOrderformsCptys] = $3
        next
      end

      if (line =~ /([A-Z]+)\s*([A-Z]+)\s*Direct\s*PD:\s*([\d\.]+)/)
         hashProperties[Globals.panelDDCalcType] = $1
         hashProperties[Globals.panelOrderformsAlgo] = $2
         hashProperties[Globals.panelDDpdValue] = $3
         next
      end

      if (line =~ /^\s*([A-Z]+)\s*$/)
        hashProperties[Globals.panelOrderformsTif] = $1
        next
      end

      expandedData += "#{line}\n"
    end

    hashProperties[Globals.orderItemExapndedData] = expandedData
    log "Resume Order to original size"
    btn = Controls.firstElement(eName, activeElement)
    @ui.clickOnWebElement(btn, $uiDefaults["minimumTimeToSleep"]["after"]["click"])
    return hashProperties
  end

  def getOrderTransactions(onFailureRaiseException = true,
                           onFailureAddToScenarioFails = false,
                           onFailureWriteToActionsF = false,
                           onFailureCreateScreenshot = false)
    eNameTransactionType = "orderItem_action"
    eName = "orderItem_transaction"
    baseElement = getActiveOrderElement()
    allValues = []
    eTransactionType = Controls.value2(eNameTransactionType, baseElement, false, false, false, false)
    if (eTransactionType.empty?)
      UiHelpers.throw("Cannot get transaction type",
                      onFailureRaiseException,
                      onFailureAddToScenarioFails,
                      onFailureWriteToActionsF,
                      onFailureCreateScreenshot)
    else
      allElements = Controls.allElements(eName, baseElement)
      allElements.each do |orderTransactionWebelement|
        data = orderTransactionWebelement.text()
        if ((data.to_s != "") &&
            (data.to_s =~ /^(\d{2}\D\d{2}\D\d{2})\s*(\d+)M\D*([\d\.]+)\s*(\w+)\s+(\w+)/i))
          tHash = {}
          tHash[Globals.dealItemTradeDate] = $1.to_s
          tHash[Globals.dealItemdealtAmount] = $2.to_f
          tHash[Globals.dealItemPrice] = $3.to_f
          tHash[Globals.dealItemCpty] = $4.to_s
          tHash[Globals.dealItemEcn] = $5.to_s
          tHash[Globals.dealItemBuySell] = eTransactionType.to_s.downcase
          if (! tHash.empty?)
            if (tHash[Globals.dealItemBuySell] == Globals.orderItemBuySell)
              for bs in [Globals.orderItemBuy, Globals.orderItemSell]
                tHash = tHash.clone
                tHash[Globals.dealItemBuySell] = bs
                allValues.push(tHash)
              end
            elsif (tHash[Globals.dealItemBuySell] == Globals.orderItemSellBuy)
              for bs in [Globals.orderItemSell, Globals.orderItemBuy]
                tHash = tHash.clone
                tHash[Globals.dealItemBuySell] = bs
                allValues.push(tHash)
              end
            else
              allValues.push(tHash)
            end
          end
        end
      end
    end
    return allValues
  end

  def filterLPsOnFromTransaction(transactions)
    orderTransactions = transactions
    orderLPs = []
    orderTransactions.each do |h|
      orderLPs.push(h[Globals.dealItemCpty])
    end
    return orderLPs
  end
end