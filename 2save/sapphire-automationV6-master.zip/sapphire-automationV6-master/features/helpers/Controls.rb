#require 'singleton'
# Class is used for GUI controls
require_relative('Actions')
require_relative('UiHelpers')

class  Controls
  @@css = {}
	@@btn_chrome_settings_advanced = '#advanced-settings-expander'
	@@field_chrome_settings_downloadsPath = '#downloadLocationPath'
	@@general_dropdownMenu_option = 'option'
	@@general_dropdownMenu_option2 = 'li[class *= option]'
	@@general_dropdownMenu_option3 = 'li'
	@@general_rightClick_option = 'ul[class*=menu]:not([style*=none])>li'
	@@btn_general_tabDelete = ' [class*=tab-delete]'
	@@general_column_name = 'span'
	@@general_switch			= '[class*=toggle]>[class*=switch]'
	@@btn_general_confirm = ' [class*=confirm][class*=button]'
	@@btn_general_cancel = ' [class*=cancel][class*=button]'
	@@locked_system				= '[class*=locking-layer]'
	@@classCheckboxNotSelected 	= "ng-empty"
	@@classCheckboxSelected	 		= "ng-not-empty"
	@@checkbox							= "input[type=checkbox]"
	@@listItem							= "li"
	@@btnDone 							= ".back"
	@@ValueElement					= ' .selected'
	@@ValueElement2					= ' input'
	@@MenuElement						= ' ul'
	@@NotEmpty							= ':not(.-empty)'
	@@checkboxByClass				= '.checkbox'

	############################################# MAIN SELECTORS ########################################
	# Here exist only selectors that should be exist when Sapphire starts (even without prices)
	@@header_middlePanel			= '[class*=sap-tabs-base]'
	@@header_currentPage 			= @@header_middlePanel 	+ ' li[class*=selected]'
	@@btn_header_trade 				= @@header_middlePanel 	+ ' [ui-sref=trading]'
	@@btn_header_reports 			= @@header_middlePanel 	+ ' [ui-sref=reports]'
	@@header_rightPanel 			= '[class*=sap-app-status-toolbar]'
	@@header_floorDropdown 		= @@header_rightPanel 	+ ' [class*=floor][class*=dropdown]'
	@@header_currentUserId 		= @@header_rightPanel 	+ ' [class*=user]'
	@@header_currentDateTime 	= @@header_rightPanel 	+ ' [class*=time]'
	@@btn_header_logout 				= @@header_rightPanel 	+ ' [class*=logout]'
	@@btn_logout_confirm				= '[data-id*=logoutConfirmID] ' + @@btn_general_confirm
	@@btn_header_keyboard 			= @@header_rightPanel 	+ ' [class*=active][class*=icon]'
	@@btn_header_lock 					= @@header_rightPanel 	+ ' [class*=toggle]'
	@@btn_header_help 					= @@header_rightPanel 	+ ' [class*=help][class*=icon]'
	@@header_qos							= @@header_rightPanel 	+ ' [class*=sap-qos-icon]'
	@@header_connection				= @@header_rightPanel 	+ ' [class*=connection][class*=icon]'
	@@btn_header_settings 			= @@header_rightPanel 	+ ' [class*=preferences]'

	@@deals										= '[sap-blotter]'
	@@deals_header						= @@deals + ' [class*=ebsReportQuery]'
	@@deals_tabsLine					= @@deals_header + ' [class*=tabs]'
	@@deals_dealsTab					= @@deals_tabsLine + ' li.tab'
	@@btn_deals_find						= @@deals + ' .search'
	@@btn_deals_download				=	@@deals + ' [class*=download]'
	@@btn_deals_settings				=	' button.column-picker'
	@@deals_columns_line			=	@@deals + ' .header'
	@@deals_columns_column		=	@@deals_columns_line + ' th'
	@@deals_column_picker			= '.popover-content'
	@@deals_column_picker_menu	= @@deals_column_picker + @@MenuElement
	@@deals_column_picker_menu_item = @@deals_column_picker_menu + " " + @@listItem
	@@deals_column_picker_dragAndDrop = ".drag-btn"
	@@deals_column_picker_menu_item_checkbox = @@checkboxByClass
	@@btn_deals_search						= '.search-toggle-btn,.ebs-report-tag-input input'
	@@field_deals_searchBar				= 'input.search'
	@@btn_closeSearchBar					= 'button.clear-tags'
	@@deals_searchBar_result			= '.stork-tags-dropdown-container>div'
	@@deals_searchBar_resultType	= 'div'
	@@deals_searchBar_resultValue	= 'li'
	@@deal_in_deals								= 'table[id*=_dataTable]:not([id*=fixed]) tr'
	@@deal_in_deals_static				= 'table[id*=_dataTable][id*=fixed] tr'
	@@Contents										= ' div'
	@@deals_scroll_manager				= '.ebsReportGrid'
	@@dealItem_generalColumn			= ' .header th'
	@@dealItem_dealDateTime				= ' .dealDate' 			+ @@Contents
	@@dealItem_pair								= ' .instrument' 		+ @@Contents
	@@dealItem_exeCpty						= ' .executionCpty' + @@Contents
	@@dealItem_cpty								= ' .cpAccount' 		+ @@Contents
	@@dealItem_bs									= ' .bs' 						+ @@Contents
	@@dealItem_tenor							= ' .tenor' 				+ @@Contents
	@@dealItem_valDate						= ' .valueDate' 		+ @@Contents
	@@dealItem_dealtAmt						= ' .dealtAmount' 	+ @@Contents
	@@dealItem_dealt							= ' .dealtCcy' 			+ @@Contents
	@@dealItem_contraAmt					= ' .contraAmount' 	+ @@Contents
	@@dealItem_contraCcy					= ' .contraCcy' 		+ @@Contents
	@@dealItem_price							= ' .price' 				+ @@Contents
	@@dealItem_tradeDate					= ' .tradeDate' 		+ @@Contents
	@@dealItem_ticketId						= ' .ticketId' 			+ @@Contents
	@@dealItem_id									= ' .id' 						+ @@Contents
	@@dealItem_productType				= ' .product' 			+ @@Contents
	@@dealItem_floor							= ' .floor' 				+ @@Contents
	@@dealItem_traderId						= ' .traderId' 			+ @@Contents
	@@dealItem_ecn								= ' .ecn' 					+ @@Contents
	@@dealItem_segment						= ' .segment' 			+ @@Contents
	@@dealItem_orderId            = ' .orderId'       + @@Contents

	@staticDealItem                = 'table[id*=dataTable_fixed]'
	@@dealItem_dealDateTime_static = @staticDealItem  + ' .dealDate'      + @@Contents
	@@dealItem_pair_static				 = @staticDealItem  + ' .instrument'    + @@Contents
	@@dealItem_exeCpty_static			 = @staticDealItem  + ' .executionCpty' + @@Contents
	@@dealItem_cpty_static				 = @staticDealItem  + ' .cpAccount'     + @@Contents
	@@dealItem_bs_static					 = @staticDealItem  + ' .bs'            + @@Contents
	@@dealItem_tenor_static				 = @staticDealItem  + ' .tenor'         + @@Contents
	@@dealItem_valDate_static			 = @staticDealItem  + ' .valueDate'     + @@Contents
	@@dealItem_dealtAmt_static		 = @staticDealItem  + ' .dealtAmount'   + @@Contents
	@@dealItem_dealt_static				 = @staticDealItem  + ' .dealtCcy'      + @@Contents
	@@dealItem_contraAmt_static		 = @staticDealItem  + ' .contraAmount'  + @@Contents
	@@dealItem_contraCcy_static		 = @staticDealItem  + ' .contraCcy'     + @@Contents
	@@dealItem_price_static				 = @staticDealItem  + ' .price'         + @@Contents
	@@dealItem_tradeDate_static		 = @staticDealItem  + ' .tradeDate'     + @@Contents
	@@dealItem_ticketId_static		 = @staticDealItem  + ' .ticketId'      + @@Contents
	@@dealItem_id_static					 = @staticDealItem  + ' .id'            + @@Contents
	@@dealItem_productType_static	 = @staticDealItem  + ' .product'       + @@Contents
	@@dealItem_floor_static				 = @staticDealItem  + ' .floor'         + @@Contents
	@@dealItem_traderId_static		 = @staticDealItem  + ' .traderId'      + @@Contents
	@@dealItem_ecn_static					 = @staticDealItem  + ' .ecn'           + @@Contents
	@@dealItem_segment_static			 = @staticDealItem  + ' .segment'       + @@Contents

	@@orders									= '.sap-order-panel'
	@@orders_header						= @@orders + ' [class*=header][class*=panel]'
	@@btn_orders_offall				= @@orders + ' .offall'
	@@btn_orders_superOffAll	= @@orders + ' .superoffall'
	@@btn_orders_clear				= @@orders + ' .clear'
	@@btn_orders_pause				= @@orders + ' .pause'
	@@btn_orders_send					= @@orders + ' .send'
	@@orderItem								= @@orders + ' .sap-order'
	@@orderItem_transaction   = 'li.transaction'
	@@orderItem_stuckIcon     = '.order-status.stuck'
	@@orderItem_currencyPair	= ' .currency-pair'
	@@orderItem_productType		= ' .product-type'
	@@orderItem_tradingDates	= ' .date'
	@@orderItem_traderID			= ' .trader-id'
	@@orderItem_flow					= ' .flow'
	@@orderItem_action				= ' .display-action'
	@@orderItem_dealtAmount		= ' .amount'
	@@orderItem_dealtCCY			= '[class="important-label ng-binding"]:not([ng-bind]),' +
																'[class="ng-binding important-label"]:not([ng-bind])'
	@@orderItem_price					= ' [ng-bind*="order.price"]' # There is no special class for that element
	@@orderItem_tifOrSummery	= ' .tif-line,.summary' # Removed After few seconds.
	@@orderItem_ecn						= ' .ecn'
	@@btn_orderItem_lock			= ' .lock'
	@@btn_orderItem_delete		= ' .cancel'
	@@btn_orderItem_clear			= ' .clear'
	@@btn_orderItem_off				= ' .off'
	@@btn_orderItem_amend			= ' .amend'
	@@btn_orderItem_send			= ' .send'
	@@btn_orderItem_expand		= ' .expand'
	@@orderItem_expanded_data	=	' .opened'
	@@orderItem_expanded_data_line	= @@orderItem_expanded_data + ' .parameters-line:not(.transactions),.line-block'

	#######################################END OF MAIN SELECTORS ########################################

	###################################SELECTORS RELATED TO PAGE/TAB #####################################
	# Here exist selectors that are related to the page/tab we are currently in.
	@@settings_general										= '[class*=sub-view][class*=general]'
	@@btn_settings_general_ConfirmOnSend		= @@settings_general + ' [id*="confirmSend"] [class*="switch "],' +
																									@@settings_general + ' [id*="confirmSend"] [class$="switch"]'
	@@settings_general_line								= @@settings_general + ' [class*=parameters-line]'
	@@btn_settings_Done										= '[class*=close][class*=button]'


	@@settings_tabs 												= '[class*="settings-tabs"] [class=tabs]'
	@@settings_tab													= @@settings_tabs + ' li'
	@@settings_currentTab										= @@settings_tab + '[class*=elected]'
	@@btn_settings_tab 											= @@settings_tab + ':nth-child(NUMBER_FOR_INDEX) button:nth-child(1)'
	@@btn_settings_tab_general							= @@settings_tab + ':nth-child(1) button:nth-child(1)'
	@@btn_settings_tab_liquiditysources			= @@settings_tab + ':nth-child(2) button:nth-child(1)'
	@@settings_liquiditySources							= '[class*=liquidity-sources]'
	@@settings_liquiditySources_line			= @@settings_liquiditySources + ' tr'

	@@trade_tabs_container						= '[trader-layout="user.settings.tradingTabs"]'
	@@trade_tabs 											= @@trade_tabs_container + ' [class=tabs]'
	@@trade_tab												= @@trade_tabs + ' li'
	@@trade_noedit_tab								= @@trade_tab + ':not([class*=edit])'
	@@btn_trade_tab 									= @@trade_tab + ':nth-child(NUMBER_FOR_INDEX) button:nth-child(1)'
	@@btn_trade_tab_swaps							= @@trade_tab + ':nth-child(1) button:nth-child(1)'
	@@btn_trade_tab_outrightswp				= @@trade_tab + ':nth-child(2) button:nth-child(1)'
	@@btn_trade_tab_spot							= @@trade_tab + ':nth-child(3) button:nth-child(1)'
	@@btn_trade_tab_outrights					= @@trade_tab + ':nth-child(4) button:nth-child(1)'
	@@btn_trade_addNewTab 						= @@trade_tab + ' [class*=tab][class*=add]:not([class*=hide])'
	@@input_trade_addNewTabName				= @@trade_tabs_container + ' [class*=editor] input[class*=tab-edit]'
	@@btn_trade_addNewTabName_accept	= @@trade_tabs_container + ' [class*=editor] [class*=tab-accept]'
	@@btn_trade_confirmToDelete				= '[data-confirm-text*="DELETE"] [class*=confirm-button]'
	@@trade_currentTab 								= '[tabs-id="trader-tabs"] [class*=elected] button:nth-child(1)'

	@@reports 												= '[class*="reports"]'
	@@reports_tabs										= @@reports + ' .reportsTabs'
	@@reports_tab											= @@reports_tabs + ' a'
	@@reports_currentTab							= @@reports_tab + '[class*=active]'
	@@btn_reports_tab_deals						= @@reports_tab + ':nth-child(1)'
	@@reports_searchForm							= @@reports + ' .ebsReportQueryForm'
	@@reports_dateType_Dropdown				= @@reports_searchForm + ' [id=dateTypes]'
	@@reports_dateRange_Dropdown			= @@reports_searchForm + ' [id=dateRange]'
	@@reports_fromDate								= @@reports_searchForm + ' [id=fromDate]'
	@@reports_toDate									= @@reports_searchForm + ' [id=toDate]'
	@@reports_searchField							= @@reports_searchForm + ' input.search'
	@@btn_reports_searchClear					= @@reports_searchForm + ' .reset-search'
	@@reports_lastUpdated							= @@reports + ' [class*=last-update]'
	@@btn_reports_download						= @@reports_lastUpdated + ' [class*=download][class*=btn]'
	@@reports_deals_main							= @@reports + ' .header'
	@@reports_columns_line						= @@reports_deals_main +  ' [id$="headerTable"]'
	@@reports_column									= @@reports_columns_line 	+ ' th'


	@@signin_username 								= 'form[action*=login] [name*=sername]'
	@@signin_appDropdown 							= 'select[name*=login]'
	@@btn_signin_signin 								= 'form[action*=login] [onclick*=ubmit]'
	@@signin_otherBankName 						= '[id*=loginToAlt]'
	@@btn_signin_continueAnyway			 	= '[onclick*=destroy][onclick*=active][onclick*=session]'
	################################### END OF SELECTORS RELATED TO PAGE/TAB ##############################
	@@panel_container = '[class*=sap-price-column]'
	@@panel	= '[class*=sap-price-panel]'
	@@panel_with_data = '[class*=panel-place][class*=sap-navigation],' +
												'[class*=panel-place][class*=waiting-for-config]'
	# Second part is to fail when disabled panel is found on screen (Alex asked for it)
	@@panelLocked																	= '.panel-lock'
	@@panelConfirmationBtn												= @@panelLocked + ' .override-amount'
	@@panel_opened                                = @@panel + ' [class*=panel-body] [class*=large-view]'
	@@panel_notEntitled											      = '[class*=status-overlay][class*=entitlement-error]'
	@@btn_settingsPanel_open                      = 'button[class*=panel-settings]'
  @@settingsPanel_opened                        = '.settings-open'
  @@settingsPanelPricing                        = @@settingsPanel_opened + ' .pricing'
  @@btn_settingsPanelPricing_select             = @@settingsPanelPricing + ' [class*=header]'
	@@settingsPanelPricing_ecn                    = @@settingsPanelPricing + ' .ecn span.selected'
	@@settingsPanelPricing_dealtAmount            = @@settingsPanelPricing + ' input[ng-model*=defaultAmount]'
	@@settingsPanelPricing_priceModel             = @@settingsPanelPricing + ' .priceModel'
	@@btn_settingsPanelPricing_priceModel         = @@settingsPanelPricing_priceModel + ' .selected'
	@@menu_settingsPanelPricing_priceModel        = @@settingsPanelPricing_priceModel + @@MenuElement
	@@settingsPanelPricing_algo                   = @@settingsPanelPricing + ' .algo'
	@@btn_settingsPanelPricing_pdInPrice          = @@settingsPanelPricing + ' .pd .switch'
	@@field_settingsPanelPricing_pdValue          = @@settingsPanelPricing + ' .pd input'
  @@btn_settingsPanelPricing_pipViewPips        = @@settingsPanelPricing + ' [class*=pip-select] button:nth-of-type(1)'
  @@btn_settingsPanelPricing_pipViewFull        = @@settingsPanelPricing + ' [class*=pip-select] button:nth-of-type(2)'
  @@settingsPanelWarnings                       = @@settingsPanel_opened + ' .warnings'
  @@btn_settingsPanelWarnings_select            = @@settingsPanelWarnings + ' [class*=header]'
  @@field_settingsPanelWarnings_warnAbove       = @@settingsPanelWarnings + ' .row:nth-of-type(1) input'
  @@btn_settingsPanelWarnings_largeSpread       = @@settingsPanelWarnings + ' .row:nth-of-type(2) .switch'
  @@field_settingsPanelWarnings_largeSpread     = @@settingsPanelWarnings + ' .row:nth-of-type(2) input'
  @@btn_settingsPanelWarnings_largeDifference   = @@settingsPanelWarnings + ' .row:nth-of-type(3) .switch'
  @@field_settingsPanelWarnings_largeDifference = @@settingsPanelWarnings + ' .row:nth-of-type(3) input'
  @@settingsPanelCptys                          = @@settingsPanel_opened + ' .cpty'
  @@btn_settingsPanelCptys_select               = @@settingsPanelCptys + ' [class*=header]'
  @@checkbox_settingsPanelCptys_selectAll       = @@settingsPanelCptys + ' input.select-all'
  @@checkbox_settingsPanelCptys_selectLP        = @@settingsPanelCptys + ' ul.checklist li'
  @@settingsPanel_bottom                         = @@settingsPanel_opened + ' .bottom-footer'
  @@checkbox_settingsPanel_bottom_makeDefaultSettings = @@settingsPanel_bottom
  @@btn_settingsPanel_close = '.settings-close'
	# live is for all prices that are changed live (mostly SP LMT..)
	@@panel_prices_LP_live 									= ' [class*=sap-market-depth]:not([class*=disabled]) li' #@@panel_opened + ' [class*=sap-market-depth]:not([class*=disabled]) li'
	@@panel_prices_LP_live_bid 							= @@panel_prices_LP_live + ' div[class*=price-container-bid]'
	@@panel_prices_LP_live_bid_amount 			= @@panel_prices_LP_live + ' [class*=bid][class*=accumulated-amount]'
	@@panel_prices_LP_live_bid_bigFigure 		= @@panel_prices_LP_live_bid + ' [class*=bigFigure]'
	@@panel_prices_LP_live_bid_pip 					= @@panel_prices_LP_live_bid + ' [class=pip]'
	@@panel_prices_LP_live_bid_decimal 			= @@panel_prices_LP_live_bid + ' [class=decimal]'
	@@panel_prices_LP_live_offer 						= @@panel_prices_LP_live + ' div[class*=price-container-offer]'
	@@panel_prices_LP_live_offer_amount 		= @@panel_prices_LP_live + ' [class*=offer][class*=accumulated-amount]'
	@@panel_prices_LP_live_offer_bigFigure 	= @@panel_prices_LP_live_offer + ' [class*=bigFigure]'
	@@panel_prices_LP_live_offer_pip 				= @@panel_prices_LP_live_offer + ' [class=pip]'
	@@panel_prices_LP_live_offer_decimal 		= @@panel_prices_LP_live_offer + ' [class=decimal]'

	# full is the default (prices in green cells)
	@@panel_prices_LP_full 									= ' [class*=sap-][class*=-ladder]:not([class*=disabled]):not([class*=market-depth]) [class^=row]:not([class*=hide])' #@@panel_opened + ' [class*=sap-][class*=-ladder]:not([class*=disabled]):not([class*=market-depth]) [class^=row]'
	@@panel_prices_LP_full_middle						= @@panel_prices_LP_full + ' [class*=middle]'
	@@panel_prices_LP_full_type							= @@panel_prices_LP_full_middle + ' input,' +
																									@@panel_prices_LP_full_middle + ' [class*=lpName],' +
																									@@panel_prices_LP_full_middle + ' [class*=rung-value]'
	@@panel_prices_LP_full_subType					= @@panel_prices_LP_full_middle + ' [class*=date],' +
																									@@panel_prices_LP_full_middle + ' [class*=midRate]'
	@@panel_prices_LP_full_bid 							= @@panel_prices_LP_full + ' [class*=sell]'
	@@panel_prices_LP_full_bid_amount 			= @@panel_prices_LP_full_bid + ' [class*=sap-amount]'
	@@panel_prices_LP_full_bid_bigFigure 		= @@panel_prices_LP_full_bid + ' [class=bigFigure]'
	@@panel_prices_LP_full_bid_pip 					= @@panel_prices_LP_full_bid + ' [class=pip]'
	@@panel_prices_LP_full_bid_decimal 			= @@panel_prices_LP_full_bid + ' [class=decimal]'
	@@panel_prices_LP_full_offer 						= @@panel_prices_LP_full + ' [class*=buy]'
	@@panel_prices_LP_full_offer_amount 		= @@panel_prices_LP_full_offer + ' [class*=sap-amount]'
	@@panel_prices_LP_full_offer_bigFigure 	= @@panel_prices_LP_full_offer + ' [class=bigFigure]'
	@@panel_prices_LP_full_offer_pip 				= @@panel_prices_LP_full_offer + ' [class=pip]'
	@@panel_prices_LP_full_offer_decimal 		= @@panel_prices_LP_full_offer + ' [class=decimal]'

	# ind ot, and ind sw are treated diffrenetly in the code.
	@@panel_prices_ot_ind 									= @@panel_prices_LP_full
	@@panel_prices_ot_ind_amount 						= '[class*=qty]>input'
	@@panel_prices_sw_ind_amount 						= '[class*=qty]>input'
	@@panel_prices_sw_ind 									= @@panel_prices_LP_full
	@@panel_prices_sw_ind_bid_price					= @@panel_prices_LP_full_bid + '>[class=rate-body]>span'
	@@panel_prices_sw_ind_offer_price				= @@panel_prices_LP_full_offer + '>[class=rate-body]>span'

	@@panel_current = '.sap-price-column'
	@@panel_current_End								= '.header-control'
	@@panel_current_tradingDates 			= ' [class*=valueDate]:not([class*=col]),[class*="-SW"] [class*=header][class*=tenor]'
	@@panel_current_currencyPair 			= @@panel_current + ' .currencyPair' 	+ '.header-control input'
	@@panel_current_liquidityProvider = @@panel_current + ' .productType'		+ '.header-control .selected'
	@@panel_current_productType 			= @@panel_current_liquidityProvider
	@@panel_current_priceModel				= @@panel_current + ' .priceModel'		+ '.header-control .selected'
	@@panel_current_dealtAmount		 		= @@panel_current + ' .qty'						+ ' input'
	@@panel_current_dealtCCY					= @@panel_current + ' .dealt-ccy'			+ '.header-control'
	@@panel_current_pdValue						= @@panel_current + ' .pd'						+ ' input'
	@@panel_current_calculatorType 		= @@panel_current_priceModel
	@@panel_current_floor 						= @@panel_current + ' .floor' 				+ ' .selected'
	@@panel_current_mainPrice_buy_base  = @@panel_current + ' .sap-rate-button.buy[data-top-price="true"]'
  @@panel_current_mainPrice_sell_base = @@panel_current + ' .sap-rate-button.sell[data-top-price="true"]'
	@@panel_current_mainPrice_buy			  = @@panel_current_mainPrice_buy_base  + @@NotEmpty
	@@panel_current_mainPrice_sell		  = @@panel_current_mainPrice_sell_base + @@NotEmpty
  @@panel_current_mainPrice_pip       = ' .pip'
	@@btn_panel_view = '.header-buttons'
	@@btn_panel_viewWithType 					= @@btn_panel_view + ' [class*=TEXT]'
	@@btn_panel_currencyPair 					= @@panel_current + ' .currencyPair' 	+ ' input'
	@@btn_panel_currencyPair_remove 	= ' button[class*=remove]'
	@@menu_panel_currencyPair					= @@panel_current + ' .currencyPair' 	+ @@MenuElement
	@@btn_panel_productType 					= @@panel_current + ' .productType'		+ ' .selected'
	@@menu_panel_productType					= @@panel_current + ' .productType' + @@MenuElement
	@@btn_panel_calculatorType 				= @@panel_current + ' .priceModel' + ' .selected'
	@@menu_panel_calculatorType 			= @@panel_current + ' .priceModel' + @@MenuElement
	@@btn_panel_floor 								= @@panel_current + ' .floor' + ' .selected'
	@@menu_panel_floor								= @@panel_current + ' .floor' + @@MenuElement
	@@btn_panel_tenors 								= @@panel_current + ' .tenor' + '.header-control .selected'
	@@menu_panel_tenors 							= @@panel_current + ' .tenor' + @@MenuElement
	@@panel_current_tenors 						= @@panel_current + ' .tenor' + '.header-control .selected'
	@@panel_current_tenor 						= @@panel_current_tenors
	@@btn_panel_tenor 								= @@btn_panel_tenors
	@@menu_panel_tenor								= @@menu_panel_tenors
	@@btn_panel_dealtAmount 					= ' .qty' + ' input'				# No start of @panel_current
	@@menu_panel_dealtAmount 					= ' .qty' + @@MenuElement 	# No start of @panel_current
	@@btn_panel_dealtCCY							= @@panel_current + ' .dealt-ccy'
	@@btn_panel_addPanel = ' [class*=add-panel][class*=button]'
	@@panel_header_line		= @@panel + ' [class=bottom-bar]'
	@@btn_panel_header_Rfq	= @@panel_header_line + ' [class*=button-rfq]'
	@@btn_panel_line_Rfq		= @@panel_prices_LP_full + ' [class*=rfq][class*=button]'

	@@panel_footer									= '[class*=panel-footer]'
	@@btn_panel_footer_home 				= @@panel_footer + ' [class*=option-home]'
	@@btn_panel_footer_volumeLadder = @@panel_footer + ' [class*=option-volumeLadder]'
	@@btn_panel_footer_lpLadder			= @@panel_footer + ' [class*=option-lpLadder]'
	@@btn_panel_footer_tenorLadder	= @@panel_footer + ' [class*=option-tenorLadder]'

	@@panelBody							= '.top-price-container'
	@@panel_rfqLine					= '[class*=bottom-bar]'
	@@btn_rfqLine_bid				= @@panel_rfqLine + ' button[class*=button-bid]'
	@@btn_rfqLine_offer			= @@panel_rfqLine + ' button[class*=button-offer]'
	@@btn_rfqLine_rfq				= @@panel_rfqLine + ' button[class*=button-rfq]'
	@@btn_rfqLine_rfqCancel	= '.rfq-cancel'
	@@btn_orderForm_CANCEL	= @@panelBody + ' .cancel'
	@@btn_orderForm_HOLD		= @@panelBody + ' .hold'
	@@btn_orderForm_SEND		= @@panelBody + ' .send'
	@@panelOrderForms_priceField								= @@panelBody + ' .sap-price-edit'
	@@panelOrderForms_priceField_bigFigure			= @@panelOrderForms_priceField + ' .big-figure'
	@@panelOrderForms_priceField_pip						= @@panelOrderForms_priceField + ' .pip'
	@@btn_panelOrderForms_priceField_add				= @@panelOrderForms_priceField + ' .add'
	@@btn_panelOrderForms_priceField_subtract		= @@panelOrderForms_priceField + ' .subtract'

	@@panelOrderForms_current_ecn				= @@panelBody + ' [class*=ecn-selector]'
	@@panelOrderForms_current_algo 			= @@panelBody + ' .algo'
	@@panelOrderForms_current_iceberg 	= @@panelBody + ' .iceberg'
	@@panelOrderForms_current_tif				= @@panelBody + ' [options=tifOptions] .selected'
	@@panelOrderForms_current_bid				= @@panelBody + ' .bid .side-value'
	@@panelOrderForms_current_offer			= @@panelBody + ' .offer .side-value'
	@@panelOrderForms_current_priceType	=	@@panelBody + ' .price-type .selected'
	@@btn_panelOrderForms_cptys					= @@panelBody + ' .cptys'
	@@panelOrderForms_current_cptys			= @@btn_panelOrderForms_cptys
	@@btn_panelOrderForms_tif 					= @@panelBody + ' [options=tifOptions]'
	@@menu_panelOrderForms_tif					= @@btn_panelOrderForms_tif +  @@MenuElement
	@@btn_panelOrderForms_priceType			= @@panelBody + ' .price-type .selected'
	@@menu_panelOrderForms_priceType		= @@panelBody + ' .price-type' + @@MenuElement

	@@datepicker_open = 'input[ui-date="dateOptions"]'
	@@datepicker_opened = '[class*=panels-container] [class*=settings-open]'
	@@datepicker_datepicker = @@datepicker_opened + " [class*=calendars-wrapper]>[class*=date-picker]:not([class*=hidden])"
	@@datepicker_header = @@datepicker_datepicker  + " [class*=header]"
	@@btn_datepicker_next = @@datepicker_header + " [class*=next]"
	@@btn_datepicker_old_next = ' [class*=ui-datepicker-next]'
	@@btn_datepicker_prev = @@datepicker_header + " [class*=prev]"
	@@btn_datepicker_old_prev = ' [class*=ui-datepicker-prev]'
	@@datepicker_table = @@datepicker_datepicker + " table"
	@@datepicker_old_table = " table"
	@@datepicker_table_Near = @@datepicker_table
	@@datepicker_table_Far = @@datepicker_table
	@@datepicker_nonTradeableDayInMonth = @@datepicker_datepicker + ' td[class*=ui-datepicker-unselectable]:not([class*=other-month])'
	@@datepicker_nonTradeableDayForOtherMonth = @@datepicker_datepicker + ' td[class*=other-month]'
	@@datepicker_dayInTable = 'td[data-handler="selectDay"]'
	@@datepicker_setDateValue = '[class*=header][class*=TEXT] [class*=chosen] input' # TEXT=near/far
	@@btn_datepicker_near = @@datepicker_opened + " div[class*=near][class*=leg] [class*=title]"
	@@btn_datepicker_far = @@datepicker_opened + " div[class*=far][class*=leg] [class*=title]"
	@@datepicker_currentDateMonth = @@datepicker_datepicker + " [class*=ui-datepicker-title] [class*=month]"
	@@datepicker_currentDateYear = @@datepicker_datepicker + " [class*=ui-datepicker-title] [class*=year]"
	@@datepicker_old_currentDateMonth = " [class*=ui-datepicker-title] [class*=month]"
	@@datepicker_old_currentDateYear = " [class*=ui-datepicker-title] [class*=year]"
	@@btn_datepicker_close = 'button[class*=close]'
	@@btn_datepicker_old_close = '[class*=button][class*=close]'
	@@datepicker_tenors = @@datepicker_opened  + ' [class*=tenor-tables-wrapper]>[class*=TEXT]' # TEXT=near/far
	@@btn_datepicker_tenors = @@datepicker_tenors + ' [data-tenor-name]:not([class*=hide])'			# TEXT=near/far

	if (ENV["SAP_RELEASE_NUMBER"].to_s == "5")
		@@panel_current_tradingDates = ' [class*=valueDate]:not([class*=col]),[class*="-SW"] [class*=header][class*=tenor]'
		@@btn_panel_productType = '[class*="productType"]'
		@@datepicker_tenors = @@datepicker_opened + " [class*=tenor-tables-wrapper] [class*=tenors-table][class*=TEXT]"
		@@btn_datepicker_tenors = @@datepicker_tenors + ' [data-tenor-name]:not([class*=hide])'
	end

	@@btn_panel_lp	 = @@btn_panel_productType
	@@menu_panel_lp = @@menu_panel_productType

	####### Hash inplementation of the selectros (required for web_feture.rb and UiHelpers.rb) ###

	@@css['general'] = {
			'dropdownOption' 		=> @@general_dropdownMenu_option,
			'dropdownOption2' 	=> @@general_dropdownMenu_option2,
			'dropdownOption3' 	=> @@general_dropdownMenu_option3,
			'rightClickOption' 	=> @@general_rightClick_option,
			'lockedSystem'			=> @@locked_system,
			'columnName'				=> @@general_column_name
	}


	############################################# MAIN SELECTORS ########################################
	# Here exist only selectors that should be exist when Sapphire starts (even without prices)
	@@css['header'] = {
			'tradeBtn' 					=> @@btn_header_trade,
			'reportsBtn' 				=> @@btn_header_reports,

			'floorDropdown'			=> @@header_floorDropdown,
			'currentUserId'			=> @@header_currentUserId,
			'currentDateTime'		=> @@header_currentDateTime,
			'logoutBtn'					=> @@btn_header_logout,
			'keyboardBtn'				=> @@btn_header_keyboard,
			'lockBtn' 					=> @@btn_header_lock,
			'helpBtn'						=> @@btn_header_help,
			'qos'								=> @@header_qos,
			'connection'				=> @@header_connection,
			'settingsBtn' 			=> @@btn_header_settings,

			'currentPage' 			=> @@header_currentPage
	}

	@@css['deals'] = {
			'header'			=> @@deals_header,
			'tabsLine'		=> @@deals_tabsLine,
			'dealsTab'		=> @@deals_dealsTab,
			'findBtn'			=> @@btn_deals_find,
			'downloadBtn'	=> @@btn_deals_download,
			'settingsBtn'	=> @@btn_deals_settings,
			'column'			=> @@deals_columns_column
	}

	@@css['orders'] = {
			'header'					=> @@orders_header,
			'offallBtn'				=> @@btn_orders_offall,
			'superOffallBtn'	=> @@btn_orders_superOffAll,
			'clearBtn'				=> @@btn_orders_clear,
			'pauseBtn'				=> @@btn_orders_pause,
			'sendBtn'					=> @@btn_orders_send
	}

	#######################################END OF MAIN SELECTORS ########################################


	###################################SELECTORS RELATED TO PAGE/TAB #####################################
	# Here exist selectors that are related to the page/tab we are currently in.
	@@css['reports'] = {
			'tab'								=> @@reports_tab,
			'dealsTabBtn'				=> @@btn_reports_tab_deals,
			'currentTab'				=> @@reports_currentTab,
			'dateTypeDropdown'	=> @@reports_dateType_Dropdown,
			'dateRangeDropdown'	=> @@reports_dateRange_Dropdown,
			'fromDate'					=> @@reports_fromDate,
			'toDate'						=> @@reports_toDate,
			'searchTextField'		=> @@reports_searchField,
			'lastUpdated'				=> @@reports_lastUpdated,
			'downloadBtn'				=> @@btn_reports_download,
			'column'						=> @@reports_column
	}

	@@css['settings'] = {
			'tab'												=> @@settings_tab,
			'currentTab'								=> @@settings_currentTab,
			'tabBtn' 										=> @@btn_settings_tab,
			'generalBtn'								=> @@btn_settings_tab_general,
			'liquiditySourcesBtn'				=> @@btn_settings_tab_liquiditysources,
			'generalDoneBtn'						=> @@btn_settings_Done,
			'liquiditySourcesDoneBtn'		=> @@btn_settings_Done
	}

	@@css['trade'] = {
			'tab'							=> @@trade_tab,
			'tabBtn' 					=> @@btn_trade_tab,
			'swapsBtn'				=> @@btn_trade_tab_swaps,
			'outrightSwpBtn'	=> @@btn_trade_tab_outrightswp,
			'spotBtn'					=> @@btn_trade_tab_spot,
			'outrightsBtn'		=> @@btn_trade_tab_outrights,
			'currentTab' 			=> @@trade_currentTab
	}

	@@css['signin'] = {
			'username' => @@signin_username,
			'apps'		 => @@signin_appDropdown,
			'signinBtn' => @@btn_signin_signin,
			'otherBankName' => @@signin_otherBankName,
			'continueAnywayBtn' => @@btn_signin_continueAnyway
	}
	################################### END OF SELECTORS RELATED TO PAGE/TAB ##############################


	@@css['panel'] = {
			'panel'												=> @@panel,
			'pricesLPLive'								=> @@panel_prices_LP_live,
			'pricesLPLiveBid'							=> @@panel_prices_LP_live_bid,
			'pricesLPLiveBidAmount'				=> @@panel_prices_LP_live_bid_amount,
			'pricesLPLiveBidBigFigure'		=> @@panel_prices_LP_live_bid_bigFigure,
			'pricesLPLiveBidPip'					=> @@panel_prices_LP_live_bid_pip,
			'pricesLPLiveBidDecimal'			=> @@panel_prices_LP_live_bid_decimal,
			'pricesLPLiveOffer'						=> @@panel_prices_LP_live_offer,
			'pricesLPLiveOfferAmount'			=> @@panel_prices_LP_live_offer_amount,
			'pricesLPLiveOfferBigFigure' 	=> @@panel_prices_LP_live_offer_bigFigure,
			'pricesLPLiveOfferPip'				=> @@panel_prices_LP_live_offer_pip,
			'pricesLPLiveOfferDecimal'		=> @@panel_prices_LP_live_offer_decimal,
			'pricesLPFull'								=> @@panel_prices_LP_full,
			'pricesLPFullType'						=> @@panel_prices_LP_full_type,
			'pricesLPFullSubType'					=> @@panel_prices_LP_full_subType,
			'pricesLPFullBidAmount' 			=> @@panel_prices_LP_full_bid_amount,
			'pricesLPFullBidBigFigure'		=> @@panel_prices_LP_full_bid_bigFigure,
			'pricesLPFullBidPip'					=> @@panel_prices_LP_full_bid_pip,
			'pricesLPFullBidDecimal'			=> @@panel_prices_LP_full_bid_decimal,
			'pricesLPFullOfferAmount' 		=> @@panel_prices_LP_full_offer_amount,
			'pricesLPFullOfferBigFigure'	=> @@panel_prices_LP_full_offer_bigFigure,
			'pricesLPFullOfferPip'				=> @@panel_prices_LP_full_offer_pip,
			'pricesLPFullOfferDecimal'		=> @@panel_prices_LP_full_offer_decimal,

			'pricesOtInd'									=>	@@panel_prices_LP_full,
			'pricesOtIndAmount'						=>	@@panel_prices_ot_ind_amount,
			'pricesOtIndBidBigFigure'			=>	@@panel_prices_LP_full_bid_bigFigure,
			'pricesOtIndBidPip'						=>	@@panel_prices_LP_full_bid_pip,
			'pricesOtIndBidDecimal'				=>	@@panel_prices_LP_full_bid_decimal,
			'pricesOtIndOfferBigFigure'		=>	@@panel_prices_LP_full_offer_bigFigure,
			'pricesOtIndOfferPip'					=>	@@panel_prices_LP_full_offer_pip,
			'pricesOtIndOfferDecimal'			=>	@@panel_prices_LP_full_offer_decimal,

			'pricesSwInd'									=> @@panel_prices_LP_full,
			'pricesSwIndAmount'						=> @@panel_prices_sw_ind_amount,
			'pricesSwIndBidPrice'					=> @@panel_prices_sw_ind_bid_price,
			'pricesSwIndOfferPrice'				=> @@panel_prices_sw_ind_offer_price,

			'currentTradingDates' 				=> @@panel_current_tradingDates,
			'currentCurrencyPair' 				=> @@panel_current_currencyPair,
			'currentLiquidityProvider' 		=> @@panel_current_liquidityProvider,
			'currentCalculatorType' 			=> @@panel_current_calculatorType,
			'viewBtn' 				 => @@btn_panel_view,
			'viewBtnWithType'	 => @@btn_panel_viewWithType,
			'currencyPairBtn'  => @@btn_panel_currencyPair,
			'currencyPairMenu' => @@menu_panel_currencyPair,
			'productTypeBtn' 	 => @@btn_panel_productType,
			'productTypeMenu'  => @@menu_panel_productType,
			'floorBtn'				 => @@btn_panel_floor,
			'floorMenu'				 => @@menu_panel_floor,
			'tenorsBtn'				 => @@btn_panel_tenors,
			'tenorsMenu'			 => @@menu_panel_tenors,
			'headerRfqBtn'		 => @@btn_panel_header_Rfq,
			'lineRfqBtn'			 => @@btn_panel_line_Rfq
	}

	@@css['datepicker'] = {
			'open' => @@datepicker_open,
			'opened' => @@datepicker_opened ,
			'nextMonthBtn' => @@btn_datepicker_next ,
			'prevMonthBtn' => @@btn_datepicker_prev ,
			'currentMonth' => @@datepicker_currentDateMonth ,
			'currentYear' => @@datepicker_currentDateYear ,
			'tableNear'		=> @@datepicker_table_Near,
			'tableFar'		=> @@datepicker_table_Far,
			'dayInTable'	=> @@datepicker_dayInTable,
			'nonTradableDayInMonth'	=> @@datepicker_nonTradeableDayInMonth,
			'nonTradableDayForOtherMonth'	=> @@datepicker_nonTradeableDayForOtherMonth,
			'nearBtn' => @@btn_datepicker_near ,
			'farBtn' => @@btn_datepicker_far ,
			'close' => @@btn_datepicker_close,
			'tenorBtns' => @@btn_datepicker_tenors  #TEXT=near/far
	}


	@@btnLogout = 'div.sap-app-status-toolbar a.logout'

    def initialize()

    end

	def value(part, subPart, baseElement, num=-1, text=nil)
		element = self.element(part, subPart, baseElement, -1, num, text)
		if (element == nil)
			UiHelpers.throw("No element ")
		else
			element = element["element"]
		end

		textVal = ""
		begin
			textVal = element.text
		rescue
		end

		if (textVal == "")
			begin
				textVal = element["value"]
				if (textVal == "")
					textVal = element["innerHTML"]
				end
			rescue
			end
		end

		return textVal
	end

	def elements(part, subPart, baseElement, num=-1, text=nil)
		elements = nil
		css = self.css(part, subPart, num, text)
		if (css != nil)
			elements = baseElement.find_elements(:css, css)
		end

		return elements
	end



		def element(part, subPart, baseElement, sleepAfterClick=-1, num=-1, text=nil)
			errors = ""
			toReturn = {}
			parameters = "(part=#{part.to_s}, subPart=#{subPart.to_s}, num=#{num.to_s}, text=#{text.to_s})"
			toReturn["parameters"] = parameters
			css = self.css(part, subPart, num, text)
			if (css == nil)
				errors = "No such css"
			else
				begin
					element = self.elements(part, subPart, baseElement, num, text)[0]
					toReturn["element"] = element
				rescue
				end

				if (element == nil)
					errors = "Element not found"
				else
					if (sleepAfterClick >= 0)
						begin
							toReturn["clicked"] = false
							element.click
							if (sleepAfterClick > 0)
								sleep(sleepAfterClick)
							end
							toReturn["clicked"] = true
						rescue Exception=>e
							errors = "Element not clicked (error: #{e.message.to_s})"
						end
					end
				end
			end
			toReturn["errors"] = errors

			return toReturn
		end

    def css(part, sub_part, num=-1, text=nil)
      to_ret = nil
      if ((part != nil) && (sub_part != nil) && (@@css.key?(part) && (@@css[part].key?(sub_part))))
        css = @@css[part][sub_part]
				to_ret = css.dup
        if (num.to_i >= 0)
           to_ret = to_ret.sub('NUMBER_FOR_INDEX', num.to_s)
        end

        if (text != nil)
          to_ret = to_ret.sub('TEXT', text.to_s)
        end
      end
      return to_ret
		end

		def cssHash(part, num=-1, text=nil)
			toRet = {}
			if ((part != nil) && (@@css.key?(part)))
				@@css[part].each do |subPart, css|
					curCss = css.dup
					if (num.to_i >= 0)
						curCss = curCss.sub('NUMBER_FOR_INDEX', num.to_s)
					end

					if (text != nil)
						curCss = curCss.sub('TEXT', text.to_s)
					end

					toRet[subPart] = curCss
				end
			end

			return toRet
		end


	  def Controls.get(element_name, text=nil, number=nil)
      toRet = ""
      begin
			  css = Controls.class_variable_get('@@'+element_name)
			  toRet = css.dup # Since bug was found for using sub of the element returned from Controls.
      rescue
        log "No css (name: #{element_name.to_s})"
      end

			if (text != nil)
				toRet = toRet.sub('TEXT', text.to_s)
			end

			if (number != nil)
				toRet = toRet.sub('NUMBER_FOR_INDEX', number.to_s)
			end
			return toRet
		end

		def Controls.click(element_name, baseElement)
			css = self.get(element_name)
			if ((css != nil) && (baseElement != nil))
				e = baseElement.find_elements(:css, css)[0]
				begin
					e.click()
				rescue Exception=>e
					UiHelpers.throw("No css (#{element_name})")
				end
			end
		end
	def Controls.click2(element_name, baseElement, onFailureRaiseException = true,
											onFailureAddToScenarioFails = false,
											onFailureWriteToActionsF = false,
											onFailureCreateScreenshot = false)
		css = self.get(element_name)
		if ((css == nil) || (css == ""))
			UiHelpers.throw("No css (#{element_name})", onFailureRaiseException, onFailureAddToScenarioFails,
											onFailureWriteToActionsF, onFailureCreateScreenshot)
		end

		if (baseElement == nil)
			UiHelpers.throw("No baseElement", onFailureRaiseException, onFailureAddToScenarioFails,
											onFailureWriteToActionsF, onFailureCreateScreenshot)
		end

		begin
			e = baseElement.find_elements(:css, css)[0]
		rescue
		end

		if (e == nil)
			UiHelpers.throw("No element found", onFailureRaiseException, onFailureAddToScenarioFails,
											onFailureWriteToActionsF, onFailureCreateScreenshot)
		end

		begin
				e.click()
		rescue Exception=>e
				UiHelpers.throw("Failed to click", onFailureRaiseException, onFailureAddToScenarioFails,
												onFailureWriteToActionsF, onFailureCreateScreenshot)
				e = nil
		end

		return e
	end

		def Controls.value(element_name, baseElement, text=nil)
			css = self.get(element_name, text)
			if (css == nil)
				UiHelpers.throw("No css (#{element_name})")
			end

			e = baseElement.find_elements(:css, css)[0]
			if (e == nil)
				UiHelpers.throw("No element (#{element_name})")
			end

			toRet = e.text
			if (toRet == "")
				toRet = e["value"]
			end

			return toRet.to_s
		end
	def Controls.value2(element_name, baseElement, onFailureRaiseException = true,
											onFailureAddToScenarioFails = false, onFailureWriteToActionsF = false,
											onFailureCreateScreenshot = false, text=nil)
		css = self.get(element_name, text)
		if (css == nil)
			UiHelpers.throw("No css (#{element_name})", onFailureRaiseException, onFailureAddToScenarioFails,
											onFailureWriteToActionsF, onFailureCreateScreenshot)
    end
    toRet = nil
    e = nil
    all = baseElement.find_elements(:css, css)
    if ((all != nil) && (all.length > 0))
      e = all[0]
    end
		if (e == nil)
			UiHelpers.throw("No element (#{element_name})", onFailureRaiseException, onFailureAddToScenarioFails,
											onFailureWriteToActionsF, onFailureCreateScreenshot)
		else
			toRet = e.text
			if (toRet == "")
				toRet = e["value"]
			end
		end
		return toRet.to_s
	end

	def Controls.allElements(element_name, baseElement, text=nil)
		css = self.get(element_name, text)
		if (css == nil)
			UiHelpers.throw("No css (#{element_name})")
		end

		all = baseElement.find_elements(:css, css)
		return all
	end

	def Controls.firstElement(element_name, baseElement, text=nil)
		toRet = nil
		all = Controls.allElements(element_name, baseElement, text)
		if ((all != nil) && (all.length > 0))
			toRet = all[0]
		end

		return toRet
	end


	def Controls.validateElementExists(element_name, baseElement, messageWhileWaiting="waiting for element...",
															messageIfNotFound="element not found",  messageIfFound="element found")
			e = nil
			for numberOfSecondsToWait in 1..4 do
				begin
					e = Controls.firstElement(element_name, baseElement)
				rescue
					UiHelpers.throw(element_name)
				end

				if (e == nil)
					Controls.log(messageWhileWaiting)
				else
					Controls.log(messageIfFound)
					break
				end

				sleep numberOfSecondsToWait
			end
			if (e == nil)
				UiHelpers.throw(messageIfNotFound)
			end

			return e
	end

	def Controls.log(message, filename=nil, parentFunc=nil)
		if (parentFunc == nil)
			parentFunc = caller_locations(1).first.label
		end
		parentFunc = parentFunc.gsub(/^.*\W(\w+)$/,'\1')
		if ((parentFunc.include?("block")) &&  (parentFunc.include?("in")))
			parentFunc = "main"
		end

		if (filename == nil)
			filename = File.basename(__FILE__)
		end
		filename = filename.gsub(/^(.*).rb$/,'\1').to_s
		parentFunc = parentFunc.to_s
		message = message.to_s
		toExclude = [
				"Panel getAllPanels",
				"Panel ctorNumOrId"
		]

		messageHeader = "#{filename} #{parentFunc}"
		if (! toExclude.include?(messageHeader))
			msg = "#{messageHeader}: #{message}"
			Actions.v(msg)
		end
	end
	end