require_relative 'Panel'

class SettingsPanel < Panel
  def initialize(ui, type, data, data2 = nil, data3 = nil)
    super(ui, type, data, data2, data3)
    @ui = getUI()
    @num = getPanelNumber()
    @@baseElementName = "settingsPanel"
  end

  def open()
    panel = getActivePanelElement()
    eName = "btn_#{@@baseElementName}_open"
    btn = Controls.firstElement(eName, panel)
    @ui.clickOnWebElement(btn)
  end

  def close(          onFailureRaiseException = true,
                      onFailureAddToScenarioFails = false,
                      onFailureWriteToActionsF = false,
                      onFailureCreateScreenshot = false)
    panel = getActivePanelElement()
    eName = "btn_#{@@baseElementName}_close"
    btn = Controls.firstElement(eName, panel)
    @ui.clickOnWebElement(btn, 2)
  end

  def selectSection(sectionName) # SectionName is taken from Globals.panelSettingsSection...
    eName = "btn_#{@@baseElementName}#{sectionName}_select"
    baseElement = @ui.getBaseElement()
    btn = Controls.firstElement(eName, baseElement)
    @ui.clickOnWebElement(btn)
  end

  def getLPs(shouldOpenBefore = false, shouldCloseAfter = false)
    allLps = {}
    cptys = Globals.panelSettingsSectionCptys
    if (shouldOpenBefore)
      open()
    end
    baseElement = @ui.getBaseElement()
    selectSection(cptys)
    eName = "checkbox_#{@@baseElementName}#{cptys}_selectLP"
    allCheckboxLines = Controls.allElements(eName, baseElement)
    allCheckboxLines.each do |checkboxLine|
      name = checkboxLine.text().to_s
      e = Controls.firstElement("checkbox", checkboxLine)
      if (e["class"].to_s.downcase =~ /not.empty/)
        value = "on"
      else
        value = "off"
      end
      if ((! name.empty?) && (! value.empty?))
        allLps[name] = value
      end
    end
    if (shouldCloseAfter)
      close()
    end
    return allLps
  end

  def getLPsOn(shouldOpenBefore = false, shouldCloseAfter = false)
    lps = getLPs(shouldOpenBefore, shouldCloseAfter)
    lpsOn = lps.select{|k,v| [Globals.settingsOn].include? v}.keys
    return lpsOn
  end

  def setLPs(hashOfSettings = nil) # When hash is nil, all Counterparties checkbox will be selected.
    cptys = Globals.panelSettingsSectionCptys
    eNameAllConterparties = "checkbox_#{@@baseElementName}#{cptys}_selectAll"
    baseElement = @ui.getBaseElement()
    selectSection(cptys)
    if (hashOfSettings == nil)
      hashOfSettings = {Globals.cptyAllCounterpaties => Globals.settingsOn}
    end
    if (! hashOfSettings.has_key?(Globals.cptyAllCounterpaties))
      hashOfSettings[Globals.cptyAllCounterpaties] = Globals.settingsOff
    end

    log "1. setting #{Globals.cptyAllCounterpaties}"
    allCounterpartiesCheckboxElement = Controls.firstElement(eNameAllConterparties, baseElement)
    if (allCounterpartiesCheckboxElement["class"].to_s.downcase =~ /not.empty/)
      allCounterpartiesValue = Globals.settingsOn
    else
      allCounterpartiesValue = Globals.settingsOff
    end
    if (allCounterpartiesValue != hashOfSettings[Globals.cptyAllCounterpaties])
      @ui.clickOnWebElement(allCounterpartiesCheckboxElement)
    end

    log "2. if exist #{Globals.cptyOthers}, settings all other checkboxes accordingly"
    eName = "checkbox_#{@@baseElementName}#{cptys}_selectLP"
    allCheckboxLines = Controls.allElements(eName, baseElement)
    if (hashOfSettings.has_key? (Globals.cptyOthers))
      requiredValue = hashOfSettings[Globals.cptyOthers]
      allCheckboxLines.each do |checkboxLine|
        e = Controls.firstElement("checkbox", checkboxLine)
        if (e["class"].to_s.downcase =~ /not.empty/)
          value = "on"
        else
          value = "off"
        end
        if (value != requiredValue)
          @ui.clickOnWebElement(e)
        end
      end
    end

    log "3. setting specific checkboxes"
    allCheckboxLines.each do |checkboxLine|
      name = checkboxLine.text().to_s
      if (! hashOfSettings.has_key?(name))
        next
      end
      requiredValue = hashOfSettings[name]
      e = Controls.firstElement("checkbox", checkboxLine)
      if (e["class"].to_s.downcase =~ /not.empty/)
        value = "on"
      else
        value = "off"
      end
      if (value != requiredValue)
        @ui.clickOnWebElement(e)
      end
    end
  end

  def getProperties()
    errors = ""
    pricing = Globals.panelSettingsSectionPricing
    warning = Globals.panelSettingsSectionWarning
    cptys = Globals.panelSettingsSectionCptys
    hashProperties = {}
    hashEnames = {
        pricing => {
            "#{Globals.dealItemEcn}" => "#{@@baseElementName}#{pricing}_#{Globals.dealItemEcn}",
            "#{Globals.dealItemdealtAmount}" => "#{@@baseElementName}#{pricing}_dealtAmount",
            "#{Globals.panelDDCalcType}" => "#{@@baseElementName}#{pricing}_priceModel",
            "#{Globals.panelOrderformsAlgo}" => "#{@@baseElementName}#{pricing}_algo",
            "#{Globals.panelDDpdValue}" => "#{@@baseElementName}#{pricing}_pdValue",
        },
        warning => {
            "warnAbove" => "field_#{@@baseElementName}#{warning}_warnAbove",
            "largeSpread" => "field_#{@@baseElementName}#{warning}_largeSpread",
            "largeDifference" => "field_#{@@baseElementName}#{warning}_largeDifference"
        },
        cptys => {
            "lps" => "checkbox_#{@@baseElementName}#{cptys}_selectLP"
        }
    }

    hashSectionBtnsEnames = {
        Globals.panelSettingsSectionPricing => "btn_#{@@baseElementName}#{pricing}_select",
        Globals.panelSettingsSectionWarning => "btn_#{@@baseElementName}#{warning}_select",
        Globals.panelSettingsSectionCptys   => "btn_#{@@baseElementName}#{cptys}_select"
    }

    baseElement = @ui.getBaseElement()
    for section in hashEnames.keys
      curHashProperties = {}
      selectSection(section)
      for key in hashEnames[section].keys
        begin
          eName = hashEnames[section][key]
          css = Controls.get(eName, baseElement)
          if (((css == nil) || (css == "")) && (eName !~ /^field/i))
            log "No css for element name: #{eName}"
            eName = "field_#{eName}"
            log "Searching instead for css for element name: #{eName}"
            css = Controls.get(eName, baseElement)
            if ((css != nil) && (css != ""))
              log Globals.messagePassed
            else
              error = "#{Globals.messageFailed}, no css"
              UiHelpers.throw(error, true, false, false, false)
            end
          end
          log "searching element (name: #{eName})"
          elements = baseElement.find_elements(:css, css)
          log "#{Globals.messagePassed}, getting values (name: #{eName})"
          values = []
          elements.each do |element|
            value = @ui.getValueOrTextOrInnerHTML(element, false)
            if ((value != nil) && (value != ""))
              log "#{Globals.messagePassed} (name: #{eName}, value: #{value.to_s})"
              values.push(value)
            end
          end
          if (values.length > 0)
            if (values.length == 1)
              curHashProperties[key] = values[0]
            else
              curHashProperties[key] = values
            end
          else
            error = "No values found"
            UiHelpers.throw(error, true, false, false, false)
          end
        rescue => e
          errMessage = "Error while geting values (name: #{eName.to_s}, error: #{e.message})"
          errors += "#{errMessage}\n"
        end
      end
      if (curHashProperties.length > 0)
        hashProperties[section] = curHashProperties
      end
    end

    if (errors != "")
      log errors
      hashProperties = {}
    end
    return hashProperties
  end

  def setDefaultValues()
    raise "NOT IMPLEMENTED"
    setOrderformsPanelDDMenu2(Globals.panelDDdealtAmount, Globals.dealtAmountStr1M)
    setOrderformsPanelDDMenu2(Globals.panelDDpdValue, "0.0")
    setOrderformsPanelDDMenu2(Globals.panelOrderformsCptys,
                                {
                                    Globals.cptyABC1=> Globals.checkboxChecked,
                                    Globals.cptyABC2=> Globals.checkboxChecked,
                                    Globals.cptyARKA=> Globals.checkboxChecked,
                                    Globals.cptyAcc1=> Globals.checkboxChecked,
                                    Globals.cptyAcc2=> Globals.checkboxChecked,
                                    Globals.cptyAcc4=> Globals.checkboxChecked,
                                    Globals.cptyAcc6=> Globals.checkboxChecked,
                                    Globals.cptyAcc7=> Globals.checkboxChecked,
                                    Globals.cptyAff1=> Globals.checkboxChecked,
                                    Globals.cptyAff2=> Globals.checkboxChecked,
                                    Globals.cptyC1TC=> Globals.checkboxChecked,
                                    Globals.cptyC1TD=> Globals.checkboxChecked,
                                    Globals.cptyEMSQ=> Globals.checkboxChecked,
                                    Globals.cptyLP32=> Globals.checkboxChecked,
                                    Globals.cptyLP33=> Globals.checkboxChecked,
                                    Globals.cptyLPE2=> Globals.checkboxChecked,
                                    Globals.cptyLPLA=> Globals.checkboxChecked,
                                    Globals.cptyLPLB=> Globals.checkboxChecked,
                                    Globals.cptyLPLK=> Globals.checkboxChecked,
                                    Globals.cptyLPLL=> Globals.checkboxChecked,
                                    Globals.cptyLPP1=> Globals.checkboxChecked,
                                    Globals.cptyLPP2=> Globals.checkboxChecked,
                                    Globals.cptyLPRI=> Globals.checkboxChecked,
                                    Globals.cptyLPRJ=> Globals.checkboxChecked,
                                    Globals.cptyLPRK=> Globals.checkboxChecked,
                                    Globals.cptyLPRL=> Globals.checkboxChecked,
                                    Globals.cptyLPRM=> Globals.checkboxChecked,
                                    Globals.cptyLSQ1=> Globals.checkboxChecked,
                                    Globals.cptyLPTA=> Globals.checkboxChecked,
                                    Globals.cptyLPTB=> Globals.checkboxChecked,
                                    Globals.cptyLPTC=> Globals.checkboxChecked,
                                    Globals.cptyLPTL=> Globals.checkboxChecked,
                                    Globals.cptyLPU1=> Globals.checkboxChecked,
                                    Globals.cptyN1MA=> Globals.checkboxChecked,
                                    Globals.cptyN1MC=> Globals.checkboxChecked,
                                    Globals.cptyN1MD=> Globals.checkboxChecked,
                                    Globals.cptyRC59=> Globals.checkboxChecked,
                                    Globals.cptyRL11=> Globals.checkboxChecked,
                                    Globals.cptyRL12=> Globals.checkboxChecked,
                                    Globals.cptyRT01=> Globals.checkboxChecked,
                                    Globals.cptyRT02=> Globals.checkboxChecked,
                                    Globals.cptyRT04=> Globals.checkboxChecked,
                                    Globals.cptySBJ1=> Globals.checkboxChecked,
                                    Globals.cptySBJ3=> Globals.checkboxChecked,
                                    Globals.cptyUTQ1=> Globals.checkboxChecked,
                                    Globals.cptyZ4MA=> Globals.checkboxChecked,
                                    Globals.cptyZ4MB=> Globals.checkboxChecked,
                                    Globals.cptyZBBI=> Globals.checkboxChecked,
                                    Globals.cptyZRBC=> Globals.checkboxChecked,
                                    Globals.cptyZZ11=> Globals.checkboxChecked,
                                    Globals.cptyZZ13=> Globals.checkboxChecked,
                                    Globals.cptyZZ14=> Globals.checkboxChecked,
                                })
    setOrderformsPanelDDMenu2(Globals.panelOrderformsTif, Globals.tifGTC)
    setOrderformsPanelDDMenu2(Globals.panelOrderformsPriceType, Globals.typeBid)
    setOrderformsPanelDDMenu2(Globals.panelOrderformsPrice, {Globals.panelPriceTypeBigFigure => "1.22",
                                                              Globals.panelPriceTypePip => "010"})
  end
end