require 'cucumber'
require 'net/ssh'
require 'net/scp'
require 'net/sftp'
require 'net/ftp'
#require 'net/ssh/shell'
require 'net/http'
require 'net/https'
require 'json'
#require 'json-comp'
require 'json-compare'
require 'dbi'
require 'oci8'
require 'fileutils'
require 'csv-diff'
require 'csv-mapper'
require 'csv2json'
require 'diff_dirs'
require 'diffy'
require 'time'
require 'csv'
require 'hashdiff'

require 'capybara'
require "capybara/cucumber"
require "capybara/dsl"

require_relative 'Globals'

begin
  require '../../features/helpers/Actions'
  require Dir.getwd+'/features/helpers/Controls'
rescue LoadError
end


class Entitlements

def Entitlements.loadJsonEntitlements(schema,userUI,sap_version)
  #Actions.getDbQueryResults4Clob('sdata4',"select asd_util_pkg.getUserEntitlement('auto1@ebs.com', '0')from dual")
  query="select entitlement_json from asd_entitlment_json  where entitlement_key=( select entitlement_key from asd_user_gid_mapping where user_name='"+userUI+"' )" if sap_version.to_i == 5
  query="SELECT entitlement_json2 from asd_entitlment_json where entitlement_key=( select entitlement_key from asd_user_gid_mapping where user_name='"+userUI+"' )" if sap_version.to_i > 5
  res=Actions.getDbQueryResults4Clob(schema,query)
  @@entitlements['entitlement_json']=res if(!res.nil?)
end


def Entitlements.isPanelNotEntitledMessageAppear?(strNumOrId)
  #res=Panel.getAllNotEntitledPanels().select{|panel| panel['number']==strNumOrId && panel['message'].include?('NOT ENTITLED')}
  panelNumOrId = strNumOrId
  panelNumOrId = strNumOrId.to_i if strNumOrId.is_number?
  res=false
  notEntitledPanels = Panel.getAllNotEntitledPanels()
  if (notEntitledPanels.keys.include?(panelNumOrId))
    res = notEntitledPanels[panelNumOrId]['message'].include?('NOT ENTITLED')
  end
  return res
end

def Entitlements.getDbProductTypeFromUiProductType(product_type)
  db_product_type=nil
  return nil if(product_type.nil? || product_type.to_s.empty?)
  case product_type.to_s.upcase
    when "SP"
      db_product_type="SPOT"
    when "OT"
      db_product_type="OUTRIGHT"
    when "SW"
      db_product_type="SWAP"
  end
  return db_product_type
end


def Entitlements.getDbProductTypeFromUiProductType2(product_type)
  db_product_type=nil
  return nil if(product_type.nil? || product_type.to_s.empty?)
  case product_type.to_s.upcase
    when "SPOT"
      db_product_type="SP"
    when "OUTRIGHT"
      db_product_type="OT"
    when "SWAP"
      db_product_type="SW"
  end
  return db_product_type
end

def Entitlements.getUiProductTypeFromDbProductType(product_type)
  ui_product_type=nil
  return nil if(product_type.nil? || product_type.to_s.empty?)
  case product_type.to_s.upcase
    when "SPOT"
      ui_product_type="SP"
    when "OUTRIGHT"
      ui_product_type="OT"
    when "SWAP"
      ui_product_type="SW"
  end
  return ui_product_type
end


def Entitlements.getUiProductTypeFromDbProductType2(product_type)
  ui_product_type=nil
  return nil if(product_type.nil? || product_type.to_s.empty?)
  case product_type.to_s.upcase
    when "SP"
      ui_product_type="SPOT"
    when "OT"
      ui_product_type="OUTRIGHT"
    when "SW"
      ui_product_type="SWAP"
  end
  return ui_product_type
end


#sweepable = LMT or/and VVOP
def Entitlements.getSetupEntitlements(setup_ents,floor,product,ccy_base,ccy_counter,user='auto1@ebs.com') #used to match ccy entitled for floor
  found=setup_ents.select{|ent|
    ent["GID"]==user && ent["FLOOR"]==floor && ent["PRODUCT_TYPE"]==product && ent["BASE_CCY"]==ccy_base && \
        ent["COUNTER_CCY"]==ccy_counter  #&&  ent["IS_MARKET_SEGMENT_RFQ"]==rfq  &&  ent["IS_MARKET_SEGMENT_SWEEPABLE"]==sweepable  && ent["IS_MARKET_SEGMENT_FULL"]==full
  }[0]

  if(!found.nil?)
    Actions.v 'Entitlements for '+floor+' '+product+' '+ccy_base+'/'+ccy_counter+ ' for user '+user+ ' FOUND'
    return found
  else
    Actions.v'Entitlements for '+floor+' '+product+' '+ccy_base+'/'+ccy_counter+ ' for user '+user+ ' NOT FOUND'
    return nil
  end
end


def Entitlements.getJsonUiEntitledTenorsArray(all_db_tenors,floor,ccy_pair,product_type)
=begin
    query="select entitlement_json from asd_entitlment_json  where entitlement_key=( select entitlement_key from asd_user_gid_mapping where user_name='"+userUI+"' )"
    res=Actions.getDbQueryResults4Clob(schema,query)
    @@entitlements['entitlement_json']=res if(!res.nil?)
=end
    marketType = "EBSD"
    ui_ccy_tenors=[]
    bin_ccys=@@entitlements['entitlement_json']['floors'][floor][marketType]['currency'][ccy_pair].split('+')
    product_index = 0 if product_type=="SPOT"
    product_index = 1 if product_type=="OUTRIGHT"
    product_index = 2 if product_type=="SWAP"
    bin_tenors=@@entitlements['entitlement_json']['productEntitlements'][bin_ccys[product_index]]['tenors'][0].to_s(2).reverse
    bin_tenors.scan(/\w/).each_with_index{|bool,index| ui_ccy_tenors.push(all_db_tenors[Entitlements.getDbProductTypeFromUiProductType2(product_type)][index]) if(bool.to_bool) }
    return [] if ui_ccy_tenors.nil? || ui_ccy_tenors.empty?

    return ui_ccy_tenors
end


def Entitlements.getDbEntitledTenorsArray(all_db_tenors,product_type,floor_and_ccy_tenors_hash)
    #  #all_db_tenors - - available tenors in Sdata
    # {"OT"=>["TOD", "TOM", "1Wk", "2Wk", "3Wk", "1Mth", "2Mth", "3Mth", "4Mth", "5Mth", "6Mth", "9Mth", "12Mth", "15Mth", "18Mth", "24Mth", "IMM1"],
    # "SP"=>["SP"],
    # "SW"=>["O/N", "T/N", "S/N", "1Wk", "2Wk", "3Wk", "1Mth", "2Mth", "3Mth", "4Mth", "5Mth", "6Mth", "9Mth", "12Mth", "15Mth", "18Mth", "24Mth", "IMM1"], "swapLeg"=>["TOD", "TOM", "SP", "1Wk", "2Wk", "3Wk", "1Mth", "2Mth", "3Mth", "4Mth", "5Mth", "6Mth", "9Mth", "12Mth", "15Mth", "18Mth", "24Mth", "IMM1"]}
    #DEFAULT LAST for OT/SW -"IMM"

    floor_and_ccy_tenors = []
    #return empty list when no min/max tenors defined - usually for spot product
    return nil if(all_db_tenors.nil? || floor_and_ccy_tenors_hash.nil? || product_type.nil?)
    return floor_and_ccy_tenors if(floor_and_ccy_tenors_hash['MIN_TENOR_TYPE'].nil? || floor_and_ccy_tenors_hash['MIN_TENOR_VALUE'].nil? || floor_and_ccy_tenors_hash['MAX_TENOR_TYPE'].nil? || floor_and_ccy_tenors_hash['MAX_TENOR_VALUE'].nil? )
    #|| min_tenor_type.to_s.upcase=="SPOT" #ToDo use in future


    min_tenor_type = floor_and_ccy_tenors_hash['MIN_TENOR_TYPE']
    min_tenor_value = floor_and_ccy_tenors_hash['MIN_TENOR_VALUE']
    max_tenor_type = floor_and_ccy_tenors_hash['MAX_TENOR_TYPE']
    max_tenor_value = floor_and_ccy_tenors_hash['MAX_TENOR_VALUE']



    db_product_type = nil
    min_tenor = nil
    min_tenor_idx = nil
    max_tenor = nil
    max_tenor_id = nil


    return floor_and_ccy_tenors if(min_tenor_type.to_s.empty? || max_tenor_type.to_s.empty?)

    db_product_type=Entitlements.getDbProductTypeFromUiProductType2(product_type)

    case min_tenor_type.to_s.upcase
      when "T"
        min_tenor_idx=all_db_tenors[db_product_type].index{|elem| elem=~/^T/} if(db_product_type=="OT")
        min_tenor_idx=all_db_tenors[db_product_type].index{|elem| elem=~/N/} if(db_product_type=="SW")
        min_tenor_idx+=min_tenor_value.to_i if (!min_tenor_value.nil? && !min_tenor_value.to_s.empty? && min_tenor_value.is_a?(Numeric) && min_tenor_value.to_i>0)
      when "W"
        min_tenor_idx=all_db_tenors[db_product_type].index{|elem| elem=~/^[0-9]W/}
        min_tenor_idx+=min_tenor_value.to_i if (!min_tenor_value.nil? && !min_tenor_value.to_s.empty? && min_tenor_value.is_a?(Numeric) && min_tenor_value.to_i>1)
      when "M"
        min_tenor_idx=all_db_tenors[db_product_type].index{|elem| elem=~/^[0-9]M/}
        min_tenor_idx+=min_tenor_value.to_i if (!min_tenor_value.nil? && !min_tenor_value.to_s.empty? && min_tenor_value.is_a?(Numeric) && min_tenor_value.to_i>1)
      when "SPOT"
        min_tenor_idx=all_db_tenors[db_product_type].index{|elem| elem=~/^S/}
        min_tenor_idx+=min_tenor_value.to_i if (!min_tenor_value.nil? && !min_tenor_value.to_s.empty? && min_tenor_value.is_a?(Numeric) && min_tenor_value.to_i>1)
      when "",min_tenor_type.nil?
        #entitled_panel_tenors.push("SP") #SPOT is default when no specified min,max tenor_type and their values
        return floor_and_ccy_tenors
    end


    case max_tenor_type.to_s.upcase
      when "T"
        max_tenor_idx=all_db_tenors[db_product_type].index{|elem| elem=~/^T/} if(db_product_type=="OT")
        max_tenor_idx=all_db_tenors[db_product_type].index{|elem| elem=~/N/} if(db_product_type=="SW")
        max_tenor_idx+=max_tenor_value.to_i if (!max_tenor_value.nil? && !max_tenor_value.to_s.empty? && max_tenor_value.is_a?(Numeric) && max_tenor_value.to_i>0)
      when "W"
        max_tenor_idx=all_db_tenors[db_product_type].index{|elem| elem=~/^#{max_tenor_value}W/}
        max_tenor_idx+=max_tenor_value.to_i if (!max_tenor_value.nil? && !max_tenor_value.to_s.empty? && max_tenor_value.is_a?(Numeric) && max_tenor_value.to_i>1)
      when "M"
        max_tenor_idx=all_db_tenors[db_product_type].index{|elem| elem=~/^#{max_tenor_value}M/}
        max_tenor_idx+=max_tenor_value.to_i if (!max_tenor_value.nil? && !max_tenor_value.to_s.empty? && max_tenor_value.is_a?(Numeric) && max_tenor_value.to_i>1)
      when "SPOT"
        max_tenor_idx=all_db_tenors[db_product_type].index{|elem| elem=~/^S/}
        max_tenor_idx+=max_tenor_value.to_i if (!max_tenor_value.nil? && !max_tenor_value.to_s.empty? && max_tenor_value.is_a?(Numeric) && max_tenor_value.to_i>1)
      when "",max_tenor_type.nil?
        #entitled_panel_tenors.push("SP") #SPOT is default when no specified min,max tenor_type and their values
        return floor_and_ccy_tenors
    end


    case db_product_type.to_s.upcase
      when "OT" #"OUTRIGHT"
        #db_product_type="OT"
        floor_and_ccy_tenors.push(all_db_tenors[db_product_type][min_tenor_idx..max_tenor_idx])
        floor_and_ccy_tenors.push(all_db_tenors[db_product_type].last) #"IMM"
      when "SW" #"SWAP"
       #db_product_type="SW"
        floor_and_ccy_tenors.push(all_db_tenors[db_product_type][min_tenor_idx..max_tenor_idx])
        floor_and_ccy_tenors.push(all_db_tenors[db_product_type].last) #"IMM"
      when "SP" #"SPOT"
        #db_product_type="SP"
        #T0 - T2 -> min max tenors are empty in SDATA.V_ASD_ENT_INSTRUMENTS
        floor_and_ccy_tenors.push(all_db_tenors[db_product_type])
    end


    return floor_and_ccy_tenors

end


def Entitlements.compareJsonUiAndDbTenors(all_db_tenors,floor,ccy_pair,product_type,db_floor_and_ccy_tenors_hash,fail_on_mismatch)
    db_tenors=Entitlements.getDbEntitledTenorsArray(all_db_tenors,product_type,db_floor_and_ccy_tenors_hash)
    json_ui_tenors=Entitlements.getJsonUiEntitledTenorsArray(all_db_tenors,floor,ccy_pair,product_type)
    if (db_tenors.flatten!=json_ui_tenors.flatten)
      Actions.f("Mismatch found on tenors for #{floor} - #{product_type} - #{ccy_pair}")
      Actions.ff("db_tenors: " +db_tenors.flatten.to_s) if (!db_tenors.nil? || !db_tenors.empty?)
      Actions.ff("ui_tenors: " +json_ui_tenors.flatten.to_s) if (!json_ui_tenors.nil? || !json_ui_tenors.empty?)
    end
    fail('Will not run UI due to the mismatch in tenors') if db_tenors.flatten!=json_ui_tenors.flatten && fail_on_mismatch
end


def Entitlements.getSetupEntitledTenorsArray(all_db_tenors,panel_hash) #panel_hash represent selected values for Panel in UI
  #  #all_db_tenors - - availbale tenors in Sdata
  # {"OT"=>["TOD", "TOM", "1Wk", "2Wk", "3Wk", "1Mth", "2Mth", "3Mth", "4Mth", "5Mth", "6Mth", "9Mth", "12Mth", "15Mth", "18Mth", "24Mth", "IMM1"],
  # "SP"=>["SP"],
  # "SW"=>["O/N", "T/N", "S/N", "1Wk", "2Wk", "3Wk", "1Mth", "2Mth", "3Mth", "4Mth", "5Mth", "6Mth", "9Mth", "12Mth", "15Mth", "18Mth", "24Mth", "IMM1"], "swapLeg"=>["TOD", "TOM", "SP", "1Wk", "2Wk", "3Wk", "1Mth", "2Mth", "3Mth", "4Mth", "5Mth", "6Mth", "9Mth", "12Mth", "15Mth", "18Mth", "24Mth", "IMM1"]}
  #DEFAULT LAST for OT/SW -"IMM"

  entitled_panel_tenors = []
  #return empty list when no min/max tenors defined - usually for spot product
  return nil if(all_db_tenors.nil? || panel_hash.nil? || panel_hash['PRODUCT_TYPE'].nil?)
  return entitled_panel_tenors if(panel_hash['MIN_TENOR_TYPE'].nil? || panel_hash['MIN_TENOR_VALUE'].nil? || panel_hash['MAX_TENOR_TYPE'].nil? || panel_hash['MAX_TENOR_VALUE'].nil? )
  #|| min_tenor_type.to_s.upcase=="SPOT" #ToDo use in future

  product_type = panel_hash['PRODUCT_TYPE']
  min_tenor_type = panel_hash['MIN_TENOR_TYPE']
  min_tenor_value = panel_hash['MIN_TENOR_VALUE']
  max_tenor_type = panel_hash['MAX_TENOR_TYPE']
  max_tenor_value = panel_hash['MAX_TENOR_VALUE']



  db_product_type = nil
  min_tenor = nil
  min_tenor_idx = nil
  max_tenor = nil
  max_tenor_id = nil
  ui_product_type = Entitlements.getUiProductTypeFromDbProductType(product_type)
  return nil if ui_product_type.nil? || ui_product_type.empty?

  return entitled_panel_tenors if(min_tenor_type.to_s.empty? || max_tenor_type.to_s.empty?)

  case min_tenor_type.to_s.upcase
    when "T"
      min_tenor_idx=all_db_tenors[ui_product_type].index{|elem| elem=~/^T/} if(product_type=="OUTRIGHT")
      min_tenor_idx=all_db_tenors[ui_product_type].index{|elem| elem=~/N/} if(product_type=="SWAP")
      min_tenor_idx+=min_tenor_value.to_i if (!min_tenor_value.nil? && !min_tenor_value.to_s.empty? && min_tenor_value.is_a?(Numeric) && min_tenor_value.to_i>0)
    when "W"
      min_tenor_idx=all_db_tenors[ui_product_type].index{|elem| elem=~/^[0-9]W/}
      min_tenor_idx+=min_tenor_value.to_i if (!min_tenor_value.nil? && !min_tenor_value.to_s.empty? && min_tenor_value.is_a?(Numeric) && min_tenor_value.to_i>1)
    when "M"
      min_tenor_idx=all_db_tenors[ui_product_type].index{|elem| elem=~/^[0-9]M/}
      min_tenor_idx+=min_tenor_value.to_i if (!min_tenor_value.nil? && !min_tenor_value.to_s.empty? && min_tenor_value.is_a?(Numeric) && min_tenor_value.to_i>1)
    when "SPOT"
      min_tenor_idx=all_db_tenors[ui_product_type].index{|elem| elem=~/^S/}
      min_tenor_idx+=min_tenor_value.to_i if (!min_tenor_value.nil? && !min_tenor_value.to_s.empty? && min_tenor_value.is_a?(Numeric) && min_tenor_value.to_i>1)
    when "",min_tenor_type.nil?
      #entitled_panel_tenors.push("SP") #SPOT is default when no specified min,max tenor_type and their values
      return entitled_panel_tenors
  end


  case max_tenor_type.to_s.upcase
    when "T"
      max_tenor_idx=all_db_tenors[ui_product_type].index{|elem| elem=~/^T/} if(product_type=="OUTRIGHT")
      max_tenor_idx=all_db_tenors[ui_product_type].index{|elem| elem=~/N/} if(product_type=="SWAP")
      max_tenor_idx+=max_tenor_value.to_i if (!max_tenor_value.nil? && !max_tenor_value.to_s.empty? && max_tenor_value.is_a?(Numeric) && max_tenor_value.to_i>0)
    when "W"
      max_tenor_idx=all_db_tenors[ui_product_type].index{|elem| elem=~/^#{max_tenor_value}W/}
      max_tenor_idx+=max_tenor_value.to_i if (!max_tenor_value.nil? && !max_tenor_value.to_s.empty? && max_tenor_value.is_a?(Numeric) && max_tenor_value.to_i>1)
    when "M"
      max_tenor_idx=all_db_tenors[ui_product_type].index{|elem| elem=~/^#{max_tenor_value}M/}
      max_tenor_idx+=max_tenor_value.to_i if (!max_tenor_value.nil? && !max_tenor_value.to_s.empty? && max_tenor_value.is_a?(Numeric) && max_tenor_value.to_i>1)
    when "SPOT"
      max_tenor_idx=all_db_tenors[ui_product_type].index{|elem| elem=~/^S/}
      max_tenor_idx+=max_tenor_value.to_i if (!max_tenor_value.nil? && !max_tenor_value.to_s.empty? && max_tenor_value.is_a?(Numeric) && max_tenor_value.to_i>1)
    when "",max_tenor_type.nil?
      #entitled_panel_tenors.push("SP") #SPOT is default when no specified min,max tenor_type and their values
      return entitled_panel_tenors
  end


  case product_type.to_s.upcase
    when "OUTRIGHT" #"OT"
      db_product_type="OT"
      entitled_panel_tenors.push(all_db_tenors[db_product_type][min_tenor_idx..max_tenor_idx])
      entitled_panel_tenors.push(all_db_tenors[db_product_type].last) #"IMM"
    when "SWAP"     #"SW"
      db_product_type="SW"
      entitled_panel_tenors.push(all_db_tenors[db_product_type][min_tenor_idx..max_tenor_idx])
      entitled_panel_tenors.push(all_db_tenors[db_product_type].last) #"IMM"
    when "SPOT"     #"SP"
      db_product_type="SP"
      #T0 - T2 -> min max tenors are empty in SDATA.V_ASD_ENT_INSTRUMENTS
      entitled_panel_tenors.push(all_db_tenors[db_product_type])
  end


  return entitled_panel_tenors

end


def Entitlements.compareJsonUiVsDB(fail_on_mismatch)
  #Floors compare
  floors_match = false
  floors_match = true if @@entitlements['entitlement_json']['floors'].keys.sort==$setup_ents.collect{|floor| floor['FLOOR']}.uniq
  Actions.f('Mismatch found between uiJson and DB for floors') if !floors_match
  msgUiFloors=''
  msgUiFloors+='uiJson floors: ' + @@entitlements['entitlement_json']['floors'].keys.sort.to_s if(!@@entitlements['entitlement_json']['floors'].nil? && !@@entitlements['entitlement_json']['floors'].length==0)
  Actions.ff(msgUiFloors) if !floors_match && !msgUiFloors.to_s.empty?
  msgUiFloors=''
  msgUiFloors+='uiJson floors are EMPTY '  if(@@entitlements['entitlement_json']['floors'].nil? || @@entitlements['entitlement_json']['floors'].length==0)
  Actions.ff(msgUiFloors) if !floors_match && !msgUiFloors.to_s.empty?

  msgDbFloors=''
  msgDbFloors+='DB floors: ' + !$setup_ents.collect{|floor| floor['FLOOR']}.uniq.to_s if(!$setup_ents.collect{|floor| floor['FLOOR']}.uniq.nil? && !$setup_ents.collect{|floor| floor['FLOOR']}.uniq.length==0)
  Actions.ff(msgDbFloors) if !floors_match && !msgDbFloors.to_s.empty?
  msgDbFloors=''
  msgDbFloors+='DB floors are EMPTY ' if($setup_ents.collect{|floor| floor['FLOOR']}.uniq.nil? || $setup_ents.collect{|floor| floor['FLOOR']}.uniq.length==0)
  Actions.ff(msgDbFloors) if !floors_match && !msgDbFloors.to_s.empty?

  fail('Not running UI due to mismatch in floors') if !floors_match && fail_on_mismatch
  fail('Not entitled floors found in DB and uiJson') if((!$setup_ents.collect{|floor| floor['FLOOR']}.uniq.nil? && !$setup_ents.collect{|floor| floor['FLOOR']}.uniq.length==0) && (!@@entitlements['entitlement_json']['floors'].nil? && !@@entitlements['entitlement_json']['floors'].length==0)) && fail_on_mismatch

  #ccys per floor compare
  unique_ui_ccys = []
  marketType = "EBSD"
  @@entitlements['entitlement_json']['floors'].each{|floor|
    unique_ui_ccys << floor[1][marketType]['currency'].keys
  }
  unique_ui_ccys = unique_ui_ccys.flatten.uniq.sort if !unique_ui_ccys.empty?
  unique_db_ccys = []
  unique_db_ccys = $setup_ents.collect{|db_floor| db_floor['BASE_CCY']+'/'+db_floor['COUNTER_CCY']}
  unique_db_ccys = unique_db_ccys.uniq.sort if !unique_db_ccys.empty?

  Actions.f('No entitled currencies found in uiJson') if unique_ui_ccys.empty?
  fail('No entitled currencies found in uiJson') if unique_ui_ccys.empty? && fail_on_mismatch
  Actions.f('No entitled currencies found in DB') if unique_db_ccys.empty?
  fail('No entitled currencies found in DB')  if unique_db_ccys.empty? && fail_on_mismatch

  if unique_ui_ccys!=unique_db_ccys
    Actions.f 'Mismatch found between uiJson and DB currencies'
    Actions.ff 'uiJson unique currencies: ' + unique_ui_ccys.to_s
    Actions.ff 'DB unique currencies '+unique_db_ccys.to_s
    fail('Not running UI due to mismatch in currencies') if fail_on_mismatch
  end


  @@entitlements['entitlement_json']['floors'].each{|floor|
    uiFloorCcys = @@entitlements['entitlement_json']['floors'][floor[0]][marketType]['currency']
    uiFloorCcys=uiFloorCcys.keys.sort if !uiFloorCcys.nil?
    uiFloorCcys.each{|uiFloorCcy|
      #Entitlements.getSetupEntitledCurrencyPairsArray($setup_ents,floor[0]).uniq.sort
      floorCcyMatch=$setup_ents.select{|db_floor| db_floor['FLOOR']==floor[0] && db_floor['BASE_CCY']+'/'+db_floor['COUNTER_CCY']==uiFloorCcy }.uniq{|u| u['PRODUCT_TYPE']}
      if floorCcyMatch.nil? || floorCcyMatch.empty?
        Actions.f("Mismatch found for "+floor[0]+" Floor's currency " + uiFloorCcy + " - Found in uiJson and Not found in DB")
        if fail_on_mismatch
          fail('Will not run UI due to mismatch in currencies')
        else
          next
        end
      else
        #tenors compare
        floorCcyMatch.each{|row| Entitlements.compareJsonUiAndDbTenors($all_db_tenors,row['FLOOR'],uiFloorCcy,row['PRODUCT_TYPE'],row,fail_on_mismatch) }
      end
    }
  }

end


def Entitlements.getSetupEntitledPriceModelArray(panel_hash)
  #Price Model bits:  Read RightToLeft
  #bits 1,2 if SWEEP (vwap+limit)  # bit 3 if FULL  bit 4 if IND  bit 5 if RFQ
  pm=[]
  if panel_hash["IS_MARKET_SEGMENT_SWEEPABLE"]=="1"
    pm.push "VWAP"
    pm.push "LMT"
  end
  pm.push "FULL" if panel_hash["IS_MARKET_SEGMENT_FULL"]=="1"

  return pm
end


def Entitlements.getSetupEntitledCurrencyPairsArray(setup_ents,floor=nil)
  return setup_ents.map{|x| x['BASE_CCY']+'/'+x['COUNTER_CCY']} if(floor.nil?) #all entitled currencies
  return setup_ents.select{|x| x['FLOOR']==floor }.map{|y| y['BASE_CCY']+'/'+y['COUNTER_CCY']} if(!floor.nil?) #currencies entitled by floor
end

def Entitlements.isCcyPairEntitledByFloor?(setup_ents,ccy_pair,floor=nil) #used onCreate new panel
  pair_entitled=false
  pairs_entitled=getSetupEntitledCurrencyPairsArray(setup_ents,floor)
  pair_entitled=pairs_entitled.to_s.include?(ccy_pair)
  return pair_entitled
end


def Entitlements.getAvailableProductTypesArray(setup_ents,floor,base_ccy,counter_ccy,uiCcyPair) #uiCcyPair "EUR/USD"
  #products=setup_ents.select{|e| e['FLOOR']==floor && base_ccy+'/'+counter_ccy==uiCcyPair}.map{|p| p['PRODUCT_TYPE']}.uniq
  products=setup_ents.select{|e| e['FLOOR']==floor && e['BASE_CCY']==base_ccy && e['COUNTER_CCY']==counter_ccy}.map{|p| p['PRODUCT_TYPE']}.uniq
  return products
end


def Entitlements.getAllDbListingsSdata(schema)
  res=Actions.getDbQueryResults4Clob(schema,'select * from v_sd_full_currency_json2') #select * from v_sd_full_currency_json2 - ALL currencies list
  @@entitlements['list']=res if(!res.nil?)

  return @@entitlements
end

def Entitlements.getAllDbCurrenciesSdata
  begin
    return @@entitlements['list']['sortedPairs']
  rescue Exception=>e
  end
end


def Entitlements.getAllDbTenorsSdata
  begin
    return @@entitlements['list']['tenors']
  rescue Exception=>e
  end
end


def Entitlements.insertToSapphireDb(query)
    Actions.insertToDbWithCommit('sapphire','sapphire',query)
end


def Entitlements.insertToSapphireCustomDb(query, schema, passwd)
    Actions.insertToDbWithCommit(schema,passwd,query)
end


def Entitlements.deleteInstrumentsSdata(schema,userUI)
  sql= 'UPDATE CNFG_REMOTE_TABLES set IS_ENABLED=0'
  Entitlements.insertToSapphireCustomDb(sql,schema,schema)

  instruments_table = 'V_ASD_ENT_INSTRUMENTS'
  Actions.v 'Deleting instruments for user ' + userUI + ' in ' + schema + ' schema for '+instruments_table+' table'
  begin
    sql= 'UPDATE CNFG_REMOTE_TABLES set IS_ENABLED=0'
    Entitlements.insertToSapphireCustomDb(sql,schema,schema)
    sql = 'DELETE FROM '+instruments_table+" WHERE GID='"+userUI+"'"
    Entitlements.insertToSapphireCustomDb(sql,schema,schema)
  rescue Exception=>e
    fail('Error while deleteInstrumentsSdata (query "'+sql+'") from schema "'+schema+'"'+"\n"+e.message)
  end
end


def Entitlements.setupInstrumentsSdata(schema,csv_hash_arr)
  instruments_table = 'V_ASD_ENT_INSTRUMENTS'
  Actions.v 'Setting instruments  in ' + schema + ' schema for '+instruments_table+' table'
  begin
    csv_hash_arr.each{|row|
      row["GID"] = "auto1@ebs.com" if(ENV["SapphireUiUser"].nil? )
      row["GID"] = ENV["SapphireUiUser"] if(!ENV["SapphireUiUser"].nil? )
      columns=row.keys.to_s.gsub('[','(').gsub(']',')').gsub('"','')
      #values=row.values.to_s.gsub('[','(').gsub(']',')').gsub('nil','null').gsub('"',"'")
      values = ''
      row.values.each_with_index{|value,index|
        if value.is_number?
          values+=value
          values+="," if index<row.values.length-1
        else
          values+="'"+value+"'" if(!value.nil?)
          values+="null" if(value.nil?)
          values+="," if index<row.values.length-1
        end
      }
      values='('+values+')'

      $query='INSERT INTO '+instruments_table+' '+columns+' values '+values
      Entitlements.insertToSapphireCustomDb($query,schema,schema)
      #puts $query
    }

=begin
    sql= 'UPDATE CNFG_REMOTE_TABLES set IS_ENABLED=0'
    Entitlements.insertToSapphireCustomDb(sql,schema,schema)
=end

    $query='SELECT asd_util_pkg.refreshEntitlementsData from DUAL'
    Entitlements.insertToSapphireCustomDb($query,schema,schema)

    sql="select t.local_table,t.is_enabled from CNFG_REMOTE_TABLES t"
    res=Actions.getDbQueryResultsWithoutFailure3(schema,sql)
    Actions.v 'UPDATE CNFG_REMOTE_TABLES results: ' +res.to_s if !res.nil?

  rescue Exception=>e
    fail('Error while setupInstrumentsSdata query:' +$query+"\n"+e.message)
  end
end



def Entitlements.getInstrumentsSdata(schema='',gid='',floor='',product='',base_ccy='',counter_ccy='',order_by='')
  args_names=method(__method__).parameters.map do |_, name| name.to_s if(name.to_s!='schema' && name.to_s!='order_by') end
  args_names=args_names.reject { |a| a.to_s.empty? || a.nil? }
  args_values = method(__method__).parameters.map do |_, name| binding.local_variable_get(name) if(name.to_s!='schema'  && name.to_s!='order_by') end
  args_values=args_values.reject { |a| a.nil? }

  #args_values = method(__method__).parameters.map do |_, name| binding.local_variable_get(name) if(name.to_s!='order_by')  end
  #not_empty_args = args.reject { |a| a.to_s.empty? || a.nil? }

  res=nil
  instruments_table = 'V_ASD_ENT_INSTRUMENTS'
  Actions.v 'Getting instruments  from ' + schema + ' schema for '+instruments_table+' table'
  begin
    $query="SELECT * FROM "+schema+"."+instruments_table
    $query+=" WHERE " if(!args_names.nil? && args_names.length>0)
    args_names.each_with_index{|field_name,index|
      next if args_values[index].nil? || args_values[index].to_s.empty?
      $query+=" "+field_name+"='"+args_values[index]+"' " if(!args_values[index].is_number?)
      $query+=" "+field_name+"="+args_values[index]+" " if(args_values[index].is_number?)
      $query+=" and " if index<args_names.length-1
    }
    $query+=" order by " + order_by if(!order_by.empty?)

      #puts $query
      # res=getDbQueryResultsWithoutFailure4(schema,schema,$query)
  rescue Exception=>e
    fail('Error while getInstrumentsSdata query:' +$query+"\n"+e.message)
  end

  return res
end




def Entitlements.clickAndCancelRfqIfEntitled(panelNumOrId,panel_hash,ui,tenor=' 1st default tenor ')
  begin
    if panel_hash['IS_MARKET_SEGMENT_RFQ']=="1"
       exist=Controls.validateElementExists("btn_rfqLine_rfq",$panel.getActivePanelElement)
       if !exist
          Actions.f ('RFQ btn should appear for  floor: '+panel_hash['FLOOR']+' ccy_pair: ' + panel_hash['BASE_CCY']+'/'+panel_hash['COUNTER_CCY']+ " #{tenor}")
       else
        Actions.v 'Clicking on RFQ btn'
        #ui.clickOnElement(btn_rfqLine_rfq,$panel.getActivePanelElement)
        ui.clickOnElement(Controls.get('btn_rfqLine_rfq'),$panel.getActivePanelElement)
        sleep 3
        Actions.v 'Clicking on Cancel RFQ btn'
        #ui.clickOnElement(btn_rfqLine_rfqCancel,$panel.getActivePanelElement)
        ui.clickOnElement(Controls.get('btn_rfqLine_rfqCancel'),$panel.getActivePanelElement)
        sleep 3
        exist=Controls.validateElementExists("btn_rfqLine_rfq",$panel.getActivePanelElement)
        Actions.f ('Unable to return from RFQ Cancel for  floor: '+panel_hash['FLOOR']+' ccy_pair: ' + panel_hash['BASE_CCY']+'/'+panel_hash['COUNTER_CCY']+ " #{tenor}") if !exist
       end
    end
  rescue Exception=>e
    begin
      Actions.f 'Error in clickAndCancelRfqIfEntitled for panel: '+panelNumOrId + ' floor: '+panel_hash['FLOOR']+' ccy_pair: ' + panel_hash['BASE_CCY']+'/'+panel_hash['COUNTER_CCY'] +" #{tenor} "+ e.message
    rescue Exception=>e2
=begin
      rfq_error=[]
      panelNumOrId.nil? || panelNumOrId.empty? ? rfq_error.push( 'panelNumOrId is missing ') : rfq_error.push('panelNumOrId is ' +panelNumOrId)
      panel_hash['FLOOR'].nil? ? rfq_error.push('FLOOR is missing ') : rfq_error.push('FLOOR is ' +panel_hash['FLOOR'])
      panel_hash['BASE_CCY'].nil? ? rfq_error.push(' BASE_CCY is missing ') : rfq_error.push(' BASE_CCY is ' + panel_hash['BASE_CCY'])
      panel_hash['COUNTER_CCY'].nil? ? rfq_error.push('COUNTER_CCY is missing ') : rfq_error.push('COUNTER_CCY is ' +panel_hash['COUNTER_CCY'])
      tenor.nil? ? rfq_error.push('tenor is missing ') : rfq_error.push('tenor is ' +tenor)
      Actions.f 'Error in clickAndCancelRfqIfEntitled: ' + rfq_error.to_s
=end
      Actions.f 'Error in clickAndCancelRfqIfEntitled'
    end
        UiHelpers.createAndShowScreenshot('Unable to click on RFQ btn or btn not exist')
    return false
  end
  return true
end



def Entitlements.isCalcTypeEntitled?(panel_hash,calcName,validateTrue=false)
  entitled = false
  return true if(panel_hash['IS_MARKET_SEGMENT_SWEEPABLE']=="1" && (calcName.to_s.upcase=="LMT" || calcName.to_s.upcase=="VWAP"))
  return true if(panel_hash['IS_MARKET_SEGMENT_FULL']=="1" && (calcName.to_s.upcase=="FULL"))

  Actions.f (calcName+' should be entitled for '+ panel_hash['FLOOR']+ ' '+ panel_hash['PRODUCT_TYPE']+' '+panel_hash['BASE_CCY']+'/'+panel_hash['COUNTER_CCY'])

  returned entitled
end


def Entitlements.displayErrorIfNotEntitledMessageAppear(str_panel_number,err_msg)
  message_appear=isPanelNotEntitledMessageAppear?(str_panel_number)
  if(message_appear)
    Actions.f(err_msg)
    UiHelpers.createAndShowScreenshot("Message 'NOT ENTITLED' should NOT appear",true)
  end
end


def Entitlements.displayErrorIfNotEntitledMessageDoesntAppear(str_panel_number,err_msg)
    message_appear=isPanelNotEntitledMessageAppear?(str_panel_number)
    if(!message_appear)
      Actions.f(err_msg)
      UiHelpers.createAndShowScreenshot("Message 'NOT ENTITLED' SHOULD appear",true)
    end
end


end