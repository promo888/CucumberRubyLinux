# #require 'singleton'
class Globals

	class << self
	attr_reader :pageTrade, :pageReports, :pageSettings,
							:tabSwaps, :tabOutrightSwp, :tabSpot, :tabOutrights,
							:panelDDFloor, :panelDDCCY, :panelDDCalcType, :panelDDTenor, :panelDDProductType,
							:panelDDtradingDates, :panelDDdealtAmount, :panelDDpdValue, :panelDDdealtCCY,
							:sdataVersion,
							:panelOrderformsEcn, :panelOrderformsAlgo, :panelOrderformsIceberg,
							:panelOrderformsCptys, :panelOrderformsTif, :panelOrderformsEcn,
							:panelOrderformsBid, :panelOrderformsOffer, :panelOrderformsPriceType,
							:panelOrderformsPrice, :panelOrderformsOrderID,
              :panelSettingsSectionPricing, :panelSettingsSectionWarning, :panelSettingsSectionCptys,
              :panelSettingsDone,
							:panelHomeLadder, :panelVolumeLadder, :panelLpLadder, :panelTenorLadder,
							:panelViewLarge, :panelViewMedium, :panelViewSmall, :controlsDefaultlist,
							:panelTypeBid, :panelTypeOffer, :panelLpSW, :panelLpOT, :panelLpSP, :panelLpSPFullName,
							:panelPriceTypeBigFigure, :panelPriceTypePip, :panelPriceTypeDecimal,
							:panelPriceViewFull, :panelPriceViewLive,
							:panelCalcTypeVWAP, :panelCalcTypeLMT, :panelCalcTypeIND, :panelCalcTypeFull,
							:panelNearLeg, :panelFarLeg, :panelExpectedRes,
							:panelTenorOptionMore,
							:panelDatepickerDirectionNext, :panelDatepickerDirectionPrev,
							:panelDatePickerTypeOld, :panelDatePickerTypeNew,
							:newPanelTypeNumber, :newPanelTypeWebElement, :newPanelTypeParameters, :newPanelTypeID,
							:typeTradingDates, :typeNonTradingDates, :typeCurrent, :filterWeekend,
							:configLoginURL, :configLoginUsername,
							:systemIsLocked, :systemIsUnlocked, :messageErrorSystemIsLocked, :messageErrorSystemIsUnlocked,
							:headerElement, :dealsElement, :ordersElement, :tabElement, :panelElement,
							:generalToAllElements,
							:verifyClickable, :verifyClickableMenu, :verifyExists,
							:settingsOn, :settingsOff,
							:sourceDatepicker, :sourceMenu,
							:orderFormsCancel, :orderFormsHold, :orderFormsSend,
							:resolutionHigher, :resolutionHighest, :resolutionLower, :resolutionLowest,
							:resolutionX, :resolutionY,
							:messageWaitingForElement, :messageElementNotFound, :messageElementFound,
							:messageNoResolutionToSet, :messageMissingParams, :messageExcludeWindow, :messageCloseWindow,
							:messageNoCss, :messageJavaScriptClickFailed, :messageRegularClick, :messageFailed,
							:messagePassed, :messageJavaScriptClick, :messageCannotClickOnEmptyList, :messageOK,
							:messageElementNotAccessible, :messageNoCssImplemented, :messageFoundCss,
							:messageElementIsRequired, :messageReturnedEmptyArray, :messageNoPanels,
							:messageMethodStarted, :messageMethodFinished, :messageChangePanelView,
							:messageWaitingForAccessibleElement, :messageInRequestedPage,	:messageNotInRequestedPage,
							:messageNoOptionSelected, :messageOptionSelected, :messageEmptyStringNotAllowed,
							:messageNotImplementedYet, :messageUnlocking, :messageLocking, :messageNotFound,
							:messageUpdateEmptyIdsArray, :messageValueWasNotSet, :messageSkipNonActivePanels,
							:ignoreAllSpaces, :locationURL, :locationPage, :locationPageName, :locationPageNameLowerCase,
							:locationTab, :locationTabName, :locationTabNameLowerCase,
							:cssMainHeader, :cssSubCurrentPage, :cssSubcurrentTab, :cssMainRedirectTo,
							:attributeInnerHTML, :attributeValue, :attributeDisabled, :attributeClass,
							:javascriptAlertTrue, :javascriptAlertOK, :javascriptAlertAccept,
							:curPrice, :curAmount, :curType, :curSubType,
							:dateYear, :dateMonth, :dateMonthNumber, :dateDay,
							:notEntitledPanelsElement , :notEntitledPanelsMessage,
							:checkboxChecked, :checkboxUnchecked, :baseElementNamePanel, :baseElementNameOrderFormsPanel,
							:orderItemCurrencyPair, :orderItemProductType, :orderItemDate, :orderItemTraderID, :orderItemFlow,
							:orderItemAction, :orderItemdealtAmount, :orderItemPrice, :orderItemTifOrSummery,
							:orderItemEcn, :orderItemExapndedData,
							:orderItemSell, :orderItemBuy, :orderItemBuySell, :orderItemSellBuy,
							:dealItemDate, :dealItemCurrencyPair, :dealItemExeCpty,
							:dealItemCpty, :dealItemBuySell, :dealItemTenor,
							:dealItemValDate, :dealItemdealtAmount, :dealItemdealtCcy,
							:dealItemContraAmt, :dealItemContraCcy, :dealItemPrice,
							:dealItemTradeDate, :dealItemTicketId, :dealItemId,
							:dealItemProductType,:dealItemFloor, :dealItemTraderID,
							:dealItemEcn, :dealItemSegment, :dealItemOrderId,
							:dealtAmountStr1M,:dealtAmountStr5M,:dealtAmountStr10M,
							:dealtAmountStr15M,:dealtAmountStr25M,:dealtAmountStr30M,
							:dealtAmountStr50M,:dealtAmountStr75M,:dealtAmountStr100M,
							:cptyABC1,:cptyABC2,:cptyARKA,
							:cptyAcc1,:cptyAcc2,:cptyAcc4,
							:cptyAcc6,:cptyAcc7,:cptyAff1,
							:cptyAff2,:cptyC1TC,:cptyC1TD,
							:cptyEMSQ,
							:cptyLP32,:cptyLP33,:cptyLPE2,
							:cptyLPLA,:cptyLPLB,:cptyLPLK,
							:cptyLPLL,:cptyLPP1,:cptyLPP2,
							:cptyLPRI,:cptyLPRJ,:cptyLPRK,
							:cptyLPRL,:cptyLPRM,:cptyLSQ1,
							:cptyN1MA,:cptyN1MC,:cptyN1MD,
							:cptyRC59,:cptyRL11,:cptyRL12,
							:cptyRT01,:cptyRT02,:cptyRT04,
							:cptySBJ1,:cptySBJ3,:cptyUTQ1,
							:cptyZ4MA,:cptyZ4MB,:cptyZBBI,
							:cptyZRBC,:cptyZZ11,:cptyZZ13,
							:cptyZZ14,:cptyLPTA,:cptyLPTB,
							:cptyLPTC,:cptyLPTL,:cptyLPU1,
							:cptyAllCounterpaties, :cptyOthers,
							:tifGTC,:tifDAY,:tifGTT,:tifGTD,
							:typeBid,:typeOffer,
							:convertAmountShortString, :convertAmountLongNumberWithCommas,
							:datePeriodToday, :datePeriodYesterday, :datePeriodFirstDayOfWeekToToday, :datePeriod1Week,
							:datePeriodFirstDayOfMonthToToday, :datePeriod1Month, :datePeriod3Month,
							:reportsDateFilterDealDate, :reportsDateFilterTradeDate, :reportsDateFilterValueDate,
							:directionDiffBoth, :directionDiffA1MinusA2, :directionDiffA2MinusA1
	end

	#def initialize()
		@pageTrade				= "trade"
		@pageReports			= "reports"
		@pageSettings			= "settings"

		@tabSwaps					= "Swaps"
		@tabOutrightSwp		= "Outright/Swp"
		@tabSpot					= "Spot"
		@tabOutrights			= "Outrights"

		@panelDDFloor 		= "floor"
		@panelDDCCY 			= "currencyPair"
		@panelDDCalcType	= "calculatorType"
		@panelDDTenor			= "tenors"
		@panelDDProductType			= "productType"
		@panelDDtradingDates 	= "tradingDates"
		@panelDDdealtAmount 	= "dealtAmount"
		@panelDDpdValue				= "pdValue"
		@panelDDdealtCCY			= "dealtCCY"

		@panelOrderformsEcn				= "ecn"
		@panelOrderformsAlgo			= "algo"
		@panelOrderformsIceberg		= "iceberg"
		@panelOrderformsCptys			= "cptys"
		@panelOrderformsTif				= "tif"
		@panelOrderformsEcn				= "ecn"
		@panelOrderformsBid				= "bid"
		@panelOrderformsOffer			= "offer"
		@panelOrderformsPriceType	= "priceType"
		@panelOrderformsPrice 		= "price"
		@panelOrderformsOrderID		= "orderID"

    @panelSettingsSectionPricing = "Pricing"
    @panelSettingsSectionWarning = "Warnings"
    @panelSettingsSectionCptys   = "Cptys"
	  @panelSettingsDone = "Done"
		@sdataVersion			= "sdata5"

		@panelHomeLadder 			= "home"
		@panelVolumeLadder		= "volumeLadder"
		@panelLpLadder				= "lpLadder"
		@panelTenorLadder			= "tenorLadder"

		@panelViewLarge				= "large"
		@panelViewMedium			= "medium"
		@panelViewSmall				= "small"

		@controlsDefaultlist	= "general_dropdownMenu_option3"

		@panelTypeBid					= "bid"
		@panelTypeOffer				= "offer"

		@panelLpSW						= "SW"
		@panelLpOT						= "OT"
		@panelLpSP						= "SP"
		@panelLpSPFullName		= "SPOT"

		@panelPriceTypeBigFigure = "bigFigure"
		@panelPriceTypePip			 = "pip"
		@panelPriceTypeDecimal	 = "decimal"

		@panelPriceViewFull			 = "FULL"
		@panelPriceViewLive			 = "LIVE"

		@panelCalcTypeFull			= "FULL"
		@panelCalcTypeVWAP			= "VWAP"
		@panelCalcTypeLMT				= "LMT"
		@panelCalcTypeIND				= "IND"

		@panelNearLeg						= "near"
		@panelFarLeg						= "far"
		@panelExpectedRes				= "expectedResult"
		@panelTenorOptionMore		= "More..."

		@panelDatePickerTypeOld				= "old"
		@panelDatePickerTypeNew				= "new"

		@panelDatepickerDirectionNext = "next"
		@panelDatepickerDirectionPrev = "prev"

		@newPanelTypeNumber			= "number"
		@newPanelTypeWebElement	= "element"
		@newPanelTypeParameters	= "params"
		@newPanelTypeID					= "id"

		@typeTradingDates				= "trading_dates"
		@typeNonTradingDates		= "non_trading_dates"
		@typeCurrent						= "current"

		@filterWeekend					= "weekend"

		@configLoginURL					= "SapphireLoginUrl"
		@configLoginUsername		= "SapphireUiUser"

		@systemIsLocked					= "locked"
		@systemIsUnlocked				= "unlocked"

		@headerElement					= "header"
		@dealsElement						= "deals"
		@ordersElement					= "orders"
		@tabElement							= "tab"
		@panelElement						= "panel"
		@generalToAllElements		= "general"

		@verifyExists						= "exist"
		@verifyClickable				= "clickable"
		@verifyClickableMenu		= "clickableMenu"

		@settingsOn							= "on"
		@settingsOff						= "off"

		@sourceDatepicker				= "datepicker"
		@sourceMenu							= "menu"

		@orderFormsCancel				= "CANCEL"
		@orderFormsHold					= "HOLD"
		@orderFormsSend					= "SEND"

		@resolutionHigher				= "higher"
		@resolutionHighest			= "highest"
		@resolutionLower				= "lower"
		@resolutionLowest				= "lowest"
		@resolutionX						= "x"
		@resolutionY						= "y"

		@messageWaitingForElement				=	"waiting for element..."
		@messageElementNotFound					= "element not found"
		@messageElementFound						= "element found"
		@messageNoResolutionToSet				= "no resolution to set"
		@messageMissingParams						= "Missing parameters"
		@messageExcludeWindow						= "Excluding window"
		@messageCloseWindow							=	"Closing window"
		@messageNoCss										= "No css selector for element"
		@messageNoCssImplemented				= "css not yet implemented"
		@messageNotImplementedYet				= "Not implemented yet"
		@messageJavaScriptClickFailed		= "Clicking on element using JavaScript failed"
		@messageRegularClick						= "Clicking using regular click"
		@messageJavaScriptClick 				= "Clicking using JavaScript"
		@messageFailed									= "Failed"
		@messagePassed									= "Passed"
		@messagePass										= "Passed"
		@messageOK											= "ok"
		@messageCannotClickOnEmptyList	= "empty list, so cannot click"
		@messageElementNotAccessible		= "element is not accessible"
		@messageWaitingForAccessibleElement = "Waiting for element to be accessible"
		@messageFoundCss								= "Found css"
		@messageInRequestedPage					= "In requested page"
		@messageNotInRequestedPage			= "Not in requested page"
		@messageElementIsRequired				= "Element is required"
		@messageNoOptionSelected				= "No option selected"
		@messageOptionSelected 					= "Option selected"
		@messageEmptyStringNotAllowed		= "String cannot be empty"
		@messageUnlocking								= "Unlocking system"
		@messageErrorSystemIsLocked			= "System is locked (expected to be unlocked)"
		@messageLocking									= "Locking system"
		@messageErrorSystemIsUnlocked		= "System is unlocked (expected to be locked)"
		@messageNotFound								= "NOT_FOUND"
		@messageReturnedEmptyArray			= "Returned array was empty"
		@messageUpdateEmptyIdsArray			= "Updating empty ids array"
		@messageNoPanels								= "No panels"
		@messageChangePanelView					= "Setting view of panel"
		@messageValueWasNotSet					= "Value was not set"
		@messageSkipNonActivePanels			= "Skipping non active panel"
		@messageMethodStarted						= "Started"
		@messageMethodFinished					= "Finished"

		@ignoreAllSpaces								= "all"
		@locationURL										= "url"
		@locationPage  									= "page"
		@locationPageName								= "pageName"
		@locationPageNameLowerCase			= "pageNameLowerCase"
		@locationTab 										= "tab"
		@locationTabName								= "tabName"
		@locationTabNameLowerCase				= "tabNameLowerCase"
		@cssMainHeader									= "header"
		@cssMainRedirectTo							= "redirectTo"
		@cssSubCurrentPage							= "currentPage"
		@cssSubcurrentTab								= "currentTab"

		@attributeInnerHTML							= "innerHTML"
		@attributeValue									= "value"
		@attributeDisabled							= "disabled"
		@attributeClass									= "class"

		@javascriptAlertTrue						= "true"
		@javascriptAlertOK							= "ok"
		@javascriptAlertAccept					= "accept"

		@curPrice												= "price"
		@curAmount											= "amount"
		@curType												= "type"
		@curSubType											= "subType"

		@dateDay  = "day"
		@dateYear = "year"
		@dateMonth = "month"
		@dateMonthNumber = "monthNumber"


		@notEntitledPanelsElement = "element"
		@notEntitledPanelsMessage = "message"

		@checkboxChecked					= "checked"
		@checkboxUnchecked				= "unchecked"

		@baseElementNamePanel						= "panel"
		@baseElementNameOrderFormsPanel	= "panelOrderForms"

		@orderItemCurrencyPair	= "currencyPair"
		@orderItemProductType 	= "productType"
		@orderItemDate 					= "tradingDates"
		@orderItemTraderID 			= "traderID"
		@orderItemFlow 					= "flow"
		@orderItemAction 				= "action"
		@orderItemdealtAmount		= "dealtAmount"
		@orderItemPrice 				= "price"
		@orderItemTifOrSummery	= "tifOrSummery"
		@orderItemEcn						= "ecn"
		@orderItemSell					= "sell"
		@orderItemBuy						= "buy"
		@orderItemBuySell				= "b/s"
		@orderItemSellBuy				= "s/b"
		@orderItemExapndedData	= "expandedData"
		@dealItemDate          = "dealDateTime"
    @dealItemOrderId       = "orderId"
		@dealItemCurrencyPair  = "pair"
		@dealItemExeCpty       = "exeCpty"
		@dealItemCpty          = "cpty"
		@dealItemBuySell       = "bs"
		@dealItemTenor         = "tenor"
		@dealItemValDate       = "valDate"
		@dealItemdealtAmount   = "dealtAmt"
		@dealItemdealtCcy      = "dealt"
		@dealItemContraAmt     = "contraAmt"
		@dealItemContraCcy     = "contraCcy"
		@dealItemPrice         = "price"
		@dealItemTradeDate     = "tradeDate"
		@dealItemTicketId      = "ticketId"
		@dealItemId            = "id"
		@dealItemProductType   = "productType"
		@dealItemFloor         = "floor"
		@dealItemTraderID      = "traderId"
		@dealItemEcn           = "ecn"
		@dealItemSegment       = "segment"

		@convertAmountShortString 					= "shortString"
		@convertAmountLongNumberWithCommas 	= "longNumberWithCommas"

		@dealtAmountStr1M 	= "1M"
		@dealtAmountStr5M 	= "5M"
		@dealtAmountStr10M 	= "10M"
		@dealtAmountStr15M 	= "15M"
		@dealtAmountStr25M 	= "25M"
		@dealtAmountStr30M 	= "30M"
		@dealtAmountStr50M 	= "50M"
		@dealtAmountStr75M 	= "75M"
		@dealtAmountStr100M = "100M"

		@cptyABC1 = "ABC1"
		@cptyABC2 = "ABC2"
		@cptyARKA = "ARKA"
		@cptyAcc1 = "Acc1"
		@cptyAcc2 = "Acc2"
		@cptyAcc4 = "Acc4"
		@cptyAcc6 = "Acc6"
		@cptyAcc7 = "Acc7"
		@cptyAff1 = "Aff1"
		@cptyAff2 = "Aff2"
		@cptyC1TC = "C1TC"
		@cptyC1TD = "C1TD"
		@cptyEMSQ = "EMSQ"

		@cptyLP32 = "LP32"
		@cptyLP33 = "LP33"
		@cptyLPE2 = "LPE2"
		@cptyLPLA = "LPLA"
		@cptyLPLB = "LPLB"
		@cptyLPLK = "LPLK"
		@cptyLPLL = "LPLL"
		@cptyLPP1 = "LPP1"
		@cptyLPP2 = "LPP2"
		@cptyLPRI = "LPRI"
		@cptyLPRJ = "LPRJ"
		@cptyLPRK = "LPRK"
		@cptyLPRL = "LPRL"
		@cptyLPRM = "LPRM"
		@cptyLPTA = "LPTA"
		@cptyLPTB = "LPTB"
		@cptyLPTC = "LPTC"
		@cptyLPTL = "LPTL"
		@cptyLPU1 = "LPU1"
		@cptyLSQ1 = "LSQ1"

	  @cptyN1MA = "N1MA"
		@cptyN1MC = "N1MC"
		@cptyN1MD = "N1MD"
		@cptyRC59 = "RC59"
		@cptyRL11 = "RL11"
		@cptyRL12 = "RL12"
		@cptyRT01 = "RT01"
		@cptyRT02 = "RT02"
		@cptyRT04 = "RT04"
		@cptySBJ1 = "SBJ1"
		@cptySBJ3 = "SBJ3"
		@cptyUTQ1 = "UTQ1"
		@cptyZ4MA = "Z4MA"
		@cptyZ4MB = "Z4MB"
		@cptyZBBI = "ZBBI"
		@cptyZRBC = "ZRBC"
		@cptyZZ11 = "ZZ11"
		@cptyZZ13 = "ZZ13"
		@cptyZZ14 = "ZZ14"
	  @cptyAllCounterpaties = "All Counterparties"
		@cptyOthers = "others"

		@tifGTC = "GTC"
		@tifDAY = "DAY"
		@tifGTT = "GTT"
		@tifGTD = "GTD"

		@typeBid = "BID"
		@typeOffer = "OFFER"

		@datePeriodToday = "Today"
		@datePeriodYesterday = "Yesterday"
		@datePeriodFirstDayOfWeekToToday = "Week To Date"
		@datePeriodFirstDayOfMonthToToday = "Month To Date"
		@datePeriod1Week  = "1 Week"
		@datePeriod1Month = "1 Month"
		@datePeriod3Month = "3 Months"

		@reportsDateFilterDealDate = "Deal Date"
		@reportsDateFilterTradeDate = "Trade Date"
		@reportsDateFilterValueDate = "Value Date"

		@directionDiffBoth = "BOTH"
		@directionDiffA1MinusA2 = "arr1-arr2"
		@directionDiffA2MinusA1 = "arr2-arr1"
	#end
end

