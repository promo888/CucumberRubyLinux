require_relative('UiHelpers')
require_relative('DealItem')
require 'fileutils'
require 'json'
class Deals
  @@baseElementName = "deals"

  def initialize(ui, num, element = nil)
    @ui = ui
    @num = num
    @dealElement = element
  end

  def verifyThereAreNoDealsInBlotter()
    db_table = @@CONFIG['PTRADE_SCHEMA'].to_s.upcase + '.FX_TICKET_LEG'
    log "Removing all ers from DB"
    sql = 'DELETE FROM ' + db_table
    insertToSapphireCustomDb(sql, CONFIG.get['SAPPHIRE_SCHEMA'], CONFIG.get['SAPPHIRE_SCHEMA'])
    @ui.redirectTo(Globals.pageSettings)
    @ui.redirectTo(Globals.pageTrade)
    allDeals = getAllDeals()
    if ((allDeals != nil) && (allDeals.length > 0))
      UiHelpers.throw "Deals found, where expected not to be found"
    else
      log Globals.messagePassed
    end
  end

  def verifyPostTradeIsUp()
    service="~/PTS/bin/service.sh"
    running="alive"
    cmdStatus = "#{service} status | grep -i #{running} | egrep -i 'tidy|core' |wc -l"
    cmdRestart = "#{service} restart"
    resStatus = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['CORE_HOST_USER'],
                              CONFIG.get['CORE_HOST_PWD'], cmdStatus, 1)
    if (resStatus.to_i < 2)
      resRestart = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['CORE_HOST_USER'],
                                    CONFIG.get['CORE_HOST_PWD'], cmdRestart, 5)
      log "Restarting post trade: #{resRestart}"
      maxTimeToWait = 10
      resStatus = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['CORE_HOST_USER'],
                                      CONFIG.get['CORE_HOST_PWD'], cmdStatus, 1)
      while ((resStatus.to_i < 2) && (maxTimeToWait > 0))
        log "Waiting for post trade to be up..."
        sleep 1
        resStatus = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'], CONFIG.get['CORE_HOST_USER'],
                                        CONFIG.get['CORE_HOST_PWD'], cmdStatus, 1)
      end
      if (maxTimeToWait <= 0)
        UiHelpers.throw "post trade, is not up (max time to wait exceeded)"
      end
    end
    log Globals.messagePassed
  end

  def verifySapCmdIsInstalled()

    defaultPath = "#{CONFIG.get['REMOTE_HOME']}/#{CONFIG.get['APP_HOST_USER']}/sap-cmd"
    cmdSearchIfInstalled  = "find #{defaultPath} -type f -name 'nos'  2>/dev/null | tail -1 2>/dev/null"
    log "Searching if sap-cmd is installed..."
    foundSapCmd = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'],
                                            CONFIG.get['CORE_HOST_USER'],
                                            CONFIG.get['CORE_HOST_PWD'],
                                            cmdSearchIfInstalled, 1).to_s.chomp
    if (foundSapCmd == "")
      UiHelpers.throw "sap-cmd is not installed, please install it manually"
    else
      $sapCmd = foundSapCmd
      log Globals.messagePassed
    end
  end

  def copyFileToTempLocation(filename, logPrefix = nil)
    ip = CONFIG.get['APP_HOST_IP']
    user = CONFIG.get['APP_HOST_USER']
    pwd = CONFIG.get['APP_HOST_PWD']
    tempPath = "/tmp"
    filename = filename.to_s
    filenamesToCreateIfMissing = /(nos\.log)$/
    if ((filename.length > 0) && (filename =~ /([^\/]+)$/))
        base = $1
        tempDestFilename = "#{tempPath}/#{base}"
    end
    if (! logPrefix.nil?)
      tempDestFilename = "#{tempDestFilename}#{logPrefix.to_s}"
    end
    if (tempDestFilename.empty?) then UiHelpers.throw("Temp destination filename cannot be empty"); end
    cmd = "rm -f \"#{tempDestFilename}\"; " +
          "cp -f \"#{filename}\" \"#{tempDestFilename}\""
    Actions.SSH_NO_FAIL(ip, user, pwd, cmd, 10)
    errors = ""
    cmdList = "ls \"#{tempDestFilename}\" 1>/dev/null 2>&1; echo $?"
    resList = Actions.SSH_NO_FAIL(ip, user, pwd, cmdList, 10).to_s
    if (resList.to_i > 0)
      if (tempDestFilename =~ filenamesToCreateIfMissing)
        cmdCreate = "touch \"#{tempDestFilename}\" 2>&1"
        errors = Actions.SSH_NO_FAIL(ip, user, pwd, cmdCreate, 10).to_s
      else
        errors = "#{tempDestFilename} doesn't exist"
      end
    end
    return errors
  end

  def diffFileWithTempLocationFile(filename, afterClickLogsPrefix = nil)
    filename = filename.to_s
    tempPath = "/tmp"
    res = ""
    toRetDiff = {}
    ip = CONFIG.get['APP_HOST_IP']
    user = CONFIG.get['APP_HOST_USER']
    pwd = CONFIG.get['APP_HOST_PWD']
    if ((filename.length > 0) && (filename =~ /([^\/]+)$/))
      base = $1
      filename2 = "#{tempPath}/#{base}"
      if (! afterClickLogsPrefix.nil?) then filename = "#{filename2}#{afterClickLogsPrefix}"; end
      cmd1Exists = "ls \"#{filename}\" 2>/dev/null"
      cmd2Exists = "ls \"#{filename2}\" 2>/dev/null"
      res1Exists = ""
      res2Exists = ""
      maxTimeToTry = 10
      while (((res1Exists.to_s.empty?) || (res2Exists.to_s.empty?)) && (maxTimeToTry > 0))
        res1Exists = Actions.SSH_NO_FAIL(ip, user, pwd, cmd1Exists, 10)
        res2Exists = Actions.SSH_NO_FAIL(ip, user, pwd, cmd2Exists, 10)
        if ((res1Exists.to_s.empty?) || (res2Exists.to_s.empty?))
          maxTimeToTry -= 2
          sleep 2
        end
      end
      if (maxTimeToTry <= 0)
        errMsg = ""
        if (res1Exists.to_s.empty?) then errMsg += "#{filename} is missing"; end
        if (res2Exists.to_s.empty?) then errMsg += "#{filename2} is missing"; end
        if (! errMsg.to_s.empty?)
          errMsg = "Missing files before diff (#{errMsg})"
          UiHelpers.throw(errMsg, true, false, true, false)
        end
      end
      cmd1 = "diff '#{filename}' '#{filename2}' | grep '^<' | sed -e 's/^<\s//'"
      res1 = Actions.SSH_NO_FAIL(ip, user, pwd, cmd1, 10)

      cmd2 = "diff '#{filename}' '#{filename2}' | grep '^>' | sed -e 's/^>\s//'"
      res2 = Actions.SSH_NO_FAIL(ip, user, pwd, cmd2, 10)

      if (! res1.to_s.empty?)
        toRetDiff[filename] = res1.to_s
      end

      if (! res2.to_s.empty?)
        toRetDiff[filename2] = res2.to_s
      end
    end

    return toRetDiff
  end

  def getGcOrderLogFiles(logPath)
    cmd = "find #{logPath} -type f -name '#{CONFIG.get['APP_HOST_IP']}-GCMD.Order*_*' 2>/dev/null | " +
            " grep '[0-9]\.log$' 2>/dev/null"
    res = Actions.SSH_NO_FAIL(CONFIG.get['APP_HOST_IP'],
                                CONFIG.get['CORE_HOST_USER'],
                                CONFIG.get['CORE_HOST_PWD'], cmd, 10)
    if (res == nil)
      res = ""
    end
    return res.split("\n")
  end

  def getLogsDiff(logDataFile, regExpToFilterBefore = nil, regExpToFilterAfter = nil,
                  afterClickLogsPrefix = nil, productType = Globals.panelLpSP)
    resdiff = diffFileWithTempLocationFile(logDataFile, afterClickLogsPrefix)
    resDiffHash = nil
    toRet = []
    begin
      res = ""
      if (! resdiff.empty?)
        res = resdiff.values[0]
        if (regExpToFilterBefore != nil)
          resFiltered = ""
          if (res =~ regExpToFilterBefore) then resFiltered = $'  end
          res = resFiltered
        end
        if (regExpToFilterAfter != nil)
          resFiltered = ""
          if (res =~ regExpToFilterAfter)then resFiltered = $` end
          res = resFiltered
        end
        jsonRes = res.to_s
      end
      begin
        dataHash = JSON.parse(jsonRes)
      rescue
        if (! jsonRes.empty?)
          # Multiple legs to single legs line
          foundLegs = []
          curStr = jsonRes
          while (curStr =~ /^legs \{$.*?^\}$/m)                           # multiple lines of legs: {
            cur = $&                                                      # to 1 line of legs: [
            curStr = $'                                                   #                      array
            cur = cur.sub(/^\s*legs\s*/, "").
                gsub(/[\"\'\,]/,"").
                gsub(/\s*$/, "").
                gsub(/(\w+)(:\s*)([^\s]+)$/, "\"\\1\"\\2\"\\3\"").
                gsub(/(\w+)(\s*\{)/,"\"\\1\":\\2").
                gsub(/([\"\}])$/, "\\1,").
                gsub(/\,(\n[\r\t ]*\})/m, "\\1").
                sub(/\,\z/, "")
            foundLegs.push(cur)
          end
          foundLegsStr = "[ " + foundLegs.join(',') + " ]"
          curStr = jsonRes.sub(/(legs \{\n.*?\n\}\n)+/m, "\"legs\": #{foundLegsStr},\n")
          jsonRes = curStr
          # End of Multiple legs to single legs line

          jsonRes = jsonRes.split("\n")
          for i in 0..(jsonRes.length - 1)
            jsonRes[i] = jsonRes[i].
                gsub(/[\"\'\,]/,"").                                     # Remove "',
                gsub(/^\s*/,"").                                         # trim the line
                gsub(/\s*$/, "").                                        #
                gsub(/([^\:]+)(:\s*)([^\s]+)$/, "\"\\1\"\\2\"\\3\",").   # key: value -> "key": "value",
                gsub(/^(\w+)(\s*\{)/,"\"\\1\":\\2").                     # key { -> "key": {
                gsub(/(\})$/,"\\1,")                                     # } -> },
          end
          jsonRes = jsonRes.join("\n")
          curStr = jsonRes.dup
          lpsList = []
          while (curStr =~ /"lps": "(\w+)"/)      # from: lps: "LPLB",
            lp = $1                               #       lps: "LPLA",
            lpsList.push(lp)                      # to: "lps": ["LPLB", "LPLA"],
            curStr = $'                           #
          end                                     #
          if (lpsList.empty?)                     # for message sent to GW
            lpsList = []                          # "liquidityProvider": {
            curStr = jsonRes                      # "accountId": "LPLB"}
            while (curStr =~ /"liquidityProvider":\s+\{([^}]+)}/m)
              data = $1
              curStr = $'
              lp = ""
              if (data =~ /accountId\W+(\w+)/) then lp = $1.to_s; end
              if (! lp.empty?) then lpsList.push(lp); end
            end
          end
          if (! lpsList.empty?)
            if (! jsonRes.index("lps"))
              jsonRes = jsonRes.sub(/("liquidityProvider":\s+\{[^}]+},\n)+/m, "\"lps\": #{lpsList.to_s},\n")
            else
              jsonRes = jsonRes.sub(/(\"lps\"\s*:\s*\"\w+\",\n)+/,"\"lps\": #{lpsList.to_s},\n")
            end
          end

          jsonRes = jsonRes.
              gsub(/,\z/,"}").                 # Adding { to the beginning
              gsub(/(\A\s*[^{])/, "{\\1").     # and } to the end of JSON
              gsub(/,(\n})/, "\\1")            # Removing , before }
          begin
            dataHash = JSON.parse(jsonRes)
          rescue
          end
        end

      end
      if ((dataHash != nil) && (! dataHash.empty?))
        legs = []
        if (! dataHash.has_key?("legs"))
          log "No legs key (can be fine if orderLeg exists)"

        elsif (dataHash["legs"].class.to_s == "Array")
          legs = dataHash["legs"]
        else
          legs = [ dataHash['legs'] ] rescue []
        end

        legs.each do |leg|
          if (leg == nil)
            log "No leg from data (can be fine if orderLeg exists)"
          end
          resDiffHash = {}
          resDiffHash[Globals.dealItemFloor] = dataHash['floorCode']
          if (! resDiffHash[Globals.dealItemFloor])
            resDiffHash[Globals.dealItemFloor] = dataHash["executingParty"]['floorCode'] rescue nil
          end
          resDiffHash[Globals.dealItemCurrencyPair] = dataHash['instrument']
          if ((! resDiffHash[Globals.dealItemCurrencyPair]) && (! dataHash['symbol'].nil?))
            resDiffHash[Globals.dealItemCurrencyPair] = dataHash['symbol']
          end
          resDiffHash['lps'] = dataHash['lps']
          resDiffHash[Globals.dealItemdealtAmount] = leg['amount']['value'] rescue nil
          if (! resDiffHash[Globals.dealItemdealtAmount])
            resDiffHash[Globals.dealItemdealtAmount] = dataHash['orderLeg']['orderQty']['mantissa'] rescue nil
          end

          if (resDiffHash[Globals.dealItemdealtAmount] != nil)
            resDiffHash[Globals.dealItemdealtAmount] =
                resDiffHash[Globals.dealItemdealtAmount].to_f / 1000000.0
          end
          resDiffHash[Globals.dealItemPrice] = leg['price']['value'] rescue nil
          if (! resDiffHash[Globals.dealItemPrice])
            resDiffHash[Globals.dealItemPrice] = dataHash['orderLeg']['orderPx']['mantissa'] rescue nil
          end

          if (resDiffHash[Globals.dealItemPrice] != nil)
            resDiffHash[Globals.dealItemPrice] =                # to_f is for OT prices
                resDiffHash[Globals.dealItemPrice].to_f.to_i.   # to_i is for prices from gc_order
                to_s.sub(/^(\d)(\d)/, "\\1\.\\2") #( / 100000 causes bug)
          end
          resDiffHash[Globals.dealItemTraderID] = dataHash['traderId']
          if (! resDiffHash[Globals.dealItemTraderID])
            resDiffHash[Globals.dealItemTraderID] = dataHash['executingParty']['traderId'] rescue nil
          end
          direction = leg['direction'] rescue nil
          if (! direction)
            legSide = dataHash['orderLeg']['legSide'].to_s.downcase
            if (legSide == Globals.orderItemSell.to_s.downcase)
              resDiffHash[Globals.dealItemBuySell] = Globals.orderItemSell
            else
              resDiffHash[Globals.dealItemBuySell] = Globals.orderItemBuy
            end
          elsif (direction.to_i == 1)
            resDiffHash[Globals.dealItemBuySell] = Globals.orderItemSell
          else
            resDiffHash[Globals.dealItemBuySell] = Globals.orderItemBuy
          end
          toRet.push(resDiffHash)
        end
      end
    rescue
    end
    return toRet
  end


  def sendNosMessage(dealtAmount = Globals.dealtAmountStr1M,
                     buyOrSell = Globals.orderItemBuy,
                     confirmOnSend = "off", floor, ccy, productType,
                     lpsToSet, logNamesToSave, afterClickLogsPrefix)
    # if ($sapCmd == nil)
    #   UiHelpers.throw "$sapCmd, should be declared"
    # end
    errorsFound = false
    toRet = []
    panel = Panel.new(@ui, Globals.newPanelTypeNumber, "1")
    panel.setFloor(floor)
    panel.setCurrencyPair(ccy)
    panel.setProductType(productType)
    panel.setPanelDDMenu2(Globals.panelDDdealtAmount, dealtAmount)
    panel.confirmAmountIfAsked()
    panelSettings = SettingsPanel.new(@ui, Globals.newPanelTypeNumber, 1)
    panelSettings.open()
    panelSettings.setLPs(lpsToSet)
    currentLPs = panelSettings.getLPsOn()
    panelSettings.close()
    base = panel.getActivePanelElement()
    bsForCss = Globals.orderItemBuy.to_s.downcase
    if ((buyOrSell != Globals.orderItemBuy) && (buyOrSell != Globals.orderItemSellBuy))
      bsForCss = Globals.orderItemSell.to_s.downcase
    end
    cssBtn = Controls.get("panel_current_mainPrice_#{bsForCss}_base")
    btn = @ui.firstWithCss(cssBtn, nil, base)
    btnValue = ""
    if (btn == nil)
      errorsFound = true
      UiHelpers.throw("btn wasn't found")
    else
      btnValue = btn.text()
      if (btnValue.to_s.empty?)
        log "No prices, clicking on rfq button before"
        Controls.click("btn_panel_header_Rfq", base)
      elsif (productType != Globals.panelLpSP)
        log "#{productType} supports only rfq, clicking on rfq button"
        Controls.click("btn_panel_header_Rfq", base)
      end

      sleep 5
      if (btnValue.to_s.empty?) then btnValue = btn.text(); end
      if (btnValue.to_s.empty?) then UiHelpers.throw("No prices shown on panel", false, false, true, true); end
    end

    traderID = @ui.getTraderIdFromHeader()
    if (traderID.empty?)
      UiHelpers.throw("No trader id found on header", false ,false, true, true)
    end

    logNamesToSave.each do |logNameToSave|
      if (logNameToSave.to_s != "")
        errorsInCopy = copyFileToTempLocation(logNameToSave.to_s)
        if (! errorsInCopy.to_s.empty?)
          UiHelpers.throw("Errors while creating temp files (#{errorsInCopy})", true, false, true,false)
        end
      end
    end
    @ui.doubleClick(btn)
    if (confirmOnSend == "on")
      option = Globals.orderFormsSend
      eName = "btn_orderForm_#{option}"
      btn = Controls.firstElement(eName, panel.getActivePanelElement())
      @ui.clickOnWebElement(btn, 2)
    end

    sleep 3
    order = OrderItem.new(@ui, 1)
    orderId = nil
    orderPrice = nil
    begin
      orderProperties = order.getOrderProperties(false, false, false, false)
      expandedData = orderProperties[Globals.orderItemExapndedData]
      orderPrice = orderProperties[Globals.orderItemPrice]
      orderId = expandedData.split("\n")[3].split("\s")[0] rescue nil
      if (orderId.nil?)
        orderId = orderProperties.
                    select{|k,v| k.to_s.downcase.
                    include?(Globals.dealItemOrderId.to_s.downcase)}.values[0] rescue nil
      end
    rescue => ex
      log "Couldn't get orderId from order panel"
      errorsFound = true
    end
    if (orderPrice == nil)
      UiHelpers.throw("Couldn't get order's price")
      errorsFound = true
    end
    if (orderId == nil)
      UiHelpers.throw("Couldn't get order's details from orders panel", false, false, true, true)
      errorsFound = true
    end

    if (! errorsFound)
      amount = dealtAmount.to_s.gsub(/M$/, "").to_f
      innerHashToRet = {}
      innerHashToRet[Globals.dealItemFloor] = floor
      innerHashToRet[Globals.dealItemCurrencyPair] = ccy
      innerHashToRet['lps'] = currentLPs
      innerHashToRet[Globals.dealItemdealtAmount] = amount
      innerHashToRet[Globals.dealItemTraderID] = traderID
      innerHashToRet[Globals.dealItemOrderId] = orderId
      innerHashToRet[Globals.dealItemBuySell] = buyOrSell.to_s.downcase
      innerHashToRet[Globals.dealItemPrice] = orderPrice
      if (innerHashToRet[Globals.dealItemBuySell] == Globals.orderItemBuySell)
        for bs in [Globals.orderItemBuy, Globals.orderItemSell]
          innerHashToRet = innerHashToRet.clone
          innerHashToRet[Globals.dealItemBuySell] = bs.to_s.downcase
          toRet.push(innerHashToRet)
        end
      elsif (innerHashToRet[Globals.dealItemBuySell] == Globals.orderItemSellBuy)
        for bs in [Globals.orderItemSell, Globals.orderItemBuy]
          innerHashToRet = innerHashToRet.clone
          innerHashToRet[Globals.dealItemBuySell] = bs.to_s.downcase
          toRet.push(innerHashToRet)
        end
      else
        toRet.push(innerHashToRet)
      end

      logNamesToSave.each do |logNameToSave|
        if (logNameToSave.to_s != "")
          copyFileToTempLocation(logNameToSave.to_s, afterClickLogsPrefix)
        end
      end
    end
    return toRet
  end

  def verifyDealsRecievedInDealblotter(hashRequiredTotalDeals,
                                       orderTransactions = nil,
                                       shouldFailOnException = true,
                                       productType = Globals.panelLpSW)
    @ui.redirectTo(Globals.pageTrade)
    allDealsFromUi = []
    timeToTry = 30
    allDealsProperties = nil
    specificProperties = [Globals.dealItemTicketId , Globals.dealItemOrderId, Globals.dealItemdealtAmount,
                          Globals.dealItemBuySell, Globals.dealItemPrice, Globals.dealItemCpty, Globals.dealItemEcn]
    while ((timeToTry > 0) && ((allDealsProperties == nil) || (allDealsProperties.length == 0)))
      allDealsProperties = getAllDealsPropeties(specificProperties, 2)
      if ((allDealsProperties == nil) || (allDealsProperties.length == 0))
        currentSleeptime = 5
        log "waiting to deals in blotter (sleep time: #{currentSleeptime})"
        timeToTry -= currentSleeptime
        sleep currentSleeptime
      end
    end

    if ((allDealsProperties == nil) || (allDealsProperties.length == 0))
      UiHelpers.throw("Deals not found, where expected to be found", true, false, true, true)
    else
      cmpFields = [Globals.dealItemdealtAmount, Globals.dealItemPrice, Globals.dealItemBuySell,
                         Globals.dealItemEcn]
      if (productType == Globals.panelLpSW)
        cmpFields = [Globals.dealItemdealtAmount, Globals.dealItemBuySell, Globals.dealItemEcn]
      end

      if (orderTransactions != nil)
        compareOrderTransactionsWithDeals(orderTransactions, allDealsProperties, productType, cmpFields)
      end
      compareTotalDealsWithRequiredTotalDeals(allDealsProperties, hashRequiredTotalDeals, shouldFailOnException)
    end
  end

  def getColumnsValues()
    values = []
    elements = getColumnsElements()
    elements.each do |element|
      value = element.text
      values.push(value)
    end
    return values
  end

  def getColumnsElements()
    eNameMenu = "#{@@baseElementName}_column_picker_menu"  # ul
    eNameListItem = "listItem"              # li
    css = "#{Controls.get(eNameMenu)} #{Controls.get(eNameListItem)}"
    baseElement = @ui.getBaseElement()
    allColumnsElements = baseElement.find_elements(:css, css)
    toRet = []
    for i in 0..(allColumnsElements.length - 1)
      if (@ui.javascriptIsElementVisible(allColumnsElements[i]))
        toRet.push(allColumnsElements[i])
      end
    end
    return toRet
  end

  # names will be column names as written in UI (not in column picker)
  def setColumns(names)
    if (names == nil)
      UiHelpers.throw "names cannot be nil"
    end

    namesToSet = []
    names.each do |name|
      nameToSet = name.dup
      namesToSet.push(nameToSet)
    end

    specialNames = $uiDefaults["dealsColumnsInColumnPickerRelatedToMoreThanOneColumn"]
                                                                            # Dealt->Dealt,Dealt Amt
    for specialNameInColumnPicker in specialNames.keys do                   # Dealt
      arrRelatedNamesInColumns = specialNames[specialNameInColumnPicker]    # Dealt,Dealt Amt
      log "Check if namesToSet contains special names in columns "
      foundAllNames = true
      arrRelatedNamesInColumns.each do |name|
        if (! namesToSet.include?(name))
          foundAllNames = false
          break
        end
      end

      if (foundAllNames == true)                # namesToSet: some_strings, Dealt, Dealt Amt , ...
        log Globals.messagePassed
        log "These names will be replaced " +
              "with name in column picker"
        firstFoundIndex = -1
        arrRelatedNamesInColumns.each do |name| # namesToSet: some_strings, ...
          if (firstFoundIndex < 0)
            log "Getting first index of found name"
            firstFoundIndex = namesToSet.index(name)
          end

          namesToSet.delete(name)
        end
        namesToSet.insert(firstFoundIndex, specialNameInColumnPicker) # namesToSey: some_strings, Dealt, ...
      end
    end

    log "Finished replacing names, columns will be set by these names"
    eNameListItemCheckbox = "#{@@baseElementName}_column_picker_menu_item_checkbox"
    @ui.redirectTo(Globals.pageTrade)
    openColumnsPickerWindow()
    columnsValues = getColumnsValues()
    if (columnsValues.length < namesToSet.length) # columns always >= names (due to unchecked columns)
      UiHelpers.throw "Mismatch between names given to method and columns found in window " +
                          "(found: #{columnsValues.length.to_s}, names: #{namesToSet.length.to_s})"
    end

    i = 0
    while (i < namesToSet.length) do
      name = namesToSet[i]
      foundInIndex = columnsValues.index(name)
      if (foundInIndex == nil)
        UiHelpers.throw "Cannot find name: #{name}, in columns"
      end

      log "Setting element #{name} in relevant place"
      cssDragAndDrop = Controls.get("#{@@baseElementName}_column_picker_dragAndDrop")
      while (foundInIndex > i)
        columnsElements = getColumnsElements()
        src = columnsElements[i]                  # order of who is src and who is dst is important,
        dst = columnsElements[foundInIndex]       # if dst=columnsElement[i] and src=columnsElements[found..] it fails.
        src = @ui.firstWithCss(cssDragAndDrop, nil, src)
        dst = @ui.firstWithCss(cssDragAndDrop, nil, dst)
        @ui.dragAndDrop(src, dst)                 # change position of elements in list
        columnsValues = getColumnsValues()        # get values after changed position of elements
        foundInIndex = columnsValues.index(name)
      end                                         # element i in its requested postion.
      i += 1
    end

    log "After setting columns in place validate that elements are checked, and other aren't checked"
    i = 1 # Skipping static elements from beginning (sapphire 6)
    columnsElements = getColumnsElements()
    while (i < columnsElements.length) do
      shouldElementBeChecked = false
      if (i < namesToSet.length)
        shouldElementBeChecked = true
      end

      selectedClass = "selected"
      chkBoxElement = Controls.firstElement(eNameListItemCheckbox, columnsElements[i])
      isElementChecked = false
      chkboxClass = chkBoxElement["class"].to_s.downcase
      if (chkboxClass.include?(selectedClass))
        isElementChecked = true
      end

      if  ((shouldElementBeChecked && (! isElementChecked)) ||
          ((! shouldElementBeChecked) &&  isElementChecked ) )
        @ui.clickOnWebElement(chkBoxElement)
        columnsElements = getColumnsElements() # Fix bug, when clicked elements are refreshed.
      end
      i += 1
    end

    closeColumnsPickerWindow()
  end

  def getHeaderColumnsNames()
    eNameGeneralColumn = "dealItem_generalColumn"
    baseElement = @ui.getBaseElement()
    arrValues = []
    arrWebElemnets = Controls.allElements(eNameGeneralColumn, baseElement)
    arrWebElemnets.each do |webElement|
      value = @ui.getValueOrTextOrInnerHTML(webElement)
      arrValues.push(value)
    end
    return arrValues
  end

  # names will be column names as written in UI (not in column picker)
  def verifyColumns(names)
    arrNames = []
    names.each do |name|
      arrNames.push(name.dup)
    end # No need to check for names in column picker since we already handled it in setColumns

    arrValues = getHeaderColumnsNames()

    errors = minusIntersection(arrNames, arrValues, "Should be in UI", "In UI")
    if (errors != "")
      UiHelpers.throw errors
    end
  end

  def openColumnsPickerWindow()
    eNameColumnPicker  = "#{@@baseElementName}_column_picker"
    eNameBtnOpenColumnPicker = "btn_#{@@baseElementName}_settings"
    baseElement = @ui.getBaseElement()
    foundOpenedMenu = nil
    begin
      elementColumnPicker = Controls.firstElement(eNameColumnPicker, baseElement)
      if ((elementColumnPicker == nil) || (! @ui.isElementAccessible(elementColumnPicker)))
        foundOpenedMenu = elementColumnPicker
      end
    rescue
    end

    if (foundOpenedMenu == nil)
      btn = Controls.firstElement(eNameBtnOpenColumnPicker, baseElement)
      @ui.clickOnWebElement(btn)
      foundOpenedMenu = Controls.firstElement(eNameColumnPicker, baseElement)
    end

    return foundOpenedMenu
  end

  def closeColumnsPickerWindow()
    log "Since there is no close button, clicking on header element"
    eNameHeader = "header_currentPage"
    baseElement = @ui.getBaseElement()
    btn = Controls.firstElement(eNameHeader, baseElement)
    @ui.clickOnWebElement(btn)
  end

  def getAllDeals()
    dealsArr = DealItem.new(@ui, 1).getAllDeals()
    return dealsArr
  end

  def getAllDealsProperty(property)
    pArr = []
    eNameProperty = "dealItem_#{property}"
    baseElement = @ui.getBaseElement()
    begin
      arr = Controls.allElements(eNameProperty, baseElement)
      arr.each do |dealItem|
        cellProperty = dealItem.text()
        if ((cellProperty != nil) && (cellProperty != ""))
          pArr.push(cellProperty)
        end
      end
    rescue => e
      errMessage = "Error found before scrollDown (error message = #{e.message},  pArr = #{pArr.to_s})"
      log errMessage
    end
    begin
      pArrBefore = []
      maxScrollDown = 10
      while ( (pArr != pArrBefore) || (maxScrollDown > 0) )
        pArrBefore = pArr.dup
        pCurArr = []
        scrollDownDeals()
        arr = Controls.allElements(eNameProperty, baseElement)
        arr.each do |dealItem|
          cellProperty = dealItem.text()
          if ((cellProperty != nil) && (cellProperty != ""))
            pCurArr.push(cellProperty)
          end
        end
        pArr = pArr | pCurArr
        if (pArr == pArrBefore)
          maxScrollDown -= 1
        end
      end
    rescue => e
      errMessage = "Error found on scrollDown loop (error message = #{e.message},  pArr = #{pArr.to_s})"
      log errMessage
    end

    return pArr
  end

  def getAllDealsPropeties(specificProperties = [], maxScrollDown = 5)
    pArr = []
    baseElement = @ui.getBaseElement()
    begin
      arr = getAllDeals()
      arr.each do |dealItem|
        log "getting current deal's properties"
        dealProperties = dealItem.getProperties(true, false, false, false, specificProperties)
        if ((dealProperties != nil) && (dealProperties != ""))
          pArr.push(dealProperties)
        end
      end
    rescue => e
      errMessage = "Error found before scrollDown (error message = #{e.message},  pArr = #{pArr.to_s})"
      log errMessage
    end
    begin
      pArrBefore = []
      while ( (pArr != pArrBefore) || (maxScrollDown > 0) )
        pArrBefore = pArr.dup
        pCurArr = []
        scrollDownDeals()
        arr = getAllDeals()
        arr.each do |dealItem|
          log "getting current deal's properties"
          dealProperties = dealItem.getProperties(true, false, false, false, specificProperties)
          if ((dealProperties != nil) && (dealProperties != ""))
            pCurArr.push(dealProperties)
          end
        end
        pArr = pArr | pCurArr
        if (pArr == pArrBefore)
          log "at the end of scrolling, waiting #{maxScrollDown} before continue this step"
          maxScrollDown -= 1
        end
      end
    rescue => e
      errMessage = "Error found on scrollDown loop (error message = #{e.message},  pArr = #{pArr.to_s})"
      log errMessage
    end

    return pArr
  end

  def findDeals(stringToSearch, type = nil)
    eNameBtnSearch            = "btn_#{@@baseElementName}_search"
    eNameSearchInput          = "field_#{@@baseElementName}_searchBar"
    eNameSearchBarResult      = "#{@@baseElementName}_searchBar_result"
    eNameSearchBarResultType  = "#{eNameSearchBarResult}Type"
    eNameSearchBarResultValue = "#{eNameSearchBarResult}Value"
    eNameSearchResultFieldName = ""
    baseElement = @ui.getBaseElement()
    btn = Controls.firstElement(eNameBtnSearch, baseElement)
    if (btn != nil)
      begin
        timeToSleep = $uiDefaults["minimumTimeToSleep"]["after"]["click"]
        @ui.clickOnWebElement(btn, timeToSleep)
      rescue
      end
    end
    type = type.to_s.downcase.delete("[\s\.\/]")
    fieldSearchElement = Controls.firstElement(eNameSearchInput, baseElement)
    @ui.setField(fieldSearchElement, stringToSearch)
    arr = Controls.allElements(eNameSearchBarResult, baseElement)
    arr.each do |resultElement|
      resultType = Controls.value2(eNameSearchBarResultType, resultElement).to_s.downcase.delete("[\s\.\/]")
      if (resultType == type)
        resultValue = nil
        allResults = Controls.allElements(eNameSearchBarResultValue, resultElement)
        if (allResults == nil)
          allResults = []
        end
        i = 0
        while ((resultValue == nil) && (i < allResults.length))
          value = allResults[i].text.to_s
          if (value == stringToSearch)
            resultValue = value
            @ui.clickOnWebElement(allResults[i], 1)
          end
          i += 1
        end

        if (resultValue != nil)
          break
        end
      end
    end
  end

  def closeSearchBar()
    eNameCloseBtn = "btn_closeSearchBar"
    baseElement = @ui.getBaseElement()
    btn = Controls.firstElement(eNameCloseBtn, baseElement)
    @ui.clickOnWebElement(btn)
  end

  def scrollDownDeals()
    eNameScrollManager = "deals_scroll_manager"
    driver = @ui.getBaseElement()
    scrollManager = Controls.firstElement(eNameScrollManager, driver)
    maxTriesBeforeFailure = 5
    jsVerifyGridExists = "return angular.element(arguments[0]).scope().reportGridApi"
    jsScrollDown = "var gridblotterGrid = angular.element(arguments[0]).scope().reportGridApi.grid;" +
                    "gridblotterGrid.scrollY += 250"
    reportGridApi = driver.execute_script(jsVerifyGridExists, scrollManager)
    while (((reportGridApi == nil) || (reportGridApi.length == 0)) && (maxTriesBeforeFailure > 0))
      timeToSleep = maxTriesBeforeFailure
      log "wating for grid to become available (sleeping #{timeToSleep})"
      reportGridApi = driver.execute_script(jsVerifyGridExists, scrollManager)
      maxTriesBeforeFailure -= 1
    end
    return driver.execute_script(jsScrollDown, scrollManager)
  end

  def filterDealsByDate(datePeriod)
    log "Started (datePeriod: #{datePeriod})"
    eNameDateTypeFilterDD  = "reports_dateType_Dropdown"
    eNameDateRangeFilterDD = "reports_dateRange_Dropdown"
    baseElement = @ui.getBaseElement()
    ddMenu = Controls.firstElement(eNameDateTypeFilterDD, baseElement)
    @ui.selectFromDropdownMenu(ddMenu, Globals.reportsDateFilterDealDate)
    ddMenu2 = Controls.firstElement(eNameDateRangeFilterDD, baseElement)
    @ui.selectFromDropdownMenu(ddMenu2, datePeriod)
    log "Finished"
  end

  def getDatesPeriodFromUI(dateRange)
    eNameCurrentPage = "header_currentPage"
    eNameFrom = "reports_fromDate"
    eNameTo = "reports_toDate"
    eNameRange = "reports_dateRange_Dropdown"
    baseElement = @ui.getBaseElement()
    currentPage = Controls.value2(eNameCurrentPage, baseElement)
    if (currentPage.to_s.downcase != "reports")
      @ui.redirectTo(Globals.pageReports)
    end

    ddMenu = Controls.firstElement(eNameRange, baseElement)
    @ui.selectFromDropdownMenu(ddMenu, dateRange)
    from = Controls.value2(eNameFrom, baseElement)
    to = Controls.value2(eNameTo, baseElement)
    return {"to" => to.to_s, "from" => from.to_s}
  end

  def compareOrderTransactionsWithDeals(orderTransactions, allDealsProperties, productType, cmpFields)
    bs, buy, sell, ecn, price, dealtAmount = Globals.dealItemBuySell, Globals.orderItemBuy,
                                              Globals.orderItemSell, Globals.dealItemEcn,
                                              Globals.dealItemPrice, Globals.dealItemdealtAmount
    toCompare = { "orders" => { "base" => orderTransactions, "diff" => []},
                  "deals"  => { "base" => allDealsProperties,"diff" => []} }
    for type in ["orders", "deals"] do
      toCompare[type]["base"].each do |item|
        filteredVals = filteredVals = item.select{|k,v| cmpFields.include?(k.to_s)}
        if (filteredVals.has_key?(ecn))
          filteredVals[ecn] = filteredVals[ecn].gsub(/^(\w).*$/, "\\1")
        end
        if (filteredVals.has_key?(price))
          filteredVals[price] = filteredVals[price].to_f.to_s
        end
        if (filteredVals.has_key?(dealtAmount))
          filteredVals[dealtAmount] = filteredVals[dealtAmount].to_f.to_s
        end
        if (! filteredVals.has_key?(bs))
          UiHelpers.throw("Essential key wasn't found (#{bs})")
        else
          filteredVals[bs] = filteredVals[bs].to_s.downcase
          if (filteredVals[bs].include?(Globals.orderItemBuySell))   # for SW, instead of order with b/s
            for bsValue in [buy, sell]            # push 2 orders: buy and sell.
              filteredVals = filteredVals.clone
              filteredVals[bs] = bsValue
              toCompare[type]["diff"].push(filteredVals)
            end
          elsif (filteredVals[bs].include?(Globals.orderItemSellBuy))
            for bsValue in [sell, buy]
              filteredVals = filteredVals.clone
              filteredVals[bs] = bsValue
              toCompare[type]["diff"].push(filteredVals)
            end
          else # Default state (SP and OT)
            toCompare[type]["diff"].push(filteredVals)
          end
        end
      end
    end
    log "Comparing deals blotter with order's trasactions"
    directionInDiff = Globals.directionDiffBoth
    if (productType == Globals.panelLpSW)
      directionInDiff = Globals.directionDiffA2MinusA1
    end
    errorsInDiff = @ui.minusIntersection(toCompare["deals"]["diff"],
                                         toCompare["orders"]["diff"],
                                         "deals", "transactions in order", directionInDiff)
    if (! errorsInDiff.to_s.empty?)
      if (shouldFailOnException)
        UiHelpers.throw(errorsInDiff, true, true, true, true)
      end
    else
      log Globals.messagePassed
    end
  end

  def compareTotalDealsWithRequiredTotalDeals(allDealsProperties, hashRequiredTotalDeals, shouldFailOnException)
    totalDeals = {}
    allDealsProperties.each do |dealItem|
      dealItem[Globals.dealItemBuySell] = dealItem[Globals.dealItemBuySell].downcase # to match sent deal
      key = dealItem[Globals.dealItemBuySell]
      if (! totalDeals.has_key?(key))
        totalDeals[key] = {}
        totalDeals[key][Globals.dealItemOrderId] = dealItem[Globals.dealItemOrderId].dup
        totalDeals[key][Globals.dealItemdealtAmount] = dealItem[Globals.dealItemdealtAmount].dup.to_f
        totalDeals[key][Globals.dealItemBuySell] = dealItem[Globals.dealItemBuySell].dup
      elsif (totalDeals[key][Globals.dealItemBuySell] != dealItem[Globals.dealItemBuySell])
        error = "Mismatch at Buy/Sell (deal contains: #{dealItem[Globals.dealItemBuySell]}, " +
            "expected to contain: #{totalDeals[key][Globals.dealItemBuySell]})"
        if (shouldFailOnException)
          UiHelpers.throw(error, true, true, true, true)
        end
      else
        totalDeals[key][Globals.dealItemdealtAmount] += dealItem[Globals.dealItemdealtAmount].to_f
      end
    end

    filterKeys = [Globals.dealItemOrderId, Globals.dealItemdealtAmount, Globals.dealItemBuySell]
    valuesTotalDeals = UiHelpers.filterFromArrayOfHashes(totalDeals.values, filterKeys)
    valuesRequiredTotalDeals = UiHelpers.filterFromArrayOfHashes(hashRequiredTotalDeals, filterKeys)
    directionInDiff = Globals.directionDiffBoth
    if (valuesTotalDeals.length != valuesRequiredTotalDeals.length)
      UiHelpers.throw("Mismatch is length (deals: #{valuesTotalDeals.length.to_s}, " +
                          "required: #{valuesRequiredTotalDeals.length.to_s})")
    end
    for i in 0..(valuesTotalDeals.length - 1)
      errorsInDiff2 = @ui.minusIntersectionHashes(valuesTotalDeals[i], valuesRequiredTotalDeals[i],
                                                  "UI deals[#{i}]", "required deals[#{i}]", directionInDiff)
      if (! errorsInDiff2.to_s.empty?)
        if (shouldFailOnException)
          UiHelpers.throw(errorsInDiff2, true, true, true, true)
        end
      end
    end
    log Globals.messagePassed # no exception -> passed.
  end
end