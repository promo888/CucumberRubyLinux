require_relative('UiHelpers')

class DealItem
  @@baseElementName = "dealItem"

  def initialize(ui, rowNumber, element = nil, staticElement = nil)
    @ui = ui
    @number = rowNumber
    @element = element
    @staticElement = staticElement
    if (@ui == nil)
      UiHelpers.throw "No UI element"
    end

    if (@number == nil)
      UiHelpers.throw "No row number"
    end
  end

  def log(message)
    parentFunc =  caller_locations(1).first.label
    Controls.log(message, File.basename(__FILE__), parentFunc.to_s)
  end

  def getNumber()
    return @number
  end

  def getElement()
    return @element
  end

  def getActiveElement(onFailureRaiseException = true,
                       onFailureAddToScenarioFails = false,
                       onFailureWriteToActionsF = false,
                       onFailureCreateScreenshot = false)
    activeElement = getElement()
    begin
      activeElement['class']
    rescue
      activeElement = nil
    end
    if (activeElement == nil)
      arr = getAllDeals(onFailureRaiseException,
                      onFailureAddToScenarioFails,
                      onFailureWriteToActionsF,
                      onFailureCreateScreenshot)
      if (arr == nil)
        UiHelpers.throw("No lines of deals found",
                      onFailureRaiseException,
                      onFailureAddToScenarioFails,
                      onFailureWriteToActionsF,
                      onFailureCreateScreenshot)
      end

      if (arr.length < @number)
        UiHelpers.throw("rowNumber: #{@number},  is too high (amount of deal lines: #{arr.length.to_s})",
                      onFailureRaiseException,
                      onFailureAddToScenarioFails,
                      onFailureWriteToActionsF,
                      onFailureCreateScreenshot)
      end

      activeElement = arr[@number - 1].getElement()
    end
    return activeElement
  end

  def getPropertyValue(property, activeElement)
    endElementName = property
    eName = "#{@@baseElementName}_#{endElementName}"
    eNameStatic = "#{eName}_static"
    value = nil
    allElements = Controls.allElements(eName, activeElement) # Sapphire 6 fix.
    if (allElements == nil)
      allElements = []
    end

    if (allElements.length == 0)
      allElements = Controls.allElements(eNameStatic, activeElement) # Sapphire 6 fix.
      if (allElements == nil)
        allElements = []
      end
    end

    allElements.each do |element|
      text = element.text()
      if ((text != nil) && (text != ""))
        value = text
        break
      end
    end
    return value
  end

  def getProperty(property, onFailureRaiseException = true,
                  onFailureAddToScenarioFails = false,
                  onFailureWriteToActionsF = false,
                  onFailureCreateScreenshot = false)
    propertyValue = nil
    activeElement = getActiveElement(onFailureRaiseException,
                                     onFailureAddToScenarioFails,
                                     onFailureWriteToActionsF,
                                     onFailureCreateScreenshot)
    if (activeElement == nil)
      UiHelpers.throw("No active element", onFailureRaiseException,
                      onFailureAddToScenarioFails,
                      onFailureWriteToActionsF,
                      onFailureCreateScreenshot)
    end

    maxTriesBeforeFailure = 3
    log "Getting value (property: #{property.to_s})"
    for i in 1 .. maxTriesBeforeFailure do
      propertyValue = getPropertyValue(property, activeElement)
      if ((propertyValue != nil) && (propertyValue != ""))
        break
      end
    end
    if (propertyValue == nil)
      UiHelpers.throw("Failed to get property #{property}", onFailureRaiseException,
                    onFailureAddToScenarioFails,
                    onFailureWriteToActionsF,
                    onFailureCreateScreenshot)
    else
      log "#{Globals.messagePassed} (value: #{propertyValue})"
    end
    return propertyValue
  end


  def getProperties(onFailureRaiseException = true,
                    onFailureAddToScenarioFails = false,
                    onFailureWriteToActionsF = false,
                    onFailureCreateScreenshot = false, specificProperties = [])
    hashProperties = {}
    activeElement = getActiveElement(onFailureRaiseException,
                                     onFailureAddToScenarioFails,
                                     onFailureWriteToActionsF,
                                     onFailureCreateScreenshot)
    baseElement = @ui.getBaseElement()
    if (activeElement == nil)
      UiHelpers.throw("No active element", onFailureRaiseException,
                      onFailureAddToScenarioFails,
                      onFailureWriteToActionsF,
                      onFailureCreateScreenshot)
    end

    maxTriesBeforeFailure = 3
    propertiesToGet = [Globals.dealItemDate, Globals.dealItemCurrencyPair, Globals.dealItemExeCpty,
                       Globals.dealItemCpty, Globals.dealItemBuySell, Globals.dealItemTenor,
                       Globals.dealItemValDate, Globals.dealItemdealtAmount, Globals.dealItemdealtCcy,
                       Globals.dealItemContraAmt, Globals.dealItemContraCcy, Globals.dealItemPrice,
                       Globals.dealItemTradeDate, Globals.dealItemTicketId, Globals.dealItemId,
                       Globals.dealItemProductType,Globals.dealItemFloor, Globals.dealItemTraderID,
                       Globals.dealItemEcn, Globals.dealItemSegment]
    if (specificProperties.length > 0)
      propertiesToGet = specificProperties
    end
    for propertyName in propertiesToGet do
      for i in 1 .. maxTriesBeforeFailure do
        value = getPropertyValue(propertyName, activeElement)
        if ((value == nil) || (value == ""))
          value = getPropertyValue(propertyName,baseElement) # Sapphire 6 fix.
        end

        if ((value != nil) && (value != ""))
          break
        end
      end

      if ((value != nil) && (value != ""))
        hashProperties[propertyName] = value
      else
        UiHelpers.throw("Failed to get value for #{propertyName}", onFailureRaiseException,
                        onFailureAddToScenarioFails,
                        onFailureWriteToActionsF,
                        onFailureCreateScreenshot)
      end
    end
    return hashProperties
  end

  def getAllDeals(onFailureRaiseException = true,
                  onFailureAddToScenarioFails = false,
                  onFailureWriteToActionsF = false,
                  onFailureCreateScreenshot = false)
    arrToRet = []
    isStatic = false
    if (Controls.value2("header_currentPage", @ui.getBaseElement()).to_s.downcase ==
        Globals.pageReports.downcase)
      isStatic = false
    else
      isStatic = true
    end

    eNameDeal = "deal_in_deals"
    baseElement = @ui.getBaseElement()
    begin
      arr = Controls.allElements(eNameDeal, baseElement)
      if ((arr == nil) || (arr.length == 0))
        log "could not get deals from UI"
        arr = []
      end
      arrTemp = []
      arr.each do |partialLineElement|
        text = partialLineElement.text()
        if ((text != nil) && (text != ""))
          arrTemp.push(partialLineElement)
        end
      end
      arr = arrTemp

      arrStatic = []
      if (isStatic)
        eNameDealStatic = "deal_in_deals_static"
        arrStatic = Controls.allElements(eNameDealStatic, baseElement)
        if ((arrStatic == nil) || (arrStatic.length == 0))
          log "could not get deals from UI"
          arrStatic = []
        end
        arrTemp = []
        arrStatic.each do |partialLineElement|
          text = partialLineElement.text()
          if ((text != nil) && (text != ""))
            arrTemp.push(partialLineElement)
          end
        end
        arrStatic = arrTemp
      end

      for rowNum in 1 .. arr.length do
        element = arr[rowNum-1]
        if (! isStatic)
          dealObject = DealItem.new(@ui,rowNum, element)
        else
          staticElement = arrStatic[rowNum-1]
          dealObject = DealItem.new(@ui,rowNum, element, staticElement)
        end
        arrToRet.push(dealObject)
      end
    rescue => e
      log "Found error while getting all deals (error: #{e.message.to_s})"
    end
    return arrToRet
  end
end
