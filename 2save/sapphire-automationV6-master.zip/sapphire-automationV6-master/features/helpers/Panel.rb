require_relative('UiHelpers')

class Panel
  def initialize(ui, type, data, data2 = nil, data3 = nil)
    @ui = ui
    @num = nil

    case type
      when Globals.newPanelTypeNumber, Globals.newPanelTypeID
        ctorNumOrId(data, type)
      when Globals.newPanelTypeWebElement
        ctorWebElement(data)
      when Globals.newPanelTypeParameters
        ctorParameters(data, data2, data3)
    end

    if (@num == nil)
      UiHelpers.throw "No panel number after C'tor ended"
    end

    begin
      @hash = getSinglePanelHash()
    rescue => e
      log "hash not created (error: #{e.message})"
    end
  end

  def log(message)
    parentFunc =  caller_locations(1).first.label
    Controls.log(message, File.basename(__FILE__), parentFunc.to_s)
  end

  def ctorParameters(currencyPair, calculatorType, liquidityProvider)
    e = getPanel(currencyPair, calculatorType, liquidityProvider)
    if (e.nil? || e.empty?)
      UiHelpers.throw "C'tor of Panel: No element found using getPanel"
    end
    ctorWebElement(e)
    log "Panel created (currencyPair: #{currencyPair}, "+
            "calculatorType: #{calculatorType}, "+
            "liquidityProvider: #{liquidityProvider})"
  end
  def ctorWebElement(webElement)
    i = 1
    @num = -1
    allPanels = getAllPanels()
    allPanels.each do |p|
      if (p == webElement)
        @num = i
        break
      end

      i += 1
    end

    if (@num < 0)
      UiHelpers.throw "C'tor of Panel: #{Globals.messageElementNotFound}"
    end

    log "#{Globals.messagePassed} (webElement: #{webElement.to_s})"
  end
  def ctorNumOrId(num, typeOfNum=Globals.newPanelTypeNumber)
    @num = num
    if (typeOfNum != Globals.newPanelTypeNumber)
      @num = getPanelNumById(@num)
    else
      @num = @num.to_i
    end

    log "#{Globals.messagePassed} (num: #{num.to_s}, typeOfNum: #{typeOfNum})"
  end

  def getUI()
    return @ui
  end

  def getPanelNumber()
    return @num
  end

  def getPanelHash()
    return @hash
  end

  def getActivePanelElement()
    element = nil
    all = getAllPanels()
    if (@num > all.length)
      @num = all.length
    else
      if (@num < 1)
        @num = 1
      end
    end

    return all[@num - 1]
  end

  def getCurrent()
    hashCurrent = {}
    base = getActivePanelElement()

  end

  # According to panel number returns hash of available button elements
  def getFooterBtns()
    panelElement = getActivePanelElement()

    hashOfButtons = {}
    for footerBtnName in [Globals.panelHomeLadder, Globals.panelVolumeLadder,
                          Globals.panelLpLadder, Globals.panelTenorLadder] do
      displayedBtnName = footerBtnName
      if (displayedBtnName == Globals.panelHomeLadder)
        displayedBtnName = Globals.panelPriceViewFull
      end

      begin
        footerBtn = "btn_panel_footer_#{footerBtnName}"
        btn = Controls.firstElement(footerBtn, panelElement)
        if (btn != nil)
          if (panelElement[Globals.attributeClass].downcase.include?(displayedBtnName.downcase))
            hashOfButtons[footerBtnName] = btn
          end
        end
      end
    end

    return hashOfButtons
  end

  def setLadder(ladderType, sleepAfterClick = 1)
    allBtns = getFooterBtns()
    if (allBtns.has_key?(ladderType))
      btn = allBtns[ladderType]
      @ui.clickOnWebElement(btn, sleepAfterClick)
    end
  end

  # Changes the view of the panel (large, small or medium)
  def changeViewOfPanel(panel, viewType = Globals.panelViewLarge)
    @ui.exceptionIfNil(panel, viewType)
    eNameBtnChangeView = "btn_panel_viewWithType"
    log "#{Globals.messageChangePanelView}: #{viewType}"
    btnCss = Controls.get(eNameBtnChangeView, viewType)
    if (btnCss == nil)
      UiHelpers.throw "#{Globals.messageNoCssImplemented} viewType:#{viewType}"
    end

    parent = getPanelContainerParent(panel)
    btn = @ui.firstWithCss(btnCss, nil, parent)
    if (btn == nil)
      UiHelpers.throw "#{Globals.messageElementNotFound} (viewType:#{viewType}, css:#{css})"
    end
    @ui.clickOnWebElement(btn,0)
  end

  def isNotEntitled()
    isCurrentPanelNotEntitled = false
    notEntitled = Panel.getAllNotEntitledPanels()
    if (notEntitled.has_key?(@num))
      isCurrentPanelNotEntitled = true
    end

    return isCurrentPanelNotEntitled
  end

  def getPanelDDElements(category)
    panel_number = @num
    menu = getPanelDDMenu(category)
    elements = Controls.allElements(Globals.controlsDefaultlist, menu)
    if (elements.nil?)
      elements = []
    end
    return elements
  end

  def getPanelDDValues(category, excludeValues = [])
    values = []
    begin
      panel_number = @num
      menu = getPanelDDMenu(category)
      elements = Controls.allElements(Globals.controlsDefaultlist, menu)
      elements.each do |e|
        val = e.text
        if (val.nil? || val.empty?)
          next
        end

        if (excludeValues.include?(val))
          next
        end

        values.push(val)
      end

      if (elements.empty?)
        raise "#{Globals.messageReturnedEmptyArray} (treated like error)"
      end
    rescue => e
      log "#{Globals.messageReturnedEmptyArray}, getting current value instead " +
              "(category: #{category}, error: #{e.message})"
      current = ""
      begin
        current = getCurrentClosedDDValue(category)
      rescue => ex
        log "ERROR while getting current value (category: #{category}, error: #{ex.message})"
        current = ""
      end

      if (current != "")
        values = [ current ]
      end

    ensure
      verifyDDMenuInPanelIsClosed()
    end

    return values
  end

  def getPanelDDValues2(category, excludeValues = [],
                        onFailureRaiseException = true,
                        onFailureAddToScenarioFails = false,
                        onFailureWriteToActionsF = false,
                        onFailureCreateScreenshot = false)
    values = []

    begin
      panel_number = @num
      menu = getPanelDDMenu(category)
      elements = Controls.allElements(Globals.controlsDefaultlist, menu)
      elements.each do |e|
        val = e.text
        if (val.nil? || val.empty?)
          next
        end

        if (excludeValues.include?(val))
          next
        end

        values.push(val)
      end

      if (elements.empty?)
        raise "#{Globals.messageReturnedEmptyArray} (treated like error)"
      end
    rescue => e
      values = []
    end

    if (values.empty?)
      begin
        current = getCurrentClosedDDValue2(category, onFailureRaiseException,
                                           onFailureAddToScenarioFails,
                                           onFailureWriteToActionsF,
                                           onFailureCreateScreenshot)
      rescue => ex
        current = ""
      end

      if (current != "")
        values = [ current ]
      end

    end

    verifyDDMenuInPanelIsClosed2(onFailureRaiseException,
                                 onFailureAddToScenarioFails,
                                 onFailureWriteToActionsF,
                                 onFailureCreateScreenshot)
    return values
  end

  def getPanelDDElements2(category, onFailureRaiseException = true,
                          onFailureAddToScenarioFails = false,
                          onFailureWriteToActionsF = false,
                          onFailureCreateScreenshot = false,
                          baseElementName = Globals.baseElementNamePanel)
    btnElementName = "btn_#{baseElementName}_#{category}"
    menuElementName = "menu_#{baseElementName}_#{category}"
    panel_number = @num
    css = Controls.get(menuElementName) + " " + Controls.get(Globals.controlsDefaultlist)
    panel = getActivePanelElement()
    if (category == Globals.panelDDFloor)
      panel = getPanelContainerParent2(panel)
    end

    btn = Controls.firstElement(btnElementName, panel)
    @ui.clickOnWebElement(btn, $uiDefaults["minimumTimeToSleep"]["after"]["click"])
    elements = panel.find_elements(:css, css)
    return elements
  end


  def getPanelDDMenu(category)
    panel_number = @num
    log "On category:#{category} panel:#{panel_number}"
    panel = getActivePanelElement()
    btnElementName = "btn_panel_#{category}"
    menuElementName = "menu_panel_#{category}"

    if (category == Globals.panelDDFloor)
      panel = getPanelContainerParent(panel)
    end

    btn = Controls.firstElement(btnElementName, panel)
    @ui.clickOnWebElement(btn)
    sleep 1
    ddMenu = Controls.firstElement(menuElementName, panel)
    log Globals.messageMethodFinished
    return ddMenu
  end

  def getCurrentClosedDDValue(category)
    currentElementName = "panel_current_#{category}"
    base = getActivePanelElement()
    if (category == Globals.panelDDFloor)
      base = getPanelContainerParent(base)
    end

    val = Controls.value(currentElementName, base)
    return val
  end
  def getCurrentClosedDDValue2(category, onFailureRaiseException = true,
                               onFailureAddToScenarioFails = false,
                               onFailureWriteToActionsF = false,
                               onFailureCreateScreenshot = false)
    currentElementName = "panel_current_#{category}"
    base = getActivePanelElement()
    if (category == Globals.panelDDFloor)
      base = getPanelContainerParent(base)
    end

    val = Controls.value(currentElementName, base)
    return val
  end

  def clickOnElementFromDD2(category, what_to_choose, onFailureRaiseException = true,
                            onFailureAddToScenarioFails = false,
                            onFailureWriteToActionsF = false,
                            onFailureCreateScreenshot = false)
    what_to_choose = @ui.trimString(what_to_choose)
    panel_number = @num
    maxTriesBeforeFailures = 10
    val = "NO VALUE WAS SET YET"
    wasOptionChosen = false
    while ((maxTriesBeforeFailures > 0) && (wasOptionChosen == false))
      log "Setting menu #{category} to #{what_to_choose} in panel number: #{panel_number.to_s}"
      setPanelDDMenu2(category, what_to_choose, onFailureRaiseException,
                    onFailureAddToScenarioFails,
                    onFailureWriteToActionsF,
                    onFailureCreateScreenshot)
      log "#{Globals.messagePassed}. verifying value was set"
      val = getCurrentClosedDDValue(category)
      val = @ui.trimString(val)

      if (val != what_to_choose)
        log "#{Globals.messageValueWasNotSet} (expected: #{what_to_choose}, found: #{val})"
        wasOptionChosen = false
        sleep 1
        maxTriesBeforeFailures -= 1
        log "Trying again (category: #{category.to_s}, to choose: #{what_to_choose.to_s})"
      else
        wasOptionChosen = true
        log "#{Globals.messagePassed} (expected: #{what_to_choose}, found: #{val})"
      end
  end
    return wasOptionChosen
  end

  def getAllAvailableEmptyPanelsNumbers()
    addPanelElementName = "btn_panel_addPanel"
    availableEmptyPanels = []
    all = getAllPanels(false)
    i = 1
    all.each do |p|
      addPanelBtn = nil
      begin
        addPanelBtn = Controls.firstElement(addPanelElementName, p)
        if (addPanelBtn != nil)
          availableEmptyPanels.push(i)
        end
      rescue
      end

      i += 1
    end

    return availableEmptyPanels
  end

  def removePanel()
    btnRemoveFirstStepElementName = "btn_panel_currencyPair"
    btnRemoveSecondStepElementName = "btn_panel_currencyPair_remove"
    panel = getActivePanelElement()
    btn = Controls.firstElement(btnRemoveFirstStepElementName, panel)
    @ui.clickOnWebElement(btn)
    btn = Controls.firstElement(btnRemoveSecondStepElementName, panel)
    @ui.clickOnWebElement(btn)
  end

  def setNewPanel(currencyPair)
    btnAddPanelElementName = "btn_panel_addPanel"
    menuCcysOnPanelElementName = "menu_panel_currencyPair"
    availablePanels = getAllAvailableEmptyPanelsNumbers()
    if (availablePanels.length == 0)
      raise "No available panel to set"
    end

    panelNum = availablePanels[0]
    panel = getAllPanels(false)[panelNum - 1]
    btn = Controls.firstElement(btnAddPanelElementName, panel)
    @ui.clickOnWebElement(btn, 0.3)
    ddMenu = Controls.firstElement(menuCcysOnPanelElementName, panel)
    @ui.selectFromDropdownMenu(ddMenu, currencyPair, true)
    newPanel = Panel.new(@ui, Globals.newPanelTypeNumber, panelNum)
    return newPanel
  end

  def setPanelDDMenu(category, what_to_choose)
    maxTries = 20
    what_to_choose = @ui.trimString(what_to_choose)
    if (category == Globals.panelDDdealtCCY)
      currentElementName = "panel_current_#{Globals.panelDDdealtCCY}"
      btnElementName = "btn_panel_#{Globals.panelDDdealtCCY}"
      found = false
      for i in 1..maxTries do
        panel = getActivePanelElement()
        current = Controls.value(currentElementName, panel)
        if (@ui.trimString(current) == what_to_choose)
          found = true
          break
        end

        btn = Controls.firstElement(btnElementName, panel)
        @ui.clickOnWebElement(btn)
      end

      if (! found)
        UiHelpers.throw "#{what_to_choose} #{Globals.messageElementNotFound} category: #{category}"
      end
    else
      panel_number = @num
      ddMenu = getPanelDDMenu(category)
      @ui.selectFromDropdownMenu(ddMenu, what_to_choose, true)
    end
  end

  def confirmAmountIfAsked()
    driver = @ui.getBaseElement()
    panel = getActivePanelElement()
    panelLocked = Controls.firstElement("panelLocked", panel)
    isDisplayedButton =
        driver.execute_script("return (window.getComputedStyle(arguments[0]).display != 'none')", panelLocked)
    if (isDisplayedButton)
      btn = Controls.firstElement("panelConfirmationBtn", panel)
      @ui.clickOnWebElement(btn)
    end
  end

  def setPanelDDMenu2(category, what_to_choose, onFailureRaiseException = true,
                      onFailureAddToScenarioFails = false,
                      onFailureWriteToActionsF = false,
                      onFailureCreateScreenshot = false,
                      baseElementName = Globals.baseElementNamePanel)
    maxTries = 20
    what_to_choose = @ui.trimString(what_to_choose)
    currentElementName = "#{baseElementName}_current_#{category}"
    sleepAfterClick = $uiDefaults["minimumTimeToSleep"]["after"]["click"]
    panel = getActivePanelElement()
    if (category == Globals.panelDDFloor)
      parent = getPanelContainerParent2(panel)
      current = Controls.value(currentElementName, parent)
    else
      current = Controls.value(currentElementName, panel)
    end

    found = false
    if (@ui.trimString(current) == what_to_choose)
      found = true
    end

    if (! found)
      case category
        when Globals.panelDDdealtCCY
          btnElementName = "btn_#{baseElementName}_#{Globals.panelDDdealtCCY}"
          for i in 1..maxTries do
            panel = getActivePanelElement()
            current = Controls.value(currentElementName, panel)
            if (@ui.trimString(current) == what_to_choose)
              found = true
              break
            end

            btn = Controls.firstElement(btnElementName, panel)
            @ui.clickOnWebElement(btn, sleepAfterClick)
          end

          if (! found)
            UiHelpers.throw "#{what_to_choose} #{Globals.messageElementNotFound} category: #{category}"
          end
        when Globals.panelDDpdValue
          inputElementName =  "#{baseElementName}_current_#{category}"
          panel = getActivePanelElement()
          element = Controls.firstElement(inputElementName, panel)
          found = true
          @ui.setField(element, what_to_choose)
        else
          sleepAfterClick = 1 # Required for sapphire 6
          panel_number = @num
          what_to_choose = @ui.trimString(what_to_choose)
          elements = getPanelDDElements2(category, onFailureRaiseException,
                                         onFailureAddToScenarioFails,
                                         onFailureWriteToActionsF,
                                         onFailureCreateScreenshot, baseElementName)
          elements.each do |e|
            val = e.text
            if (@ui.trimString(val) == what_to_choose)
              found = true
              @ui.clickOnWebElement(e, sleepAfterClick)
              break
            end
          end
      end
    end
    return found
  end


  # Sets the currency pair on the required 
  def setCurrencyPair(pair, onFailureRaiseException = true,
                      onFailureAddToScenarioFails = false,
                      onFailureWriteToActionsF = false,
                      onFailureCreateScreenshot = false)
    category = Globals.panelDDCCY
    return clickOnElementFromDD2(category, pair, onFailureRaiseException,
                                 onFailureAddToScenarioFails,
                                 onFailureWriteToActionsF,
                                 onFailureCreateScreenshot)
  end

  def setProductType(type, onFailureRaiseException = true,
            onFailureAddToScenarioFails = false,
            onFailureWriteToActionsF = false,
            onFailureCreateScreenshot = false)
    category = Globals.panelDDProductType
    return clickOnElementFromDD2(category, type, onFailureRaiseException,
                                 onFailureAddToScenarioFails,
                                 onFailureWriteToActionsF,
                                 onFailureCreateScreenshot)
  end

  # Sets the floor name
  def setFloor(name, onFailureRaiseException = true,
               onFailureAddToScenarioFails = false,
               onFailureWriteToActionsF = false,
               onFailureCreateScreenshot = false)
    category = Globals.panelDDFloor
    return clickOnElementFromDD2(category, name, onFailureRaiseException,
                                 onFailureAddToScenarioFails,
                                 onFailureWriteToActionsF,
                                 onFailureCreateScreenshot)
  end

  def setCalcType(name, onFailureRaiseException = true,
                  onFailureAddToScenarioFails = false,
                  onFailureWriteToActionsF = false,
                  onFailureCreateScreenshot = false)
    category = Globals.panelDDCalcType
    return clickOnElementFromDD2(category, name, onFailureRaiseException,
                                 onFailureAddToScenarioFails,
                                 onFailureWriteToActionsF,
                                 onFailureCreateScreenshot)
  end

  def getPanelContainerParent(panelElement)
    panelContainerElementName = "panel_container"
    driver = @ui.getBaseElement()
    cssContainer = Controls.get(panelContainerElementName)
    classFromCss = ""
    if (cssContainer =~ /class\s*\*=\s*([^\]]+)\s*\]/i)
      classFromCss = $1.to_s
      log "Found class: #{classFromCss}"
    end

    if (classFromCss.nil? || classFromCss.empty?)
      UiHelpers.throw "No class found"
    end

    parentElement =
        driver.execute_script(
          "e = arguments[0]; " +
          "while (! e.className.includes('#{classFromCss}')){" +
            "e = e.parentElement" +
          "}" +
          "return e;", panelElement)

    if (parentElement == nil)
      UiHelpers.throw "Parent #{Globals.messageElementNotFound}"
    end
    return parentElement
  end
  def getPanelContainerParent2(panelElement, onFailureRaiseException = true,
                               onFailureAddToScenarioFails = false,
                               onFailureWriteToActionsF = false,
                               onFailureCreateScreenshot = false)
    panelContainerElementName = "panel_container"
    driver = @ui.getBaseElement()
    cssContainer = Controls.get(panelContainerElementName)
    classFromCss = ""
    if (cssContainer =~ /class\s*\*=\s*([^\]]+)\s*\]/i)
      classFromCss = $1.to_s
      log "Found class: #{classFromCss}"
    end

    if (classFromCss.nil? || classFromCss.empty?)
      UiHelpers.throw("No class found", onFailureRaiseException,
                      onFailureAddToScenarioFails,
                      onFailureWriteToActionsF,
                      onFailureCreateScreenshot)
    end

    parentElement =
        driver.execute_script(
            "e = arguments[0]; " +
                "while (! e.className.includes('#{classFromCss}')){" +
                "e = e.parentElement" +
                "}" +
                "return e;", panelElement)

    if (parentElement == nil)
      UiHelpers.throw "Parent #{Globals.messageElementNotFound}"
    end
    return parentElement
  end

  def getAllPanels (shouldAddPanelsIds = true)
    panelElementName = "panel"
    panels = Controls.allElements(panelElementName, @ui.getBaseElement())
    if (shouldAddPanelsIds)
      $panelNumById = {}
      updatedIDsAmount = 0
      begin
        for i in 1..(panels.length) do
          panelId = Panel.getPanelId(panels[i-1])
          if ((!panelId.nil?) && (!panelId.empty?))
            updatedIDsAmount += 1
            $panelNumById[panelId] = i
          end
        end
      rescue
      end
      log "Updated ids for #{updatedIDsAmount} panels"
    end
    return panels
  end

  def getAllActivePanels()
    activePanelElementName = "panel_with_data"
    panels = Controls.allElements(activePanelElementName, @ui.getBaseElement())
    return panels
  end

  def getPanelMainPrices()
    panel = getActivePanelElement()
    pricesToRet = {}
    for priceType in ["buy", "sell"] do
      eName = "panel_current_mainPrice_#{priceType}"
      begin
        val = Controls.value(eName, panel)
        if ((val != nil) && (val != ""))
          pricesToRet[priceType] = val
        end
      rescue
        log "Cannot get price (eName: #{eName.to_s}), it is a problem only if you see prices on panel"
      end
    end

    return pricesToRet
  end

  def Panel.getAllNotEntitledPanels()
    hashToRet = {}
    activePanels = $panel.getAllActivePanels()
    panels = $panel.getAllPanels()
    i = 0
    panels.each do |p|
      i += 1
      if (!activePanels.include?(p))
        log "#{Globals.messageSkipNonActivePanels} (#{i})"
        next
      end

      begin
        text = Controls.value2("panel_notEntitled", p, false, false, false, false)
        if ((text != nil) && (text != ""))
          log "Adding panel #{i.to_s}'s notEntitled message: #{text} to the array."
          hashToRet[i] ={ Globals.notEntitledPanelsElement => p,
                        Globals.notEntitledPanelsMessage => text}
        end

      rescue
      end
    end

    return hashToRet
  end


  def getPanelNumById(panelId)
    toRet = nil
    if ($panelNumById.nil? || $panelNumById.empty?)
      log Globals.messageUpdateEmptyIdsArray
      getAllPanels()
    end

    if ($panelNumById.has_key?(panelId))
      toRet = $panelNumById[panelId]
      toRet = toRet.to_i
    end

    return toRet
  end

  def getPanel(currencyPair = nil, calculatorType = nil, liquidityProvider = nil)
    panelsArr	= getAllPanels()
    if (panelsArr == nil)
      UiHelpers.throw Globals.messageNoPanels
    end

    foundPanel = nil
    current = {Globals.panelDDCCY         => "",
               Globals.panelDDCalcType    => "",
               Globals.panelDDProductType => "" }
    panelsArr.each do |panel|
      for key in current.keys
        currentValueElementName = "panel_current_#{key}"
        value = Controls.value(currentValueElementName, panel)
        if (value != nil)
          current[key] = value.to_s.upcase
        end
      end

      if (  ((currencyPair == nil) || (currencyPair == current[Globals.panelDDCCY])) &&
            ((calculatorType == nil) || (calculatorType == current[Globals.panelDDCalcType])) &&
            ((liquidityProvider == nil) || (liquidityProvider == current[Globals.panelDDProductType]))  )
        # Found 
        foundPanel = panel
        break
      end
    end

    return foundPanel
  end

  def getQuotes(currencyPair, calculatorType, liquidityProvider)
    panelPricesOtIndAmountElementName = "panel_prices_ot_ind_amount"
    defaultPricesCssStatement = "panel_prices_LP_full"
    hashToRet = {}
    panel = getPanel(currencyPair, calculatorType, liquidityProvider)
    if (panel == nil)
      UiHelpers.throw Globals.messageNoPanels
    end

    log Globals.messageChangePanelView
    changeViewOfPanel(panel, Globals.panelViewLarge)
    log Global.messagePassed

    defaultAmount = nil
    arr = nil
    arrPrices = nil
    calculatorTypeUpperCase = calculatorType.to_s.upcase
    liquidityProviderUpperCase = liquidityProvider.to_s.upcase
    pricesCssStatement = defaultPricesCssStatement
    if ((calculatorTypeUpperCase == Globals.panelCalcTypeVWAP) ||
        (calculatorTypeUpperCase == Globals.panelCalcTypeLMT)  )
      pricesCssStatement = "panel_prices_LP_live"
    else
      if (calculatorTypeUpperCase == Globals.panelCalcTypeIND)
        pricesCssStatement = "panel_prices_#{liquidityProvider.to_s.downcase}_ind"
        defaultAmount = Controls.value(panelPricesOtIndAmountElementName, panel)
      end
    end

    log "getting array of lines with prices"
    css = Controls.get(pricesCssStatement)
    if (css == nil)
      UiHelpers.throw "No css implemented for #{pricesCssStatement}"
    end

    arrPrices = panel.find_elements(:css, css)
    if ((arrPrices == nil) || (arrPrices.length == 0))
      if (pricesCssStatement.to_s.upcase.include?(Globals.panelPriceViewLive))
        log "Even in LIVE panel we can be at the FULL view (depends on bottom button)"
        log "Trying to handle it as FULL view..."
        pricesCssStatement = "panel_prices_LP_full"
        css = Controls.get(pricesCssStatement)
        arrPrices = find_elements(:css, css)
        if ((arrPrices == nil) || (arrPrices.length == 0))
          return nil
        end
      else
        return nil
      end
    end

    for type in [Globals.panelTypeBid, Globals.panelTypeOffer] do
      hashToRet[type] = []
      arrPrices.each do |p|
        log "Handling price line (type: #{type})"
        curPrice = {}
        if (liquidityProvider == Globals.panelLpSW)
          log "In SW there is only price"
          priceElementName = "panel_prices_#{liquidityProvider.downcase}_#{calculatorType.downcase}_#{type}_price"
          css = Controls.get(priceElementName)
          priceElement = @ui.firstWithCss(css, nil, p)
          price = priceElement.text # Value or innerHTML cause bug for empty 
          if ((price == nil) || (price == ""))
            log "Missing price (LP: #{Globals.panelLpSW}, type: #{type})"
            next
          end
          curPrice[Globals.curPrice] = price.to_s
        else
          for priceTag in [Globals.panelPriceTypeBigFigure, Globals.panelPriceTypePip,
                           Globals.panelPriceTypeDecimal]
            log "Getting value of #{priceTag} for line of #{type}"
            cssStatement = "#{pricesCssStatement}_#{type}_#{priceTag}"
            begin
              curPrice[priceTag] = Controls.value(cssStatement, p)
            rescue
              log "Trying to get the value of the default css"
              cssStatement = "#{defaultPricesCssStatement}_#{type}_#{priceTag}"
              curPrice[priceTag] = Controls.value(cssStatement, p)
            end

            if (curPrice[priceTag] == "")
              curPrice[priceTag] = nil
            end
          end
        end

        if ((curPrice[Globals.panelPriceTypeBigFigure] != nil) &&
            (curPrice[Globals.panelPriceTypePip]       != nil) &&
            (curPrice[Globals.panelPriceTypeDecimal]   != nil) )
          # Copies them as strings ("1.13" + "47" + "2" = "1.13472")
          curPrice[Globals.curPrice] = curPrice[Globals.panelPriceTypeBigFigure] +
                              curPrice[Globals.panelPriceTypePip] +
                              curPrice[Globals.panelPriceTypeDecimal]
        end

        if ((calculatorTypeUpperCase == Globals.panelCalcTypeIND) && (defaultAmount != nil))
          log "Getting default amount (CALC: #{Globals.panelCalcTypeIND})"
          curPrice[Globals.curAmount] = defaultAmount
        else
          log "Getting amount from line of price (#{liquidityProvider}, #{calculatorType})"
          cssStatement = "#{pricesCssStatement}_#{type}_amount"
          begin
            curPrice[Globals.curAmount] = Controls.value(cssStatement, p)
          rescue
            log "Trying to get the amount using the default css"
            cssStatement = "#{defaultPricesCssStatement}_#{type}_amount"
            curPrice[priceTag] = Controls.value(cssStatement, p)
          end

          if (curPrice[Globals.curAmount] == "")
            curPrice[Globals.curAmount] = nil
          end
        end

        log "Adding type to #{Globals.panelPriceViewFull} panels... " +
                "(#{Globals.panelCalcTypeIND} is also treated as #{Globals.panelPriceViewFull} in this section)"
        if (liquidityProviderUpperCase =~ /(#{Globals.panelPriceViewFull}|#{Globals.panelCalcTypeIND})/)
          cssStatement = "panel_prices_LP_full_type"
          log "Getting type"
          priceType = Controls.value(cssStatement, p)
          if (priceType != nil)
            log "Updating type to: #{priceType}"
            curPrice[Globals.curType] = priceType
          end

          log "Getting sub type"
          cssStatement = "panel_prices_LP_full_subType"
          priceSubType = Controls.value(cssStatement, p)
          if (priceSubType != nil)
            log "Updating sub type to: #{priceSubType}"
            curPrice[Globals.curSubType] = priceSubType
          end
        end

        if ((curPrice[Globals.curAmount] != nil) && (curPrice[Globals.curPrice] != nil))
          hashToRet[type].push(curPrice)
        end
      end
    end

    return hashToRet
  end

  def datepickerGetCurrentSetValue(type = Globals.panelNearLeg)
    setDateElementName = 'datepicker_setDateValue'
    toRet = ""
    begin
      base = @ui.getBaseElement()
      toRet = Controls.value(setDateElementName, base, type)
    rescue
      toRet = ""
    end

    return toRet
  end

  # option name should be Tenor's name
  def clickOnTenorButtonInDatePicker(optionName, type)
    btnDatepickerTenorsElementName = 'btn_datepicker_tenors'
    keyWithElementNameInValue = "data-tenor-name"

    log "#{Globals.messageMethodStarted} (optionName: #{optionName.to_s}, type: #{type})"
    if (optionName == Globals.panelLpSPFullName)
      log "Changed SPOT (inner option name) to SP (html viewed name)"
      optionName = Globals.panelLpSP
    end

    optionName = optionName.to_s.downcase
    optionName = @ui.trimString(optionName)
    base = @ui.getBaseElement()
    css = Controls.get(btnDatepickerTenorsElementName, type) #For general button (with some [data-tenor-name]).
    arr = base.find_elements(:css, css)
    foundElement = nil
    arr.each do |e|
      eOptionName = e[keyWithElementNameInValue].to_s.downcase
      eOptionName = @ui.trimString(eOptionName)
      if (eOptionName == optionName)
        foundElement = e
        break
      end
    end

    if (foundElement == nil)
      UiHelpers.throw "#{Globals.messageElementNotFound} optionName: #{optionName}"
    end

    foundElement = @ui.waitForElementToBecomeAccessible(foundElement, 4)
    @ui.clickOnWebElement(foundElement)
    sleep 2
    log Globals.messageMethodFinished
    return true
  end

  def openDatePickerWindow(lp = Globals.panelLpSW,
                           onFailureRaiseException = true,
                           onFailureAddToScenarioFails = false,
                           onFailureWriteToActionsF = false,
                           onFailureCreateScreenshot = false)
    datepickerOpenElementName = 'datepicker_open'
    option = Globals.panelTenorOptionMore
    log "#{Globals.messageMethodStarted} (lp:#{lp})"
    case lp.to_s.upcase
      when Globals.panelLpSW
        setPanelDDMenu2(Globals.panelDDTenor, option, onFailureRaiseException,
                               onFailureAddToScenarioFails,
                               onFailureWriteToActionsF,
                               onFailureCreateScreenshot)
      when Globals.panelLpOT
        panel = getActivePanelElement()
        btn = Controls.firstElement(datepickerOpenElementName, panel)
        @ui.clickOnWebElement(btn)
      else
        UiHelpers.throw "#{lp} no implemented yet in daetpicker"
    end
    log Globals.messageMethodFinished
  end

  def getMaxTenorFromUI()
    all = getPanelDDValues2(Globals.panelDDTenor)
    immIndex = all.index("IMM1")
    foundValue = all[immIndex - 1]
    if (foundValue == nil)
      UiHelpers.throw "No value found for Max tenor"
    end
    return foundValue
  end

  def getMaxDateByTenor(tenorName, type, baseDate=nil, lp = Globals.panelLpSW)
    tenorName = tenorName.to_s.downcase
    if (baseDate == nil)
      date = Date.today()
    else
      date = baseDate
    end

    nextDate = nil
    if (tenorName =~ /(\d+)wk/)
      nextDate = date + (7 * $1.to_i)
    else if (tenorName =~ /(\d+)mth/)
           nextDate = date >> $1.to_i
         end
    end

    if (nextDate != nil)
      nextDate = nextDate + 1
    end

    nextDateStr = "#{nextDate.day.to_s}/#{nextDate.month.to_s}/#{nextDate.year.to_s}"
    log "current maxDate: #{nextDateStr}, searching in datepicker for more far date"
    clickNextOrPrevToDate(nextDateStr, type, lp)
    log "In month related to date: #{nextDateStr}"
    baseElement = @ui.getBaseElement()
    if (lp == Globals.panelLpOT)
      tableElement = Controls.firstElement("datepicker_old_table", baseElement)
    else
      tableElement = Controls.firstElement("datepicker_table_#{type.to_s.capitalize}", baseElement)
    end
    css = Controls.get('datepicker_dayInTable')
    log "Getting days of current month"
    dayElements = tableElement.find_elements(:css, css)
    log "Found #{dayElements.length.to_s} days"
    dayElements.each do |dayElement|
      day = dayElement.text.to_i
      log "Current day in datepicker: #{day.to_s}"
      if (day > nextDate.day.to_i)
        log "Day is higher, maxDate will now be day's date..."
        foundDate = "#{day.to_s}/#{nextDate.month.to_s}/#{nextDate.year.to_s}"
        nextDate = Date.parse(foundDate)
        break
      end
    end
    clickNextOrPrevToDate(@ui.dateStr(date), type, lp)
    return nextDate
  end

  # Assumes datepicker is already opened
  def datepickerGetUiAllTradingAndNonTradingDates(type, tenorName, lp = Globals.panelLpSW)
    curMonthElementName = "datepicker_currentDateMonth"
    curYearElementName  = "datepicker_currentDateYear"

    today = Date.today()
    maxDate = getMaxDateByTenor(tenorName, type)
    toRet = {}
    curMonth = Controls.value(curMonthElementName, @ui.getBaseElement())
    curMonth = @ui.getMonthNumber(curMonth).to_s
    curYear  = Controls.value(curYearElementName, @ui.getBaseElement())
    curDate = "#{curMonth}/#{curYear}"

    monthBeforeClickingNext = nil
    yearBeforeClickingNext = nil
    while ( (curMonth != monthBeforeClickingNext) ||
        (curYear  != yearBeforeClickingNext)   )
      log "Getting opened table of dates"
      css = Controls.get("datepicker_table_#{type.to_s.capitalize}") # type = near/far
      table = @ui.firstWithCss(css)
      dates = { Globals.typeNonTradingDates => [], Globals.typeTradingDates => []}

      log "Getting dates from table (#{curMonth}/#{curYear})"
      elements = { Globals.typeNonTradingDates => Controls.allElements('datepicker_nonTradeableDayInMonth', table),
                   Globals.typeTradingDates    => Controls.allElements('datepicker_dayInTable', table)}

      log "Gets days filtered"

      # dateType = trading / nonTrading
      for dateType in dates.keys do
        elements[dateType].each do |day|
          date = "#{day.text}/#{curMonth}/#{curYear}"
          parsedDate = Date.parse(date)
          if ((parsedDate >= today) && (parsedDate <= maxDate))
            dates[dateType].push(date)
          else
            log "#{date} was filtered since it is not between #{@ui.dateStr(today)} and #{@ui.dateStr(maxDate)}"
          end
        end
      end

      toRet[curDate] = dates
      datepickerClickNextMonth(lp)

      monthBeforeClickingNext = curMonth
      yearBeforeClickingNext = curYear
      curMonth = Controls.value(curMonthElementName, @ui.getBaseElement())
      curMonth = @ui.getMonthNumber(curMonth).to_s
      curYear  = Controls.value(curYearElementName, @ui.getBaseElement())
      curDate = "#{curMonth}/#{curYear}"
    end
    return toRet
  end

  def datepickerClickOnTypeBtn(type=Globals.panelNearLeg)
    panel = getActivePanelElement()
    btn = Controls.firstElement("btn_datepicker_#{type}", panel)
    @ui.clickOnWebElement(btn)
  end

  # Private function, in use at setDatePicker.
  def datepickerHandleDate(type, typeBtnElement, day, month, year, lp = Globals.panelLpSW)
    date = "#{day}/#{month}/#{year}"
    @ui.exceptionIfNil(day, month, year)

    wasSet = false
    @ui.clickOnWebElement(typeBtnElement)

    log "Testing that days before, and days after current month, are not clickable"
    errors = checkNontTradingDatesBeforeAndAfter()
    if (errors != "")
      UiHelpers.throw errors
    end


    clickNextOrPrevToDate(date, type, lp)

    if (! isDatePickerInMonth(month))
      exception = "#{type}: datePicker is not on month:#{month}"
      UiHelpers.throw exception
    end

    log "Getting Far next month"
    css = Controls.get("datepicker_table_#{type.to_s.capitalize}")
    tableElement = @ui.firstWithCss(css)
    if (tableElement != nil)
      dayElements = Controls.allElements('datepicker_dayInTable', tableElement)
      found = @ui.getInnerElementWithFoundText(day, dayElements)
      if (found == nil)
        UiHelpers.throw "Day not found in table of days (day: #{day})"
      end

      @ui.clickOnWebElement(found)
      wasSet = true
    end

    return wasSet
  end

  def datepickerMoveOneMonth(direction = Globals.panelDatepickerDirectionNext, lp = Globals.panelLpSW)
    if (lp == Globals.panelLpSW)
      elementNameDirectionBtn = "btn_datepicker_#{direction}"
    else
      elementNameDirectionBtn = "btn_datepicker_old_#{direction}"
    end

    css = Controls.get(elementNameDirectionBtn)
    @ui.exceptionIfNil(css)
    @ui.javascriptClickOnCss(css)
  end

  def datepickerClickNextMonth(lp = Globals.panelLpSW)
    datepickerMoveOneMonth(Globals.panelDatepickerDirectionNext, lp)
  end

  def datepickerClickPrevMonth(lp = Globals.panelLpSW)
    datepickerMoveOneMonth(Globals.panelDatepickerDirectionPrev, lp)
  end

  def datepickerGetCurrentDate(lp = Globals.panelLpSW)
    dateYear = Globals.dateYear
    dateMonth = Globals.dateMonth
    dateMonthNumber = Globals.dateMonthNumber
    elementNames = {}
    current = {}
    if (lp == Globals.panelLpSW)
      elementNames[dateYear] = "datepicker_currentDateYear"
      elementNames[dateMonth] = "datepicker_currentDateMonth"
    else
      elementNames[dateYear] = "datepicker_old_currentDateYear"
      elementNames[dateMonth] = "datepicker_old_currentDateMonth"
    end

    for elementType in elementNames.keys do
      e = Controls.validateElementExists(elementNames[elementType], @ui.getBaseElement())
      current[elementType] = @ui.getValueOrTextOrInnerHTML(e)
    end
    current[dateYear] = current[dateYear].to_i
    current[dateMonthNumber] = @ui.getMonthNumber(current[dateMonth]).to_i
    return current
  end

  def getHowManyClicksNext(date, near_or_far = "", lp = Globals.panelLpSW)
    day = 0
    month = 0
    year = 0
    if (/(\d+)[^\d]+(\d+)[^\d]+(\d+)/ =~ date)
      day = $1.to_i
      month = $2.to_i
      year = $3.to_i
    end
    total_clicks = 0
    currentDate = datepickerGetCurrentDate(lp)
    log "Calculating total clicks (requested date: #{date}, current date: #{currentDate})"
    total_clicks = (year.to_i - currentDate[Globals.dateYear].to_i) * 12 + (month.to_i - currentDate[Globals.dateMonthNumber])

    return total_clicks
  end

  def clickNextOrPrevToDate(date, type, lp = Globals.panelLpSW)
    how_many_clicks = getHowManyClicksNext(date.to_s, type.to_s, lp)
    log "Should click #{how_many_clicks.to_s}"
    if (how_many_clicks > 0)
      for i in 1 .. how_many_clicks
        log "Clicking next"
        datepickerClickNextMonth(lp)
        sleep(1)
      end
    else
      if (how_many_clicks < 0)
        # Going backwards.
        how_many_clicks = (-1) * how_many_clicks
        for i in 1 .. how_many_clicks
          log "Clicking prev"
          datepickerClickPrevMonth(lp)
          sleep(1)
        end
      end
    end
  end

  def checkNontTradingDatesBeforeAndAfter()
    allowedClicksErrors = ""
    Controls.log "First testing dates before and after current month, that apear on table"
    datesBeforeAndAfter = getDatePickerNonTradeableDatesForOtherMonthes()
    if (datesBeforeAndAfter != nil)
      datesBeforeAndAfter.each do |hashElement|
        eDate = hashElement["date"]
        eElement = hashElement[Globals.newPanelTypeWebElement]
        eElementClass = eElement['class'].to_s.downcase
        if (! eElementClass.include?('disabled'))
          allowedClicksErrors += "#{eDate} is clickable when expected not to be clickable"
        end
      end
    end

    return allowedClicksErrors
  end

  # Sets the date picker to specific date
  # all parameters are numeric
  def setDatePicker(to_date, from_date=nil)
    begin
      panel_number = @num
      log "#{Globals.messageMethodStarted}" +
              " (panel_number:#{panel_number}, to_date:#{to_date}, from_date:#{from_date})"
      set_date = false
      @ui.exceptionIfNil(panel_number, to_date)

      openDatePickerWindow()
      current = @ui.getCurrentLocation()

      toSet = {Globals.panelNearLeg => {}, Globals.panelFarLeg => {}}
      toSet[Globals.panelNearLeg]["date"] = from_date
      toSet[Globals.panelFarLeg]["date"] = to_date

      log "Checking if we should set date using Tenors/Datepicker"
      for dateType in toSet.keys do # near/far
        toSet[dateType]["tenorName"] = ""
        toSet[dateType]["wasSet"] = false

        if ((toSet[dateType]["date"] != nil) && (/(\d+)[^\d]+(\d+)[^\d]+(\d+)/ =~ toSet[dateType]["date"]))
          toSet[dateType][Globals.dateDay] = $1.to_i
          toSet[dateType][Globals.dateMonth] = $2.to_i
          toSet[dateType][Globals.dateYear] = $3.to_i
          @ui.exceptionIfNil(toSet[dateType][Globals.dateDay],
                             toSet[dateType][Globals.dateMonth],
                             toSet[dateType][Globals.dateYear])

        else
          toSet[dateType]["tenorName"] = toSet[dateType]["date"] # Expected to support setDatePicker(1,"TOM", "TOD")
        end
        log Globals.messagePassed

        log "Setting date of #{dateType} (date: #{toSet[dateType]['date']})"
        css = Controls.get("btn_datepicker_#{dateType}")
        toSet[dateType]["btnElement"] = @ui.firstWithCss(css)
        @ui.exceptionIfNil(toSet[dateType]["btnElement"])
        if (toSet[dateType]["tenorName"] != "")
          toSet[dateType]["wasSet"] =
              clickOnTenorButtonInDatePicker(toSet[dateType]["tenorName"], dateType)
        else
          toSet[dateType]["wasSet"] = datepickerHandleDate(dateType,
                                                           toSet[dateType]["btnElement"],
                                                           toSet[dateType][Globals.dateDay],
                                                           toSet[dateType][Globals.dateMonth],
                                                           toSet[dateType][Globals.dateYear])
        end

        if (! toSet[dateType]["wasSet"])
          message "#{dateType} date to #{toSet[dateType]["date"]} wasn't set correctly"
          log message
          UiHelpers.throw "Error: #{message}"
        else
          log Globals.messagePassed
        end

        setValAfterSettingDate = datepickerGetCurrentSetValue(dateType)
        log "After clicking, date was set to: #{setValAfterSettingDate}"
      end

      set_date = toSet[Globals.panelNearLeg]["wasSet"] && toSet[Globals.panelFarLeg]["wasSet"]
    ensure
      # Close the opened
      verifyDatepickerIsClosed()
      curCcyValue = Controls.value("panel_current_currencyPair", getActivePanelElement())
      errorsSet = wasDateSetCorrectlyAfterClosingDatePicker(curCcyValue, to_date, from_date)
      if ((! errorsSet.nil?) && (! (errorsSet == "")))
        exception = "After datepicker done and closed, date was not set (tried to set from:#{from_date} to:#{to_date} error:#{errorsSet})"
        UiHelpers.throw exception
      end
    end
    log "#{Globals.messageMethodFinished} (#{set_date})"
    return set_date
  end

  def isOpenedDatepicker()
    toRet = false
    css = Controls.get("datepicker_opened")
    if (@ui.firstWithCss(css) != nil)
      toRet = true
    end

    return toRet
  end

  def goMaxBackwardsInMonths()
    cssPrevBtn = Controls.get("btn_datepicker_prev")
    prevBtn = @ui.firstWithCss(cssPrevBtn)
    maxTries = 12
    curTry = 0
    while ((prevBtn != nil) && (@ui.isElementAccessible(prevBtn)) && (curTry < maxTries))
      begin
        datepickerClickPrevMonth()
      rescue

      end
      prevBtn = @ui.firstWithCss(cssPrevBtn)

      curTry += 1
    end
  end

  def getClosestTradingDate(date)
    dateDay = 0
    dateMonth = 0
    dateYear = 0
    tradingDay = nil
    if (/^(\d+)[^\d]+(\d+)[^\d]+(\d+)/ =~ date)
      dateDay = $1.to_i
      dateMonth = $2.to_i
      dateYear = $3.to_i
    end
    if (! isOpenedDatepicker())
      openDatePickerWindow()
    end

    goMaxBackwardsInMonths()
    cssTableNear =  Controls.get("datepicker_table_Near")
    cssDayInTable = Controls.get("datepicker_dayInTable")
    css = "#{cssTableNear} #{cssDayInTable}"
    dayElements = @ui.getBaseElement().find_elements(:css, css + " a")
    dayElements.each do |dayElement|
      dayElementDay = dayElement.text.to_i
      while (dayElementDay < dateDay)
        next
      end

      while (dayElementDay > dateDay)
        dateDay += 1
      end

      if (dayElementDay == dateDay)
        log "trading day was set to: #{dateDay.to_s}"
        tradingDay = "#{dateDay.to_s}/#{dateMonth.to_s}/#{dateYear.to_s}"
        break
      end
    end

    verifyDatepickerIsClosed()
    return tradingDay
  end

  def verifyDDMenuInPanelIsClosed()
    log "Since there is no close button to dropdown menu, redirects to Swaps again"
    @ui.redirectTo(Globals.pageTrade ,Globals.tabSwaps)
  end
  def verifyDDMenuInPanelIsClosed2(onFailureRaiseException = true,
                                   onFailureAddToScenarioFails = false,
                                   onFailureWriteToActionsF = false,
                                   onFailureCreateScreenshot = false)
    log "Since there is no close button to dropdown menu, clicking on header element"
    eNameHeader = "header_currentPage"
    baseElement = @ui.getBaseElement()
    btn = Controls.firstElement(eNameHeader, baseElement)
    @ui.clickOnWebElement(btn)
  end

  def verifyDatepickerIsClosed(lp = Globals.panelLpSW)
    # Close the opened
    begin
      baseElement = @ui.getBaseElement()
      if (lp == Globals.panelLpSW)
        closeBtnElementName = "btn_datepicker_close"
      else
        closeBtnElementName = "btn_datepicker_old_close"
      end
      baseElement = @ui.getBaseElement()
      btn = Controls.firstElement(closeBtnElementName, baseElement)
      if (btn != nil)
        @ui.clickOnWebElement(btn, 1)
      end
    rescue
    end
  end

  def getNextMonth(month, year)
    if (month.is_a?(String))
      month = @ui.getMonthNumber(month)
    end

    date = "1/#{month.to_s}/#{year.to_s}"
    date = Date.parse(date)
    date = date.next_month()

    return {Globals.dateMonth => date.month(), Globals.dateYear => date.year()}
  end

  # Verifies that we currently in the required month on datePicker
  # Month is a number
  def isDatePickerInMonth(month)
    loc = 1 # 1.Near 2.Far
    if (@ui.getCurrentLocation()[Globals.locationTabNameLowerCase] == Globals.tabSwaps)
      if (@ui.firstWithCss('[class*=show-far]') != nil)
        loc = 2
      end
    end

    # Get month as abbr (Nov instead of 11..)
    month = @ui.getMonthName(month)

    # Check if current month name on datePicker is month
    curMonthElementName = "datepicker_currentDateMonth"
    css = Controls.get(curMonthElementName)
    datePickerMonth = @ui.firstWithCss(css)
    @ui.exceptionIfNil(datePickerMonth)
    isInMonth = false
    datePickerText = datePickerMonth.text
    if (datePickerText == month)
      isInMonth = true
    end

    return isInMonth
  end

  def getDatesPairInPanel()
    panel_number = @num
    css = Controls.get("panel_current_tradingDates")
    e = @ui.elementWithCssOnLoc(css, panel_number)
    text = ""
    if (e != nil)
      text = e.text.to_s
      text = text.gsub(/\s/, "")
    end

    return text
  end

  def convertDateToDateInPanel(dateToConvert)
    dateToRet = "NOT CONVERTED DATE"
    if (dateToConvert =~ /(\d+)[^\d]+(\d+)[^\d]+(\d+)/)
      day = $1.to_s
      if (day.length == 1)
        day = "0#{day}"
      end

      month = $2.to_s
      month = @ui.getMonthAbbr(month.to_i)

      year = $3.to_s
      dateToRet = "#{day} #{month}"
    end

    return dateToRet
  end


  def wasDateSetCorrectlyAfterClosingDatePicker(ccyValue, to_date, from_date=nil)
    expectedResult = ""
    if ((to_date !~ /(\d+)[^\d]+(\d+)[^\d]+(\d+)/) &&
        (from_date !~ /(\d+)[^\d]+(\d+)[^\d]+(\d+)/) )
      begin
        log "Handling from_date and to_date as tenors"
        baseObjectsArr = $uiDefaults["tenorsExpectedResults"][ccyValue]
        log "baseObjectsArr: #{baseObjectsArr.to_s}"
        baseObjectsArr.each do |baseObject|
          if ((baseObject[Globals.panelNearLeg] == from_date)  &&
              (baseObject[Globals.panelFarLeg]  == to_date)    )
            expectedResult = baseObject["expectedResult"]
            break
          end
        end
      rescue
      end
    end

    if (expectedResult == "")
      dateNear = convertDateToDateInPanel(from_date)
      dateFar  = convertDateToDateInPanel(to_date)
      expectedResult = "#{dateNear} / #{dateFar}"
    end

    panel_number = @num
    expectedResult = expectedResult.gsub(/\s/, "").downcase

    toRet = ""
    dateInPanel = getDatesPairInPanel()
    dateInPanel = dateInPanel.downcase
    if (expectedResult == dateInPanel)
      toRet = ""
    else
      toRet = "Date was not set properly, expected: #{expectedResult}, found: #{dateInPanel}"
    end

    return toRet
  end

  def getDatePickerNonTradeableDatesForOtherMonthes()
    toRet = []
    curMonth = Controls.value("datepicker_currentDateMonth", @ui.getBaseElement())
    curYear = Controls.value("datepicker_currentDateYear", @ui.getBaseElement())
    curDate = "1/#{curMonth}/#{curYear}"

    monthBefore = ""
    yearBefore = ""
    monthAfter = ""
    yearAfter = ""
    curDate = Date.parse(curDate)
    nextMonthDate = curDate.next_month()
    prevMonthDate = curDate.prev_month()
    monthBefore = prevMonthDate.month.to_s
    yearBefore = prevMonthDate.year.to_s
    monthAfter = nextMonthDate.month.to_s
    yearAfter = nextMonthDate.year.to_s


    nonTradeAbleDays = Controls.allElements("datepicker_nonTradeableDayForOtherMonth", @ui.getBaseElement())
    if (nonTradeAbleDays != nil)
      nonTradeAbleDays.each do |d|
        toRetElement = {}
        toRetElement[Globals.newPanelTypeWebElement] = d
        dateDay = d.find_elements(:css, "span")[0]
        dateDay = @ui.getValueOrTextOrInnerHTML(dateDay)
        if (dateDay.to_i > 27)
          date = "#{dateDay}/#{monthBefore}/#{yearBefore}"
        else
          date = "#{dateDay}/#{monthAfter}/#{yearAfter}"
        end

        toRetElement["date"] = date
        toRet.push(toRetElement)
      end
    end

    return toRet
  end

  def Panel.getPanelId(element)
    element=element.native if(element.kind_of?(Capybara::Node::Element))
    res = Capybara.page.driver.browser.execute_script("xxx = $(arguments[0]).find('.panel-body').scope().panelSettings.id;return xxx", element)
    return res.to_s
  end
  
  def Panel.getPanelNodeById(id)
    pricePanelCss='div.sap-price-column'
    res = ''
    Capybara.page.all(:css, pricePanelCss).each do |panel|
      panelCurrId = Panel.getPanelId(panel)
      res = panel if(panelCurrId.to_s == id.to_s)
    end
    return res
  end

  def Panel.getPricePanelsHash
    pricePanelCss='div.sap-price-panel'

    ccyPairCss='div.currencyPair input.txt-input'
    ccyPairCss2='div.currencyPair'
    ccyPairCssSelected='div.dropdown ul.option-container li.option.-selected'

    productTypeCss='div.productType span.selected'

    priceModelCss='div.priceModel span.selected'

    dealtAmountCss='div.qty input.number-input'

    hash={}
    counter=0

    Capybara.page.all(:css, pricePanelCss).each do |panel|
      counter+=1
      hash_current={}
      hash['panel_'+counter.to_s]=hash_current

      hash_current['panelNodeElement']=panel

      res = Panel.getPanelId(panel)
      hash_current['panelId']=res

      # res = UiHelpers.getTextByCssAfterClick(panel,ccyPairCss, ccyPairCss, ccyPairCss2+' '+ccyPairCssSelected)
      res = UiHelpers.getValueByCss(panel,ccyPairCss)
      hash_current['ccyPair']=res

      res = UiHelpers.getTextByCss(panel,productTypeCss)
      hash_current[Globals.panelDDProductType]=res

      res = UiHelpers.getTextByCss(panel,priceModelCss)
      hash_current['priceModel']=res

      res = UiHelpers.getValueByCss(panel,dealtAmountCss)
      hash_current['dealtAmount']=res
    end

    return hash
  end

  def getSinglePanelHash()
    hash={}
    hash_current = {}
    panelWithNum = 'panel_'+getPanelNumber().to_s
    hash[panelWithNum]=hash_current

    hash_current['panelNodeElement'] = getActivePanelElement()

    res = Panel.getPanelId(hash_current['panelNodeElement'])
    hash_current['panelId'] = res

    res = Controls.value("panel_current_currencyPair", hash_current['panelNodeElement'])
    hash_current['ccyPair']=res

    res = Controls.value("panel_current_productType", hash_current['panelNodeElement'])
    hash_current[Globals.panelDDProductType]=res

    res = Controls.value("panel_current_priceModel", hash_current['panelNodeElement'])
    hash_current['priceModel']=res

    res = Controls.value("panel_current_dealtAmount", hash_current['panelNodeElement'])
    hash_current['dealtAmount']=res

    return hash
  end

  def Panel.getPanelNodesArrByHashKey(hashPricePanels,hashKey,value,getFirstOnly=false)
    if hashPricePanels.class != Hash
      UiHelpers.throw 'getPanelNodeByHashKey error: not hash given'
    end

    resPanelArr=[]
    hashPricePanels.each do |panelCurrent|
      if panelCurrent[1].include?(hashKey)
        if panelCurrent[1][hashKey] == value
          resPanelArr.push(panelCurrent[1]['panelNodeElement'])
          break if(getFirstOnly)
        end
      end
    end

    if resPanelArr.empty?
      UiHelpers.throw 'getPanelNodeByHashKey error: "'+hashKey+'" is not a key of given price panels hash'
    end

    return resPanelArr
  end

  def Panel.clickBtnRfqInPanel(panelNode)
    eName  =  "btn_panel_header_Rfq"
    baseElement = panelNode.native
    Controls.click2(eName, baseElement)
  end
end