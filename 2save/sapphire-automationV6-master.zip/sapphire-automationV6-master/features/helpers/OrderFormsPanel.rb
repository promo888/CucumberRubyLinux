require_relative 'Panel'

class OrderFormsPanel < Panel
  def initialize(ui, type, data, data2 = nil, data3 = nil)
    super(ui, type, data, data2, data3)
    productTypeForOrderForms = "SP"
    @ui = getUI()
    @num = getPanelNumber()
    @defaultCCY = $uiDefaults["defaultValues"]["ccy"]
    @defaultFloor = $uiDefaults["defaultValues"]["floor"]
    element = getActivePanelElement()
    setPanelDDMenu2(Globals.panelDDCCY, @defaultCCY)
    setPanelDDMenu2(Globals.panelDDFloor, @defaultFloor)
    setPanelDDMenu2(Globals.panelDDProductType, productTypeForOrderForms)
  end

  def openOrderForms(type = Globals.panelTypeBid)
    log "Waiting for prices on panel"
    pricesHash = {}
    for i in 1 .. 4 do
      pricesHash = getPanelMainPrices()
      if (pricesHash.empty?)
        log "Prices not found, waiting #{i} seconds"
        sleep i
      else
        log "Prices found"
        break
      end
    end
    if (pricesHash.empty?)
      UiHelpers.throw "No prices on panel, so cannot open order forms"
    end

    panel = getActivePanelElement()
    eName = "btn_rfqLine_#{type}"
    btn = Controls.firstElement(eName, panel)
    @ui.clickOnWebElement(btn)
  end

  def closeOrderForms(option = Globals.orderFormsCancel,
                      onFailureRaiseException = true,
                      onFailureAddToScenarioFails = false,
                      onFailureWriteToActionsF = false,
                      onFailureCreateScreenshot = false)
    panel = getActivePanelElement()
    eName = "btn_orderForm_#{option}"
    btn = Controls.firstElement(eName, panel)
    @ui.clickOnWebElement(btn, 2)
  end

  def getOrderformsPanelCurrentClosedDDValue2(category, baseElementName = Globals.baseElementNameOrderFormsPanel,
                                              onFailureRaiseException = true,
                                              onFailureAddToScenarioFails = false,
                                              onFailureWriteToActionsF = false,
                                              onFailureCreateScreenshot = false)
    panel = getActivePanelElement()
    val = nil
    begin
      eName = "#{baseElementName}_current_#{category}"
      val = Controls.value2(eName, panel,onFailureRaiseException,
                            onFailureAddToScenarioFails,
                            onFailureWriteToActionsF,
                            onFailureCreateScreenshot)
    rescue
      log "On #{category} couldn't get values using #{baseElementName}, " +
              "trying to get value using default panel's method"
      val = getCurrentClosedDDValue2(category, onFailureRaiseException,
                                     onFailureAddToScenarioFails,
                                     onFailureWriteToActionsF,
                                     onFailureCreateScreenshot)
    end

    return val
  end

  def convertEcnToFullName(ecnShortName)
    ecnName = ""
    if (ecnShortName == "D")
      ecnName = "Direct"
    end
    return ecnName
  end

  def getOpenedOrderProperties()
    hashProperties = {}
    for key in [ Globals.panelDDFloor,
                 Globals.panelDDCCY,
                 Globals.panelDDProductType,
                 Globals.panelDDtradingDates,
                 Globals.panelDDCalcType,
                 Globals.panelDDdealtAmount,
                 Globals.panelDDdealtCCY,
                 Globals.panelDDpdValue ] do
      val = getOrderformsPanelCurrentClosedDDValue2(key)
      if (key == Globals.panelDDdealtAmount)
        val = UiHelpers.convertAmount(val, Globals.convertAmountShortString)
      end

      hashProperties[key] = val
    end

    for key in [Globals.panelOrderformsAlgo,
                Globals.panelOrderformsCptys,
                Globals.panelOrderformsEcn,
                Globals.panelOrderformsIceberg,
                Globals.panelOrderformsTif,
                Globals.panelOrderformsPriceType] do
      val = getOrderformsPanelCurrentClosedDDValue2(key)
      case key
        when Globals.panelOrderformsEcn
          val = convertEcnToFullName(val)
        when Globals.panelOrderformsPriceType
          val = val.to_s.downcase
      end

      hashProperties[key] = val
    end

    priceElements = getPriceFieldWebElements()
    price = @ui.getValueOrTextOrInnerHTML(priceElements[Globals.panelPriceTypeBigFigure]) +
            @ui.getValueOrTextOrInnerHTML(priceElements[Globals.panelPriceTypePip])
    hashProperties[Globals.panelOrderformsPrice] = price

    return hashProperties
  end

  def getPriceFieldWebElements(baseElementName = Globals.baseElementNameOrderFormsPanel)
    panel = getActivePanelElement()
    elementsToRet = {}
    for priceType in [Globals.panelPriceTypeBigFigure, Globals.panelPriceTypePip] do
      eName = "#{baseElementName}_priceField_#{priceType}"
      elementsToRet[priceType] = Controls.firstElement(eName, panel)
    end
    return elementsToRet
  end

  def setDefaultValues()
    setOrderformsPanelDDMenu2(Globals.panelDDdealtAmount, Globals.dealtAmountStr1M)
    setOrderformsPanelDDMenu2(Globals.panelDDpdValue, "0.0")
    setOrderformsPanelDDMenu2(Globals.panelOrderformsCptys,
                                {
                                    Globals.cptyABC1=> Globals.checkboxChecked,
                                    Globals.cptyABC2=> Globals.checkboxChecked,
                                    Globals.cptyARKA=> Globals.checkboxChecked,
                                    Globals.cptyAcc1=> Globals.checkboxChecked,
                                    Globals.cptyAcc2=> Globals.checkboxChecked,
                                    Globals.cptyAcc4=> Globals.checkboxChecked,
                                    Globals.cptyAcc6=> Globals.checkboxChecked,
                                    Globals.cptyAcc7=> Globals.checkboxChecked,
                                    Globals.cptyAff1=> Globals.checkboxChecked,
                                    Globals.cptyAff2=> Globals.checkboxChecked,
                                    Globals.cptyC1TC=> Globals.checkboxChecked,
                                    Globals.cptyC1TD=> Globals.checkboxChecked,
                                    Globals.cptyEMSQ=> Globals.checkboxChecked,
                                    Globals.cptyLP32=> Globals.checkboxChecked,
                                    Globals.cptyLP33=> Globals.checkboxChecked,
                                    Globals.cptyLPE2=> Globals.checkboxChecked,
                                    Globals.cptyLPLA=> Globals.checkboxChecked,
                                    Globals.cptyLPLB=> Globals.checkboxChecked,
                                    Globals.cptyLPLK=> Globals.checkboxChecked,
                                    Globals.cptyLPLL=> Globals.checkboxChecked,
                                    Globals.cptyLPP1=> Globals.checkboxChecked,
                                    Globals.cptyLPP2=> Globals.checkboxChecked,
                                    Globals.cptyLPRI=> Globals.checkboxChecked,
                                    Globals.cptyLPRJ=> Globals.checkboxChecked,
                                    Globals.cptyLPRK=> Globals.checkboxChecked,
                                    Globals.cptyLPRL=> Globals.checkboxChecked,
                                    Globals.cptyLPRM=> Globals.checkboxChecked,
                                    Globals.cptyLSQ1=> Globals.checkboxChecked,
                                    Globals.cptyLPTA=> Globals.checkboxChecked,
                                    Globals.cptyLPTB=> Globals.checkboxChecked,
                                    Globals.cptyLPTC=> Globals.checkboxChecked,
                                    Globals.cptyLPTL=> Globals.checkboxChecked,
                                    Globals.cptyLPU1=> Globals.checkboxChecked,
                                    Globals.cptyN1MA=> Globals.checkboxChecked,
                                    Globals.cptyN1MC=> Globals.checkboxChecked,
                                    Globals.cptyN1MD=> Globals.checkboxChecked,
                                    Globals.cptyRC59=> Globals.checkboxChecked,
                                    Globals.cptyRL11=> Globals.checkboxChecked,
                                    Globals.cptyRL12=> Globals.checkboxChecked,
                                    Globals.cptyRT01=> Globals.checkboxChecked,
                                    Globals.cptyRT02=> Globals.checkboxChecked,
                                    Globals.cptyRT04=> Globals.checkboxChecked,
                                    Globals.cptySBJ1=> Globals.checkboxChecked,
                                    Globals.cptySBJ3=> Globals.checkboxChecked,
                                    Globals.cptyUTQ1=> Globals.checkboxChecked,
                                    Globals.cptyZ4MA=> Globals.checkboxChecked,
                                    Globals.cptyZ4MB=> Globals.checkboxChecked,
                                    Globals.cptyZBBI=> Globals.checkboxChecked,
                                    Globals.cptyZRBC=> Globals.checkboxChecked,
                                    Globals.cptyZZ11=> Globals.checkboxChecked,
                                    Globals.cptyZZ13=> Globals.checkboxChecked,
                                    Globals.cptyZZ14=> Globals.checkboxChecked,
                                })
    setOrderformsPanelDDMenu2(Globals.panelOrderformsTif, Globals.tifGTC)
    setOrderformsPanelDDMenu2(Globals.panelOrderformsPriceType, Globals.typeBid)
    setOrderformsPanelDDMenu2(Globals.panelOrderformsPrice, {Globals.panelPriceTypeBigFigure => "1.22",
                                                              Globals.panelPriceTypePip => "010"})
  end

  def setOrderformsPanelDDMenu2(category, what_to_choose, onFailureRaiseException = true,
                                onFailureAddToScenarioFails = false,
                                onFailureWriteToActionsF = false,
                                onFailureCreateScreenshot = false)
    case category
      when Globals.panelOrderformsCptys
        panel = getActivePanelElement()
        eNameCheckBox = "checkbox"
        eNameBtn = "btn_panelOrderForms_#{category}"
        cssList = Controls.get("MenuElement") + " " + Controls.get("listItem")
        hashWhatToChoose = what_to_choose
        if (! hashWhatToChoose.is_a?(Hash))
          UiHelpers.throw("Hash expected for category: #{category}",onFailureRaiseException,
                          onFailureAddToScenarioFails,
                          onFailureWriteToActionsF,
                          onFailureCreateScreenshot)
        end

        if (hashWhatToChoose.empty?)
          UiHelpers.throw("Hash cannot be empty", onFailureRaiseException,
                          onFailureAddToScenarioFails,
                          onFailureWriteToActionsF,
                          onFailureCreateScreenshot)
        end
        begin
          btn = Controls.firstElement(eNameBtn, panel)
          @ui.clickOnWebElement(btn)
          for elementFromHash in hashWhatToChoose.keys do
            # To prevent bugs caused by element changing positions,
            # getting all elements for every key in hash.
            all = panel.find_elements(:css, cssList)
            all.each do |listItem|
              current = listItem.text()
              current = @ui.trimString(current)
              if (current == elementFromHash)
                inputCheckbox = Controls.firstElement(eNameCheckBox, listItem)
                @ui.setCheckBox(inputCheckbox, hashWhatToChoose[elementFromHash])
                break
              end
            end
          end
        ensure
          eNameBtnDone = "btnDone"
          btnClose = Controls.firstElement(eNameBtnDone, panel)
          @ui.clickOnWebElement(btnClose)
        end
      when Globals.panelOrderformsPrice
        hashWhatToSet = what_to_choose
        if (! hashWhatToSet.is_a?(Hash))
          UiHelpers.throw("Hash expected for category: #{category}", onFailureRaiseException,
                          onFailureAddToScenarioFails,
                          onFailureWriteToActionsF,
                          onFailureCreateScreenshot)
        end

        if (hashWhatToSet.empty?)
          UiHelpers.throw("Hash cannot be empty", onFailureRaiseException,
                          onFailureAddToScenarioFails,
                          onFailureWriteToActionsF,
                          onFailureCreateScreenshot)
        end

        priceElements = getPriceFieldWebElements()
        log "Validating all data required to set exists"
        for key in priceElements.keys do
          if (! hashWhatToSet.has_key?(key))
            UiHelpers.throw("Missing key: #{key.to_s} in what_to_choose: #{what_to_choose.to_s}",
                            onFailureRaiseException,
                            onFailureAddToScenarioFails,
                            onFailureWriteToActionsF,
                            onFailureCreateScreenshot)
          else
            val = hashWhatToSet[key]
            if ((val == nil) || (val.to_s.empty?))
              UiHelpers.throw("Value cannot be empty (what_to_choose: #{what_to_choose})",
                              onFailureRaiseException,
                              onFailureAddToScenarioFails,
                              onFailureWriteToActionsF,
                              onFailureCreateScreenshot)
            end
          end
        end
        log "#{Globals.messagePassed}, setting the values"
        for key in priceElements.keys do
          val = hashWhatToSet[key]
          element = priceElements[key]
          @ui.setField(element, val)
        end
        log Globals.messagePassed
      else
        baseElementName = Globals.baseElementNameOrderFormsPanel
        begin
          setPanelDDMenu2(category, what_to_choose, onFailureRaiseException,
                          onFailureAddToScenarioFails,
                          onFailureWriteToActionsF,
                          onFailureCreateScreenshot, baseElementName)
        rescue
          log "On #{category} couldn't set #{what_to_choose} using #{baseElementName}, " +
              "trying using default baseElementName instead"
          setPanelDDMenu2(category, what_to_choose, onFailureRaiseException,
                          onFailureAddToScenarioFails,
                          onFailureWriteToActionsF,
                          onFailureCreateScreenshot)
        end
    end
  end
end