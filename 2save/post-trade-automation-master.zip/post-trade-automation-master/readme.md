-------PostTrade API Sanity------
Testing ALL Adapters and DB changes after MSL recovery.
Config file config/environments.yml used to change environments settings and run cucumber -p YourProfile.
Copy/Paste default ptrade1 profile,change settings and rename to YourProfile in order to run.
