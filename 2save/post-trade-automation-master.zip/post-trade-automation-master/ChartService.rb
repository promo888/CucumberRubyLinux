require 'webrick'
include WEBrick
require 'erb'

WEBrick::HTTPUtils::DefaultMimeTypes['rhtml'] = 'text/html'
server = WEBrick::HTTPServer.new :Port => 4444, :DocumentRoot => Dir.pwd



class ChartServlet < WEBrick::HTTPServlet::ERBHandler #FileHandler #HTTPServlet::AbstractServlet
  @@test3 = "test3"
  def initialize()
    @test4="test4"
    super
  end

  def do_GET(request, response)
    @test="testvar"
    erb :index#, :locals => {test2 => "testvar2"}

    begin
      File.open(request.path.to_s.sub(/\//, ''),'r') do |f|
        @template = ERB.new(f.read)
        #@template.def_method
      end
      response.status = 200 # Success
      response.headers['Cache-Control'] = 'max-age=3155760000'
      response.body = @template.result(binding) #"Test" #
      #response.headers['Content-Type'] = 'text/event-stream'
      response.content_type = "text/plain"
      raise HTTPStatus::OK
    rescue Exception=>e
      puts 'Error Backtrace: '
      puts e.backtrace.to_s
    end
  end

  # Respond with an HTTP POST just as we do for the HTTP GET.
  alias :do_POST :do_GET
end

#server.mount('/', ChartServlet) #/getChartFromCsv  #to display Dynamic response by Servlet
server.mount '/', WEBrick::HTTPServlet::FileHandler, '' #to display html/rhtml Static Files
#yield server if block_given?
['INT', 'TERM'].each {|signal|
  trap(signal) {server.shutdown}
}
server.start




=begin
def start_webrick(config = {})
  # always listen on port 6666
  config.update(:Port => 6666)
  config.update(:MimeTypes => {'rhtml' => 'text/html'})
  server = HTTPServer.new(config)
  yield server if block_given?
  ['INT', 'TERM'].each {|signal|
    trap(signal) {server.shutdown}
  }
  server.start
end
start_webrick(:DocumentRoot => Dir::pwd)
=end


__END__
aaa
