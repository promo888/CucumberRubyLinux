require "webrick"

begin
  ###require_relative('Actions')
rescue LoadError
  raise "Couldn't load Actions.rb\n"
end

include WEBrick
@server = nil
$set_params={}
LOG_FILE="webrick.log"
$common_log = WEBrick::Log.new(LOG_FILE,WEBrick::Log::INFO)

class Service
  class SetServlet < WEBrick::HTTPServlet::AbstractServlet
   def do_GET (request, response)
    #super
    puts("Service setter got request: "+request.to_s)
    $common_log.info('Service setter got request: '+request.to_s)
    request.request_line.to_s.split("HTTP")[0].split("?")[1].split("&").each{|kv|
      k=kv.split("=")
      $set_params[k[0].to_s.downcase]=k[1].to_s.downcase
    }
    response.content_type = "text/plain"
    response.body = "GET request served \n"
    raise HTTPStatus::OK
   end
  end

  class GetServlet < WEBrick::HTTPServlet::AbstractServlet
    def prevent_caching(res)
      res['ETag']          = nil
      res['Last-Modified'] = Time.now + 100**4
      res['Cache-Control'] = 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0'
      res['Pragma']        = 'no-cache'
      res['Expires']       = Time.now - 100**4
    end

    def do_GET (request, response)
      #super
      prevent_caching(response)
      puts("Service getter got request: "+request.to_s)
      $common_log.info('Service getter got request: '+request.to_s)
      response.content_type = "text/plain"
      $set_params.empty? ? response.body = " \n" :response.body = $set_params.to_s+" \n"
      raise HTTPStatus::OK
    end
  end


  class ResetServlet < WEBrick::HTTPServlet::AbstractServlet
    def do_GET (request, response)
      #super
      puts("Service reset got request: "+request.to_s)
      $common_log.info('Service reset got request: '+request.to_s)
      $set_params={}

      response.content_type = "text/plain"
      response.body = "GET reset request served \n"
      raise HTTPStatus::OK
    end
  end


  def Service.start(port=1234)
    begin
      server = WEBrick::HTTPServer.new(:Port => port)
      server.mount "/set", SetServlet
      server.mount "/get", GetServlet
      server.mount "/reset", ResetServlet

      trap "INT" do
        puts 'Service GOT Shutdown'
        $common_log.info('Service GOT Shutdown')
        server.shutdown
      end

      File.write(Dir.getwd+"/"+LOG_FILE,"") #Reset log on each start
      server.start
      puts 'Service started on port '+port.to_s
      $common_log.info('Service started on port '+port.to_s)
    rescue Exception=>e
      puts "Start Service failed: " + e.message
      $common_log.info("Start Service failed: " + e.message)
    end
  end


  def Service.stop(instance)
    begin
      instance.shutdown
    rescue Exception=>e
      puts("Stop Service failed: " +e.message)
      $common_log.info("Stop Service failed: " + e.message)
    end
  end

  def initialize(port=1234)
    Service.start(port)
  end

end


#Service.new
ARGV.each do|a|
  puts 'script got param: '+a.to_s
  Service.start if a.to_s.downcase.eql?('start')
  Service.stop if a.to_s.downcase.eql?('stop')
end