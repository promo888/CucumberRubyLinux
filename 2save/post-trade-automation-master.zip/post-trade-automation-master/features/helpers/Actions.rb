require 'cucumber'
require 'net/ssh'
require 'net/scp'
require 'net/sftp'
require 'net/ftp'
#require 'net/ssh/shell'
require 'net/http'
require 'net/https'
require 'json'
#require 'json-comp'
require 'json-compare'
require 'dbi'
require 'oci8' #oracle_query
require 'fileutils'
require 'csv-diff'
require 'csv-mapper'
require 'csv2json'
require 'diff_dirs'
require 'diffy'
require 'time'
require 'csv'
require 'hashdiff'


require Dir.getwd + '/features/helpers/Config'
require Dir.getwd + '/features/helpers/Globals'

class Actions
      #include Config
      #include CONFIG



    def Actions.SSH(host, user, pwd, cmd, timeout_sec, bash_output, expected_output)
        begin
            #c 'Opening SSH session... '
            session_timeout = Integer(timeout_sec) rescue nil
            ssh = Net::SSH.start(host, user, :password => pwd)
            if (session_timeout)
               timeout session_timeout do
                   time = Time.new
                   cur_time = time.day.to_s+'-'+time.month.to_s+'-'+time.year.to_s+'_'+time.hour.to_s+'-'+time.min.to_s+'-'+time.sec.to_s
                    v ' Executing command "' +cmd.to_s+'"...'
                    $ssh_output = ssh.exec!(cmd)
                    v 'Command "' +cmd.to_s+'" finished'
                    #sleep(3)
                    #ssh.loop(3)
               end
            end
            ####ssh.close
            if (!expected_output.to_s.empty? && expected_output.is_a?(Array) && bash_output)
              not_found = false
              expected_output.each_with_index { |row, i|
                not_found = true  if(!$ssh_output=~row)
               # fail("Expected Regex ''"+row.to_s+"'  Not Found in SSH output: ")  if(not_found)
              }
              fail("Expected Regex ''"+expected_output.to_s+"'  Not Found in SSH output: "+$ssh_output)  if(not_found)
            else
              fail('Expected Regex '+expected_output.to_s+"' Not Found in SSH output: "+$ssh_output) if (!expected_output.to_s.empty? && !$ssh_output.to_s.include?(expected_output) && bash_output && !expected_output.is_a?(Array))
            end
        rescue Exception => e
            @@scenario_fails.push(e.message)
            f "SSH Error: " + e.to_s + " #{host} for #{user}@#{pwd} on cmd:#{cmd}"  if (e!=nil)
            fail("SSH Error: " + e.to_s + " #{host} for #{user}@#{pwd} on cmd:#{cmd}") if (e!=nil)
        ensure
            ssh.close if (ssh!=nil)
            #c 'SSH session closed!'
        end

      @@scenario_fails.push('SSH FAILED - ' + $ssh_output.to_s)   if (!$ssh_output.to_s.empty? && !bash_output || $ssh_output.to_s.downcase.include?('error') || $ssh_output.to_s.downcase.include?('No such file or directory'))
      fail('SSH FAILED - ' + $ssh_output.to_s) if (!$ssh_output.to_s.empty? && !bash_output)#bash_output for parsing bash results
      fail('SSH FAILED - ' + $ssh_output.to_s) if ($ssh_output.to_s.downcase.include?('not found') || $ssh_output.to_s.downcase.include?('error') || $ssh_output.to_s.downcase.include?('No such file or directory'))

      return $ssh_output

    end




    def Actions.SSH_NO_FAIL(host, user, pwd, cmd, timeout_sec)
      begin
        #v 'Opening SSH session... '
        session_timeout = Integer(timeout_sec) rescue nil
        ssh = Net::SSH.start(host, user, :password => pwd)
        if (session_timeout)
          timeout session_timeout do
            v ' Executing command  ' +cmd.to_s
            $ssh_output = ssh.exec!(cmd)

          end
        end

      rescue Exception => e
        #f "SSH Error: " + e.to_s + " #{host} for #{user}@#{pwd}"  if (e!=nil)
        #fail("SSH Error: " + e.to_s + " #{host} for #{user}@#{pwd}") if (e!=nil)
        #@@scenario_fails.push(e.message)
        #e:execution expired Timeout::Error
         err_msg='Exception in SSH_NO_FAIL: '
         err_msg+=e.message if !e.message.nil?
         Actions.v err_msg
      ensure
        ########ssh.close if (ssh!=nil)
        #v 'SSH session closed!'
        return $ssh_output
      end

      return $ssh_output

    end



    def Actions.SSH_SHELL(host, user, pwd, cmd_array, timeout_sec, bash_output, expected_output)
      begin
      session_timeout = Integer(timeout_sec) rescue nil
      ssh_shell = Net::SSH.start(host, user, :password => pwd)

        timeout session_timeout do
            ssh_shell.exec! "whoami"
            $r=ssh_shell.exec! " bash /export/home/oracle/Automation/sdata_schema_install_automatic.sh -v"#cmd_array #"cd ~/MSLErSender/bin && ./mslErSender.sh -s ~/data/tmp_ER2"
            self.v 'ssh_shell res:'+$r.to_s


          #  assert_match(/.txt with execId [....-....-....-..]+/, cmd.to_s,' Terminal Output Should contain execId')
          #  c ($r =~ /.txt with execId [....-....-....-..]+/)
          ##  c $r =~ /txt with execId/i
          ##  report_string = 'ExecId asserted ' + $r.scan(/\[(.*?)\]/).to_s
          ##  c report_string
        end

    rescue Exception => e
      self.f "SSH Error: " + e.to_s + " #{host} for #{user}@#{pwd}"
      fail("SSH Error: " + e.to_s + " #{host} for #{user}@#{pwd}")
      @@scenario_fails.push(e.message)
    ensure
      ssh_shell.close if (ssh_shell!=nil)
    end


    #fail('SSH FAILED - ' + $r.to_s) if (!$r.to_s.empty? && !bash_output)#bash_output for parsing bash results #TODO bashError
    #fail('SSH FAILED - ' + $r.to_s) if ($r.to_s.downcase.include?('not found') || $r.to_s.downcase.include?('error') )
  rescue Exception=>e
    self.f 'ssh_shell failed - '+ e.message

    #return $cmd

  end



  def Actions.WINCMD(cmd, timeout_sec, expected_output)
    self.v 'Executing local win command ' + cmd + (!expected_output.to_s.empty? ? ' expected_output - ' + expected_output : '')
    begin
      session_timeout = Integer(timeout_sec) rescue nil
      $cmd_output =[]
      if (session_timeout)
        timeout session_timeout do
          IO.popen(cmd).each do |line|
            c line.chomp
            $cmd_output  << line.chomp
          end
        end
      else
        IO.popen(cmd).each do |line|
          c line.chomp
          $cmd_output  << line.chomp
        end
      end
    #c  ('WinCMD  Response: ' + $cmd_output.to_s)
    fail('Expected Regex Not Found in CMD output: ' + expected_output ) if (!expected_output.to_s.empty? && !$cmd_output.to_s =~ expected_output.to_s)

    rescue Exception => e
      @@scenario_fails.push(e.message)
      f "Local WinCmd Error: " + e.to_s if (e!=nil)
      fail("Local WinCmd Error: " + e.to_s ) if (e!=nil)
    ensure
      #IO.close
    end


    fail('Local WinCmd  FAILED - ' + $cmd_output.to_s) if ( $cmd_output.to_s.downcase.include?('not found') || $cmd_output.to_s.downcase.include?('error')  || $cmd_output.to_s.downcase.include?('not recognized'))

    return $cmd_output

  end



  def Actions.WINCMD_NO_FAIL(cmd, timeout_sec)
      #self.c 'Executing local win command ' + cmd
      begin
        session_timeout = Integer(timeout_sec) rescue nil
        $cmd_output =[]
        if (session_timeout)
          timeout session_timeout do
            IO.popen(cmd).each do |line|
              #p line.chomp
              $cmd_output  << line.chomp
              $cmd_output
            end
          end
        else
          IO.popen(cmd).each do |line|
            #p line.chomp
            $cmd_output  << line.chomp
            v $cmd_output
          end
        end
        #c  ('WinCMD  Response: ' + $cmd_output.to_s)

      rescue Exception => e
        #NO_FAIL :-)
      ensure
        #Kill in Before Scenario
        #IO.close
      end

      return $cmd_output

  end


    def Actions.WINCMD_NO_FAIL2(cmd, timeout_sec="na") #execute and exit - dont grab output for long run processes
      v 'Execute and exit local win command "' + cmd +'"'
      begin
        Process.spawn(cmd) #system exec
      rescue nil
        #NO_FAIL :-)
      ensure
        return
      end
    end


  def Actions.killUserProcesses(host,pwd,user,proc_grep_value)
    cmd="/bin/ps -f|egrep -i '#{proc_grep_value}'|grep -v grep|grep -v ssh"
    # res=Actions.SSH(host, user, pwd, cmd, 60, true, '')
    res=Actions.SSH_NO_FAIL(host, user, pwd, cmd, 60)
    Actions.v 'ps results: ' +res.to_s if !res.nil?

    cmd="kill -9 $(/bin/ps -f|egrep -i '#{proc_grep_value}'|grep -v grep|grep -v ssh|awk '{print $2}')"
    # res=Actions.SSH(host, user, pwd, cmd, 60, true, '')
    res=Actions.SSH_NO_FAIL(host, user, pwd, cmd, 60)
    Actions.v 'Kill results: ' +res.to_s if !res.nil?
  end

  def Actions.getHashFromJsonFile(json_file_path)
    c 'json_file_path ' + json_file_path
    c 'Current Dir ' + Dir.getwd
    $json_output = {}
    begin
      json_file =  File.read(json_file_path)
             # #er_file_path 'libs/MSLErSender/data/Scenario0/er_test.txt'
      json = json_file.to_json
      $json_output = JSON.parse(json, :quirks_mode => true)
    rescue Exception => e
      @@scenario_fails.push(e.message)
      f e.message if (!e.nil?)
      fail('Error in Json - ' + e.message ) if (!e.nil?)
    ensure
      #file.close if !file.nil?
    end

    return $json_output
  end



  def Actions.getDbQueryResults(query,expected_row_count,failed_file_name)
    host = @@CONFIG['ORACLE_HOST']
    port = @@CONFIG['ORACLE_HOST_PORT']
    service = @@CONFIG['ORACLE_HOST_SERVICE']
    usr = @@CONFIG['ORACLE_DB_USER']
    pwd = @@CONFIG['ORACLE_DB_PWD']

    v 'Connecting to ' + host.to_s+':'+port.to_s+'/'+service.to_s+' with ' +usr.to_s+'/'+pwd.to_s+'...'

    $query_results = []
    begin
      dbh = DBI.connect('DBI:OCI8:'+host.to_s+':'+port.to_s+'/'+service.to_s,usr.to_s,pwd.to_s)
      sth = dbh.prepare(query)
      sth.execute() #('SYSTEM')
      #$db_res = sth.fetch_hash #fetch 1row
      $row_count = 0
      while row=sth.fetch_hash do
        $row_count+= 1
       # c row[0].to_s
        $query_results << row
      end
      c (" Query Results <br> " + printDbTableHash($query_results) + " <br> ")
      fail (expected_row_count.to_s + " records expected for query but Actual is '" + $row_count.to_s+"' <br> Query <br>" + query + " <br> ")  if(!expected_row_count.to_s.empty? && expected_row_count.to_i!=$row_count)

      #c '<br> ASSERTED - '+ expected_row_count.to_s + ' rows amount for query - ' + query + '<br>'
    rescue Exception => e
      @@scenario_fails.push(e.message)
      f e.message if (!e.nil?)
      fail('DB Error  - ' + e.message) if (!e.nil?)
    ensure
      sth.finish if !dbh.nil?
      dbh.disconnect if dbh
    end

    c $query_results.to_s
    return $query_results


  end




  def Actions.compareDbTableResults(source_schema, target_schema, folder_timestamp)
    Actions.v 'compareDbTableResults - #Started#'
    tables = @@CONFIG['ORACLE_TABLES_TO_COMPARE']
    results_dir =  folder_timestamp.nil? ? @@CONFIG['ORACLE_TABLES_COMPARE_RESULTS_DIR'] : @@CONFIG['ORACLE_TABLES_COMPARE_RESULTS_DIR']+'/'+folder_timestamp
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+@@CONFIG['ORACLE_TABLES_COMPARE_RESULTS_DIR']+' && mkdir ' +  folder_timestamp, 10) #if(!folder_timestamp.nil?)

    Actions.checkTablesChanges(source_schema, target_schema)
    Actions.compareTablesStructure(source_schema, target_schema)
    Actions.compareViewsStructure(source_schema,target_schema)
    Actions.compareViews(source_schema,source_schema,target_schema,target_schema)
    #Actions.checkViewsChanges('ptrade1', 'ptrade') #instead of Actions.compareViews

    tables.each_with_index { |table, index|
      Actions.compareTableStructure(source_schema, target_schema, table.keys[0].to_s) if(!table.keys[0].to_s.nil?)
      if(table.keys[0].nil?)
        Actions.f ' DB Error - Table '+ table.keys[0]
        @@scenario_fails.push(' DB Error - Table '+ table.keys[0] )
        fail(' DB Error - Table '+ table.keys[0] )
        return
      end

      $sql_query_source_diff=nil
      $sql_query_target_diff=nil
      $order_by=nil
      $order_by=tables[index].find { |key, value| key.to_s.match(/#{tables[index].keys[0]}/)}[1][0]['ORDER_BY']
      #puts 'order_by - ' +$order_by

      $source_cols_query = "SELECT column_name FROM  all_tab_columns WHERE  table_name = '" +tables[index].keys[0] +"'  AND owner = '"+source_schema.to_s.upcase+"' order by 1"
      $target_cols_query = "SELECT column_name FROM  all_tab_columns WHERE  table_name = '" +tables[index].keys[0] +"'  AND owner = '"+target_schema.to_s.upcase+"' order by 1"

      $source_cols = self.getDbQueryResultsWithoutFailure4(source_schema,source_schema.to_s.downcase,$source_cols_query)
      $target_cols = self.getDbQueryResultsWithoutFailure4(target_schema,target_schema.to_s.downcase,$target_cols_query)
      if($source_cols.nil? || $target_cols.nil?)
        #self.f(' Error ? - No Data Returned')
        @@scenario_fails.push('DB Error for '+tables[index].keys[0])
        fail(' DB Error '+tables[index].keys[0])
        return
      end

       if(!($source_cols-$target_cols).nil? && ($source_cols-$target_cols).length>0)
           $cols_list=''
           ($source_cols - $target_cols).each { |col_value|  $cols_list+=(col_value['COLUMN_NAME']+'<br>') }
           if(!$cols_list.to_s.empty?)
             self.f(' Error ? - in table '+ tables[index].keys[0] + ' Removed fields: <br>')
             $world.puts($cols_list)
           end
        end
        if( !($target_cols-$source_cols).nil? && ($target_cols-$source_cols).length>0)
          $cols_list=''
          ($target_cols-$source_cols).each { |col_value|  $cols_list+=(col_value['COLUMN_NAME']+'<br>') }
           if(!$cols_list.to_s.empty?)
             self.f(' Error ? - in table '+ tables[index].keys[0] + ' Added fields: <br>')
             $world.puts($cols_list)
           end
        end
        $exclude_cols = @@CONFIG['ORACLE_HOST_TABLES_EXCLUDED_COLUMNS'][index][table.keys[0]]
        $include_cols = $target_cols-($target_cols-$source_cols)-($source_cols-$target_cols)
        $include_cols = $include_cols - $exclude_cols if(!$exclude_cols.nil?)

        $remove_index_arr = []
        $include_cols.each_with_index { |elem, index|
          $exclude_cols.each_with_index { |elem2,index2|
            $remove_index_arr.push(index) if(elem['COLUMN_NAME']==elem2)
          }
        }
        $shift_index = 0
        $remove_index_arr.each_with_index{|remove_index,index|
           if index==0
             $include_cols.delete_at(remove_index)
             $shift_index+=1
           else
             $include_cols.delete_at(remove_index-$shift_index)
             $shift_index+=1
           end
        }

        $sql_query_source_diff = "SELECT  "
        $include_cols.each_with_index{|val,i|
          $sql_query_source_diff << $include_cols[i]['COLUMN_NAME'].to_s
          $sql_query_source_diff << "," if(i+1!=$include_cols.length)
        }
        $sql_query_source_diff << " FROM " +source_schema+"."+tables[index].keys[0]
        #$sql_query_source_diff << ' order by 1 '
        $sql_query_source_diff << " MINUS "
        $sql_query_source_diff << "SELECT  "
        $include_cols.each_with_index{|val,i|
          $sql_query_source_diff << $include_cols[i]['COLUMN_NAME'].to_s
          $sql_query_source_diff << "," if(i+1!=$include_cols.length)
        }
        $sql_query_source_diff << " FROM " +target_schema+"."+tables[index].keys[0]
        #$sql_query_source_diff << ' order by 1 '



        $sql_query_target_diff = "SELECT  "
        $include_cols.each_with_index{|val,i|
          $sql_query_target_diff << $include_cols[i]['COLUMN_NAME'].to_s
          $sql_query_target_diff << "," if(i+1!=$include_cols.length)
        }
        $sql_query_target_diff << " FROM " +target_schema+"."+tables[index].keys[0]
        #$sql_query_target_diff << ' order by 1 '
        $sql_query_target_diff << " MINUS "
        $sql_query_target_diff << "SELECT  "
        $include_cols.each_with_index{|val,i|
          $sql_query_target_diff << $include_cols[i]['COLUMN_NAME'].to_s
          $sql_query_target_diff << "," if(i+1!=$include_cols.length)
        }
        $sql_query_target_diff << " FROM " +source_schema+"."+tables[index].keys[0]
        #$sql_query_target_diff << ' order by 1 '



      source_res = self.getDbQueryResultsWithoutFailure4(source_schema,source_schema.to_s.downcase,$sql_query_source_diff)
      target_res = self.getDbQueryResultsWithoutFailure4(target_schema,target_schema.to_s.downcase,$sql_query_target_diff)

      if(source_res.nil? || target_res.nil? || source_res!=target_res || !source_res.to_s.empty? || !target_res.to_s.empty?)
        $link_path = ''
        if Dir.getwd.include?(@@CONFIG['JENKINS_JOB_NAME']) # specific for a jenkins url and job remove C:/Jenkins/jobs/CPT-Sanity/workspace/
          if ((!source_res.nil? && !target_res.nil?) && (source_res-target_res).length>0)
            f ' Error ? - Diff Found - ' + tables[index].keys[0] + ' ' + ((source_res-target_res).length).to_s  + ' Changed or Missing records' # in '+ target_schema
            source_file=Dir.getwd+results_dir+'/source_'+source_schema+'_'+tables[index].keys[0]+'.csv'
            target_file=Dir.getwd+results_dir+'/target_'+target_schema+'_'+tables[index].keys[0]+'.csv'
            $link_path_source = @@CONFIG['JENKINS_URL'].to_s+'job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +source_file
            $link_path_target = @@CONFIG['JENKINS_URL'].to_s+'job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +target_file
            $link_path_source.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
            $link_path_target.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
            f "Storing SqlMinus Diff <a href='" + $link_path_source+"'>"+File.basename(source_file.to_s)+"</a> and <a href='"+$link_path_target+"'>" + File.basename(target_file.to_s)+"</a> in " +results_dir

          elsif ((!source_res.nil? && !target_res.nil?) && (target_res-source_res).length>0)
            f ' Error ? - Diff Found - ' + tables[index].keys[0] + ' ' + ((target_res-source_res).length).to_s  + ' Changed or Added records' # in '+ target_schema
            source_file=Dir.getwd+results_dir+'/source_'+source_schema+'_'+tables[index].keys[0]+'.csv'
            target_file=Dir.getwd+results_dir+'/target_'+target_schema+'_'+tables[index].keys[0]+'.csv'
            $link_path_source = @@CONFIG['JENKINS_URL'].to_s+'job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +source_file
            $link_path_target = @@CONFIG['JENKINS_URL'].to_s+'job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +target_file
            $link_path_source.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
            $link_path_target.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
            f "Storing SqlMinus Diff <a href='" + $link_path_source+"'>"+File.basename(source_file.to_s)+"</a> and <a href='"+$link_path_target+"'>" + File.basename(target_file.to_s)+"</a> in " +results_dir
          end

        else
          if ((!source_res.nil? && !target_res.nil?) && (source_res-target_res).length>0)
            f 'Error ? - Diff Found - ' + tables[index].keys[0] + ' ' + ((source_res-target_res).length).to_s  + ' Changed or Missing records' # in '+target_schema
            source_file=Dir.getwd+results_dir+'/source_'+source_schema+'_'+tables[index].keys[0]+'.csv'
            target_file=Dir.getwd+results_dir+'/target_'+target_schema+'_'+tables[index].keys[0]+'.csv'
            f "Storing SqlMinus Diff <a href='" + source_file+"'>"+File.basename(source_file.to_s)+"</a> and <a href='"+target_file+"'>" + File.basename(target_file.to_s)+"</a> in " +results_dir

          elsif ((!source_res.nil? && !target_res.nil?) && (target_res-source_res).length>0)
            f 'Error ? - Diff Found - ' + tables[index].keys[0] + ' ' + ((target_res-source_res).length).to_s  + ' Changed or Added records' # in '+target_schema
            source_file=Dir.getwd+results_dir+'/source_'+source_schema+'_'+tables[index].keys[0]+'.csv'
            target_file=Dir.getwd+results_dir+'/target_'+target_schema+'_'+tables[index].keys[0]+'.csv'
            f "Storing SqlMinus Diff <a href='" + source_file+"'>"+File.basename(source_file.to_s)+"</a> and <a href='"+target_file+"'>" + File.basename(target_file.to_s)+"</a> in " +results_dir

          end

        end

        if(!tables[index].keys[0].nil?)
            source_csv_filename = 'source_'+source_schema+'_'+tables[index].keys[0]+'.csv' #Source file
            target_csv_filename = 'target_'+target_schema+'_'+tables[index].keys[0]+'.csv' #Target file
            self.writeSqlMinusDiffToFile(tables[index].keys[0],Dir.getwd+results_dir+'/'+source_csv_filename,source_res,CONFIG.get['CORE_HOST_USER1'])
            self.writeSqlMinusDiffToFile(tables[index].keys[0],Dir.getwd+results_dir+'/'+target_csv_filename,target_res,CONFIG.get['CORE_HOST_USER'])

            ############## DB Diff by code
            self.printDbColumnDiffToFile(tables,$include_cols,source_schema,target_schema,tables[index].keys[0].to_s) #if(!tables[index].keys[0].nil?)
        else
           @@scenario_fails.push('Exception in SELECT from TABLE' + (!tables[index].nil? ? tables[index]:''))
           f 'Exception in SELECT from TABLE ' + (!tables[index].nil? ? tables[index]:'')
        end

      else
        c tables[index].keys[0]+' matched in ' + source_schema + ' and ' + target_schema + ' schemas '
      end


    }

    Actions.v 'compareDbTableResults - #Finished#'
  end


#TODO to continue
  def Actions.writeSqlMinusDiffToFile(table,file_path,data_to_convert_to_csv,diff_for_user)
    begin
      if(table.nil? || file_path.nil?)
         u='' if diff_for_user.nil?
         t='' if table.nil?
         fail("Empty or no access to table #{u}.#{t} for user #{diff_for_user} ")
      else
        File.write(file_path, (!data_to_convert_to_csv.nil? && !data_to_convert_to_csv.empty? && !convertHashMapToCsv(data_to_convert_to_csv).nil?) ? convertHashMapToCsv(data_to_convert_to_csv) : '')
      end

    rescue Exception=>e
      @@scenario_fails.push('Exception in Save File or Empty table '+table+ ' for user '+diff_for_user+' ' + e.message)
      f 'Exception in Save File or Empty table '+table+ ' for user '+diff_for_user+' ' + e.message
      fail('Exception in Save File or Empty table '+table+ ' for user '+diff_for_user+' ' + e.message)
    end
  end


  def Actions.printDbColumnDiffToFile(tables,include_cols,source_schema,target_schema,table_name)
    begin
      sql_query_source_qa = "SELECT  "
      include_cols.each_with_index{|val,i|
        sql_query_source_qa << include_cols[i]['COLUMN_NAME'].to_s
        sql_query_source_qa << "," if(i+1!=include_cols.length)
      }
      sql_query_source_qa << " FROM " +source_schema+"."+table_name
      sql_query_source_qa << ' order by ID,ECP_EXEC_ID,ECP_FLOOR_KEY,CP_SI_CCY ' if table_name.to_s.downcase=='fx_ticket_leg'
      sql_query_source_qa << ' order by ID ' if table_name.to_s.downcase=='sd_target'
      sql_query_source_qa << ' order by EXEC_ID,ASSET_COUNTER,INSTR_PRODUCT_TYPE,ECP_FLOOR_KEY,EFP_FLOOR_KEY ' if table_name.to_s.downcase=='fx_deal'
      sql_query_source_qa << ' order by EXEC_ID,EFP_INSTITUTION_KEY,FP_SIDE,LEG_TYPE ' if table_name.to_s.downcase=='fx_deal_leg'


      sql_query_target_qa = "SELECT  "
      include_cols.each_with_index{|val,i|
        sql_query_target_qa << include_cols[i]['COLUMN_NAME'].to_s
        sql_query_target_qa << "," if(i+1!=include_cols.length)
      }
      sql_query_target_qa << " FROM " +target_schema+"."+table_name
      sql_query_target_qa << ' order by ID,ECP_EXEC_ID,ECP_FLOOR_KEY,CP_SI_CCY ' if table_name.to_s.downcase=='fx_ticket_leg'
      sql_query_target_qa << ' order by ID ' if table_name.to_s.downcase=='sd_target'
      sql_query_target_qa << ' order by EXEC_ID,ASSET_COUNTER,INSTR_PRODUCT_TYPE,ECP_FLOOR_KEY,EFP_FLOOR_KEY ' if table_name.to_s.downcase=='fx_deal'
      sql_query_target_qa << ' order by EXEC_ID,EFP_INSTITUTION_KEY,FP_SIDE,LEG_TYPE ' if table_name.to_s.downcase=='fx_deal_leg'


      source_res_qa = self.getDbQueryResultsWithoutFailure4(source_schema,source_schema.to_s.downcase,sql_query_source_qa)
      target_res_qa = self.getDbQueryResultsWithoutFailure4(target_schema,target_schema.to_s.downcase,sql_query_target_qa)
      diff = nil
      log_file='Diff_'+table_name+'.txt'
      log_file_path=Dir.getwd+'/templates/db/'+@@time_stamp+'/'+log_file
      space = ''
      20.times{space+=' '}
      $diff_arr = []
      $diff_arr.push  (source_res_qa.length - target_res_qa.length).to_s + ' records Missing in New Schema'  if source_res_qa.length - target_res_qa.length > 0
      $diff_arr.push  (target_res_qa.length-source_res_qa.length).to_s   + ' records Added in New Schema'  if source_res_qa.length - target_res_qa.length > 0
      report_field = 'EXEC_ID' if(table_name.to_s.downcase=='fx_deal' || table_name.to_s.downcase=='fx_deal_leg')
      report_field = 'ID' if(table_name.to_s.downcase=='fx_ticket_leg' || table_name.to_s.downcase=='sd_target')
      last_row_index = -1

      old_schema =  @@email_properties['PTRADE1_APP_VERSION'] || 'Old Value - ptrade1'
      new_schema =  @@email_properties['PTRADE_APP_VERSION'] || 'New Value - ptrade'
      $header = pSpaces('|'+report_field+'|')+space+pSpaces('|Column|')+space+pSpaces('|'+old_schema+' - ptrade1 |')+space+pSpaces('|'+new_schema+' - ptrade |')
      source_res_qa.each_with_index { |row,index |
        diff_cols=[]
        diff_cols = (source_res_qa[index].to_a - target_res_qa[index].to_a) if (index<source_res_qa.length && index<target_res_qa.length)
        diff_cols.each { |column|
          $diff_arr.push( pSpaces(row[report_field].to_s) + space+ pSpaces(column[0].to_s) + space + pSpaces(column[1].to_s) + space + pSpaces(target_res_qa[index][column[0]].to_s))
        }


        last_row_index+=1
      }
      n=last_row_index+1
      (n..source_res_qa.length-1).each{|i|
        $diff_arr.push( source_res_qa[i][report_field].to_s + space + '  Missing in New Schema')
      }
      k=last_row_index+1
      (k..target_res_qa.length-1).each{|i|
        $diff_arr.push( target_res_qa[i][report_field].to_s + space + '  Added in New Schema')
      }

      $diff_arr.insert(0,$header) if !$diff_arr.empty?
      diff = $diff_arr
      writeDiffToFile(diff,log_file_path)


      if Dir.getwd.include?(@@CONFIG['JENKINS_JOB_NAME'])
        log_file_path =  @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME'].to_s+'/ws/templates/db/'+@@time_stamp+'/'+log_file
      end
      Actions.f "<a href='" + log_file_path.to_s+"'>Click to view columns diff [byCode]: "+log_file.to_s+"</a>" if(!diff.nil? && !diff.to_a.empty?)
    rescue Exception=>e
      Actions.f 'Exception (probably cant read from table or table not exist) in printDbColumnDiffToFile: ' +e.message
    end
  end


  def Actions.pSpaces(word,spaces_amount = 20 )
    str = word.dup
    space_length = spaces_amount-word.length
    space_length.times{str<<' '}

    return str
  end

  def Actions.compareDbTableResultsVsBkp(folder_timestamp)
      tables = @@CONFIG['ORACLE_TABLES_TO_COMPARE']
      source_schema = @@CONFIG['ORACLE_HOST_TEMPLATE_SCHEMA'] #['ORACLE_HOST_BKP_SCHEMA']
      target_schema = @@CONFIG['ORACLE_HOST_SCHEMA']
      results_dir =  folder_timestamp.nil? ? @@CONFIG['ORACLE_TABLES_COMPARE_RESULTS_DIR'] : @@CONFIG['ORACLE_TABLES_COMPARE_RESULTS_DIR']+'/'+folder_timestamp
      self.WINCMD_NO_FAIL('cd '+Dir.getwd+@@CONFIG['ORACLE_TABLES_COMPARE_RESULTS_DIR']+' & mkdir ' +  folder_timestamp, 10) #if(!folder_timestamp.nil?) #TODO && !@@db_timestamp_dir.nil?)
#
      $source_tables_count_query = "select table_name from dba_tables t where t.owner='"+source_schema+"'"
      $target_tables_count_query = "select table_name from dba_tables t where t.owner='"+target_schema+"'"

      $source_tables_count_query_res = self.getDbQueryResultsWithoutFailure($source_tables_count_query)
      $target_tables_count_query_res = self.getDbQueryResultsWithoutFailure($target_tables_count_query)
      if($source_tables_count_query_res.nil? || $source_tables_count_query_res.nil?)
        self.f(' Error ? - No Data Returned')
        return
      end

      if ($source_tables_count_query_res.length != $source_tables_count_query_res.length)
        self.f(' Error ? - ' + ($source_tables_count_query_res.length-$target_tables_count_query_res.length+1).to_s + ' Removed Tables - '+ ($source_tables_count_query_res-$target_tables_count_query_res).to_s)  if($source_tables_count_query_res.length > $target_tables_count_query_res.length)
        self.f(' Error ? - ' + ($target_tables_count_query_res.length-$source_tables_count_query_res.length+1).to_s + ' Added Tables - ' + ($target_cols-$source_tables_count_query_res).to_s) if( $target_tables_count_query_res.length>$source_tables_count_query_res.length)
      end
#


      tables.each_with_index { |table, index|
        $sql_query_source_diff=nil
        $sql_query_target_diff=nil
        $order_by=nil
        $order_by=tables[index].find { |key, value| key.to_s.match(/#{tables[index].keys[0]}/)}[1][0]['ORDER_BY']
        #puts 'order_by - ' +$order_by

        $source_cols_query = "SELECT column_name FROM  all_tab_columns WHERE  table_name = '" +tables[index].keys[0] +"'  AND owner = '"+source_schema+"'"
        $target_cols_query = "SELECT column_name FROM  all_tab_columns WHERE  table_name = '" +tables[index].keys[0] +"'  AND owner = '"+target_schema+"'"

        $source_cols = self.getDbQueryResultsWithoutFailure($source_cols_query)
        $target_cols = self.getDbQueryResultsWithoutFailure($target_cols_query)
        if($source_cols.nil? || $target_cols.nil?)
          self.f(' Error ? - No Data Returned')
          return
        end

        if ($source_cols.length == $target_cols.length)
          $sql_query_source_diff = 'SELECT * FROM (select * from ' +  source_schema + '.'+tables[index].keys[0] + ' '
          $sql_query_source_diff=$sql_query_source_diff+' '+$order_by if(!$order_by.nil? && !$order_by.empty?)
          $sql_query_source_diff<< ') minus '
          $sql_query_source_diff<<'SELECT * FROM (select * from ' +  target_schema + '.'+tables[index].keys[0] + ' '
          $sql_query_source_diff=$sql_query_source_diff+' '+$order_by if(!$order_by.nil? && !$order_by.empty?)
          $sql_query_source_diff<< ')'

          $sql_query_target_diff = 'SELECT * FROM (select * from ' +  target_schema + '.'+tables[index].keys[0] + ' '
          $sql_query_target_diff=$sql_query_target_diff+' '+$order_by if(!$order_by.nil? && !$order_by.empty?)
          $sql_query_target_diff<< ') minus '
          $sql_query_target_diff<<'SELECT * FROM (select * from ' +  source_schema + '.'+tables[index].keys[0] + ' '
          $sql_query_target_diff=$sql_query_target_diff+' '+$order_by if(!$order_by.nil? && !$order_by.empty?)
          $sql_query_target_diff<< ')'

        else # Diff in columns is Found

          self.f(' Error ? - ' + ($source_cols.length-$target_cols.length+1).to_s + ' Missing fields - '+ ($source_cols-$target_cols).to_s)  if($source_cols.length > $target_cols.length)
          self.f(' Error ? - ' + ($target_cols.length-$source_cols.length+1).to_s + ' New fields - ' + ($target_cols-$source_cols).to_s) if( $target_cols.length>$source_cols.length)
          $include_cols = $target_cols-($target_cols-$source_cols)-($source_cols-$target_cols)#$source_cols - $exclude_cols


          $sql_query_source_diff = "SELECT  "
          $include_cols.each_with_index{|val,i|
            $sql_query_source_diff << $include_cols[i]['COLUMN_NAME'].to_s
            $sql_query_source_diff << "," if(i+1!=$include_cols.length)
          }
          $sql_query_source_diff << " FROM " +source_schema+"."+tables[index].keys[0]
          #$sql_query_source_diff << ' order by 1 '
          $sql_query_source_diff << " MINUS "
          $sql_query_source_diff << "SELECT  "
          $include_cols.each_with_index{|val,i|
            $sql_query_source_diff << $include_cols[i]['COLUMN_NAME'].to_s
            $sql_query_source_diff << "," if(i+1!=$include_cols.length)
          }
          $sql_query_source_diff << " FROM " +target_schema+"."+tables[index].keys[0]
          #$sql_query_source_diff << ' order by 1 '



          $sql_query_target_diff = "SELECT  "
          $include_cols.each_with_index{|val,i|
            $sql_query_target_diff << $include_cols[i]['COLUMN_NAME'].to_s
            $sql_query_target_diff << "," if(i+1!=$include_cols.length)
          }
          $sql_query_target_diff << " FROM " +target_schema+"."+tables[index].keys[0]
          #$sql_query_target_diff << ' order by 1 '
          $sql_query_target_diff << " MINUS "
          $sql_query_target_diff << "SELECT  "
          $include_cols.each_with_index{|val,i|
            $sql_query_target_diff << $include_cols[i]['COLUMN_NAME'].to_s
            $sql_query_target_diff << "," if(i+1!=$include_cols.length)
          }
          $sql_query_target_diff << " FROM " +source_schema+"."+tables[index].keys[0]
          #$sql_query_target_diff << ' order by 1 '

        end

        source_res = self.getDbQueryResultsWithoutFailure($sql_query_source_diff)
        target_res = self.getDbQueryResultsWithoutFailure($sql_query_target_diff)


        if(source_res.nil? || target_res.nil?)
          self.f(' Error ? - No Data Returned')
          return
        end
        if(source_res.length!=target_res.length)
          $link_path = ''
          if Dir.getwd.include?(@@CONFIG['JENKINS_JOB_NAME']) # specific for a jenkins url and job in order to display links in Report
            f ' Error ? - Diff Found - ' + tables[index].keys[0] + ' ' + source_res.length.to_s  + ' Missing records in '+ target_schema  if(source_res.length>target_res.length)
            f ' Error ? - Diff Found - ' + tables[index].keys[0] + ' ' + target_res.length.to_s  + ' New records in '+ target_schema if(target_res.length>source_res.length)
            source_file=Dir.getwd+'/'+results_dir+'/source_'+source_schema+'_'+tables[index].keys[0]+'.csv'
            target_file=Dir.getwd+'/'+results_dir+'/target_'+target_schema+'_'+tables[index].keys[0]+'.csv'
            $link_path_source = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +source_file
            $link_path_target = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +target_file
            $link_path_source.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
            $link_path_target.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
            f "Storing SqlMinus Diff<a href='" + $link_path_source+"'>"+File.basename(source_file.to_s)+"</a> and <a href='"+$link_path_target+"'>" + target_file.to_s+"</a> in " +results_dir
          else
            f ' Error ? - Diff Found - ' + tables[index].keys[0] + ' ' + source_res.length.to_s  + ' Missing records in '+ target_schema if(source_res.length>target_res.length)
            f ' Error ? - Diff Found - ' + tables[index].keys[0] + ' ' + target_res.length.to_s  + ' New records in '+ target_schema if(target_res.length>source_res.length)
            source_file=Dir.getwd+results_dir+'/source_'+source_schema+'_'+tables[index].keys[0]+'.csv'
            target_file=Dir.getwd+results_dir+'/target_'+target_schema+'_'+tables[index].keys[0]+'.csv'
            f "Storing SqlMinus Diff <a href='" + source_file+"'>"+File.basename(source_file.to_s)+"</a> and <a href='"+target_file+"'>" + target_file.to_s+"</a> in " +results_dir
          end

        else
          c tables[index].keys[0]+' matched in ' + source_schema + ' and ' + target_schema + ' schemas '
        end

        begin
          source_csv_filename = 'source_'+source_schema+'_'+tables[index].keys[0]+'.csv' #Source file
          target_csv_filename = 'target_'+target_schema+'_'+tables[index].keys[0]+'.csv'
          $file_csv=File.open(Dir.getwd+results_dir+'/'+source_csv_filename, 'w') do |file_line| #'/templates/db/'
            source_res.each{|rs_line|
              file_line.puts(rs_line)
            }
          end

          $file_csv=File.open(Dir.getwd+'/'+results_dir+'/'+target_csv_filename, 'w') do |file_line| #Target file '/templates/db/'
            target_res.each{|rs_line|
              file_line.puts(rs_line)
            }
          end

        rescue Exception=>e
          @@scenario_fails.push(e.message)
          f 'Exception in Save File - ' + e.message
          fail('Exception in Save File - ' + e.message)
        ensure
          #$file_csv.close if !$file_csv.nil?
        end



      }



    end



    def Actions.compareDbTableResultsForUpgrade(source_schema, target_schema)
      tables = @@CONFIG['ORACLE_TABLES_TO_COMPARE']
      Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/db & mkdir '+@@time_stamp, 10)
      Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/db/'+@@time_stamp + ' & mkdir latestVsUpgrade', 10)
      results_dir =  @@CONFIG['ORACLE_TABLES_COMPARE_RESULTS_DIR']+'/'+@@time_stamp+'/latestVsUpgrade'

      Actions.checkTablesChanges(source_schema, target_schema)
      Actions.compareTablesStructure(source_schema, target_schema)

      tables.each_with_index { |table, index|
      Actions.compareTableStructure(source_schema, target_schema, tables[index].keys[0])
        $sql_query_source_diff=nil
        $sql_query_target_diff=nil
        $order_by=nil
        $order_by=tables[index].find { |key, value| key.to_s.match(/#{tables[index].keys[0]}/)}[1][0]['ORDER_BY']
        #puts 'order_by - ' +$order_by

        $source_cols_query = "SELECT column_name FROM  all_tab_columns WHERE  table_name = '" +tables[index].keys[0] +"'  AND owner = '"+source_schema+"'" #" order by 1"
        $target_cols_query = "SELECT column_name FROM  all_tab_columns WHERE  table_name = '" +tables[index].keys[0] +"'  AND owner = '"+target_schema+"'" #" order by 1"

        $source_cols = self.getDbQueryResultsWithoutFailure4(source_schema,source_schema.to_s.downcase,$source_cols_query)
        $target_cols = self.getDbQueryResultsWithoutFailure4(target_schema,target_schema.to_s.downcase,$target_cols_query)
        if($source_cols.nil? || $target_cols.nil?)
          #self.f(' Error ? - No Data Returned')
          @@scenario_fails.push('DB Error for '+tables[index].keys[0])
          fail(' DB Error '+tables[index].keys[0])
          return
        end

        if(!($source_cols-$target_cols).nil? && ($source_cols-$target_cols).length>0)
          $cols_list=''
          ($source_cols - $target_cols).each { |col_value|  $cols_list+=(col_value['COLUMN_NAME']+'<br>') }
          if(!$cols_list.to_s.empty?)
            self.f(' Error ? - in table '+ tables[index].keys[0] + ' Removed fields: <br>')
            $world.puts($cols_list)
          end
        end
        if( !($target_cols-$source_cols).nil? && ($target_cols-$source_cols).length>0)
          $cols_list=''
          ($target_cols-$source_cols).each { |col_value|  $cols_list+=(col_value['COLUMN_NAME']+'<br>') }
          if(!$cols_list.to_s.empty?)
            self.f(' Error ? - in table '+ tables[index].keys[0] + ' Added fields: <br>')
            $world.puts($cols_list)
          end
        end
        $include_cols = $target_cols-($target_cols-$source_cols)-($source_cols-$target_cols)#$source_cols - $exclude_cols


        $sql_query_source_diff = "SELECT  "
        $include_cols.each_with_index{|val,i|
          $sql_query_source_diff << $include_cols[i]['COLUMN_NAME'].to_s
          $sql_query_source_diff << "," if(i+1!=$include_cols.length)
        }
        $sql_query_source_diff << " FROM " +source_schema+"."+tables[index].keys[0]
        $sql_query_source_diff << ' order by 1 '
        $sql_query_source_diff << " MINUS "
        $sql_query_source_diff << "SELECT  "
        $include_cols.each_with_index{|val,i|
          $sql_query_source_diff << $include_cols[i]['COLUMN_NAME'].to_s
          $sql_query_source_diff << "," if(i+1!=$include_cols.length)
        }
        $sql_query_source_diff << " FROM " +target_schema+"."+tables[index].keys[0]
        $sql_query_source_diff << ' order by 1 '



        $sql_query_target_diff = "SELECT  "
        $include_cols.each_with_index{|val,i|
          $sql_query_target_diff << $include_cols[i]['COLUMN_NAME'].to_s
          $sql_query_target_diff << "," if(i+1!=$include_cols.length)
        }
        $sql_query_target_diff << " FROM " +target_schema+"."+tables[index].keys[0]
        $sql_query_target_diff << ' order by 1 '
        $sql_query_target_diff << " MINUS "
        $sql_query_target_diff << "SELECT  "
        $include_cols.each_with_index{|val,i|
          $sql_query_target_diff << $include_cols[i]['COLUMN_NAME'].to_s
          $sql_query_target_diff << "," if(i+1!=$include_cols.length)
        }
        $sql_query_target_diff << " FROM " +source_schema+"."+tables[index].keys[0]
        $sql_query_target_diff << ' order by 1 '



        source_res = self.getDbQueryResultsWithoutFailure4(source_schema,source_schema.to_s.downcase,$sql_query_source_diff)
        target_res = self.getDbQueryResultsWithoutFailure4(target_schema,target_schema.to_s.downcase,$sql_query_target_diff)


        if(source_res.nil? || target_res.nil?)
          if(source_res.nil?)
            self.f('  - No Data Returned for ' + source_res)
            fail(' Error ? - No Data Returned for ' + source_res)
          end
          if(target_res.nil?)
            self.f(' Error ? - No Data Returned for ' + target_res)
            fail(' Error ? - No Data Returned for ' + target_res)
          end
          return
        end

        if(source_res.length!=target_res.length)
          $link_path = ''
          if Dir.getwd.include?(@@CONFIG['JENKINS_JOB_NAME']) # specific for a jenkins url and job remove C:/Jenkins/jobs/CPT-Sanity/workspace/
            f ' Error ? - Diff Found - ' + tables[index].keys[0] + ' ' + source_res.length.to_s  + ' Changed records in '+ target_schema if(source_res.length>target_res.length)
            f ' Error ? - Diff Found - ' + tables[index].keys[0] + ' ' + target_res.length.to_s  + ' Changed records in '+ target_schema if(target_res.length>source_res.length)
            source_file=Dir.getwd+'/'+results_dir+'/source_'+source_schema+'_'+tables[index].keys[0]+'.csv'
            target_file=Dir.getwd+'/'+results_dir+'/target_'+target_schema+'_'+tables[index].keys[0]+'.csv'
            $link_path_source = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +source_file
            $link_path_target = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +target_file
            $link_path_source.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
            $link_path_target.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
            f "Storing SqlMinus Diff<a href='" + $link_path_source+"'>"+File.basename(source_file.to_s)+"</a> and <a href='"+$link_path_target+"'>" + target_file.to_s+"</a> in " +results_dir
          else
            f ' Error ? - Diff Found - ' + tables[index].keys[0] + ' ' + source_res.length.to_s  + ' Changed records in '+ target_schema if(source_res.length>target_res.length)
            f ' Error ? - Diff Found - ' + tables[index].keys[0] + ' ' + target_res.length.to_s  + ' Changed records in '+ target_schema if(target_res.length>source_res.length)
            source_file=Dir.getwd+results_dir+'/source_'+source_schema+'_'+tables[index].keys[0]+'.csv'
            target_file=Dir.getwd+results_dir+'/target_'+target_schema+'_'+tables[index].keys[0]+'.csv'
            f "Storing SqlMinus Diff <a href='" + source_file+"'>"+File.basename(source_file.to_s)+"</a> and <a href='"+target_file+"'>" + target_file.to_s+"</a> in " +results_dir
          end

        else
          c tables[index].keys[0]+' matched in ' + source_schema + ' and ' + target_schema + ' schemas '
        end

        begin
          source_csv_filename = 'source_'+source_schema+'_'+tables[index].keys[0]+'.csv' #Source file
          target_csv_filename = 'target_'+target_schema+'_'+tables[index].keys[0]+'.csv'

          File.write(Dir.getwd+results_dir+'/'+source_csv_filename, convertHashMapToCsv(source_res))
          File.write(Dir.getwd+results_dir+'/'+target_csv_filename, convertHashMapToCsv(target_res))

        rescue Exception=>e
          @@scenario_fails.push('Exception in Save File or Empty table '+tables[index]+ ' - ' + e.message)
          f 'Exception in Save File or Empty table '+tables[index]+ ' - ' + e.message
          fail('Exception in Save File or Empty table '+tables[index]+ ' - '  + e.message)
        ensure
          #$file_csv.close if !$file_csv.nil?
        end

      }

  end



  def Actions.compareSdataDbTableResults(folder_timestamp)
      source_schema = @@CONFIG['ORACLE_SDATA_HOST_TEMPLATE_SCHEMA']#sdata1
      target_schema = @@CONFIG['ORACLE_SDATA_HOST_SCHEMA']#sdata
      results_dir = folder_timestamp.nil? ? @@CONFIG['ORACLE_TABLES_COMPARE_RESULTS_DIR'] : @@CONFIG['ORACLE_TABLES_COMPARE_RESULTS_DIR']+'/'+folder_timestamp
      self.WINCMD_NO_FAIL('cd ' +Dir.getwd+@@CONFIG['ORACLE_TABLES_COMPARE_RESULTS_DIR']+' & mkdir ' +  folder_timestamp, 10) #if(!folder_timestamp.nil?)
      @@db_timestamp_dir=true

      s_schema = self.getDbQueryResultsWithoutFailure4(source_schema,source_schema.to_s.downcase,"select * from "+source_schema+".SCHEMA_VERSION")
      s_schema_version=s_schema[0]['VERSION_NAME'].to_s
      s_schema_created=s_schema[0]['CREATION_TIME'].to_s
      t_schema = self.getDbQueryResultsWithoutFailure4(target_schema,target_schema.to_s.downcase,"select * from "+target_schema+".SCHEMA_VERSION")
      t_schema_version=t_schema[0]['VERSION_NAME'].to_s
      t_schema_created=t_schema[0]['CREATION_TIME'].to_s
      self.c '<b>Comparing Schema Versions - Old '+s_schema_version+' '+s_schema_created+ ' vs New '+t_schema_version+' '+t_schema_created +'</b>'
      Actions.setBuildProperty('SDATA_SCHEMA_VERSION',t_schema_version.to_s)
      Actions.setBuildProperty('SDATA1_SCHEMA_VERSION',s_schema_version.to_s)

      #
      $source_tables_count_query = "select table_name from dba_tables t where t.owner='"+source_schema+"'"
      $target_tables_count_query = "select table_name from dba_tables t where t.owner='"+target_schema+"'"

      $source_tables_count_query_res = self.getDbQueryResultsWithoutFailure4(source_schema,source_schema.to_s.downcase,$source_tables_count_query)
      v '$source_tables_count_query_res - ' + $source_tables_count_query_res.to_s
      $target_tables_count_query_res = self.getDbQueryResultsWithoutFailure4(target_schema,target_schema.to_s.downcase,$target_tables_count_query)
      v '$target_tables_count_query_res - ' + $target_tables_count_query_res.to_s
      if($source_tables_count_query_res.nil? || $source_tables_count_query_res.nil?)
        self.f(' Error  - No Data Returned for '+source_schema+' or '+target_schema+' schema')
        fail(' Error  - No Data Returned for '+source_schema+' or '+target_schema+' schema')
        return
      end

      if ($source_tables_count_query_res.length != $source_tables_count_query_res.length)
        self.f(' Error ? - ' + ($source_tables_count_query_res.length-$target_tables_count_query_res.length+1).to_s + ' Removed Tables - '+ ($source_tables_count_query_res-$target_tables_count_query_res).to_s)  if($source_tables_count_query_res.length > $target_tables_count_query_res.length)
        self.f(' Error ? - ' + ($target_tables_count_query_res.length-$source_tables_count_query_res.length+1).to_s + ' Added Tables - ' + ($target_cols-$source_tables_count_query_res).to_s) if( $target_tables_count_query_res.length>$source_tables_count_query_res.length)
      end
      #

      $excluded_types = @@CONFIG['ORACLE_SDATA_EXCLUDED_TYPES'].to_s.gsub!('[','')
      $excluded_types = $excluded_types.to_s.gsub!(']','')
      $excluded_types = $excluded_types.to_s.gsub!("\"",'\'')
      c "Excluded types from compare - " + $excluded_types.to_s

      $excluded_tables = @@CONFIG['ORACLE_SDATA_EXCLUDED_TABLES'].to_s.gsub!('[','')
      $excluded_tables = $excluded_tables.to_s.gsub!(']','')
      $excluded_tables = $excluded_tables.to_s.gsub!("\"",'\'')
      c "Excluded tables from compare - " + $excluded_tables.to_s

      $excluded_tables_query=''
      $excluded_tables.scan(/\w+/).each{ |t| $excluded_tables_query+=(" and table_name not like '" + t.to_s + "%' ") }   if(!$excluded_tables.nil?)


      $source_tables_query = "SELECT table_name FROM dba_tables where owner = '"+source_schema+"' " + $excluded_tables_query
      $target_tables_query = "SELECT table_name FROM dba_tables where owner = '"+target_schema+"' " + $excluded_tables_query
      tables = self.getSdataDbQueryResultsWithoutFailure($source_tables_query)
      target_tables = self.getSdataDbQueryResultsWithoutFailure($target_tables_query)
      #v 'Source Tables - '+tables.to_s
      #v 'Target Tables - '+target_tables.to_s

      if(tables.nil? || target_tables.nil?)
        @@scenario_fails.push('No compatible tables found')
        fail('No matching for tables found')
      end



      source_tables_diff = target_tables & tables
      target_tables_diff = tables & target_tables
      $same_tables= source_tables_diff & target_tables_diff
      $same_tables.each_with_index { |table, index|
        $sql_query_source_diff=nil
        $sql_query_target_diff=nil

        $excluded_source_cols = nil
        $exclude_table_cols = nil
        $cols_excluded_source_query="SELECT * FROM  all_tab_columns WHERE  table_name = '" + $same_tables[index]['TABLE_NAME'] +
            "'  AND owner = '"+source_schema+"' AND data_type NOT IN ("+$excluded_types+")  order by COLUMN_NAME"

        $cols_excluded_target_query="SELECT * FROM  all_tab_columns WHERE  table_name = '" + $same_tables[index]['TABLE_NAME'] +
            "'  AND owner = '"+target_schema+"' AND data_type NOT IN ("+$excluded_types+") order by COLUMN_NAME"
        target_res=self.getSdataDbQueryResultsWithoutFailure($cols_excluded_target_query)
        sres=self.getSdataDbQueryResultsWithoutFailure($cols_excluded_source_query)
        #v 'Source after Excluding Columns for '+$same_tables[index]['TABLE_NAME']+' - '+sres.to_s
        #v 'Target after Excluding Columns for '+$same_tables[index]['TABLE_NAME']+' - '+target_res.to_s

        next if(sres.nil? || target_res.nil?)

        if (target_res.length!=sres.length)
          if(sres.length>target_res.length)
            #self.f('<br> Error ? Removed columns in ' + $dif_tables[index]['TABLE_NAME'].to_s)
            (sres-target_res).each_with_index{ |c,i|
              #self.f(c['COLUMN_NAME'].to_s)
              printDbColumnsDiffAsHtmlTable(sres-target_res,'<br>Removed/Missing columns in ' + $dif_tables[i]['TABLE_NAME'].to_s)
            }
          end
          if(target_res.length>sres.length)
            #self.f('<br> Error ? New/Added columns - in ' + $dif_tables[index]['TABLE_NAME'].to_s)
            (target_res-sres).each_with_index{ |c,i|
              #self.f(c['COLUMN_NAME'].to_s)
              printDbColumnsDiffAsHtmlTable(target_res-sres,'<br>New/Added columns in ' +  $same_tables[i]['TABLE_NAME'].to_s )
            }
          end

        end

        $all_cols_source_query="SELECT COLUMN_NAME FROM  all_tab_columns WHERE  table_name = '" + $same_tables[index]['TABLE_NAME'] +"'  AND owner = '"+source_schema+
            "' AND data_type NOT IN ("+$excluded_types+") " #+" order by 1"
        sres=self.getSdataDbQueryResultsWithoutFailure($all_cols_source_query)
        $all_cols_target_query="SELECT COLUMN_NAME FROM  all_tab_columns WHERE  table_name = '" + $same_tables[index]['TABLE_NAME'] +"'  AND owner = '"+target_schema+
            "' AND data_type NOT IN ("+$excluded_types+") " #+" order by 1"
        tres=self.getSdataDbQueryResultsWithoutFailure($all_cols_target_query)
        source_same_cols = sres & tres
        target_same_cols = tres & sres
        $same_cols = (source_same_cols & target_same_cols)
        $source_fields=[]
        $target_fields=[]
        $same_cols.each_with_index {|value,key|
          $source_fields.push(value['COLUMN_NAME'])
          $target_fields.push(value['COLUMN_NAME'])
        }
        cols = !$source_fields.empty? ? $source_fields.join(","):"*"
        $cols_source_query = "SELECT "+cols+" FROM "+source_schema+"."+ $same_tables[index]['TABLE_NAME']+
                             " minus "+
                             "SELECT "+cols+" FROM "+target_schema+"."+ $same_tables[index]['TABLE_NAME']
        source_res=self.getSdataDbQueryResultsWithoutFailure($cols_source_query)
        $cols_target_query = "SELECT "+cols+" FROM "+target_schema+"."+ $same_tables[index]['TABLE_NAME']+
                                 " minus "+
                                 "SELECT "+cols+" FROM "+source_schema+"."+ $same_tables[index]['TABLE_NAME']
        target_res=self.getSdataDbQueryResultsWithoutFailure($cols_target_query)


        if((!source_res.nil? && !target_res.nil?) && (source_res.length!=target_res.length))
          $link_path = ''
          $time_stamp=Time.now.to_i.to_s
          if Dir.getwd.include?(@@CONFIG['JENKINS_JOB_NAME']) # specific for a jenkins url and job remove C:/Jenkins/jobs/CPT-Sanity/workspace/
            #f ' Error ? - Diff Found in ' + tables[index].keys[0].to_s + ' ' + source_res.length.to_s + ' records in '+ source_schema+ ' vs ' + target_res.length.to_s + ' records in ' +target_schema
            f ' Error ? - Diff Found - ' + $same_tables[index].to_s + ' ' + source_res.length.to_s  + ' Removed records in '+ target_schema if(source_res.length>target_res.length)
            f ' Error ? - Diff Found - ' + $same_tables[index].to_s + ' ' + target_res.length.to_s  + ' Added records in '+ target_schema if(target_res.length>source_res.length)
            source_file=Dir.getwd+'/'+results_dir.to_s+'/source_'+source_schema+'_'+$same_tables[index]['TABLE_NAME'].to_s+'.csv'
            target_file=Dir.getwd+'/'+results_dir.to_s+'/target_'+target_schema+'_'+$same_tables[index]['TABLE_NAME'].to_s+'.csv'
            $link_path_source = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +source_file
            $link_path_target = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +target_file
            $link_path_source.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
            $link_path_target.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
            f "Storing SqlMinus Diff <a href='" + $link_path_source+"'>"+File.basename(source_file.to_s)+"</a> and <a href='"+$link_path_target+"'>" + target_file.to_s+"</a> in " +results_dir
          else
            #f 'Error ? - Diff Found in ' + tables[index].keys[0].to_s + ' ' + source_res.length.to_s + ' records in '+ source_schema+ ' vs ' + target_res.length.to_s + ' records in ' +target_schema
            f ' Error ? - Diff Found - ' + tables[index].to_s + ' ' + source_res.length.to_s  + ' Removed records in '+target_schema  if(source_res.length>target_res.length)
            f ' Error ? - Diff Found - ' + tables[index].to_s + ' ' + target_res.length.to_s  + ' Added records in '+ target_schema if(target_res.length>source_res.length)
            source_file=Dir.getwd+'/'+results_dir.to_s+'/source_'+source_schema+'_'+$same_tables[index]['TABLE_NAME'].to_s+'.csv'
            target_file=Dir.getwd+'/'+results_dir.to_s+'/target_'+target_schema+'_'+$same_tables[index]['TABLE_NAME'].to_s+'.csv'
            f "Storing SqlMinus Diff <a href='" + source_file+"'>"+File.basename(source_file.to_s)+"</a> and <a href='"+target_file+"'>" + target_file.to_s+"</a> in " +results_dir
          end

            begin
              source_csv_filename = 'source_'+source_schema.to_s+'_'+$same_tables[index]['TABLE_NAME']+'.csv' #Source file
              target_csv_filename = 'target_'+target_schema.to_s+'_'+$same_tables[index]['TABLE_NAME']+'.csv'
              $file_csv=File.open(Dir.getwd+results_dir+'/'+source_csv_filename, 'w') do |file_line| #'/templates/db/'
                source_res.each{|rs_line|
                  file_line.puts(rs_line)
                }
              end

              $file_csv=File.open(Dir.getwd+results_dir+'/'+target_csv_filename, 'w') do |file_line| #Target file #'/templates/db/'
                target_res.each{|rs_line|
                  file_line.puts(rs_line)
                }
              end
            rescue Exception=>e
              @@scenario_fails.push(e.message)
              f 'Exception in Save File - ' + e.message
              fail('Exception in Save File - ' + e.message)
            ensure
              #$file_csv.close if !$file_csv.nil?
            end
        else
          c $same_tables[index]['TABLE_NAME']+' matched in ' + source_schema + ' and ' + target_schema + ' schemas '
        end

      }

   end


   def Actions.compareViews(source_owner,source_pwd,target_owner,target_pwd)
      source_sql = "select view_name from dba_views where owner='"+source_owner+"'" + \
      ' minus ' + \
      "select view_name from dba_views where owner='"+target_owner+"'"

      target_sql = "select view_name from dba_views where owner='"+target_owner+"'" + \
      ' minus ' + \
      "select view_name from dba_views where owner='"+source_owner+"'"


      source_diff = self.getDbQueryResultsWithoutFailure4(source_owner,source_pwd.to_s.downcase,source_sql)
      Actions.c '<b>Checking removed views from '+target_owner +'</b>'
      struct_str=''
      if(!source_diff.nil? && source_diff.length>0)
        struct_str<< '<table color="red" style="border: 100px;">'
        struct_str<< '<tr>'
        struct_res.each { |v| struct_str<<'<td>'+v['TABLE_NAME'].to_s+'</td>' }
        struct_str<< '</tr>'
        struct_str<<'</table>'
        struct_str<<'<br>'
        struct_str<<'<br>'

        Actions.f 'Removed views are found for '+target_owner+'<br><font color="red">'+struct_str+'</font>'
      else
        Actions.c 'No removed views found for ' + target_owner
      end


      target_diff = self.getDbQueryResultsWithoutFailure4(target_owner,target_pwd.to_s.downcase,source_sql)
      Actions.c '<b>Checking added views for '+target_owner +'</b>'
      struct_str=''
      if(!target_diff.nil? && target_diff.length>0)
        struct_str<< '<table color="red" style="border: 100px;">'
        struct_str<< '<tr>'
        struct_res.each { |v| struct_str<<'<td>'+v['TABLE_NAME'].to_s+'</td>' }
        struct_str<< '</tr>'
        struct_str<<'</table>'
        struct_str<<'<br>'
        struct_str<<'<br>'

        Actions.f 'Added views are found for '+target_owner+'<br><font color="red">'+struct_str+'</font>'
      else
        Actions.c 'No added views found for ' + target_owner
      end

   end




  def Actions.convertHashMapToCsv(hashMap)
    hashes = hashMap
    column_names = hashes.first.keys
    csv_output=CSV.generate do |csv|
      csv << column_names
      hashes.each do |x|
        csv << x.values
      end
    end

    return csv_output.to_s if(!csv_output.nil? || !csv_output.to_s.empty?)
    return '' if(csv_output.nil? || csv_output.to_s.empty?)
  end




  def Actions.getDbQueryResultsWithoutFailure(query)
    host = @@CONFIG['ORACLE_HOST']
    port = @@CONFIG['ORACLE_HOST_PORT']
    service = @@CONFIG['ORACLE_HOST_SERVICE']
    usr = @@CONFIG['ORACLE_DB_USER']
    pwd = @@CONFIG['ORACLE_DB_PWD']

    v 'Connecting to ' + host.to_s+':'+port.to_s+'/'+service.to_s+' with ' +usr.to_s+'/'+pwd.to_s+'...'

    $query_results = nil
    begin
      dbh = DBI.connect('DBI:OCI8:'+host.to_s+':'+port.to_s+'/'+service.to_s,usr.to_s,pwd.to_s)
      sth = dbh.prepare(query)
      v 'Executing DB query: ' + query
      sth.execute()
      $row_count = 0
      $query_results =[]
          while row=sth.fetch_hash do
        $row_count+= 1
        # c row[0].to_s
        $query_results << row
      end

    rescue Exception => e
      f 'DB Exception ->'+e.message if (!e.nil?)
      @@scenario_fails.push('DB Exception ->'+e.message)
      #fail('DB Error  - ' + e.message) if (!e.nil?)
    ensure
      sth.finish if !dbh.nil?
      dbh.disconnect if dbh
    end

    return $query_results

  end




  def Actions.getDbQueryResultsWithoutFailure2(query)
    host = @@CONFIG['ORACLE_HOST_IP']
    port = @@CONFIG['ORACLE_HOST_PORT']
    service = @@CONFIG['ORACLE_HOST_SERVICE']
    usr = @@CONFIG['ORACLE_DB_USER']
    pwd = @@CONFIG['ORACLE_DB_PWD']

    v 'Connecting to ' + host.to_s+':'+port.to_s+'/'+service.to_s+' with ' +usr.to_s+'/'+pwd.to_s+'...'

    $query_results = nil
    begin
      dbh = DBI.connect('DBI:OCI8:'+host.to_s+':'+port.to_s+'/'+service.to_s,usr.to_s,pwd.to_s)
      sth = dbh.prepare(query)
      v 'Executing DB query: ' + query
      sth.execute()
      $row_count = 0
      $query_results =[]
      while row=sth.fetch_hash do
        $row_count+= 1
        # c row[0].to_s
        $query_results << row
      end

    rescue Exception => e
      f 'DB Exception ->'+e.message if (!e.nil?)
      @@scenario_fails.push('DB Exception ->'+e.message)
        #fail('DB Error  - ' + e.message) if (!e.nil?)
    ensure
      sth.finish if !dbh.nil?
      dbh.disconnect if dbh
    end

    return $query_results

  end


    def Actions.getDbQueryResultsWithoutFailure3(user, query)
      host = @@CONFIG['ORACLE_HOST']
      port = @@CONFIG['ORACLE_HOST_PORT']
      service = @@CONFIG['ORACLE_HOST_SERVICE']
      # usr = @@CONFIG['ORACLE_DB_USER']
      usr = user
      pwd = usr

      v 'Connecting to ' + host.to_s+':'+port.to_s+'/'+service.to_s+' with ' +usr.to_s+'/'+pwd.to_s+'...'

      $query_results = nil
      begin
        dbh = DBI.connect('DBI:OCI8:'+host.to_s+':'+port.to_s+'/'+service.to_s,usr.to_s,pwd.to_s)
        sth = dbh.prepare(query)
        v 'Executing DB query: ' + query
        sth.execute()
        $row_count = 0
        $query_results = []
        while row=sth.fetch_hash do
          $row_count+= 1
          # c row[0].to_s
          $query_results << row
        end

      rescue Exception => e
        f 'DB Exception ->'+e.message if (!e.nil?)
        @@scenario_fails.push('DB Exception ->'+e.message)
          #fail('DB Error  - ' + e.message) if (!e.nil?)
      ensure
        sth.finish if !dbh.nil?
        dbh.disconnect if dbh
      end

      return $query_results

    end



    def Actions.getDbQueryResultsWithoutFailure4(usr,pwd,query)
      host = @@CONFIG['ORACLE_HOST']
      port = @@CONFIG['ORACLE_HOST_PORT']
      service = @@CONFIG['ORACLE_HOST_SERVICE']

      v 'Connecting to ' + host.to_s+':'+port.to_s+'/'+service.to_s+' with ' +usr.to_s+'/'+pwd.to_s+'...'

      $query_results = nil
      begin
        dbh = DBI.connect('DBI:OCI8:'+host.to_s+':'+port.to_s+'/'+service.to_s,usr.to_s,pwd.to_s)
        sth = dbh.prepare(query)
        v 'Executing DB query: ' + query
        sth.execute()
        $row_count = 0
        $query_results =[]
        while row=sth.fetch_hash do
          $row_count+= 1
          # c row[0].to_s
          $query_results << row
        end

      rescue Exception => e
        f 'DB Exception ->'+e.message+' for user: ' + usr if (!e.nil?)
        @@scenario_fails.push('DB Exception ->'+e.message)
          #fail('DB Error  - ' + e.message) if (!e.nil?)
      ensure
        sth.finish if !dbh.nil?
        dbh.disconnect if dbh
      end

      return $query_results

    end





    def Actions.getSdataDbQueryResultsWithoutFailure(query)
      host = @@CONFIG['ORACLE_HOST']
      port = @@CONFIG['ORACLE_HOST_PORT']
      service = @@CONFIG['ORACLE_HOST_SERVICE']
      usr = @@CONFIG['ORACLE_SDATA_DB_USER']
      pwd = @@CONFIG['ORACLE_SDATA_DB_PWD']


      v 'Connecting to ' + host.to_s+':'+port.to_s+'/'+service.to_s+' with ' +usr.to_s+'/'+pwd.to_s+'...'

      $query_results = nil
      begin
        dbh = DBI.connect('DBI:OCI8:'+host.to_s+':'+port.to_s+'/'+service.to_s,usr.to_s,pwd.to_s)
        sth = dbh.prepare(query)
        v 'Executing DB query: ' + query
        sth.execute()
        $row_count = 0
        $query_results =[]
        while row=sth.fetch_hash do
          $row_count+= 1
          # c row[0].to_s
          $query_results << row
        end

      rescue Exception => e
        f 'DB Exception ->'+e.message if (!e.nil?)
        @@scenario_fails.push('DB Exception ->'+e.message)
          #fail('DB Error  - ' + e.message) if (!e.nil?)
      ensure
        sth.finish if !dbh.nil?
        dbh.disconnect if dbh
      end

      return $query_results

    end


  def Actions.insertToDbWithCommit(usr,pwd,query)
    @@CONFIG['ORACLE_HOST']=@@CONFIG['ORACLE_HOST_IP'] if !@@CONFIG['ORACLE_HOST_IP'].nil?
    host = @@CONFIG['ORACLE_HOST']
    port = @@CONFIG['ORACLE_HOST_PORT']
    service = @@CONFIG['ORACLE_HOST_SERVICE']

    v 'Connecting to ' + host.to_s+':'+port.to_s+'/'+service.to_s+' with ' +usr.to_s+'/'+pwd.to_s+'...'

    $query_results = nil
    begin
      dbh = DBI.connect('DBI:OCI8:'+host.to_s+':'+port.to_s+'/'+service.to_s,usr.to_s,pwd.to_s)
      v 'Executing DB query: ' + query
      dbh.do(query)
      dbh.commit

    rescue Exception => e
      f 'DB Exception ->'+e.message if (!e.nil?)
      @@scenario_fails.push('DB error ->'+e.message)
      fail('DB error  -> ' + e.message) if (!e.nil?)
    ensure
      #sth.finish if !dbh.nil?
      dbh.disconnect if dbh
    end

  end


  def Actions.getHashFromErFile(er_file_path)

    begin
      file =  File.read(er_file_path) #er_file_path 'libs/MSLErSender/data/Scenario0/er_test.txt'
      $condition1 = false
      $condition2 = false
      $condition3 = false
      $child_parent_key1 = ''
      $child_parent_key2 = ''
      $child_parent_key3 = ''
      $hash = Hash.new { |h, k| h[k] = Hash.new { |hh, kk| hh[kk] = {} } } #{}
      $index = 0
      file.gsub!(/{/, ":{")
      $arr = file.split(/\n/i)
      $arr.each { |row|
        if($arr[$index]=~/:[^{]/)
          parts = $arr[$index].split(/\:/)
          key = parts[0].sub!(/\s+/, "") || parts[0]
          value = parts[1].sub!(/\s+/, "") || parts[1]
          #value = value[1].gsub!(/\"+/, "") if value=~/\"/ #TODO in Step Validations



          $condition1 = true if (!$child_parent_key1.empty? && !value=~/{/ && !value=~/}/)
          $condition2 = true if (!$child_parent_key2.empty? && !value=~/{/ && !value=~/}/)
          $condition3 = true if (!$child_parent_key3.empty?  && !value=~/{/ && !value=~/}/)


          $hash[$child_parent_key1][$child_parent_key2][$child_parent_key3][key]  = value  if ($condition2 && $condition3)
          $hash[$child_parent_key1][$child_parent_key2][key] = value if ($condition2 && !$condition3)
          $hash[$child_parent_key1][key] = value  if ($condition1 && !$condition2)
          $hash[key] = value if (!$condition1 && !$condition2 && !$condition3)

        elsif ($arr[$index]=~/:{/)
          if (!$condition1)
            parts = $arr[$index].split(/:{/)
            $child_parent_key1 = parts[0].gsub!(/\s+/, "")
            $condition1 = true
          elsif ($condition1 && !$condition2)
            parts = $arr[$index].split(/:{/)
            $child_parent_key2 = parts[0].gsub!(/\s+/, "")
            $condition2 = true
          elsif ($condition1 && $condition2 && !$condition3)
            parts = $arr[$index].split(/:{/)
            $child_parent_key3 = parts[0].gsub!(/\s+/, "")
            $condition3 = true
          end

        elsif ($arr[$index]=~/}/)
          if ($condition1 && !$condition2 && !$condition3)
            $child_parent_key1 = ''
            $condition1 = false
          elsif ($condition1 && $condition2 && !$condition3)
            $child_parent_key2 = ''
            $condition2 = false
          elsif ($condition1 && $condition2 && $condition3)
            $child_parent_key3 = ''
            $condition3 = false
          end



        end
        $index+=1
      }

    rescue Exception => e
      @@scenario_fails.push(e.message)
      f e.message if (!e.nil?)
      fail('Unable to Parse/Serialize ER file ' + e.message)
    end

    return $hash

  end





  def Actions.uploadTemplates(host, user, pwd, local_dir, remote_dir)
        self.v 'Uploading Templates and Script folders and files from local ' + local_dir + ' into remote dir ' + remote_dir + ' on ' + host + ' for user '+user
        begin
          Net::SFTP.start(host, user,:password => pwd) do |sftp|
            #sleep 5
            sftp.upload!(local_dir, remote_dir)
            #sleep 5


          end
        rescue Exception=>e
          @@scenario_fails.push(e.message)
          f(e.message)
          fail(e.message)
        end
  end


    def Actions.uploadTemplates2(host, user, pwd, local_dir, remote_dir,timeout_sec)
     self.v 'Uploading Templates and Script folders and files from local ' + local_dir + ' into remote dir ' + remote_dir + ' on ' + host + ' for user '+user
     session_timeout = Integer(timeout_sec) rescue nil
     begin
        Net::SFTP.start(host, user,:password => pwd) do |sftp|
          if (session_timeout)
            timeout session_timeout do
              sftp.upload!(local_dir, remote_dir)
            end
          end
        end
      rescue Exception=>e
          @@scenario_fails.push(e.message)
          f(e.message)
          fail(e.message)
     end

     cmd = 'dos2unix '+remote_dir
     res = Actions.SSH(host, user, pwd, cmd, 15, true, '')
     end



  def Actions.rigthsForFile(host, user, pwd, path, file, rights_number)
    v 'Setting rights for '+host+':'+path+'/'+file
    cmd = 'dos2unix '+path+'/'+file+' && chmod '+rights_number+' '+path+'/'+file
    res = Actions.SSH(host, user, pwd, cmd, 15, true, '')

    cmd = 'ls -lA '+path+'/'+file
    res2 = Actions.SSH(host, user, pwd, cmd, 5, true, '')
    v 'Rights set: '+res2
  end


  def Actions.resetDownloadsLocalFolders()
          self.deleteFolderContents(Dir.getwd+@@CONFIG['MYT_CSV_LOCAL_TARGET_DIR_PATH'])
          self.deleteFolderContents(Dir.getwd+@@CONFIG['SAPPHIRE_JSON_LOCAL_TARGET_DIR_PATH'])
          self.deleteFolderContents(Dir.getwd+@@CONFIG['ORACLE_HOST_TABLES_FILES_DIR'])
  end



  def Actions.deleteFolderContents(folder_path)
        v 'Deleting Local Folder contents  -  ' + folder_path
        begin
          FileUtils.rm_rf(Dir.glob(folder_path+'/*'))
        rescue Exception => e
          @@scenario_fails.push(e.message)
          f e.message
          fail(e.message) if(!e.nil?)
        end
  end


  def Actions.downloadRemoteDir(host, user, pwd, remote_path, local_path, use_ssh = true)#TODO timeout
        v 'Downloading from remote '+host+':'+ remote_path  + ' into local ' + local_path
        begin
           Net::SFTP.start(host, user,:password => pwd) do |sftp|
           sftp.download!(remote_path,local_path,:recursive => true)
           end
        rescue Exception=>e
          @@scenario_fails.push(e.message && !e.message.to_s.downcase.include?('log'))
          f(e.message)  if(!e.nil? && !e.message.to_s.downcase.include?('log'))
          fail(e.message) if(!e.nil? && !e.message.to_s.downcase.include?('log'))
        end
  end


  def Actions.downloadRemoteFile(host, user, pwd, remote_path, local_path, use_ssh = true)#TODO timeout
        v 'Downloading from remote '+host+':' + remote_path   + ' into local ' + local_path
        begin
          Net::SFTP.start(host, user,:password => pwd) do |sftp|
            sftp.download!(remote_path,local_path)
          end
        rescue Exception=>e
          @@scenario_fails.push(e.message)
          f(e.message)
          fail(e.message) if(!e.nil?)
        end
  end


  def Actions.transferFileRemotely(scpScript, host, user, pwd, host2, user2, pwd2, initial_path, target_path, file)
    c 'Transferring file '+host+':'+initial_path+'/'+file+' to '+host2+':'+target_path+' ...'

    if (host == host2 && user == user2)
      if pwd != pwd2
        @@scenario_fails.push('Error in transferring file(s): given hosts and users are the same, but the passwords are different: '+pwd+' and '+pwd2)
        fail('Error in transferring file(s): given hosts and users are the same, but the passwords are different: '+pwd+' and '+pwd2)
      end
      cmd = 'cp -f '+initial_path+'/'+file+' '+target_path
      res = Actions.SSH(host, user, pwd, cmd, 30, true, '')
    else
      cmd = 'chmod -R 776 '+target_path
      res = Actions.SSH(host2, user2, pwd2, cmd, 10, true, '')

      cmd =  'cd '+initial_path+' && ./'+scpScript+' '+'host2:'+host2+' '+'user2:'+user2+' '+'pwd2:'+pwd2+' '+'initial_path:'+initial_path+' '+'target_path:'+target_path+' '+'file:'+file
      res = Actions.SSH(host, user, pwd, cmd, 120, true, 'Copied successfully')
      Actions.v res.to_s
    end

  end


  def Actions.getFolderChecksum(local_dir)
        files = Dir["#{local_dir}/**/*"].reject{|f| File.directory?(f)}
        content = files.map{|f| File.read(f)}.join
        #require 'md5'
        r = Digest::MD5.md5(content).to_s
        v 'Folder Checksum - ' + r
   end


    def Actions.removeOldOutput
        self.removeOldFiles(Dir.getwd+'/tmp')
        self.removeOldFiles(Dir.getwd+'/logs')
        self.removeOldFiles(Dir.getwd+'/templates/myt')
        self.removeOldFiles(Dir.getwd+'/templates/common')
        self.removeOldFiles(Dir.getwd+'/templates/old_app_csv')
        self.removeOldFiles(Dir.getwd+'/templates/new_app_csv')
        self.removeOldFiles(Dir.getwd+'/templates/old_app_json')
        self.removeOldFiles(Dir.getwd+'/templates/new_app_json')
        self.removeOldFiles(Dir.getwd+'/templates/old_app_rtns')
        self.removeOldFiles(Dir.getwd+'/templates/new_app_rtns')
        self.removeOldFiles(Dir.getwd+'/templates/old_app_csv_traiana')
        self.removeOldFiles(Dir.getwd+'/templates/new_app_csv_traiana')
        self.removeOldFiles(Dir.getwd+'/templates/db')
        self.removeOldFiles(Dir.getwd+'/reports')
    end


    def Actions.removeOldFiles(dir_path)
      arr_folders=Dir[dir_path+'/*']
      #'modified time - mtime', oldest first - 'directory change time' (creation time -ctime for Windows)
      files_sorted_by_time = arr_folders.sort_by{ |f| File.ctime(f) }
      begin
        if(files_sorted_by_time.length>30)
          files_sorted_by_time.each_with_index { |f,i|
            FileUtils.rm_rf(f) if(i<10)
          }
        end

      rescue Exception=>e
         v 'Unable to remove files'
      end
    end


    def Actions.downloadCoreLogs(host, user, pwd)
      self.v 'Downloading PTS logs for user "'+user+'"...'
      # cmd = "cd /export/home/" + user +"/Automation/PTS/logs && rm -rf ../PTSlogs_"+user+" && mkdir -p ../PTSlogs_"+user+" && \\cp -f *.log ../PTSlogs_"+user+" 2>/dev/null"
      cmd = 'cd '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/logs && rm -rf ../PTSlogs_'+user+' && mkdir -p ../PTSlogs_'+user+' && \\cp -f *.log ../PTSlogs_'+user+' 2>/dev/null' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
      cmd = 'cd '+CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/logs && rm -rf ../PTSlogs_'+user+' && mkdir -p ../PTSlogs_'+user+' && \\cp -f *.log ../PTSlogs_'+user+' 2>/dev/null' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
      self.SSH(host, user, pwd, cmd, 120, false, '')
      sleep 10
      # self.downloadRemoteDir(host, user, pwd,'/export/home/'+user+'/Automation/PTS/PTSlogs_'+user ,Dir.getwd+'/logs/logs_'+@@time_stamp+'/'+user)
      self.downloadRemoteDir(host, user, pwd,CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/PTSlogs_'+user ,Dir.getwd+'/logs/logs_'+@@time_stamp+'/'+user) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
      self.downloadRemoteDir(host, user, pwd,CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/PTSlogs_'+user ,Dir.getwd+'/logs/logs_'+@@time_stamp+'/'+user) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
    end


    def Actions.displayFilesForDownloadInFolder(folder_path)
      if(File.directory?(folder_path))
        Actions.c 'Displaying logs from folder '+folder_path
        Dir.foreach(folder_path) {|file_name|
          displayFileLinkInReport(folder_path+'/'+file_name) if(File.file?(folder_path+'/'+file_name) )
          Actions.displayFilesForDownloadInFolder(folder_path+'/'+file_name) if(!file_name.to_s.include?('.')  && File.directory?(folder_path+'/'+file_name) && Dir.entries(folder_path+'/'+file_name).size>2)
        }
      else
         displayFileLinkInReport(folder_path) if(File.file?(folder_path))
      end

    end



    def Actions.displayFileLinkInReport(file_path)
      begin
        $file = File.new(file_path)
      ensure
        $link_path = ''
        if file_path.include?(@@CONFIG['JENKINS_JOB_NAME'])
          $link_path = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +File.dirname(file_path)+ '/'+ File.basename(file_path)
          $link_path.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
        else
          $link_path = file_path
        end
        c "File  <a href='" + $link_path.to_s+"'>"+File.basename($link_path.to_s)+ ' -- click to view or download </a>' if !$file.nil?
        $file.close if !$file.nil?
      end

      return $file
    end



    def Actions.getHashMapFromCsvFile(file_path)
      begin
        file_csv = File.new(file_path)
        $csv_file_hash =[]
        csv = CSV.new(file_csv, :headers => true) #, :header_converters => :symbol, :converters => [:all, :blank_to_nil])
        csv.to_a.map {|row|
          csv_row_hash = row.to_hash
          $csv_file_hash.push(csv_row_hash)
        }
        #c 'csv_file_hash ' + $csv_file_hash.to_s
      rescue Exception => e
        @@scenario_fails.push(e.message)
        f e.message if (!e.nil?)
        fail('CSV file Error  - ' + e.message) if (!e.nil?)
      ensure
        $link_path = ''
        if defined?(@@CONFIG) && file_path.include?(@@CONFIG['JENKINS_JOB_NAME'])
           $link_path = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +File.dirname(file_path)+ '/'+ File.basename(file_path)
           $link_path.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
        else
           $link_path = file_path
        end
        #c "File  <a href='" + $link_path.to_s+"'>"+file_path.to_s+"</a>"  + ' being parsed' if !file_csv.nil? #TODO to remove on fail
        file_csv.close if !file_csv.nil?
      end

      return $csv_file_hash
  end


  def Actions.compareHashMapsFromCsvFiles(source, target, source_file_path, target_file_path)
      $excluded_keys =  @@CONFIG['MYT_CSV_EXCLUDED_COLUMNS'] #['TICKET_ID','DEAL_DATE']
      $csv_compare_errors = []

#disabled -> checked by caller
=begin
      if(File.basename(source_file_path)!=File.basename(target_file_path))
        errMsg = File.basename(source_file_path) + ' file is missing in target '
        $csv_compare_errors.push({'ErrorMsg'=>errMsg})
        @@scenario_fails.push({'ErrorMsg'=>errMsg})
        f('Error: Mismatch Found ' + File.basename(source_file_path) + ' file is missing in target ' )

        return $csv_compare_errors
      end
=end

      if source_file_path.include?(@@CONFIG['JENKINS_JOB_NAME']) # specific  for jenkins and job remove /C:/Jenkins/jobs/CPT-Sanity/workspace
        $link_path_source = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +File.dirname(source_file_path)+'/'+ File.basename(source_file_path)
        $link_path_target = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +File.dirname(target_file_path)+'/'+ File.basename(target_file_path)
        $link_path_source.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
        $link_path_target.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
      else
        $link_path_source = source_file_path
        $link_path_target = target_file_path
      end


        if (source.length != target.length)
        errMsg = ' Error ? - Expected "' + source.length.to_s + '" rows but Actual is "' +  target.length.to_s + '" in '+ target_file_path
        $csv_compare_errors.push(errMsg)
        @@scenario_fails.push(errMsg)

        ##f(' Error ? - Mismatch Found ')
        ##$csv_compare_errors.each { |entry|  f(entry.to_s)} if(!$csv_compare_errors.nil? && !$csv_compare_errors.empty?)
        ##f "Source File  <a href='" + $link_path_source.to_s+"'>"+File.basename(source_file_path.to_s)+" -- click to view or download</a>" if(File.file?(source_file_path))
        ##f "Target File  <a href='" + $link_path_target.to_s+"'>"+File.basename(target_file_path.to_s)+" -- click to view or download</a>" if(File.file?(target_file_path))
        errMsg = "Source File  <a href='" + $link_path_source.to_s+"'>"+File.basename(source_file_path.to_s)+" -- click to view or download</a>" if(File.file?(source_file_path))
        $csv_compare_errors.push(errMsg)
        @@scenario_fails.push(errMsg)
        errMsg =  "Target File  <a href='" + $link_path_target.to_s+"'>"+File.basename(target_file_path.to_s)+" -- click to view or download</a> <br>" if(File.file?(target_file_path))
        $csv_compare_errors.push(errMsg)
        @@scenario_fails.push(errMsg)

        return $csv_compare_errors
      end


    errMsg = ''
      source.length.times{ |row|
        if (source[row].size!=target[row].size)
          errMsg = '<br> Error ? - Expected amount columns in source ' + source[row].size.to_s + ' but Actual columns amount is ' +  target[row].size.to_s + ' in target'   if (source[row].size!=target[row].size)
        end

        if((source[row].keys-target[row].keys).length>0)
          errMsg<<'<br> Removed columns'
          cols=''
          (source[row].keys-target[row].keys).each{|k| cols<<('<br>     '+k)}
          errMsg<<cols+ ' in Source'

        end
        if((target[row].keys-source[row].keys).length>0)
            errMsg<<'<br> Added columns'
            cols=''
            (target[row].keys-source[row].keys).each{|k| cols<<('<br>     '+k)}
            errMsg<<cols+ ' in Target'

        end

        errMsg+='<br><br> View or Download files with Diff below' if(!errMsg.nil? && !errMsg.to_s.empty?)
        $csv_compare_errors.push(errMsg) if(!errMsg.nil? && !errMsg.to_s.empty?)
        @@scenario_fails.push(errMsg) if(!errMsg.nil? && !errMsg.to_s.empty?)
        if($csv_compare_errors.length>0)

          @@scenario_fails.push($csv_compare_errors.to_s)
          ##f(' Error ? - Mismatch Found')
          ##$csv_compare_errors.each { |entry|  f(entry.to_s)} if(!$csv_compare_errors.nil? && !$csv_compare_errors.empty?)
          ##f "Source File  <a href='" + $link_path_source.to_s+"'>"+File.basename(source_file_path.to_s)+" -- click to view or download</a>" if(File.file?(source_file_path))
          ##f "Target File  <a href='" + $link_path_target.to_s+"'>"+File.basename(target_file_path.to_s)+" -- click to view or download</a>" if(File.file?(target_file_path))
          errMsg = "Source File  <a href='" + $link_path_source.to_s+"'>"+File.basename(source_file_path.to_s)+" -- click to view or download</a>" if(File.file?(source_file_path))
          $csv_compare_errors.push(errMsg)
          @@scenario_fails.push(errMsg)
          errMsg = "Target File  <a href='" + $link_path_target.to_s+"'>"+File.basename(target_file_path.to_s)+" -- click to view or download</a> <br>" if(File.file?(target_file_path))
          $csv_compare_errors.push(errMsg)
          @@scenario_fails.push(errMsg)

        end

        return $csv_compare_errors if($csv_compare_errors.length>0)

      }


      source.length.times{ |row|
        source[row].size.times { |column|
           if(source[row].values[column].to_s != target[row].values[column].to_s &&  !$excluded_keys.include?(target[row].keys[column].to_s.upcase))
             errMsg = 'Line Num: '+(row+2).to_s+' Expected value ' + source[row].values[column].to_s + ' for ' + source[row].keys[column].to_s+' but Actual is "' +  target[row].values[column].to_s + '" in '+ target_file_path
             $csv_compare_errors.push(errMsg)
             @@scenario_fails.push(errMsg)
           end
        }
      }


      if (!$csv_compare_errors.nil? && !$csv_compare_errors.empty?)
        ##f('Error: Mismatch Found ')
        #f('Template file: ' + source.to_s)
        #f('Actual file: ' + target.to_s)
        ##f "Source File  <a href='" + $link_path_source.to_s+"'>"+File.basename(source_file_path.to_s)+" -- click to view or download</a>" if(File.file?(source_file_path))
        ##f "Target File  <a href='" + $link_path_target.to_s+"'>"+File.basename(target_file_path.to_s)+" -- click to view or download</a> <br>" if(File.file?(target_file_path))
        ##$csv_compare_errors.each { |entry|  f(entry.to_s)}
        errMsg = "Source File  <a href='" + $link_path_source.to_s+"'>"+File.basename(source_file_path.to_s)+" -- click to view or download</a>" if(File.file?(source_file_path))
        $csv_compare_errors.push(errMsg)
        @@scenario_fails.push(errMsg)
        errMsg = "Target File  <a href='" + $link_path_target.to_s+"'>"+File.basename(target_file_path.to_s)+" -- click to view or download</a> <br>" if(File.file?(target_file_path))
        $csv_compare_errors.push(errMsg)
        @@scenario_fails.push(errMsg)
      end

      return $csv_compare_errors
  end




    def Actions.compareHashMapsFromCsvFiles2(source, target, source_file_path, target_file_path,excluded_fields_arr)
      $excluded_keys =  excluded_fields_arr
      $csv_compare_errors = []
      errMsgArr=[]

      if defined?(@@CONFIG) && source_file_path.include?(@@CONFIG['JENKINS_JOB_NAME'])
        $link_path_source = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +File.dirname(source_file_path)+'/'+ File.basename(source_file_path)
        $link_path_target = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +File.dirname(target_file_path)+'/'+ File.basename(target_file_path)
        $link_path_source.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
        $link_path_target.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
      else
        $link_path_source = source_file_path
        $link_path_target = target_file_path
      end


      if (source.length != target.length)
        errMsg = ' Error ? - Expected ' + source.length.to_s + ' rows but Actual is ' +  target.length.to_s + ' in '+ target_file_path
        $csv_compare_errors.push(errMsg)
        $csv_compare_errors_arr.push(errMsg)
        @@scenario_fails.push(errMsg)
        errMsgArr.push(errMsg)


        ##f(' Error ? - Mismatch Found ')
        ##$csv_compare_errors.each { |entry|  f(entry.to_s)} if(!$csv_compare_errors.nil? && !$csv_compare_errors.empty?)
        ##f "Source File  <a href='" + $link_path_source.to_s+"'>"+File.basename(source_file_path.to_s)+" -- click to view or download</a>" if(File.file?(source_file_path))
        ##f "Target File  <a href='" + $link_path_target.to_s+"'>"+File.basename(target_file_path.to_s)+" -- click to view or download</a>" if(File.file?(target_file_path))
        errMsg = "Source File  <a href='" + $link_path_source.to_s+"'>"+File.basename(source_file_path.to_s)+" -- click to view or download</a>" if(File.file?(source_file_path))
        $csv_compare_errors.push(errMsg)
        $csv_compare_errors_arr.push(errMsg)
        @@scenario_fails.push(errMsg)
        errMsgArr.push(errMsg)
        errMsg = "Target File  <a href='" + $link_path_target.to_s+"'>"+File.basename(target_file_path.to_s)+" -- click to view or download</a> <br>" if(File.file?(target_file_path))
        $csv_compare_errors.push(errMsg)
        $csv_compare_errors_arr.push(errMsg)
        @@scenario_fails.push(errMsg)
        errMsgArr.push(errMsg)

        return errMsgArr
      end


      errMsg = ''
      source.length.times{ |row|
        if (source[row].size!=target[row].size)
          errMsg = '<br> Error ? - Expected amount columns in source ' + source[row].size.to_s + ' but Actual columns amount is ' +  target[row].size.to_s + ' in target '   if (source[row].size!=target[row].size)
        end

        if((source[row].keys-target[row].keys).length>0)
          errMsg<<'<br> Removed columns'
          cols=''
          (source[row].keys-target[row].keys).each{|k| cols<<('<br>     '+k)}
          errMsg<<cols+ ' in Source'

        end
        if((target[row].keys-source[row].keys).length>0)
          errMsg<<'<br> Added columns'
          cols=''
          (target[row].keys-source[row].keys).each{|k| cols<<('<br>     '+k)}
          errMsg<<cols+ ' in Target'

        end

        errMsg+='<br><br> Download files with Diff  <br>' if(!errMsg.nil? && !errMsg.to_s.empty?)
        if(!errMsg.nil? && !errMsg.to_s.empty?)
          $csv_compare_errors.push(errMsg)
          $csv_compare_errors_arr.push(errMsg)
        end

        if($csv_compare_errors.length>0)

          @@scenario_fails.push($csv_compare_errors.to_s)
          ##f(' Error ? - Mismatch Found')
          ##$csv_compare_errors.each_with_index { |entry,i|  (i==0 ? f(entry.to_s) : $world.puts(entry.to_s))} if(!$csv_compare_errors.nil? && !$csv_compare_errors.empty?)
          ##f "Source File  <a href='" + $link_path_source.to_s+"'>"+File.basename(source_file_path.to_s)+" -- click to view or download</a>" if(File.file?(source_file_path))
          ##f "Target File  <a href='" + $link_path_target.to_s+"'>"+File.basename(target_file_path.to_s)+" -- click to view or download</a>" if(File.file?(target_file_path))
          errMsg = "Source File  <a href='" + $link_path_source.to_s+"'>"+File.basename(source_file_path.to_s)+" -- click to view or download</a>" if(File.file?(source_file_path))
          $csv_compare_errors.push(errMsg)
          $csv_compare_errors_arr.push(errMsg)
          @@scenario_fails.push(errMsg)
          errMsg = "Target File  <a href='" + $link_path_target.to_s+"'>"+File.basename(target_file_path.to_s)+" -- click to view or download</a> <br>" if(File.file?(target_file_path))
          $csv_compare_errors.push(errMsg)
          $csv_compare_errors_arr.push(errMsg)
          @@scenario_fails.push(errMsg)

        end

        return $csv_compare_errors if($csv_compare_errors.length>0)

      }


      source.length.times{ |row|
        source[row].size.times { |column|
          if(source[row].values[column].to_s != target[row].values[column].to_s && (!$excluded_keys.nil? ? !$excluded_keys.include?(target[row].keys[column]).to_s.upcase : true))
            errMsg = 'Line Num: '+(row+2).to_s+' Expected value "' + source[row].values[column].to_s + '" for ' + source[row].keys[column].to_s+' but Actual is ' +  (!target[row].values[column].to_s.empty? ? target[row].values[column].to_s : '""') + ' in '+ target_file_path
            $csv_compare_errors.push(errMsg)
            $csv_compare_errors_arr.push(errMsg)
            @@scenario_fails.push(errMsg)
          end
        }
      }


      if (!$csv_compare_errors.nil? && !$csv_compare_errors.empty?)
        ##f('Error: Mismatch Found ')
        #f('Template file: ' + source.to_s)
        #f('Actual file: ' + target.to_s)

        ##f "Source File  <a href='" + $link_path_source.to_s+"'>"+File.basename(source_file_path.to_s)+" -- click to view or download</a>" if(File.file?(source_file_path))
        ##f "Target File  <a href='" + $link_path_target.to_s+"'>"+File.basename(target_file_path.to_s)+" -- click to view or download</a>" if(File.file?(target_file_path))
        ##$csv_compare_errors.each { |entry|  f(entry.to_s)}
      end

      return $csv_compare_errors
    end





  def Actions.compareCsvDirs(source_dir, target_dir)
       $csv_folders_count=0
       $csv_compare_errors=[]
       errMsg = nil
       begin


         if(source_dir.nil?)
           errMsg<<(" Empty Source Folder")
           $csv_compare_errors.push(errMsg)
           @@scenario_fails.push(errMsg)
           f(errMsg)
           return $csv_compare_errors
         end


         if(target_dir.nil?)
           errMsg<<(" Empty Target Folder")
           $csv_compare_errors.push(errMsg)
           @@scenario_fails.push(errMsg)
           f(errMsg)
           return $csv_compare_errors
         end



       if Dir.entries(source_dir).length != Dir.entries(target_dir).length
         #f(' Error: Mismatch Found ')# +' Expected ' + Dir.entries(source_dir).length.to_s + ' csv files/folders , Actual is ' + Dir.entries(target_dir).length.to_s )
         errMsg = '<br> Error  - Mismatch Found Expected amount of  "' + (Dir.entries(source_dir).length-2).to_s + '" of CSV files in Source dir but Actual is "' + (Dir.entries(target_dir).length-2).to_s+'" in Target dir ' + source_dir.to_s
         errMsg<<("<br>Missing Files or Folders in Source dir "+File.basename(source_dir).to_s+": "+(Dir.entries(source_dir)-Dir.entries(target_dir)).to_s) if Dir.entries(source_dir).length > Dir.entries(target_dir).length
         errMsg<<("<br>New Files or Folders in Target dir "+File.basename(target_dir).to_s+": "+(Dir.entries(target_dir)-Dir.entries(source_dir)).to_s) if Dir.entries(target_dir).length > Dir.entries(source_dir).length
         $csv_compare_errors.push(errMsg)
         @@scenario_fails.push(errMsg)
         f(errMsg)
         return $csv_compare_errors
       end


       excluded_keys =  @@CONFIG['MYT_CSV_EXCLUDED_COLUMNS']
       self.c('Comparing CSV files [Source vs Target] in Common and MyT folders excluding fields: ' + excluded_keys.to_s) if(!$printed)
       $printed=true

       local_files = Dir.entries(source_dir)
       target_files = Dir.entries(target_dir)
       local_files.length.times{ |filename|
         if  (!File.directory?(source_dir+'/'+local_files[filename]))
           s=local_files[filename].split('.')
           file_pattern=s[0]
           search_file = File.basename(Dir.glob("#{target_dir}/**/#{file_pattern}*.csv").to_s)
           search_file.gsub!("[]","")
           search_file.gsub!("\"]","")

           if(search_file.kind_of?(Array) && search_file.length>1)
             $csv_compare_errors.push(search_file + '*.csv duplicate files with '+file_pattern+' pattern are  Found in Target dir ' )
             @@scenario_fails.push(search_file + '*.csv duplicate files with '+file_pattern+' pattern are  Found in Target dir ' )
             f search_file + '*.csv duplicate files with '+file_pattern+' pattern are  Found in Target dir '
             return $csv_compare_errors
           end

           if(search_file.nil? || search_file.to_s.empty?)
              $csv_compare_errors.push(file_pattern + '*.csv is Not Found in Target dir ' )
              @@scenario_fails.push(file_pattern + '*.csv is Not Found in Target dir ' )
              f file_pattern + '*.csv is Not Found in Target dir '
              return $csv_compare_errors
           end

           source_hash = getHashMapFromCsvFile(source_dir + '/' + local_files[filename])
           target_hash = getHashMapFromCsvFile(target_dir + '/' + search_file) #target_files[filename]
           compareHashMapsFromCsvFiles(source_hash, target_hash, source_dir + '/' + local_files[filename], target_dir + '/' + search_file) #(source_hash, target_hash) #()target_hash, source_hash) odd rows for target are matched
           v local_files[filename] + ' vs ' + search_file + ' csv files being compared'
           $csv_files_count=0 if($csv_files_count.nil?)
           $csv_files_count+=1 if(!$csv_files_count.nil?)
         else
           compareCsvDirs(source_dir+'/'+local_files[filename], target_dir+'/'+local_files[filename]) if(local_files[filename]!='.' && local_files[filename]!='..')
           $csv_folders_count+=1
         end

         Actions.v $csv_files_count.to_s+' files have been compared so far, current dir is ' + source_dir  if(!$csv_files_count.nil?)
       }
       rescue Exception=>e
         #$csv_compare_errors.push(e.message)
         #@@scenario_fails.push(e.message)
         v 'Error in CSV compare - ' + e.message if(!e.message.nil?)
         f $csv_compare_errors.to_s if($csv_compare_errors.length>0)

       end


  end


  def Actions.compareCsvDirs2(source_dir,target_dir,excluded_fields_arr,file_type,file_version,nullifyErrors=true)
      Actions.v 'Actions.compareCsvDirs2 - #Started# ' + source_dir
      $csv_compare_errors=[]
      $csv_compare_errors_arr = [] if nullifyErrors

      errMsg = nil
      begin


        if(source_dir.nil?)
          errMsg<<(" Empty Source Folder")
          $csv_compare_errors.push(errMsg)
          @@scenario_fails.push(errMsg)
          $csv_compare_errors_arr.push(errMsg)
          ##f(errMsg)
          return $csv_compare_errors_arr #$csv_compare_errors
        end


        if(target_dir.nil?)
          errMsg<<(" Empty Target Folder")
          $csv_compare_errors.push(errMsg)
          @@scenario_fails.push(errMsg)
          $csv_compare_errors_arr.push(errMsg)
          ##f(errMsg)
          return $csv_compare_errors_arr #$csv_compare_errors
        end



        if Dir.entries(source_dir).select{|e| e !~/(^\.)/}.length != Dir.entries(target_dir).select{|e| e !~/(^\.)/}.length
          #f(' Error: Mismatch Found ')# +' Expected ' + Dir.entries(source_dir).length.to_s + ' csv files/folders , Actual is ' + Dir.entries(target_dir).length.to_s )
          errMsg = '<br><br> Error ? - Mismatch Found Expected amount of  "' + (Dir.entries(source_dir).length).to_s + '" of files in Source dir but Actual is "' + (Dir.entries(target_dir).length).to_s+'" in Target dir ' + source_dir.to_s
          errMsg<<("<br>Missing Files or Folders "+File.basename(source_dir).to_s+": "+(Dir.entries(source_dir)-Dir.entries(target_dir)).to_s) if Dir.entries(source_dir).length > Dir.entries(target_dir).length
          errMsg<<("<br>New Files or Folders "+File.basename(target_dir).to_s+": "+(Dir.entries(target_dir)-Dir.entries(source_dir)).to_s) if Dir.entries(target_dir).length > Dir.entries(source_dir).length
          $csv_compare_errors.push(errMsg)
          @@scenario_fails.push(errMsg)
          $csv_compare_errors_arr.push(errMsg)
          ##f(errMsg)

          return $csv_compare_errors_arr #$csv_compare_errors
        end


        excluded_keys =  excluded_fields_arr
        self.c('Comparing CSV files [Source vs Target] in '+source_dir+' folders excluding fields: ' + excluded_keys.to_s) if(!$printed)
        $printed=true

        local_files = Dir.entries(source_dir).select{|e| e !~/(^\.)/}  if (!File.file?(source_dir))
        #target_files = Dir.entries(target_dir).select{|e| e !~/(^\.)/}
        local_files.length.times{ |filename|
          if (File.file?(source_dir+'/'+local_files[filename]))
            s=local_files[filename].split('.')
            next if (!s[1].nil? && !s[1].to_s.empty? && s[1][0..s[1].length-1-1] != file_version)
            file_pattern=s[0]
            search_file = File.basename(Dir.glob("#{target_dir}/**/#{file_pattern}.#{file_version}*.#{file_type}").to_s)

            if(search_file.nil? || search_file.to_s.empty?)
              $csv_compare_errors.push(local_files[filename] + ' is Not Found in Target dir <br>' )
              @@scenario_fails.push(local_files[filename] + ' is Not Found in Target dir <br>' )
              ##f local_files[filename] + ' is Not Found in Target dir '
              $csv_compare_errors_arr.push(errMsg)

              return $csv_compare_errors_arr #$csv_compare_errors
            end

            if(search_file.kind_of?(Array) && search_file.length>1)
              $csv_compare_errors.push(search_file + ' duplicate files with '+file_pattern+' pattern are  Found in Target dir <br>' )
              @@scenario_fails.push(search_file + ' duplicate files with '+file_pattern+' pattern are  Found in Target dir <br>' )
              ##f search_file + ' duplicate files with '+file_pattern+' pattern are  Found in Target dir '
              $csv_compare_errors_arr.push(errMsg)

              return $csv_compare_errors_arr #$csv_compare_errors
            else
              search_file.gsub!("[]","")
              search_file.gsub!("\"]","")
            end

            source_hash = getHashMapFromCsvFile(source_dir + '/' + local_files[filename])
            target_hash = getHashMapFromCsvFile(target_dir + '/' + search_file)
            compareHashMapsFromCsvFiles2(source_hash, target_hash, source_dir + '/' + local_files[filename], target_dir + '/' + search_file,excluded_fields_arr)
            v local_files[filename] + ' vs ' + search_file + ' files being compared'
            $csv_files_count=0 if($csv_files_count.nil?)
            $csv_files_count+=1 if(!$csv_files_count.nil?)
          else
            compareCsvDirs2(source_dir+'/'+local_files[filename], target_dir+'/'+local_files[filename],excluded_fields_arr,file_type,file_version,false) if(local_files[filename]!='.' && local_files[filename]!='..')
            $csv_folders_count+=1
          end

          Actions.v $csv_files_count.to_s+' files have been compared so far, current dir is ' + source_dir  if(!$csv_files_count.nil?)
        }
      rescue Exception=>e
        v 'Error in CSV compare - ' + e.message if(!e.message.nil?)
        ##f $csv_compare_errors.to_s if($csv_compare_errors.length>0)
        $csv_compare_errors.push('<br> Error in CSV compare - ' + e.message) if(!e.message.nil?)

        $csv_compare_errors_arr.push(errMsg)
        return $csv_compare_errors_arr #$csv_compare_errors
      end

      Actions.v 'Actions.compareCsvDirs2 - #Finished#'
      return $csv_compare_errors_arr #$csv_compare_errors
    end





    def Actions.compareSaphireOutputJsons(source_file, target_file)
      Actions.v 'compareSaphireOutputJsons - #Started#'
       $json_compare_errors = []
       begin
        source_arr = getJsonArrayFromFile(source_file)
        target_arr = getJsonArrayFromFile(target_file)

        exclusion = @@CONFIG['SAPPHIRE_JSON_EXCLUDED_FIELDS'] #[] #"sequence"
        $link_path_source = ''
        $link_path_target = ''
        if source_file.include?(@@CONFIG['JENKINS_JOB_NAME']) # specific  for jenkins and job remove /C:/Jenkins/jobs/CPT-Sanity/workspace
          $link_path_source = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +File.dirname(source_file)+ '/'+ File.basename(source_file)
          $link_path_target = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +File.dirname(target_file)+ '/'+ File.basename(target_file)
          $link_path_source.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
          $link_path_target.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
        else
            $link_path_source = source_file
            $link_path_target = target_file
        end

        self.c("Comparing     <b>Source</b> file:<a href='" +$link_path_source.to_s+"'>"+File.basename(source_file.to_s)+"</a>     <b>Target</b> file: <a href='" + $link_path_target.to_s+"'>"+File.basename(target_file.to_s)+"</a>")
        self.c('Excluded fields in compare ' + exclusion.to_s)

        if (source_arr.length<=2  )
          #$json_compare_errors.push('Source json doesnt contains valid data rows')
          @@scenario_fails.push('Source json doesnt contains valid data rows')
          f ('Source json doesnt contains valid data rows - ptrade1')
        end

        if (target_arr.length<=2 )
          #$json_compare_errors.push('Target json doesnt contains valid data rows')
          @@scenario_fails.push('Target json doesnt contains valid data rows')
          f ('Target json doesnt contains valid data rows - ptrade')
        end

        if (source_arr.length!=target_arr.length )
          #$json_compare_errors.push('Source contains '+source_arr.length.to_s+' rows, Target contains ' +  target_arr.length .to_s + ' rows ')
          @@scenario_fails.push('Source contains '+source_arr.length.to_s+' rows, Target contains ' +  target_arr.length .to_s + ' rows ')
          f('Source contains '+source_arr.length.to_s+' rows - ptrade1, Target contains ' +  target_arr.length .to_s + ' rows - ptrade')
        end



        if ((source_arr[0]['data'].keys-target_arr[0]['data'].keys).length>0)
          cols=''
          (source_arr[0]['data'].keys-target_arr[0]['data'].keys).each{|k| cols<<'<br>     '+k}
          f ' Error ? - Removed Fields ' +cols if(!cols.to_s.empty?)
          @@scenario_fails.push(' Error ? - Removed Fields ' +cols) if(!cols.to_s.empty?)
        end



        if ((target_arr[0]['data'].keys-source_arr[0]['data'].keys).length>0)
          cols=''
          (target_arr[0]['data'].keys-source_arr[0]['data'].keys).each{|k| cols<<'<br>     '+k}
          f ' Error ? - Added Fields ' +cols if(!cols.to_s.empty?)
          @@scenario_fails.push(' Error ? - Added Fields ' +cols) if(!cols.to_s.empty?)
        end


=begin
        if (!$json_compare_errors.empty?)
          f 'Mismatch in structure is found - escaping compare'
          return nil
        end
=end

        if ($json_compare_errors.empty?)
          source_arr.each_index{ |row|
              source_h = getCountHashFields(source_arr[row])
              target_h = getCountHashFields(target_arr[row])
              $escape_diff = false
              if (source_h['count']!=target_h['count'])
                $json_compare_errors.push('Source '+row.to_s+' contains '+source_h['count'].to_s+' fields, Target contains  '+ target_h['count'].to_s + ' fields')
                $json_compare_errors.push('Source '+row.to_s+' Fields Removed -' + (source_h['fields']-target_h['fields']).to_s ) if !(source_h['fields']-target_h['fields']).empty?
                $json_compare_errors.push('Target '+row.to_s+' Fields Added -' + (target_h['fields']-source_h['fields']).to_s ) if !(target_h['fields']-source_h['fields']).empty?

                $escape_diff = true
              end

            diff = HashDiff.diff(source_arr[row],target_arr[row])
            if(!diff.nil? || !diff.to_s.empty?)
              #r = printHtmlTableForComparedJsons(diff,exclusion) #html
              r = printToFileDiffOfComparedJsons(diff,exclusion) #file
              if (!r.nil? && !r.to_s.empty?)
=begin
#html
                $json_compare_errors.push('ID: ' + source_arr[row]['data']['ID'].to_s+(row+1).to_s+' '+ r.to_s)
                @@scenario_fails.push('ID: ' +source_arr[row]['data']['ID'].to_s+(row+1).to_s+' ')
                @@scenario_fails.push(r.to_s)
=end

                #file
                file_row = pSpaces(source_arr[row]['data']['ID'].to_s,30)+ pSpaces(r[0].to_s,30)
                $json_compare_errors.push(pSpaces(file_row))
                @@scenario_fails.push(file_row)

              end

              log_file='Diff_Jsons.txt'
              log_file_path=Dir.getwd+'/templates/new_app_json/'+@@time_stamp+'/'+log_file
              writeDiffToFile($json_compare_errors,log_file_path)

            end



          }
        end


       if (!$json_compare_errors.nil? && !$json_compare_errors.empty?)
         f('Error ? - Mismatch Found  ')
         #$json_compare_errors.each { |entry|  $world.puts(entry.to_s)} #html
         return $json_compare_errors
       end


       rescue Exception=>e
          $json_compare_errors.push(e.message)
          @@scenario_fails.push(e.message)
          f $json_compare_errors.to_s
       end

      Actions.v 'compareSaphireOutputJsons - #Finished#'
       return $json_compare_errors

  end


    def Actions.printHtmlTableForComparedJsons(failed_hash,excluded_fields) #prints red html table, iterating through failed hash which includes arrays
      struct_str=''
      diff_found =  false
      if(!failed_hash.nil? && failed_hash.length>0)
        struct_str<< '<table color="red" style="border: 100px;">'
        struct_str<< '<tr>'
        struct_str<< '<td>Source</td><td>Target</td>'
        struct_str<< '</tr>'
        $next = false
        failed_hash.each { |v|
          excluded_fields.each { |excluded_field|
             if v.to_s.include?(excluded_field)
               $next = true
               break
             end
          }
          if $next
            $next = false
            next
          end
          case v[0]
            when '-'
              struct_str<< '<tr><td><b>'+v[1].to_s+'</b></td><td>Not Exist</td></tr>'
              diff_found = true
            when '+'
              struct_str<< '<tr><td>Not Exist</td><td><b>'+v[1].to_s+'</b></td></tr>'
              diff_found = true
            when '~'
              struct_str<< '<tr><td><b>'+v[1].to_s+'='+v[2].to_s+'</b></td><td>'+v[1].to_s+'='+v[3].to_s+'</td></tr>'
              diff_found = true
          end
        }

        struct_str<<'<br>'


        struct_str<<'</table>'

       
      end

      struct_str = nil if !diff_found
      return struct_str
    end


    def Actions.printToFileDiffOfComparedJsons(failed_hash,excluded_fields) #prints table to file, iterating through failed hash which includes arrays
      struct_str=[]
      diff_found =  false
      if(!failed_hash.nil? && failed_hash.length>0)
        $next = false
        failed_hash.each { |v|
          excluded_fields.each { |excluded_field|
            if v.to_s.include?(excluded_field)
              $next = true
              break
            end
          }
          if $next
            $next = false
            next
          end
          case v[0]
            when '-'
              struct_str.push(pSpaces(v[1].to_s,30)+pSpaces('Not Exist',30))
              diff_found = true
            when '+'
              struct_str.push(pSpaces('Not Exist',30)+pSpaces(v[1].to_s,30))
              diff_found = true
            when '~'
              struct_str.push(pSpaces(v[1].to_s+'='+v[2].to_s,30)+pSpaces(v[1].to_s+'='+v[3].to_s,30))
              diff_found = true
          end
        }


      end

      struct_str = nil if !diff_found
      return struct_str
    end


    def Actions.logToFileComparedJsons(failed_hash,excluded_fields) #logs to file, iterating through failed hash which includes arrays
      struct_str=[]
      diff_found =  false
      if(!failed_hash.nil? && failed_hash.length>0)
        $next = false
        failed_hash.each { |v|
          excluded_fields.each { |excluded_field|
            if v.to_s.include?(excluded_field)
              $next = true
              next
            end
          }
          if $next
            $next = false
            next
          end

          case v[0]
            when '-'
              fields = ''
              v[2].to_s.empty? && v[2].keys.nil? ? fields = '' : v[2].to_s
              v[2].keys.each{|k| fields<<k.to_s<<' , '} if !v[2].keys.nil?
              struct_str<< v[1].to_s+fields+'  |    Not Exist'
              diff_found = true
            when '+'
              fields = ''
              v[2].to_s.empty? && v[2].keys.nil? ? fields = '' : v[2].to_s
              v[2].keys.each{|k| fields<<k.to_s<<' , '} if !v[2].keys.nil?
              struct_str<< 'Not Exist    |    '+v[1].to_s + '    ' +  fields
              diff_found = true
            when '~'
              struct_str<< v[1].to_s+'='+v[2].to_s+'  |  '+v[1].to_s+'='+v[3].to_s
              diff_found = true
          end
        }


      end


      struct_str = nil if !diff_found
      return struct_str
    end



    def Actions.compareSaphireOutputJsonsForUpgrade(source_file, target_file)
      $json_compare_errors = []
      begin
        getJsonArrayFromFile(source_file)
      rescue Exception=>e
        @@scenario_fails.push(e.message)
      end

      begin
        source_arr = JSON.parse(File.read(source_file)) #source_file #getJsonArrayFromFile(source_file)
        target_arr = JSON.parse(File.read(target_file))

        exclusion = @@CONFIG['SAPPHIRE_JSON_EXCLUDED_FIELDS'] #[] #"sequence"
        $link_path_source = ''
        $link_path_target = ''
        if source_file.include?(@@CONFIG['JENKINS_JOB_NAME']) # specific  for jenkins and job remove /C:/Jenkins/jobs/CPT-Sanity/workspace
          $link_path_source = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +File.dirname(source_file)+ '/'+ File.basename(source_file)
          $link_path_target = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME']+'/ws/' +File.dirname(target_file)+ '/'+ File.basename(target_file)
          $link_path_source.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
          $link_path_target.gsub!('C:/Jenkins/jobs/'+@@CONFIG['JENKINS_JOB_NAME']+'/workspace/','')
        else
          $link_path_source = source_file
          $link_path_target = target_file
        end

        self.c("Comparing  Jsons   <b>Source</b> file:<a href='" +$link_path_source.to_s+"'>"+source_file.to_s+"</a>     <b>Target</b> file: <a href='" + $link_path_target.to_s+"'>"+target_file.to_s+"</a>")
        self.c('Excluded fields in compare ' + exclusion.to_s)

        if (source_arr.length<=2  )
          $json_compare_errors.push('Source json doesnt contains valid data rows')
          @@scenario_fails.push('Source json doesnt contains valid data rows')

        end

        if (target_arr.length<=2 )
          $json_compare_errors.push('Target json doesnt contains valid data rows')
          @@scenario_fails.push('Target json doesnt contains valid data rows')

        end

        if (source_arr.length!=target_arr.length )
          $json_compare_errors.push('Source contains '+source_arr.length.to_s+' rows, Target contains ' +  target_arr.length .to_s + ' rows ')
          @@scenario_fails.push('Source contains '+source_arr.length.to_s+' rows, Target contains ' +  target_arr.length .to_s + ' rows ')

        end

        if ((source_arr[0]['data'].keys-target_arr[0]['data'].keys).length>0)
        cols=''
        (source_arr[0]['data'].keys-target_arr[0]['data'].keys).each{|k| cols<<'<br>     '+k}
         f 'Removed Fields ' +cols if(!cols.to_s.empty?)
        end



        if ((target_arr[0]['data'].keys-source_arr[0]['data'].keys).length>0)
          cols=''
          (target_arr[0]['data'].keys-source_arr[0]['data'].keys).each{|k| cols<<'<br>     '+k}
          f 'Added Fields  ' +cols if(!cols.to_s.empty?)
        end



        if ($json_compare_errors.empty?)
          source_arr.each_index{ |row|
            source_h = getCountHashFields(source_arr[row])
            target_h = getCountHashFields(target_arr[row])
            $escape_diff = false
            if (source_h['count']!=target_h['count'])
              $json_compare_errors.push('Source Row '+row.to_s+' contains '+source_h['count'].to_s+' fields, Target contains  '+ target_h['count'].to_s + ' fields')
              $json_compare_errors.push('Target Row '+row.to_s+' Fields Diff -' + (source_h['fields']-target_h['fields']).to_s ) if !(source_h['fields']-target_h['fields']).empty?
              $json_compare_errors.push('Target Row '+row.to_s+' Fields Diff -' + (target_h['fields']-source_h['fields']).to_s ) if !(target_h['fields']-source_h['fields']).empty?

              $escape_diff = true
            end


            diff = HashDiff.diff(source_arr[row],target_arr[row])
            if(!diff.nil? || !diff.to_s.empty?)
=begin
              r = printHtmlTableForComparedJsons(diff,exclusion)
              if (!r.nil? && !r.to_s.empty?)
                $json_compare_errors.push('Ticket  '+(row+1).to_s+' - '+ r.to_s)
                @@scenario_fails.push('Ticket  '+(row+1).to_s+':')
                @@scenario_fails.push(r.to_s)
              end

=end

              r = logToFileComparedJsons(diff,exclusion)
              if (!r.nil? && !r.to_s.empty?)
                $json_compare_errors.push('Ticket  '+(row+1).to_s+' - '+ r.to_s)
                @@scenario_fails.push('Ticket  '+(row+1).to_s+':')
                @@scenario_fails.push(r.to_s)
              end


            end

          }
        end


        if (!$json_compare_errors.nil? && !$json_compare_errors.empty?)
          f('Error ? -  Mismatch Found ')
          $world.puts("Source file: <a href='" + $link_path_source.to_s+"'>"+File.basename(source_file.to_s)+"</a>")
          $world.puts("Target file:  <a href='" + $link_path_target.to_s+"'>"+File.basename(target_file.to_s)+"</a>")
          #$json_compare_errors.each { |entry|  $world.puts(entry.to_s)}

          log_file = 'diffJsons.txt'
          log_file_path = Dir.getwd+'/templates/old_app_json/'+@@time_stamp+'/'+log_file
          writeDiffToFile($json_compare_errors,log_file_path)


          if Dir.getwd.include?(@@CONFIG['JENKINS_JOB_NAME'])
            log_file_path =  @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME'].to_s+'/ws/templates/old_app_json/'+@@time_stamp+'/'+log_file
          end
          Actions.f "<a href='" + log_file_path.to_s+"'>Click to view columns diff: "+log_file.to_s+"</a>" if(!$json_compare_errors.nil? && !$json_compare_errors.empty?)

        end

      rescue Exception=>e
        $json_compare_errors.push(e.message)
        @@scenario_fails.push(e.message)
        f $json_compare_errors.to_s
      end

      return $json_compare_errors

    end



  def Actions.getJsonArrayFromFile(file_path)
        json_arr = []
        json_file = file_path   #File.expand_path('../../redis_output.txt', __FILE__)
        text = File.read(json_file)

        text.gsub!('\\\\\\','')
        text.gsub!('\\','')
        text.gsub!('/','')


        json_list = text.scan(/{\"(.*?)}}/)
          #puts 'JsonList - ' + json_list.to_s
          json_list.each { |row|
#For Log file
=begin
          json_obj = JSON.parse('{"'+row[0].to_s+'}}') if file_path.to_s.downcase.include?('redismonitor1.txt')
          json_obj = JSON.parse('{"'+row[0].to_s+'}}}') if file_path.to_s.downcase.include?('redismonitor.txt')
=end
          json_row  = row[0].gsub('=>',':')
          json_row = '{"'+row[0].to_s+'}}'
          json_obj = JSON.parse(json_row)
              #puts 'JsonObj - ' +json_obj.to_s
          json_arr.push(json_obj)

          json_format=json_arr.to_s
          json_format.gsub!('=>',':') if(json_format.include?('=>'))
          File.write(json_file, json_format)
        }

        return json_arr
  end

  def Actions.writeToHtml(htmlFileName,arrDiff,goodMsg='',badMsg='')
      file_name = htmlFileName
      log_file_path = Dir.getwd+'/reports/'+@@time_stamp+'/'+file_name
      Actions.f badMsg  if !badMsg.empty?
      Actions.p goodMsg if !goodMsg.empty?
      if !arrDiff.nil? && !arrDiff.empty?
        File.open(log_file_path,'w')
        writeDiffToFile(arrDiff,log_file_path)
        Actions.p "<a href='" + Actions.getFileUrl(log_file_path)+"'> Click to view Diff  </a>"
      end
  end

  def Actions.compareTsvTxtFiles(source_folder_path,target_folder_path,files_filter="txt")
    Actions.v "compare #{files_filter} files - #Started#"
    approved_version = 520
    if (@@old_ptrade_version_number.nil? || @@old_ptrade_version_number.to_s.empty? || @@old_ptrade_version_number.to_i < approved_version )
      Actions.f "Escaping tests of #{files_filter} - will run with version >= " + approved_version.to_s + ' actual version is '  + '"' + @@old_ptrade_version_number.to_s + '"'
    else
      arr_diff = []
      file_filter = "/**/*.#{files_filter}*"
      old_files = Dir.glob(source_folder_path+file_filter).sort
      new_files = Dir.glob(target_folder_path+file_filter).sort
      matched_files_count = 0
      $rtns_compare_errors = []
      $rtns_compare_errors2 = []

      if (old_files.nil? || old_files.to_a.empty?)
        errMsg = "No #{file_filter} tickets found for Old version  <br>"
        $rtns_compare_errors.push(errMsg)
        #@@scenario_fails.push(errMsg)
        arr_diff.push(errMsg)
        Proc.new{break}
      end
      if (new_files.nil? || new_files.to_a.empty?)
        errMsg = "No #{file_filter} tickets found for New version  <br>"
        $rtns_compare_errors.push(errMsg)
        #@@scenario_fails.push(errMsg)
        arr_diff.push(errMsg)
        Proc.new{break}
      end

      if(old_files.length != new_files.length)
        o_files = old_files.collect{|f| File.basename(f)}
        n_files = new_files.collect{|f| File.basename(f)}
        added_files = (n_files - o_files)
        missing_files = (o_files - n_files)
        errMsg = o_files.length.to_s + ' files found for Old version, ' + n_files.length.to_s + " files found for New version  - NOT matching files in folders with different amount of files <br>" #+"- escaping #{File.dirname(old_files[0]).to_s} folder compare <br>"
        errMsg << " Missing files #{missing_files.to_s} <br><br>" if missing_files.length > 0
        errMsg << " Added files #{added_files.to_s}   <br><br>" if added_files.length > 0
        $rtns_compare_errors.push(errMsg)
        #@@scenario_fails.push(errMsg)
        arr_diff.push(errMsg+"<br><br>")
        Proc.new{break}
      end


      old_files.each_with_index { |file,index |
        old_file_name = File.basename(file).scan(/\w+-\w+-\w+-\w+-\w+.#{files_filter}*/)
        new_file_name = File.basename(new_files[index]).scan(/\w+-\w+-\w+-\w+-\w+.#{files_filter}*/)

        if old_file_name.to_s != new_file_name.to_s
          errMsg =  old_file_name.to_s+' is not found for New version <br>'
          #Actions.f old_file_name.to_s+' is not found ' #for New version'
          $rtns_compare_errors.push(errMsg)
          #@@scenario_fails.push(errMsg)
          #arr_diff.push(errMsg)
          Actions.v "Different files #{old_file_name.to_s} vs #{new_file_name.to_s}"
          next
        end

        old_file = File.readlines(file)
        new_file = File.readlines(new_files[index])
        old_file_hash_arr = old_file.to_s.scan(/\\u0001([A-Za-z0-9_\-:\/. ]*) ([A-Za-z0-9_\-:\/. ]*)/)
        new_file_hash_arr = new_file.to_s.scan(/\\u0001([A-Za-z0-9_\-:\/. ]*) ([A-Za-z0-9_\-:\/. ]*)/)

        old_file_hash_arr2 = []
        old_file_hash_arr.each { |each|
          each = each.collect { |k, v| "#{k}#{v}" }.join('||')
          old_file_hash_arr2.push(each.to_s)
        }

        new_file_hash_arr2 = []
        new_file_hash_arr.each { |each|
          each = each.collect { |k, v| "#{k}#{v}" }.join('||')
          new_file_hash_arr2.push(each.to_s)
        }

=begin
        old_file_hash_arr2.sort!
        new_file_hash_arr2.sort!
=end

        keys_array = []
        keys_array2 = []
        keys_hash = {}

        old_file_hash_arr2.each_with_index { |keyvalue, index |
          if old_file_hash_arr2[index].to_s != new_file_hash_arr2[index].to_s
            keys_array.push(old_file_hash_arr2[index].to_s, new_file_hash_arr2[index].to_s)
            keys_array2.push(keys_array)
            keys_array = []
          end
        }

        if !keys_array2.empty?
          title_arr = ['<b>Expected (value)</b>', '<b>Found (value)</b>']
          keys_array2.insert(0, title_arr)
          keys_hash[File.basename(file.to_s)] = keys_array2

          #Console Report
          ###Actions.printFailedFilePathLink2(file)
          ###Actions.printHtmlTable2(keys_hash)

          #External Html Report
          arr_diff.push getFailedFilePathLink2(file)
          arr_diff.push getHtmlTable2(keys_hash)

          matched_files_count-=1
          errMsg = 'Difference is found in '+File.basename(file.to_s)
          @@scenario_fails.push(errMsg)
        end

        matched_files_count+=1
      }

      if matched_files_count != old_files.length && matched_files_count > 0
        file_name = files_filter+"_" + @@time_stamp+'_'+"TudorDiff.html" #files_filter+"_" + '_'+"FixDiff.html"#
        log_file_path = Dir.getwd+'/reports/'+@@time_stamp+'/'+file_name
        File.open(log_file_path,'w')
        writeDiffToFile(arr_diff,log_file_path)
        Actions.f '<b>' + (old_files.length-matched_files_count).to_s + ' files NOT matched successfully from Total ' + old_files.length.to_s + ' files </b>'
        Actions.p "<a href='" + Actions.getFileUrl(log_file_path)+"'>Click to view Diff  </a>"
      else
        Actions.p '<b>' + matched_files_count.to_s + ' files matched successfully from Total ' + old_files.length.to_s + ' files </b>' if matched_files_count > 0
      end
    end
    Actions.v "compare #{file_filter} files - #Finished#"
  end

  def Actions.compareKvTxtFiles(source_folder_path,target_folder_path,files_filter="txt")
    Actions.v "compare #{files_filter} files - #Started#"
    approved_version = 520
    if (@@old_ptrade_version_number.nil? || @@old_ptrade_version_number.to_s.empty? || @@old_ptrade_version_number.to_i < approved_version )
      Actions.f "Escaping tests of #{files_filter} - will run with version >= " + approved_version.to_s + ' actual version is '  + '"' + @@old_ptrade_version_number.to_s + '"'
    else
      arr_diff = []
      file_filter = "/**/*.#{files_filter}*"
      old_files = Dir.glob(source_folder_path+file_filter).sort
      new_files = Dir.glob(target_folder_path+file_filter).sort
      matched_files_count = 0
      $rtns_compare_errors = []
      $rtns_compare_errors2 = []

      if (old_files.nil? || old_files.to_a.empty?)
        errMsg = "<br> No #{file_filter} tickets found for Old version  <br>"
        $rtns_compare_errors.push(errMsg)
        #@@scenario_fails.push(errMsg)
        arr_diff.push(errMsg)
        Proc.new{break}
      end
      if (new_files.nil? || new_files.to_a.empty?)
        errMsg = "<br> No #{file_filter} tickets found for New version  <br>"
        $rtns_compare_errors.push(errMsg)
        #@@scenario_fails.push(errMsg)
        arr_diff.push(errMsg)
        Proc.new{break}
      end

      if(old_files.length != new_files.length)
        o_files = old_files.collect{|f| File.basename(f)}
        n_files = new_files.collect{|f| File.basename(f)}
        added_files = (n_files - o_files)
        missing_files = (o_files - n_files)
        errMsg = o_files.length.to_s + ' files found for Old version, ' + n_files.length.to_s + " files found for New version - NOT matching files in folders with different amount of files <br>" #+"- escaping #{File.dirname(old_files[0]).to_s} folder compare <br>"
        errMsg << " Missing files #{missing_files.to_s} <br><br>" if missing_files.length > 0
        errMsg << " Added files #{added_files.to_s}   <br><br>" if added_files.length > 0
        $rtns_compare_errors.push(errMsg)
        #@@scenario_fails.push(errMsg)
        arr_diff.push(errMsg+"<br><br>")
        Proc.new{break}
      end


      old_files.each_with_index { |file,index |
        old_file_name = File.basename(file).scan(/\w+-\w+-\w+-\w+-\w+.#{files_filter}*/)
        new_file_name = File.basename(new_files[index]).scan(/\w+-\w+-\w+-\w+-\w+.#{files_filter}*/)

        arr_diff.push("<br>")
        if old_file_name.to_s != new_file_name.to_s
          errMsg = old_file_name.to_s+' is not found  for New version <br>' #for New version'
          # Actions.f errMsg
          $rtns_compare_errors.push(errMsg)
          #@@scenario_fails.push(errMsg)
          #arr_diff.push(errMsg)
          Actions.v "Different files #{old_file_name.to_s} vs #{new_file_name.to_s}"
          next
        end

        old_file = File.readlines(file)
        new_file = File.readlines(new_files[index])
        old_file_hash_arr = old_file.to_s.scan(/\\u0001([A-Za-z0-9_\-:\/. ]*)=([A-Za-z0-9_\-:\/. ]*)/)
        new_file_hash_arr = new_file.to_s.scan(/\\u0001([A-Za-z0-9_\-:\/. ]*)=([A-Za-z0-9_\-:\/. ]*)/)

        old_file_hash_arr2 = []
        old_file_hash_arr.each { |each|
          each = each.collect { |k, v| "#{k}#{v}" }.join('||')
          old_file_hash_arr2.push(each.to_s)
        }

        new_file_hash_arr2 = []
        new_file_hash_arr.each { |each|
          each = each.collect { |k, v| "#{k}#{v}" }.join('||')
          new_file_hash_arr2.push(each.to_s)
        }

=begin
        old_file_hash_arr2.sort!
        new_file_hash_arr2.sort!
=end

        keys_array = []
        keys_array2 = []
        keys_hash = {}

        old_file_hash_arr2.each_with_index { |keyvalue, index |
          #if old_file_hash_arr2[index].to_s != new_file_hash_arr2[index].to_s #naive/sequential compare by sorting
          old_val = keyvalue.split("||")
          next if old_val[0].nil?
          exist = new_file_hash_arr2.index{|e| e =~ /^#{old_val[0]}\|\|#{old_val[1]}$/}
          if exist.nil?
            if new_file_hash_arr2.select{|e| e =~ /^#{old_val[0]}\|\|/}.length == 1
              new_val_index = new_file_hash_arr2.index{|e| e =~ /^#{old_val[0]}\|\|/}
            else
              new_val_index = index
            end
            new_val = (new_val_index.nil? ? "NOT_FOUND" : new_file_hash_arr2[new_val_index].to_s) #{"KEY_NOT_FOUND" : "VALUE_IS_DIFFERENT" )}#new_file_hash_arr2[new_val_index].to_s
            keys_array.push(old_file_hash_arr2[index].to_s, new_val)
            keys_array2.push(keys_array)
            keys_array = []
          end
        }

        if !keys_array2.empty?
          title_arr = ['<b>Expected (key||value)</b>', '<b>Found (key||value)</b>']
          keys_array2.insert(0, title_arr)
          keys_hash[File.basename(file.to_s)] = keys_array2

          keys_hash[keys_hash.keys[0]].each_with_index{|v,i|
            fix_label_source=getFixProtocolKeyLabel(v[0].split("||")[0],(v[0].split("||")[1].nil? || v[0].split("||")[1].empty?) ? "" : v[0].split("||")[1]) if (i>0 && !v[0].nil? && !v[1].empty? && !v[0].split("||")[0].nil? && !v[0].split("||")[0].empty?)
            v[0] = fix_label_source+" - "+v[0] if !v.nil? &&  !v[0].nil? && !fix_label_source.nil?
          }

          keys_hash[keys_hash.keys[0]].each_with_index{|v,i|
            fix_label_target=getFixProtocolKeyLabel(v[1].split("||")[0],(v[1].split("||")[1].nil? || v[0].split("||")[1].empty?) ? "" : v[1].split("||")[1]) if (i>0 && !v[1].nil? && !v[1].empty? && !v[1].split("||")[0].nil? && !v[1].split("||")[0].empty?)
            v[1] = fix_label_target+" - "+v[1] if !v.nil? &&  !v[1].nil? && !fix_label_target.nil?
          }



          #Console Report
          ###Actions.printFailedFilePathLink2(file)
          ###Actions.printHtmlTable2(keys_hash)

          #External Html Report
          arr_diff.push getFailedFilePathLink2(file)
          arr_diff.push getHtmlTable2(keys_hash)

          matched_files_count-=1
          errMsg = '<br> Difference is found in '+File.basename(file.to_s)
          @@scenario_fails.push(errMsg)

        end

        matched_files_count+=1
      }

      if matched_files_count != old_files.length && matched_files_count > 0
        file_name = files_filter+"_" + @@time_stamp+'_'+"FixDiff.html" #files_filter+"_" + '_'+"FixDiff.html"#
        log_file_path = Dir.getwd+'/reports/'+@@time_stamp+'/'+file_name
        File.open(log_file_path,'w')
        writeDiffToFile(arr_diff,log_file_path)
        Actions.f '<b>' + (old_files.length-matched_files_count).to_s + ' files NOT matched successfully from Total ' + old_files.length.to_s + ' files </b>'
        Actions.p "<a href='" + Actions.getFileUrl(log_file_path)+"'> Click to view Diff  </a>"
      else
        Actions.p '<b>' + matched_files_count.to_s + ' files matched successfully from Total ' + old_files.length.to_s + ' files </b>' if matched_files_count > 0
      end

    end
    Actions.v "compare #{file_filter} files - #Finished#"
  end

  def Actions.getFixProtocolKeyLabel(key,value)
    key_label=""
    case key
      when "35"
        key_label<<"["
        key_label<<"MsgType"
        (!@@FIX_MSG_TYPE[value].nil?) ? key_label<<"#{@@FIX_MSG_TYPE[value]}" : key_label<<"]"
      when "751"
        key_label<<"["
        key_label<<"TRADE_REPORT_REJECT_REASON"
        (!@@TRADE_REPORT_STATUS_REASON[value].nil?) ? key_label<<"#{@@TRADE_REPORT_STATUS_REASON[value]}" : key_label<<"]"
      else
        key_label  << @@FIX_PROTOCOL_TAGS[key] if !@@FIX_PROTOCOL_TAGS[key].nil? && !key.gsub(" ","").empty?
    end

    return key_label
  end

  def Actions.displayRtnsErrors
    $rtns_compare_errors.each { |entry|  Actions.f(entry.to_s)}
  end

  def Actions.displayRtnsErrors2
    $rtns_compare_errors.each { |entry|  Actions.f(entry.to_s)}
    $rtns_compare_errors = []
  end

  def Actions.printFailedFilePathLink(file_path)
    if file_path.include?(CONFIG.get['JENKINS_JOB_NAME'])
      $link_path = CONFIG.get['JENKINS_URL'].to_s+'/job/'+CONFIG.get['JENKINS_JOB_NAME']+'/ws/' +File.dirname(file_path)+'/'+ File.basename(file_path)
      $link_path.gsub!('C:/Jenkins/jobs/'+CONFIG.get['JENKINS_JOB_NAME']+'/workspace/','')
    else
      $link_path = file_path
    end
    target_link_path = $link_path.to_s.gsub('old_app','new_app')
    errMsg = "<a href='" + $link_path.to_s+"'>Click to view source </a> <-and-> <a href='" + target_link_path.to_s+"'>Click to view target</a>" #if(File.file?(file_path))
    #Actions.f  errMsg
    $rtns_compare_errors.push(errMsg)
    @@scenario_fails.push(errMsg)
  end

    def Actions.printFailedFilePathLink2(file_path)
      if file_path.include?(CONFIG.get['JENKINS_JOB_NAME'])
        $link_path = CONFIG.get['JENKINS_URL'].to_s+'/job/'+CONFIG.get['JENKINS_JOB_NAME']+'/ws/' +File.dirname(file_path)+'/'+ File.basename(file_path)
        $link_path.gsub!('C:/Jenkins/jobs/'+CONFIG.get['JENKINS_JOB_NAME']+'/workspace/','')
      else
        $link_path = file_path
      end
      target_link_path = $link_path.to_s.gsub('old_app','new_app')
      errMsg = 'Difference is found in '+File.basename(file_path.to_s)+': '+"<a href='" + $link_path.to_s+"'>Click to view source </a> <-and-> <a href='" + target_link_path.to_s+"'>Click to view target</a>" #if(File.file?(file_path))
      #Actions.f  errMsg
      $rtns_compare_errors2.push(errMsg)
      @@scenario_fails.push(errMsg)
    end



  def Actions.getFailedFilePathLink2(file_path)
    if file_path.include?(CONFIG.get['JENKINS_JOB_NAME'])
      $link_path = CONFIG.get['JENKINS_URL'].to_s+'/job/'+CONFIG.get['JENKINS_JOB_NAME']+'/ws/' +File.dirname(file_path)+'/'+ File.basename(file_path)
      $link_path.gsub!('C:/Jenkins/jobs/'+CONFIG.get['JENKINS_JOB_NAME']+'/workspace/','')
    else
      $link_path = file_path
    end
    target_link_path = $link_path.to_s.gsub('old_app','new_app')
    errMsg = "<br> Difference is found in "+File.basename(file_path.to_s) + '<br> <table style="table-layout: fixed; width: 70%"> <tr>' + "<td><a href='" + $link_path.to_s+"'>Click to view source </a></td>  <td><a href='" + target_link_path.to_s+"'>Click to view target</a></td> "+"</tr></table>" #if(File.file?(file_path))
    errMsg
  end


  def Actions.getFileUrl(file_path)
    if file_path.include?(CONFIG.get['JENKINS_JOB_NAME'])
      $link_path = CONFIG.get['JENKINS_URL'].to_s+'/job/'+CONFIG.get['JENKINS_JOB_NAME']+'/ws/' +File.dirname(file_path)+'/'+ File.basename(file_path)
      $link_path.gsub!('C:/Jenkins/jobs/'+CONFIG.get['JENKINS_JOB_NAME']+'/workspace/','')
    else
      $link_path = file_path
    end

    $link_path
  end


  def Actions.getCountHashFields(hash_obj)
      $fields_count = 0
      $fields_arr=[]
      $json_fields={}

      begin
        $json_fields = Actions.getHashKeysCount(hash_obj)
      rescue Exception=>e
        $json_compare_errors.push(e.message) if !e.message.include?("undefined method \`keys\'")
        @@scenario_fails.push(e.message) if !e.message.include?("undefined method \`keys\'")

       end

      return {'count'=>$json_fields[$fields_count], 'fields'=>$fields_arr.empty? ? '':$fields_arr}
  end



  def Actions.getHashKeysCount(hash_obj)

      begin
        $fields_count += hash_obj.keys().size
        hash_obj.keys.each { |key|
          $fields_arr.push(hash_obj[key])
          $fields_count += getHashKeysCount(hash_obj[key])['count']
        }
      rescue
        return 0
      end

      return {'count'=> $fields_count, 'fields'=>$fields_arr.empty? ? '':$fields_arr}
  end


  def Actions.v(msg) #print to jenkins console
      time = Time.new
      t_stamp = '['+time.day.to_s+'-'+time.month.to_s+'-'+time.year.to_s+'_'+time.hour.to_s+'-'+time.min.to_s+'-'+time.sec.to_s+'] '
      $world.puts t_stamp+msg if (!$world.nil? && CONFIG.get['VERBOSE']==true)
      puts t_stamp+msg
  end


  def Actions.c(msg) #logs to file
    time = Time.new
    t_stamp = '['+time.day.to_s+'-'+time.month.to_s+'-'+time.year.to_s+'_'+time.hour.to_s+'-'+time.min.to_s+'-'+time.sec.to_s+'] '
    #$world.puts t_stamp+msg if (!$world.nil?) #html
    Actions.appendToFile('<br>'+t_stamp+msg,@@automation_log_file_path)
    puts t_stamp+msg
  end


  def Actions.p(msg) #print to report
      time = Time.new
      t_stamp = '['+time.day.to_s+'-'+time.month.to_s+'-'+time.year.to_s+'_'+time.hour.to_s+'-'+time.min.to_s+'-'+time.sec.to_s+'] '
      $world.puts t_stamp+msg if (!$world.nil?)
      puts t_stamp+msg
  end


  def Actions.pp(msg) #print to report
    $world.puts msg if (!$world.nil?)
    puts msg
  end


  def Actions.f(msg) #print in html report with red font
    time = Time.new
    t_stamp = '['+time.day.to_s+'-'+time.month.to_s+'-'+time.year.to_s+'_'+time.hour.to_s+'-'+time.min.to_s+'-'+time.sec.to_s+'] '
    $world.puts "<font color='red'>" + t_stamp+msg + "</font>" if(!$world.nil?) #for HTML report ONLY
    puts t_stamp+msg
  end




  def Actions.printDbTableHash(rs)
      if rs.length>0
        header ='|'
        rs[0].keys.each { |column_name|
          header+= column_name.to_s+'                     |'
        }
        c header.to_s


        rs.each_with_index  {|row,i|
        values='|'
        key_len = 0
          row.each { |key,value|
            space_num = 0
            print_space =''
            key_len+=key.to_s.length
            space_num = key.to_s.length-value.to_s.length+30
            space_num.times{print_space+= ' '}
            values+=value.to_s + print_space+'|'

          }
          c values.to_s
        }
      end

  end


  def Actions.saveFailedQueryMinusToFile(rs, file_name)
        if rs.length>0
          header ='|'
          rs[0].keys.each { |column_name|
            header+= column_name.to_s+'                              |'
          }
          c header


          rs.each { |row|
            values='|'
            key_len = 0
            row.each { |key,value|
              space_num = 0
              print_space =''
              key_len+=key.to_s.length
              space_num = key.to_s.length-value.to_s.length+30
              space_num.times{print_space+= ' '}
              values+=value.to_s + print_space+'|'

            }
            c values
          }
        end

   end


  def Actions.setBuildProperty(property,value)
      stripped_value = nil
      if value.to_s.downcase.include?('sdata_')
        begin
          stripped_value = value.scan(/db_sdata_(.*).tgz/)[0][0].to_s
        rescue Exception=>e
          c 'Failed to get SDATA package name: check that the name is like "db_sdata_(.*).tgz"'
        end
      end
      if value.to_s.downcase.include?('pts_')
        begin
          stripped_value = value.scan(/PTS_MAIN_(.*).tar.gz/)[0][0].to_s
        rescue Exception=>e
          c 'Failed to get PTS package name: check that the name is like "PTS_MAIN_(.*).tar.gz"'
        end
      end
      if(!stripped_value.nil? && !stripped_value.to_s.empty?)
        @@email_properties[property]=stripped_value
        updateBuildProperty(property,stripped_value) if(!getBuildProperty(property).nil?)
        appendToFile(property+'='+stripped_value,@@automation_build_file_path) if(getBuildProperty(property).nil?)
      else
        @@email_properties[property]=value
        updateBuildProperty(property,value) if(!getBuildProperty(property).nil?)
        appendToFile(property+'='+value,@@automation_build_file_path) if(getBuildProperty(property).nil?)
      end
  end


  def Actions.updateBuildProperty(property,value)
    begin
      regex=property+'=([A-Za-z0-9_\-:\/. ]*)'
      v "@@automation_build_file_path: #{@@automation_build_file_path}, property '#{property.to_s}', value '#{value.to_s}'" if(!property.nil? && !value.nil?)
      File.write(f = @@automation_build_file_path, File.read(f).gsub(/#{regex}/,property+'='+value)) if(!property.nil? && !value.nil?)
    rescue Exception=>e
      v 'Failed to update build property: "'+property+'" with value: "'+value+'"' if(!property.nil? && !value.nil?)
    end
  end


  def Actions.getBuildProperty(property)
      properties = {}
      begin
        File.open(Dir.getwd+'/config/build.properties', 'r') do |properties_file|
          properties_file.read.each_line do |line|
            line.strip!
            if (line[0] != ?# and line[0] != ?=)
              i = line.index('=')
              if (i)
                properties[line[0..i - 1].strip] = line[i + 1..-1].strip
              else
                properties[line] = ''
              end
            end
          end
        end


      rescue Exception=>e
        self.f('ERROR on retrieve build properties '+e.message)
        return nil
      end
      #properties
      return (!properties[property].nil? ? properties[property].to_s : nil)
  end


  def Actions.isBuildPropertyFailed?(props)
      $failed = false
      begin
      if !props.kind_of?(Array)
        $failed=true if(getBuildProperty(props).to_s.downcase == 'failed')
      else
        props.each{|property|
          if(getBuildProperty(property).to_s.downcase == 'failed')
            $failed = true
            break
          end
        }
      end
      rescue Exception=>e
        self.f('ERROR on retrieve build properties '+e.message)
        return true
      end
        #properties status
        return $failed
  end



  def Actions.createLocalDirs #ToDo move to Before scenario
    #self.WINCMD_NO_FAIL('cd '+Dir.getwd+' && mkdir reports', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+' && mkdir tmp', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+' && mkdir logs', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/logs'+' && mkdir logs_'+@@time_stamp+'\\'+CONFIG.get['CORE_HOST_USER'].to_s.downcase, 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/logs'+' && mkdir logs_'+@@time_stamp+'\\'+CONFIG.get['CORE_HOST_USER1'].to_s.downcase, 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates'+' && mkdir db', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/db && mkdir '+@@time_stamp, 10)
    self.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir new_app_csv', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/new_app_csv && mkdir '+@@time_stamp, 10)
    self.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir old_app_csv', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_csv'+' && mkdir '+@@time_stamp, 10)
    self.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir new_app_json', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/new_app_json'+' && mkdir '+@@time_stamp, 10)
    self.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir old_app_json', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_json'+' && mkdir '+@@time_stamp, 10)
    self.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates/myt'+' && mkdir source', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/myt/source'+' && mkdir '+@@time_stamp, 10)
    self.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates/myt'+' && mkdir target', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/myt/target'+' && mkdir '+@@time_stamp, 10)
    self.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir new_app_rtns', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/new_app_rtns && mkdir '+@@time_stamp, 10)
    self.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir old_app_rtns', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_rtns'+' && mkdir '+@@time_stamp, 10)
    self.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir new_app_csv_traiana', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/new_app_csv && mkdir '+@@time_stamp, 10)
    self.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir old_app_csv_traiana', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_csv'+' && mkdir '+@@time_stamp, 10)
    self.WINCMD_NO_FAIL('cd '+ Dir.getwd+' && mkdir reports', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/reports'+' && mkdir '+@@time_stamp, 10)
  end


  def Actions.createLocalDirsTemplatesLogs
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+' && mkdir tmp', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+' && mkdir logs', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/logs'+' && mkdir logs_'+@@time_stamp, 10)
  end

  def Actions.createLocalDirsTemplatesLogsDb
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+' && mkdir tmp', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+' && mkdir logs', 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/logs'+' && mkdir logs_'+@@time_stamp, 10)
    self.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates'+' && mkdir db', 10)
  end


#### Logs

  def Actions.downloadDirFromRemote2(host, user, pwd, local_target_dir, remote_dir)
      begin
        Actions.downloadRemoteDir(host, user, pwd, remote_dir, local_target_dir)
      rescue Exception=>e
        Actions.v('No logs found on remote server ' + host + ' for user ' + user + ' in folder' + remote_dir + ' Error -'+e.message)
        @@scenario_fails.push(e.message)
      end
  end


  def Actions.displaySanityLogs(with_sdata, with_sdata1, with_ptrade, with_ptrade1)
    Actions.v 'Getting logs...'
    self.downloadBuildLogsOldSdataDb if(with_sdata1)
    self.downloadBuildLogsNewSdataDb if(with_sdata)
    if(with_ptrade1)
      self.downloadBuildLogsOldPtradeDb
      self.downloadAppLogsOldApp
    end
    if (with_ptrade)
      self.downloadBuildLogsNewPtradeDb
      self.downloadAppLogsNewApp
    end
    Actions.displayFilesForDownloadInFolder(Dir.getwd+'/logs/logs_'+@@time_stamp)
  end


  def Actions.downloadCustomBuildLogs(with_sdata,with_ptrade)
    downloadBuildLogsNewSdataDb if(with_sdata)
    Actions.downloadCoreLogs(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD']) if(with_ptrade)
  end


  def Actions.downloadBuildLogsOldSdataDb
    Actions.v 'Downloading DB install logs for SDATA schema old version'
    self.downloadDirFromRemote2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/logs_SDATA1')
  end


  def Actions.downloadBuildLogsOldPtradeDb
      Actions.v 'Downloading DB install logs for PTRADE schema old version'
      self.downloadDirFromRemote2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/logs_PT_DB1')
  end


   def Actions.downloadBuildLogsNewSdataDb
      Actions.v 'Downloading DB install logs for SDATA schema last version'
      self.downloadDirFromRemote2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/logs_SDATA')
   end


   def Actions.downloadBuildLogsNewPtradeDb
      Actions.v 'Downloading DB install logs for PTRADE schema last version'
      self.downloadDirFromRemote2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/logs_PT_DB')
   end


  def Actions.downloadAppLogsOldApp
    Actions.v 'Downloading App install logs for old version'
    self.downloadDirFromRemote2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/logs_PT_APP1')
  end


  def Actions.downloadAppLogsNewApp
    Actions.v 'Downloading App install logs for last version'
    self.downloadDirFromRemote2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/logs_PT_APP')
  end


  def Actions.downloadPTSLogs(oldApp, newApp)
    version = 'old app' if(oldApp)
    version = 'new app' if(newApp)
    Actions.v 'Downloading PTS run logs for '+version
    self.downloadDirFromRemote2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp+'/'+CONFIG.get['CORE_HOST_USER1'].to_s.downcase, CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/logs') if(oldApp)
    self.downloadDirFromRemote2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp+'/'+CONFIG.get['CORE_HOST_USER'].to_s.downcase, CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/logs') if(newApp)
  end


  def Actions.getEnvVar(host, user, pwd, env_var)
    res='NA'
    cmd = 'echo $'+env_var
    res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)
    res = res.to_s.strip

    return res
  end





  def Actions.displayTarVersion(user, isDb)
    res='NA'
    env_var = '$AUTOMATION_PACKAGE_NAME_'+user.to_s.strip.downcase if(isDb)
    env_var = '$AUTOMATION_PACKAGE_NAME_PT_APP' if(!isDb && user=='ptrade')
    env_var = '$AUTOMATION_PACKAGE_NAME_PT_APP1' if(!isDb && user=='ptrade1')
    cmd = 'echo '+env_var
    res = Actions.SSH_NO_FAIL(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 10) if(isDb)
    res = Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], cmd, 10) if(!isDb)
    res = res.to_s.strip

    return res
  end

  def Actions.displayTarVersion2(user, isDb)
    res='NA'
    env_var = '$AUTOMATION_PACKAGE_NAME_'+user.to_s.strip.downcase if(isDb)
    env_var = '$AUTOMATION_PACKAGE_NAME_PT_APP' if(!isDb && user=='ptrade')
    env_var = '$AUTOMATION_PACKAGE_NAME_PT_APP1' if(!isDb && user=='ptrade1')
    cmd = 'echo '+env_var
    res = Actions.SSH_NO_FAIL(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 10) if(isDb)
    res = Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST_IP'], user, CONFIG.get['CORE_HOST_PWD'], cmd, 10) if(!isDb)
    res = res.to_s.strip

    return res
  end

  def Actions.displayDownloadedTarVersion(user,isDb,host,usr,pwd)
    res='NA'
    env_var = 'AUTOMATION_DOWNLOADED_PACKAGE_'+user.to_s.strip.downcase if(isDb)
    env_var = 'AUTOMATION_DOWNLOADED_PACKAGE_PT_APP' if(!isDb && user=='ptrade')
    env_var = 'AUTOMATION_DOWNLOADED_PACKAGE_PT_APP1' if(!isDb && user=='ptrade1')
    cmd = 'echo $'+env_var
    res = Actions.SSH_NO_FAIL(host, usr, pwd, cmd, 5)
    res = res.to_s.strip

    return res
  end


  def Actions.compareTablesStructure(old_schema,new_schema)
    struct_sql="
    with col_data as (
      select
        owner,
        table_name,
        column_name,
        data_type||
        case
            when data_type in ('CLOB','BLOB','DATE','TIMESTAMP') then null
            when data_type ='NUMBER' then '('||nvl(data_precision,38)||','||nvl(data_scale,0)||')'
            else '('||data_length||')'
        end as data_type_definition,
        nullable
      from all_tab_columns
    )
    select new_tbl.table_name,
           new_tbl.column_name,
           new_tbl.data_type_definition   as new_data_type,
           old_tbl.data_type_definition   as old_data_type,
           new_tbl.nullable               as new_nullable,
           old_tbl.nullable               as old_nullable
    from col_data old_tbl,
         col_data new_tbl
    where new_tbl.owner=upper('"+old_schema+"')
      and old_tbl.owner= upper('"+new_schema+"')
      and new_tbl.table_name=old_tbl.table_name
      and new_tbl.column_name=old_tbl.column_name
      and (new_tbl.data_type_definition<>old_tbl.data_type_definition or new_tbl.nullable<>old_tbl.nullable)
    order by 1,2"

    struct_sql.gsub!(/[\n]+/, ' ' )
    struct_res=Actions.getDbQueryResultsWithoutFailure4(old_schema,old_schema.to_s.downcase,struct_sql)
    Actions.c '<b>Comparing DB Columns structure between Old - ' + old_schema + ' Schema and New - '+new_schema + ' Schema </b>'
    struct_str=''
    if(!struct_res.nil? && struct_res.length>0)
      struct_str<< '<table color="red" style="border: 100px;">'
      struct_str<< '<tr>'
      #struct_str<< struct_res[0].keys.to_s
      struct_res[0].keys.each { |v| struct_str<< '<td>'+v+'</td>' }
      struct_str<< '</tr>'
      #struct_str<<'<br>'
      struct_str<<'<br>'
      struct_res.each{|v|
        struct_str<< '<tr>'
        #struct_str<<v.values.to_s
        v.values.each{|v| struct_str<< '<td>'+v+'</td>'}
        struct_str<< '</tr>'

      }
      struct_str<<'</table>'
      #Actions.f 'Diff in DB Columns structure is found<font color="red">'+struct_str+'</font>'  #html report
      Actions.f '<font color="red">Diff in DB Columns structure is found</font>'
      Actions.printHtmlTableToFile(struct_res,'DiffDbTablesStructure.html') #report to file and display its link
    else
      Actions.c 'No Diff found for Columns in DB between ' + old_schema + ' Schema and '+new_schema + ' Schema '
    end
  end


  def Actions.compareTableStructure(old_schema,new_schema,table_name)
    struct_sql="
    with col_data as (
      select
        owner,
        table_name,
        column_name,
        data_type||
        case
            when data_type in ('CLOB','BLOB','DATE','TIMESTAMP') then null
            when data_type ='NUMBER' then '('||nvl(data_precision,38)||','||nvl(data_scale,0)||')'
            else '('||data_length||')'
        end as data_type_definition,
        nullable
      from all_tab_columns
    )
    select new_tbl.table_name,
           new_tbl.column_name,
           new_tbl.data_type_definition   as new_data_type,
           old_tbl.data_type_definition   as old_data_type,
           new_tbl.nullable               as new_nullable,
           old_tbl.nullable               as old_nullable
    from col_data old_tbl,
         col_data new_tbl
    where new_tbl.owner=upper('"+old_schema+"')
      and old_tbl.owner= upper('"+new_schema+"')
      and new_tbl.table_name= upper('"+table_name+"')
      and new_tbl.table_name=old_tbl.table_name
      and new_tbl.column_name=old_tbl.column_name
      and (new_tbl.data_type_definition<>old_tbl.data_type_definition or new_tbl.nullable<>old_tbl.nullable)
    order by 1,2"

    struct_sql.gsub!(/[\n]+/, ' ' )
    struct_res=Actions.getDbQueryResultsWithoutFailure4(old_schema,old_schema.to_s.downcase,struct_sql)
    Actions.c '<b>Comparing DB Columns structure between OLD ' + old_schema + ' Schema and New '+new_schema + ' Schema for table ' + table_name+'</b>'
    struct_str=''
    if(!struct_res.nil? && struct_res.length>0)
      struct_str<< '<table color="red" style="border: 100px;">'
      struct_str<< '<tr>'
      #struct_str<< struct_res[0].keys.to_s
      struct_res[0].keys.each { |v| struct_str<< '<td>'+v+'</td>' }
      struct_str<< '</tr>'
      struct_str<<'<br>'
      struct_str<<'<br>'
      struct_res.each{|v|
        struct_str<< '<tr>'
        #struct_str<<v.values.to_s
        v.values.each{|v| struct_str<< '<td>'+v+'</td>'}
        struct_str<< '</tr>'

      }
      struct_str<<'</table>'
      #Actions.f 'Diff in DB Columns structure is found<br><font color="red">'+struct_str+'</font>' #html report
      Actions.f '<br><font color="red">Diff in DB Columns structure is found</font>'
      Actions.printHtmlTableToFile(struct_res,'DiffDbTableStructure.html') #report to file and display its link

    else
      Actions.c 'No Diff found in DB Columns structure for for table ' + table_name
    end


  end


  def Actions.checkAddedTablesInDb(old_schema, new_schema)
  struct_sql="select table_name from dba_tables where owner='"+new_schema+"'
       minus
       select table_name from dba_tables where owner='"+old_schema+"'"

  struct_sql.gsub!(/[\n]+/, ' ' )
  struct_res=Actions.getDbQueryResultsWithoutFailure4(old_schema,old_schema.to_s.downcase,struct_sql)
  Actions.c '<b>Checking new tables for ' + old_schema + ' Schema and New '+new_schema +'</b>'
  struct_str=''
    if(!struct_res.nil? && struct_res.length>0)
      struct_str<< '<table color="red" style="border: 100px;">'
      struct_res.each { |v| struct_str<<'<tr><td>'+v['TABLE_NAME'].to_s+'</td></tr>' }
      struct_str<<'</table>'
      struct_str<<'<br>'
      struct_str<<'<br>'
      Actions.f 'New tables are found on '+new_schema+'<br><font color="red">'+struct_str+'</font>'
    else
      Actions.c 'No new tables found for ' + new_schema
    end
  end


  def Actions.checkAddedViewsInDb(old_schema, new_schema)
    struct_sql="select view_name from dba_views where owner='"+new_schema+"'
       minus
       select view_name from dba_views where owner='"+old_schema+"'"

    struct_sql.gsub!(/[\n]+/, ' ' )
    struct_res=Actions.getDbQueryResultsWithoutFailure4(old_schema,old_schema.to_s.downcase,struct_sql)
    Actions.c '<b>Checking new views for ' + old_schema + ' Schema and New '+new_schema +'</b>'
    struct_str=''
    if(!struct_res.nil? && struct_res.length>0)
      struct_str<< '<table color="red" style="border: 100px;">'
      struct_res.each { |v| struct_str<<'<tr><td>'+v['VIEW_NAME'].to_s+'</td></tr>' }
      struct_str<<'</table>'
      struct_str<<'<br>'
      struct_str<<'<br>'
      Actions.f 'New views are found on '+new_schema+'<br><font color="red">'+struct_str+'</font>'
    else
      Actions.c 'No new views found for ' + new_schema
    end
  end


  def Actions.checkRemovedTablesInDb(old_schema, new_schema)
    struct_sql="select table_name from dba_tables where owner='"+old_schema+"'
       minus
       select table_name from dba_tables where owner='"+new_schema+"'"

    struct_sql.gsub!(/[\n]+/, ' ' )
    struct_res=Actions.getDbQueryResultsWithoutFailure4(old_schema,old_schema.to_s.downcase,struct_sql)
    Actions.c '<b>Checking removed tables on ' + old_schema + ' Schema and New '+new_schema +'</b>'
    struct_str=''
    if(!struct_res.nil? && struct_res.length>0)
      struct_str<< '<table color="red" style="border: 100px;">'
      struct_str<< '<tr>'
      struct_res.each { |v| struct_str<<'<td>'+v['TABLE_NAME'].to_s+'</td>' }
      struct_str<< '</tr>'
      struct_str<<'</table>'
      struct_str<<'<br>'
      struct_str<<'<br>'

      Actions.f 'Removed tables are found for '+new_schema+'<br><font color="red">'+struct_str+'</font>'
    else
      Actions.c 'No removed tables found for ' + new_schema
    end
  end


  def Actions.checkRemovedViewsInDb(old_schema, new_schema)
    struct_sql="select view_name from dba_views where owner='"+old_schema+"'
       minus
       select view_name from dba_views where owner='"+new_schema+"'"

    struct_sql.gsub!(/[\n]+/, ' ' )
    struct_res=Actions.getDbQueryResultsWithoutFailure4(old_schema,old_schema.to_s.downcase,struct_sql)
    Actions.c '<b>Checking removed views on ' + old_schema + ' Schema and New '+new_schema +'</b>'
    struct_str=''
    if(!struct_res.nil? && struct_res.length>0)
      struct_str<< '<table color="red" style="border: 100px;">'
      struct_str<< '<tr>'
      struct_res.each { |v| struct_str<<'<td>'+v['VIEW_NAME'].to_s+'</td>' }
      struct_str<< '</tr>'
      struct_str<<'</table>'
      struct_str<<'<br>'
      struct_str<<'<br>'

      Actions.f 'Removed views are found for '+new_schema+'<br><font color="red">'+struct_str+'</font>'
    else
      Actions.c 'No removed views found for ' + new_schema
    end
  end


  def Actions.checkTablesChanges(old_schema, new_schema)
    Actions.checkAddedTablesInDb(old_schema, new_schema)
    Actions.checkRemovedTablesInDb(old_schema, new_schema)
  end


  def Actions.checkViewsChanges(old_schema, new_schema)
    Actions.checkAddedTablesInDb(old_schema, new_schema)
    Actions.checkRemovedTablesInDb(old_schema, new_schema)
  end


  def Actions.insertZerosForRecovery(user)
    if (user != 'ptrade' && user != 'ptrade1')
      @@scenario_fails.push('Error: only users ptrade and ptrade1 are allowed for insertZerosForRecovery, given user is '+user)
      fail('Error: only users ptrade and ptrade1 are allowed for insertZerosForRecovery, given user is '+user)
    end

    struct_sql='
    INSERT into AUDIT_IN
      (SOURCE_ID, ID, MSG_SESSION, MSG_ID, MSG_TYPE,
      MSG_TIME, HDR_VERSION, UP_VERSION, MSG_ORIGIN, CONTENT_SIZE,
      CAPTURE_TIME, STATUS_CODE)
    VALUES
      (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)'

    struct_sql.gsub!(/[\n]+/, ' ' )
    struct_res=Actions.getDbQueryResultsWithoutFailure3(user, struct_sql)
    Actions.c 'Inserting zeros into AUDIT_IN for '+user

    struct_sql='SELECT * FROM AUDIT_IN'
    struct_res=Actions.getDbQueryResultsWithoutFailure3(user, struct_sql)
    struct_str=''
    if(!struct_res.nil? && struct_res.length>0)
      struct_res.each { |row| struct_str<<row.to_s+"<br>" }
      Actions.v "result of SELECT * FROM AUDIT_IN: "+struct_str
    else
      Actions.c 'SELECT * FROM AUDIT_IN: no result found'
    end
  end


  def Actions.compareViewsStructure(old_schema,new_schema)
    struct_sql="
        select new_schema.view_name,
        new_schema.TEXT_LENGTH new_length,
        old_schema.TEXT_LENGTH old_length,
        ora_hash(new_schema.TEXT_LENGTH || substr(new_schema.TEXT_VC, 10, 3990)) new_hash,
        ora_hash(old_schema.TEXT_LENGTH || substr(old_schema.TEXT_VC, 10, 3990)) old_hash,
               new_schema.TEXT_VC   new_text,
               old_schema.TEXT_VC   old_text
          from dba_views old_schema, dba_views new_schema
         where 1 = 1
           and new_schema.owner = '"+new_schema+"'
           and old_schema.owner = '"+old_schema+"'
           and old_schema.view_name = new_schema.view_name
           and ora_hash(old_schema.TEXT_LENGTH || substr(old_schema.TEXT_VC, 10, 3990)) <>
               ora_hash(new_schema.TEXT_LENGTH || substr(new_schema.TEXT_VC, 10, 3990))
     "

    struct_sql.gsub!(/[\n]+/, ' ' )
    struct_res=Actions.getDbQueryResultsWithoutFailure4(new_schema,new_schema.to_s.downcase,struct_sql)
    Actions.c '<b>Comparing DB Views structure between Old - ' + old_schema + ' Schema and New - '+new_schema + ' Schema </b>'
    if(!struct_res.nil? && struct_res.length>0)
      #Actions.printHtmlTable(struct_res,'Diff in DB Views structure is found') #html report
      Actions.f '<br><font color="red">Diff in Views Structure is found</font>'
      Actions.printHtmlTableToFile(struct_res,'DiffDbViewsStructure.html') #report to file and display its link
    else
      Actions.c 'No Diff found for Views in DB between ' + old_schema + ' Schema and '+new_schema + ' Schema '
    end
  end


  def Actions.printHtmlTable(failed_hash,report_message) #prints red html table , iterating failed hash results
    struct_str=''
    if(!failed_hash.nil? && failed_hash.length>0)
      struct_str<< '<table color="red" style="table-layout: fixed; width: 100%">'
      struct_str<< '<tr>'
      #struct_str<< struct_res[0].keys.to_s
      failed_hash[0].keys.each { |v| struct_str<< '<td>'+v+'</td>' }
      struct_str<< '</tr>'
      struct_str<<'<br>'
      struct_str<<'<br>'
      failed_hash.each{|v|
        struct_str<< '<tr>'
        #struct_str<<v.values.to_s
        v.values.each{|v| struct_str<< '<td style="word-wrap: break-word">'+v.to_s+'</td>'}
        struct_str<< '</tr>'

      }
      struct_str<<'</table>'
      Actions.f report_message + '<br><font color="red">'+struct_str+'</font>'
    end
  end


  def Actions.printHtmlTableToFile(failed_hash,file_name) #prints red html table , iterating failed hash results
    struct_str=''
    if(!failed_hash.nil? && failed_hash.length>0)
      struct_str<< '<table color="red" style="table-layout: fixed; width: 100%">'
      struct_str<< '<tr>'
      #struct_str<< struct_res[0].keys.to_s
      failed_hash[0].keys.each { |v| struct_str<< '<td>'+v+'</td>' }
      struct_str<< '</tr>'
      struct_str<<'<br>'
      struct_str<<'<br>'
      failed_hash.each{|v|
        struct_str<< '<tr>'
        #struct_str<<v.values.to_s
        v.values.each{|v| struct_str<< '<td style="word-wrap: break-word">'+v.to_s+'</td>'}
        struct_str<< '</tr>'

      }
      struct_str<<'</table>'

      log_file = file_name
      log_file_path = Dir.getwd+'/templates/db/'+@@time_stamp+'/'+log_file
      File.open(log_file_path, 'w')
      strArr=[struct_str]
      writeDiffToFile(strArr,log_file_path)

      if Dir.getwd.include?(@@CONFIG['JENKINS_JOB_NAME'])
        log_file_path =  @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME'].to_s+'/ws/templates/db/'+@@time_stamp+'/'+log_file
      end
      Actions.f "<a href='" + log_file_path.to_s+"'>Click to view diff: "+log_file.to_s+"</a>" if(!failed_hash.nil? && failed_hash.length>0)
    end
  end


  def Actions.printHtmlTable2(failed_hash) #prints red html table, iterating through failed hash which includes arrays
    struct_str=''
    if(!failed_hash.nil? && failed_hash.length>0)
      struct_str<< '<table color="red"  style="table-layout: fixed; width: 100%">'
      struct_str<< '<tr>'
      failed_hash.keys.each { |v|
        struct_str<< '<td  style="word-wrap: break-word"><b>'+v+'</b></td>'
      }
      struct_str<< '</tr>'
      struct_str<<'<br>'
      struct_str<<'<br>'
      failed_hash.values.each{ |v|
        v.each{ |v|
          struct_str<< '<tr>'
          v.each{ |v|
            v = '<i>--not set--</i>' if(v.to_s.empty?)
            struct_str<< '<td>'+v+'</td>'
          }
          struct_str<< '</tr>'
        }
      }
      struct_str<<'</table>'

      Actions.f $rtns_compare_errors2[0].to_s+'<font color="red">'+struct_str+'</font>'
      $rtns_compare_errors2 = []
    end
  end

  def Actions.getHtmlTable2(failed_hash)
    struct_str=''
    if(!failed_hash.nil? && failed_hash.length>0)
      struct_str<< '<table color="red"  style="table-layout: fixed; width: 70%">'
      ##struct_str<< '<tr>'
      failed_hash.keys.each { |v|
        ###struct_str<< '<td  style="word-wrap: break-word"><b>'+v+'</b></td>'
      }
      ##struct_str<< '</tr>'
      ##struct_str<<'<br>'
      struct_str<<'<br>'
      failed_hash.values.each{ |v|
        v.each{ |v|
          struct_str<< '<tr>'
          v.each{ |v|
            v = '<i>--not set--</i>' if(v.to_s.empty?)
            struct_str<< '<td style="word-wrap: break-word; border: 1px solid black ;">'+v+'</td>'
          }
          struct_str<< '</tr>'
        }
      }
      struct_str<<'</table>'
    end


    return '<font color="red">'+struct_str+'</font>'
  end

  def Actions.printHtmlTableBlack(hash_print) #prints black html table , iterating  hash
    struct_str=''
    if(!hash_print.nil? && hash_print.length>0)
      struct_str<< '<table  style="table-layout: fixed; width: 100%">'
      struct_str<< '<tr>'
      hash_print.keys.each { |v| struct_str<< '<td>'+v+'</td>' }
      struct_str<< '</tr>'
      struct_str<<'<br>'
      struct_str<<'<br>'
      hash_print.each{|v|
         struct_str<< '<td style="word-wrap: break-word">'+v[1].to_s+'</td>'
      }
      struct_str<<'</table>'
      Actions.pp struct_str
    end
  end


  def Actions.printHtmlTableBlack2(hash_print) #prints black html table , iterating  hash
    struct_str=''
    if(!hash_print.nil? && hash_print.length>0)
      struct_str<< '<table  style="table-layout: fixed; width: 40%">'
      hash_print.each{|k,v|
        struct_str<< '<tr><td style="word-wrap: break-word">'+k.to_s+'</td><td style="word-wrap: break-word">'+v.to_s+'</td><tr><tr><td colspan="2"></td></tr>'
      }
      struct_str<< '</table>'
      Actions.pp struct_str
    end
  end


  def Actions.writeDiffToFile(struct_str_arr,file_path)
    if !struct_str_arr.empty?
      File.open(file_path, 'a') do |file|
        struct_str_arr.each { |row|
          file.puts row.to_s
        }
      end
    end
  end


  def Actions.appendToFile(msg,file_path)
    if !msg.to_s.empty?
      File.open(file_path, 'a') do |file|
           file.puts msg
      end
    end
  end


  def Actions.printDbColumnsDiffAsHtmlTable(failed_hash,report_message)
    struct_str=''
    if(!failed_hash.nil? && failed_hash.length>0)
      struct_str<< '<table color="red" style="border: 100px;">'
      failed_hash.each { |v| struct_str<< '<tr><td>'+v['COLUMN_NAME'].to_s+'</td></tr>' }
      struct_str<<'</table>'
      Actions.f report_message+'<br><font color="red">'+struct_str+'</font>'
    end
  end


  def Actions.checkRtnsDelievery(file_path,user)
    Actions.c '<b> Testing Delievery to RTNS for user: '+user+'</b>'
    Actions.c '<b> Please note that Reuters conformance test passed for ptrade v.510, so version tested must be >= 510 </b>'
    ordersStatus=[]
    ordersId=[]
    file = File.readlines(file_path)

    rtns_line_arr=[]
    query = 'PTS-C7306' #FIX outgoing Event outgoing
    matches = file.select { |line|
      found=line[/#{query}/i]
      if (!found.nil? && found.length>0)
        res = line.to_s.scan(/.*\[8=FIXT.1.1(.*)\]/)
        rtns_line_arr.push res if !res.nil? && !res.to_s.empty?
        orderIdFound=res.to_s.scan(/.*37=(\w+-\w+-\w+-\w+-\w+)/)
        if !orderIdFound.nil? && !orderIdFound.to_a.empty?
          seqNo = res.to_s.scan(/.*34=(\d)/)
          !seqNo.nil? && !seqNo.to_a.empty? ? seqNo=seqNo[0][0] : seqNo=''
          orderStatus={'orderId' => orderIdFound[0][0], 'seqNoOutgoing' => seqNo, 'seqNoIncoming' => '', 'delieveryStatus' => '', 'failReason' => ''}
          ordersStatus.push orderStatus
          ordersId.push(orderIdFound)

        end
      end


    }


    failed = false
    ordersStatus.each { |orderid|
      query = 'PTS-C7305' #FIX incoming Event outgoing
      matches = file.select { |line|
        found=line[/#{query}/i]
        if (!found.nil? && found.length>0)
          res = line.to_s.scan(/.*\[8=FIXT.1.1(.*)\]/)

          orderId_rejected = res.to_s.scan(/.*45=(#{orderid['seqNoOutgoing']})/)
          if !orderId_rejected.nil? && !orderId_rejected.to_a.empty?
            msg_res = res.to_s.scan(/.*35=(\w+)/)
            msg=''
            msg_res.nil? || msg_res.to_a.empty? || MSG_TYPE[msg_res[0][0]].nil? ? msg='NO_DICTIONARY_KEY' : msg= MSG_TYPE[msg_res[0][0]].to_s
            reject_reason = !res.to_s.scan(/.*58=(.*?)\\/)[0][0].nil? ? res.to_s.scan(/.*58=(.*?)\\/)[0][0] : ''
            orderid['delieveryStatus'] = 'failed' #msg
            orderid['seqNoIncoming'] = orderid['seqNoIncoming'] #App reject
            orderid['failReason'] = reject_reason
            failed = true
          end
          #break if failed


          passed = false
          orderId_passed = res.to_s.scan(/.*571=(#{orderid['orderId']})/)
          if !orderId_passed.nil? && !orderId_passed.to_a.empty?
            msg_res = res.to_s.scan(/.*35=(\w+)/)
            msg=''
            msg_res.nil? || msg_res.to_a.empty? || MSG_TYPE[msg_res[0][0]].nil? ? msg='NO_DICTIONARY_KEY' : msg= MSG_TYPE[msg_res[0][0]].to_s
            if (msg_res.nil? || msg_res[0][0]!='AR' || msg_res.to_s.empty?)
              orderid['delieveryStatus'] = 'failed'
              orderid['failReason'] = "Expecting value of 'AR' in field 35,but actual is '"+msg_res[0][0].to_s+"' ("+msg+")"
              passed = false

            else
              if msg=='AR'
                orderid['delieveryStatus'] = 'passed'
                passed = true
              else
                #Actions.f orderid['orderId']+'  is not found in incoming RTNS message '
              end
            end
          end
          #break if passed


        end
      }
    }
    Actions.c "<b> " + ordersStatus.length.to_s+" TCRs sent to RTNS by user: " + user


    arrFailed=ordersStatus.select { |elem| elem["delieveryStatus"]=="failed" }
    Actions.f "<b> " + arrFailed.length.to_s+ " orders are NOT delivered to RTNS for user: "+user+" ,pls. see list below </b>" if (!arrFailed.nil? && !arrFailed.to_a.empty?)
    arrFailed.each { |failed_order|
      Actions.f " orderID: " + failed_order['orderId'] + "   sequence: " + failed_order['seqNoOutgoing'] + "   reason: " + failed_order['failReason']
    }


    arrPassed=ordersStatus.select { |elem| elem["delieveryStatus"]=="passed" }
    Actions.c "<b> " + arrPassed.length.to_s+ " orders are NOT delivered to RTNS for user: "+user+" ,pls. see list below </b>" if (!arrPassed.nil? && !arrPassed.to_a.empty?)

    Actions.f "<b> No sent orders to RTNS being found for user: "+user+" , pls. check Your prod.conf and pts_tidy_3.log </b>" if ((arrPassed.nil? &&arrFailed.nil?) || (arrPassed.length+arrFailed.length<=0))

    rtns_line_arr

  end



  def Actions.compareOutgoingRtns(log_file_path1,log_file_path2)
    Actions.c '<b> Comparing Outgoing Data to RTNS </b>'
    Actions.c '<b> Please note that Reuters conformance test passed for ptrade v.510, so version tested must be >= 510 </b>'
    file1 = File.readlines(log_file_path1)
    query = 'PTS-C7306' #FIX outgoing Event outgoing
    found_orders1=[]

    #ptrade1
    matches1 = file1.select { |line|
      found=line[/#{query}/i]
      if (!found.nil? && found.length>0)
        res = line.to_s.scan(/.*\[8=FIXT.1.1(.*)\]/)
        orderIdFound=res.to_s.scan(/.*37=(\w+-\w+-\w+-\w+-\w+)/)

        if !orderIdFound.nil? && !orderIdFound.to_a.empty?
          foundOrder1={}
          res_arr = res[0][0].to_s.split('^'.chr)
          res_arr.each_with_index { |elem,index |
            res_arr.delete_at(index) if res_arr[index].nil? || res_arr[index].to_s.empty? || (res_arr[index]=~/\w=\w/).nil?
          }

          arrKeysValues=res_arr.to_s.scan /\d+=\w+/
          arrKeysValues.each { |e,i|
            key_value=e.to_s.split('=')
            key = key_value[0].gsub('0001','')
            value = key_value[1]
            foundOrder1[key]=value
          }
          #puts foundOrder1.to_s
          found_orders1.push foundOrder1
        end
      end
    }
    Actions.c "<b> " + found_orders1.length.to_s+" TCRs sent to RTNS by user: " + CONFIG.get['CORE_HOST_USER1']+"</b>"

    #ptrade
    file2 = File.readlines(log_file_path2)
    query = 'PTS-C7306' #FIX outgoing Event outgoing
    found_orders2=[]
    matches2 = file2.select { |line|
      found=line[/#{query}/i]
      if (!found.nil? && found.length>0)
        res = line.to_s.scan(/.*\[8=FIXT.1.1(.*)\]/)
        orderIdFound=res.to_s.scan(/.*37=(\w+-\w+-\w+-\w+-\w+)/)

        if !orderIdFound.nil? && !orderIdFound.to_a.empty?
          foundOrder2={}
          res_arr = res[0][0].to_s.split('^'.chr)
          res_arr.each_with_index { |elem,index |
            res_arr.delete_at(index) if res_arr[index].nil? || res_arr[index].to_s.empty? || (res_arr[index]=~/\w=\w/).nil?
          }


          arrKeysValues=res_arr.to_s.scan /\d+=\w+/
          arrKeysValues.each { |e,i|
            key_value=e.to_s.split('=')
            key = key_value[0].gsub('0001','')
            value = key_value[1]
            foundOrder2[key]=value

          }
          #puts foundOrder2.to_s
          found_orders2.push foundOrder2
        end
      end
    }
    Actions.c "<b> " + found_orders1.length.to_s+" TCRs sent to RTNS by user: " + CONFIG.get['CORE_HOST_USER']+"</b>"

    Actions.c "<b> NO DIFF FOUND in outgoing data to RTNS - " + (found_orders1.length+found_orders2.length).to_s + " ers have been sent </b></br>" if (found_orders1-found_orders2).to_a.empty? && (found_orders2-found_orders1).to_a.empty? && (found_orders1.length+found_orders2.length)>0
    Actions.f "<b> NO ers have been sent for both users: ptrade1 and ptrade </b></br>" if (found_orders1-found_orders2).to_a.empty? && (found_orders2-found_orders1).to_a.empty? && (found_orders1.length+found_orders2.length)==0
    if !((found_orders1-found_orders2).to_a.empty?)
      Actions.f "<b> Diff FOUND in outgoing data to RTNS.Below is Missing for user: " + CONFIG.get['CORE_HOST_USER'] +' '+ (found_orders1-found_orders2).length.to_s + ' missing tcrs vs ' + CONFIG.get['CORE_HOST_USER1']+"</b>"
      Actions.f "Diff:<br>"

      (found_orders1-found_orders2).each { |hash|
        diff=''
        hash.keys.each{ |key|
          hash.values.each { |value|
            diff+=key+'='+value+' '
          }
        }
        Actions.f diff
      }

    end
    if !((found_orders2-found_orders1).to_a.empty?)
      Actions.f "<b> Diff FOUND in outgoing data to RTNS.Below is missing Missing for user: " + CONFIG.get['CORE_HOST_USER1'] +' '+(found_orders2-found_orders1).length.to_s + ' missing tcrs vs ' + CONFIG.get['CORE_HOST_USER']+"</b>"

      (found_orders1-found_orders2).each { |hash|
        diff=''
        hash.keys.each{ |key|
          hash.values.each { |value|
            diff+=key+'='+value+' '
          }
        }
        Actions.f diff
      }

    end

  end
  ### RTNS end



###Utils
  def Actions.cleanupMsl(user,mslIP,sleep_after_cleanup=0)
    Actions.v '<b> Running Cleanup and Restart of Msl Server </b>'+mslIP

    cmd ='cd '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation && dos2unix MSLdbCleaner_automatic.sh && chmod 755 MSLdbCleaner_automatic.sh'
    res=self.SSH(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], cmd, 10, true, '')
    cmd ='cd '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation && ./MSLdbCleaner_automatic.sh -msl:'+mslIP
    r=self.SSH(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], cmd, 300, true, 'Finished successfully')
    v 'Msl '+mslIP+' Cleanup command output - '+r.to_s
    sleep sleep_after_cleanup
  end

  def Actions.cleanupMslCustom(mslIP, target_dir_path,sleep_after_cleanup=0)
    mslCleanerScript = 'MSLdbCleaner_automatic.sh'
    v '<b> Running Cleanup and Restart of Msl Server </b>'+mslIP

    Actions.uploadTemplates(mslIP,CONFIG.get['MSL_HOST_USER'],CONFIG.get['MSL_HOST_PWD'],Dir.getwd+'/templates/bash/'+mslCleanerScript,CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['MSL_HOST_USER']+'/'+target_dir_path+'/'+mslCleanerScript)
    Actions.rigthsForFile(mslIP,CONFIG.get['MSL_HOST_USER'],CONFIG.get['MSL_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['MSL_HOST_USER']+'/'+target_dir_path,mslCleanerScript,'755')

    cmd ='cd '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['MSL_HOST_USER']+'/'+target_dir_path+' && ./MSLdbCleaner_automatic.sh -msl:'+mslIP
    res=self.SSH(mslIP, CONFIG.get['MSL_HOST_USER'], CONFIG.get['MSL_HOST_PWD'], cmd, 300, true, 'Finished successfully')

    v 'Msl Cleanup command output - '+res.to_s
    c 'Cleaning of MSL '+mslIP+' finished'
    sleep sleep_after_cleanup
  end


def Actions.truncatePtradeTables(schema)
query="truncate table "+schema+".AUDIT_IN DROP STORAGE;
truncate table "+schema+".FX_DEAL DROP STORAGE;
truncate table "+schema+".FX_DEAL_LEG DROP STORAGE;
truncate table "+schema+".FX_TICKET_LEG DROP STORAGE;
update "+schema+".SD_TARGET set LAST_ID = NULL, LAST_SESSION = NULL, LAST_SRC_SESSION = NULL,  LAST_SRC_ID = NULL;
commit;
"

    getDbQueryResultsWithoutFailure4(schema,schema.to_s.downcase,query)

end


  def Actions.stopPtradeService(host, user, pwd, log = true)#TODO
    Actions.v 'Stopping PTS services for '+user
    # cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/bin/service.sh stop'
    cmd = CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh stop' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
    cmd = CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh stop' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
    expected_output_rows=['pts_tidy stopped successfully','pts_core stopped successfully','pts_http stopped successfully']
    res = Actions.SSH(host, user, pwd, cmd, 60, true, expected_output_rows)
    Actions.v res.to_s if(log)
  end


  def Actions.restartPtradeService(host, user, pwd,log = true)
    Actions.v 'Restarting PTS service for '+user
    # cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/bin/service.sh restart'
    cmd = "cd "+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/bin && ./service.sh restart' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
    cmd = "cd "+CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/bin && ./service.sh restart' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
    # expected_output_rows=['The PTS (module: tidy) is alive','The PTS (module: core) is alive','The PTS (module: http) is alive']
    unexpected_output_rows=['The PTS (module: tidy) is not running','The PTS (module: core) is not running','The PTS (module: http) is not running']
    res = Actions.SSH(host, user, pwd, cmd, 60, true, '')
    Actions.v res.to_s if(log)
    unexpected_output_rows.each { |procMsg|
      if res.to_s.downcase.include?(procMsg)
        Actions.f 'PTS process is not alive: '+procMsg+' for user "'+user+'"'
        @@scenario_fails.push('<br>PTS process is not alive: '+procMsg+' for user "'+user+'"')
        fail('PTS process is not alive: '+procMsg+' for user "'+user+'"')
      end
    }
    sleep 60 #Waiting for Ptrade started

    # cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/bin/service.sh status'
    cmd = CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh status' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
    cmd = CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh status' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
    unexpected_output_rows=['The PTS (module: tidy) is not running','The PTS (module: core) is not running','The PTS (module: http) is not running']
    res = Actions.SSH(host, user, pwd, cmd, 60, true, '')
    Actions.v res.to_s
    unexpected_output_rows.each { |procMsg|
      if res.to_s.downcase.include?(procMsg)
        Actions.f 'PTS process is not alive: '+procMsg+' for user "'+user+'"'
        @@scenario_fails.push('<br>PTS process is not alive: '+procMsg+' for user "'+user+'"')
        fail('PTS process is not alive: '+procMsg+' for user "'+user+'"')
      end
    }

    # cmd ='cat ' + CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/logs/pts_core_*.log'
    cmd = 'cat ' + CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+"/PTS/logs/pts_core_*.log | egrep -i 'error|exception' | egrep -v '\\-XX\\:\\+HeapDumpOnOutOfMemoryError'" if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
    cmd = 'cat ' + CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+"/PTS/logs/pts_core_*.log | egrep -i 'error|exception' | egrep -v '\\-XX\\:\\+HeapDumpOnOutOfMemoryError'" if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
    res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 60) #Display log
    #Actions.v '<br>Core Logs -'+res.to_s if(!res.nil? && log)
    Actions.v 'Found "exception|error" in pts_core logs'+' for user "'+user+'": '+res.to_s if(log && !res.to_s.empty?)
    Actions.v 'No "exception|error" found in pts_core logs'+' for user "'+user+'"' if(log && res.nil? || res.to_s.empty?)

    # cmd ='cat ' + CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/logs/pts_tidy_*.log'
    cmd = 'cat ' + CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+"/PTS/logs/pts_tidy_*.log | egrep -i 'error|exception' | egrep -v '\\-XX\\:\\+HeapDumpOnOutOfMemoryError'" if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
    cmd = 'cat ' + CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+"/PTS/logs/pts_tidy_*.log | egrep -i 'error|exception' | egrep -v '\\-XX\\:\\+HeapDumpOnOutOfMemoryError'" if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
    res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 60) #Display log
    #Actions.v '<br>Tidy Logs -'+res.to_s if(log && !res.nil?)
    Actions.v 'Found "exception|error" in pts_tidy logs'+' for user "'+user+'": '+res.to_s if(log && !res.to_s.empty?)
    Actions.v 'No "exception|error" found in pts_core logs'+' for user "'+user+'"' if(log && res.nil? || res.to_s.empty?)
  end


  def Actions.SCP(host,usr,pwd,local_path,remote_path)
    Net::SCP.start(host, usr, :password => pwd) do |scp|
      # asynchronous upload; call returns immediately and requires SSH
      # event loop to run
      channel = scp.upload(local_path, remote_path)
      channel.wait
    end
  end


  def Actions.isIpValidInParams
    ip_found=false
    ENV.each do |a|
      #Actions.v "Env Param: #{a[0].to_s}"
      if(a[0].to_s.include?('_IP'))
        ip_found=self.valid_IP_v4?(a[1].to_s)
        if(!ip_found)
          Actions.f "Please define valid IP for param #{a[0].to_s}"
          fail("Please define valid IP for param #{a[0].to_s}")
        end
      end
    end
    # return ip_found
    if(!ip_found)
      Actions.f('No valid IPs found in given params')
      fail('No valid IPs found in given params')
    end
  end


  def Actions.valid_IP_v4?(addr)
    found=false
    if /\A(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\Z/ =~ addr
      #return $~.captures.all? {|i| i.to_i < 256}
      $~.captures.each {|i| i.to_i < 256 ? found=true : found=false}
    end
    return found
  end


  def Actions.changeInFileBetweenMatches(host, user, pwd, filePath, startPieceToMatch, endPieceToMatch, textToBeChanged, textToPaste)
    c 'Changing text "'+textToBeChanged+'" to "'+textToPaste+'" in '+host+':'+filePath
    cmd ='sed -i -e "/^'+startPieceToMatch+'/,/^'+endPieceToMatch+'/s/'+textToBeChanged+'/'+textToPaste+'/g" '+filePath
    res=self.SSH(host, user, pwd, cmd, 30, true, '')
  end


  def Actions.isUp?(host)
    # require 'net/ping'
    # check = Net::Ping::External.new(host)
    # if check.ping?
    #   v host+':Ping finished successfully'
    # end

    v 'Pinging '+host+'...'
    res = Actions.WINCMD_NO_FAIL('ping '+host, 20)
    res = res.to_s.downcase
    if res.include?('reply')
      if res.include?('0% loss')
        v host+':Pinging '+host+' finished successfully'
      else
        f 'Pinging '+host+' finished with losses'
      end
    else
      f 'ERROR: ping to '+host+' failed'
      fail('ERROR: ping to '+host+' failed')
    end
  end


  def Actions.removeDos2unixTmpFiles(host,user,pwd,path)
    Actions.v 'Removing dos2unix temp files in "'+path+'" on '+host
    cmd = 'cd '+path+' && find . -maxdepth 1 -name \'d2utmp*\' -type f -print0|xargs -0 rm -f --'
    res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 25)
  end


  def Actions.moveToFolderByMask(host,user,pwd,path,newFolderName,mask)
    Actions.v 'Moving files by mask "'+mask+'" from "'+path+'" to '+newFolderName+' on '+host
    cmd = 'cd '+path+' && mkdir -p '+newFolderName+' && mv -f '+mask+' '+newFolderName
    res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 25)
  end


  def Actions.compareCsvFolders(time_stamp)
    $csv_folders_count = 0
    $csv_files_count = 0
    Actions.v 'compareCsvFolders - #Started#'
    source_dir = Dir.getwd + '/templates/old_app_csv/'+time_stamp
    target_dir = Dir.getwd + '/templates/new_app_csv/'+time_stamp
    res1=Actions.compareCsvDirs2(source_dir+'/common', target_dir+'/common',CONFIG.get['MYT_CSV_EXCLUDED_COLUMNS'],"csv","c")
    Actions.c ($csv_folders_count).to_s+' folders have been tested in folder common' if(!$csv_folders_count.nil? && !res1.nil? && !res1.to_s.downcase.include?('error'))
    writeToHtml("data_common_csv_"+@@time_stamp+'.html',res1,goodMsg='',badMsg=(res1.nil? || res1.empty?  ? '' : 'Diff Found for data:/csv common files' ))
    res2=Actions.compareCsvDirs2(source_dir+'/myt', target_dir+'/myt',CONFIG.get['MYT_CSV_EXCLUDED_COLUMNS'],"csv","m")
    Actions.c ($csv_folders_count).to_s+' folders have been tested in folder myt' if(!$csv_folders_count.nil? && !res2.nil? && !res2.to_s.downcase.include?('error'))
    writeToHtml("data_myt_csv_"+@@time_stamp+'.html',res2,goodMsg='',badMsg=(res2.nil? || res2.empty?  ? '' : 'Diff Found for data:/csv myt files' ))
    Actions.c $csv_files_count.to_s+' files have been compared' if(!$csv_files_count.nil?)
    Actions.v 'compareCsvFolders - #Finished#'

    if($csv_folders_count.nil? || $csv_folders_count==0)
      @@scenario_fails.push('0 Folders compared')
      Actions.f('0 Folders compared')
      $csv_compare_errors.push('0 Folders compared')

      return '0 Folders compared'
    end
    if($csv_files_count.nil? || $csv_files_count==0)
      @@scenario_fails.push('0 Files compared')
      Actions.f('0 Files compared')
      $csv_compare_errors.push('0 Files compared')

      #return '0 Files compared'
    end
  end

  def Actions.compareCsvFolders3(source_dir,target_dir)
    Actions.v 'compareCsvFolders - #Started#'
    dir_count=Actions.compareCsvDirs2(source_dir, target_dir,CONFIG.get['MYT_CSV_EXCLUDED_COLUMNS'],"csv","c")
    Actions.c (dir_count).to_s+' folders have been tested in folder common' if(!$csv_folders_count.nil? && !dir_count.nil? && !dir_count[0].to_s.downcase.include?('error'))
    dir_count=Actions.compareCsvDirs2(source_dir, target_dir,CONFIG.get['MYT_CSV_EXCLUDED_COLUMNS'],"csv","m")
    Actions.c (dir_count).to_s+' folders have been tested in folder myt' if(!$csv_folders_count.nil? && !dir_count.nil? && !dir_count[0].to_s.downcase.include?('error'))
    Actions.c $csv_files_count.to_s+' files have been compared' if(!$csv_files_count.nil?)
    Actions.v 'compareCsvFolders - #Finished#'

    if($csv_folders_count.nil? || $csv_folders_count==0)
      @@scenario_fails.push('0 Folders compared')
      Actions.f('0 Folders compared')
      return
    end
    if($csv_files_count.nil? || $csv_files_count==0)
      @@scenario_fails.push('0 Files compared')
      Actions.f('0 Files compared')
    end
  end

  def Actions.setEnvVar(host,user,pwd,envName,envValue)
    Actions.v 'Setting env var "'+envName+'" to "'+envValue+'" on '+host+' for user "'+user+'"'
    cmd = 'if grep -q "export '+envName+'=" /export/home/'+user+'/.bashrc 2>/dev/null; then'+"\n"\
    +'sed -i -e "s/export '+envName+'=.*/export '+envName+'='+envValue+'/g" /export/home/'+user+'/.bashrc'+"\n"\
    +'source /export/home/'+user+'/.bashrc'+"\n"\
    +'else'+"\n"\
    +'echo "export '+envName+'='+envValue+'" >> /export/home/'+user+'/.bashrc'+"\n"\
    +'source /export/home/'+user+'/.bashrc'+"\n"\
    +'fi'
    res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 25)
  end







  def Actions.compareCsvFolders2(source_dir,target_dir,excluded_fields_arr,file_type,file_version)
    $csv_folders_count = 0
    $csv_files_count = 0
    Actions.v 'compareCsvFolders2 - #Started#'
    Actions.v 'Comparing CSV folders source: ' + source_dir + ' and ' + target_dir
    res=Actions.compareCsvDirs2(source_dir,target_dir,excluded_fields_arr,file_type,file_version)
    Actions.c ($csv_folders_count).to_s+' folders have been tested in '+source_dir if(!$csv_folders_count.nil? && !res.nil? && !res.to_s.downcase.include?('error'))
    Actions.c $csv_files_count.to_s+' files have been compared' if(!$csv_files_count.nil?)

    if($csv_folders_count.nil? || $csv_folders_count==0)
      @@scenario_fails.push('0 Folders compared')
      Actions.f('0 Folders compared')
      $csv_compare_errors.push('0 Folders compared')

      return res #$csv_compare_errors
    end
    if($csv_files_count.nil? || $csv_files_count==0)
      @@scenario_fails.push('0 Files compared')
      Actions.f('0 Files compared')
      $csv_compare_errors.push('0 Files compared')

      return res #$csv_compare_errors
    end

    Actions.v 'compareCsvFolders2 - #Finished#'
    return res #$csv_compare_errors

  end


  def Actions.printMessagesCountFromMsl(host,user,pwd)
    Actions.v 'select count(*) from messages; from msl "'+host+'":'
    cmd = 'psql -U msl -d redur -c "select count(*) from messages;"'
    res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 25)
    Actions.v res.to_s
    msgs=res.to_s

    Actions.v 'select count(*) from redur; from msl "'+host+'":'
    cmd = 'psql -U msl -d redur -c "select count(*) from redur;"'
    res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 25)
    Actions.v res.to_s

    return msgs
  end





  def Actions.getFileCountInDir(dir_path)
    count=nil
    begin
      count=Dir.glob(File.join(dir_path, '**', '*')).select { |file| File.file?(file) }.count
    rescue Exception=>e
      v 'Unable to count files from dir:  ' + dir_path
    end

    count=0 if count.nil?
    return count
  end





  def Actions.getTicketsCount(schema_name)
      sql="select count(1) from " + schema_name + ".fx_ticket_leg"
      res=Actions.getDbQueryResultsWithoutFailure4(schema_name,schema_name.to_s.downcase,sql)

      return res[0]['COUNT(1)'].to_i if !res.nil?
      return nil
  end


  def Actions.getEnvParamsFromService(serviceIPandPORT)
    uri = URI.parse("http://#{serviceIPandPORT}/get")
    http = Net::HTTP.new(uri.host, uri.port)
    request = Net::HTTP::Get.new(uri.request_uri)
    begin
      response = http.request(request)
      response.body
      hash_response=response.body.gsub("\n","").gsub("\\","").gsub(" ","")
      hash_response="" if(hash_response.nil? || hash_response.to_s.empty?)

      if(!hash_response.nil? && !hash_response.empty?)
        res=eval(hash_response)
        if (res.instance_of?(Hash) && (!res.nil? || !res.empty?))
          res.each{|key,value| ENV[key]=value}
        end
      end
    rescue Exception=>e
      v "Request failed: "+uri.to_s+" #{e.message}"
    end
  end


  def Actions.setEnvParamsInService(keyValuePairsHash,serviceIPandPORT)
    req_params = ""
    keyValuePairsHash.each_with_index{|elem,index|
      k=keyValuePairsHash.keys[index].to_s
      v=keyValuePairsHash[k.to_s].to_s
      if(!k.nil? && !v.nil? && !k.empty? && !v.empty?)
        req_params << (k+"="+v)
        if index<keyValuePairsHash.length-1 #if not last pair kv
          k2=keyValuePairsHash.keys[index+1].to_s
          v2=keyValuePairsHash[k2.to_s].to_s
           req_params << "&" if(!k2.nil? && !v2.nil? && !k2.empty? && !v2.empty?)
        end
      end
    }
    if req_params.empty?
      v "NOT Sending setEnvParams  request: MISSING_PARAMS"
      return
    end

    uri = URI.parse("http://#{serviceIPandPORT}/set/?#{req_params}")
    http = Net::HTTP.new(uri.host, uri.port)
    request = Net::HTTP::Get.new(uri.request_uri)
    v "Sending setEnvParams GET request: " + uri.to_s
    begin
      response = http.request(request)
      response.body
    rescue Exception=>e
      v "Request failed: "+uri.to_s+" #{e.message}"
    end
  end


  def Actions.resetEnvParamsInService(serviceIPandPORT)

    uri = URI.parse("http://#{serviceIPandPORT}/reset")
    http = Net::HTTP.new(uri.host, uri.port)
    request = Net::HTTP::Get.new(uri.request_uri)
    v "Sending resettEnvParams GET request: " + uri.to_s
    begin
      response = http.request(request)
      response.body
    rescue Exception=>e
      v "Request failed: "+uri.to_s+" #{e.message}"
    end
  end



end
