require "webrick"

begin
  require_relative('Actions')
rescue LoadError
  raise "Couldn't load Actions.rb\n"
end

include WEBrick
class Service < WEBrick::HTTPServlet::AbstractServlet
  def prevent_caching(res)
    res['ETag']          = nil
    res['Last-Modified'] = Time.now + 100**4
    res['Cache-Control'] = 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0'
    res['Pragma']        = 'no-cache'
    res['Expires']       = Time.now - 100**4
  end

  def do_GET (request, response)
    #super
    #prevent_caching(response)
    Actions.v("AutomationService got request: "+request.to_s)
   # if (request.query["cmd"] ) #used for performance for user ptrade start/stop ptrade
   if request.query.keys.select{|k| k.downcase=="cmd"}.length > 0
      cmd=request.query.keys.select{|k| k.downcase=="cmd"}[0] #request.query["cmd"] #Ignore params case
      if request.query[cmd].to_s.gsub(" ","").downcase.eql?("stopPtrade".downcase)
        begin
          response.status = 200
          response.content_type = "text/plain"
          response.body = "PostTrade is Stopped for "+CONFIG.get['CORE_HOST_USER']+"@"+CONFIG.get['CORE_HOST']+" \n"
          Actions.stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],false)
          @@POSTTRADE_IS_STOPPED = true
          raise HTTPStatus::OK
        rescue Exception => e
          if !(e.to_s =~ /WEBrick::HTTPStatus::OK/)#!e.nil?
            response.status = 200
            response.content_type = "text/plain"
            response.body = "Stop Ptrade failed for "+CONFIG.get['CORE_HOST_USER']+"@"+CONFIG.get['CORE_HOST']+" error: "+e.message + " \n"
            raise HTTPStatus::OK
            fail("Stop Ptrade failed: " +e.message)
          end
        end
      else
        response.status = 404
        response.content_type = "text/plain"
        response.body = "You did not provide the correct parameters for stopping Ptrade \n"
        raise HTTPStatus::OK #NotFound
      end
    end

    #if (request.query["stop"] ) #used for performance for user ptrade start/stop ptrade
    if request.query.keys.select{|k| k.downcase=="stop"}.length > 0
      cmd=request.query.keys.select{|k| k.downcase=="stop"}[0] #request.query["stop"] #ignore case
      if request.query[cmd].to_s.gsub(" ","").downcase.eql?("ptrade")
        begin
          @@POSTTRADE_IS_STOPPED = true
          response.status = 200
          response.content_type = "text/plain"
          response.body = "Ptrade stopped status DO updated for "+CONFIG.get['CORE_HOST_USER']+"@"+CONFIG.get['CORE_HOST']+" \n"
          Actions.v "Ptrade stopped status DO updated for "+CONFIG.get['CORE_HOST_USER']+"@"+CONFIG.get['CORE_HOST']
          raise HTTPStatus::OK
        rescue Exception => e
          if !(e.to_s =~ /WEBrick::HTTPStatus::OK/)#!e.nil?
            @@POSTTRADE_IS_STOPPED = true
            response.status = 200
            response.content_type = "text/plain"
            response.body = "Ptrade stopped status DO updated for "+CONFIG.get['CORE_HOST_USER']+"@"+CONFIG.get['CORE_HOST']+" \n"
            Actions.v "Ptrade stopped status NOT updated for "+CONFIG.get['CORE_HOST_USER']+"@"+CONFIG.get['CORE_HOST']
            raise HTTPStatus::OK
          end
        end
      else
        response.status = 404
        response.content_type = "text/plain"
        response.body = "You did not provide the correct parameters for POSTTRADE_IS_STOPPED \n"
        #response.body = "Ptrade stopped status NOT updated for "+CONFIG.get['CORE_HOST_USER']+"@"+CONFIG.get['CORE_HOST']+" \n"
        Actions.v "Ptrade stopped status NOT updated for "+CONFIG.get['CORE_HOST_USER']+"@"+CONFIG.get['CORE_HOST']
        raise HTTPStatus::OK #NotFound
      end
    end

    if request.query.keys.select{|k| k.downcase=="error"}.length > 0
      cmd=request.query.keys.select{|k| k.downcase=="error"}[0] #request.query["stop"] #ignore case
      if request.query[cmd].to_s.gsub(" ","").downcase.eql?("NO_TIDY_TICKETS_FOUND")
        begin
          @@NO_TIDY_TICKETS_FOUND = true
          response.status = 200
          response.content_type = "text/plain"
          response.body = "NO_TICKETS_FOUND accepted for "+CONFIG.get['CORE_HOST_USER']+"@"+CONFIG.get['CORE_HOST']+" \n"
          Actions.v "NO_TICKETS_FOUND for "+CONFIG.get['CORE_HOST_USER']+"@"+CONFIG.get['CORE_HOST']
          raise HTTPStatus::OK
        rescue Exception => e
          if !(e.to_s =~ /WEBrick::HTTPStatus::OK/)#!e.nil?
            @@NO_TIDY_TICKETS_FOUND = true
            response.status = 200
            response.content_type = "text/plain"
            response.body = "Ptrade stopped status DO updated for "+CONFIG.get['CORE_HOST_USER']+"@"+CONFIG.get['CORE_HOST']+" \n"
            Actions.v "Ptrade stopped status NOT updated for "+CONFIG.get['CORE_HOST_USER']+"@"+CONFIG.get['CORE_HOST']
            raise HTTPStatus::OK
          end
        end
      else
        response.status = 404
        response.content_type = "text/plain"
        #response.body = "You did not provide the correct parameters for NO_TICKETS_FOUND\n"
        response.body = "NO_TICKETS_FOUND NOT accepted for "+CONFIG.get['CORE_HOST_USER']+"@"+CONFIG.get['CORE_HOST']+" \n"
        Actions.v "NO_TICKETS_FOUND NOT accepted for "+CONFIG.get['CORE_HOST_USER']+"@"+CONFIG.get['CORE_HOST']
        raise HTTPStatus::OK #NotFound
      end
    end

  end


  def startServer(port=1234)
    server=nil
    begin
      server = WEBrick::HTTPServer.new(:Port => port)
      server.mount "/", Service
      server.start
      Actions.v 'Service started on port '+port.to_s
      trap("INT") {
        server.shutdown
      }
    rescue Exception=>e
      fail("Start Service failed: " + e.message)
    end
  end

  def Service.start(port=1234)
    begin
      Thread.new{startServer(port)}
    rescue Exception=>e
      fail("Start Service failed: " + e.message)
    end
  end

  def Service.stop(instance)
    begin
      instance.shutdown
    rescue Exception=>e
      fail("Stop Service failed: " +e.message)
    end
  end


end
