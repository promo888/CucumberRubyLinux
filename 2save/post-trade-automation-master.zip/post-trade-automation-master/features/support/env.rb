require 'time'
begin
  require '../../features/helpers/Actions'
rescue LoadError
end


Before do
  $world = self
  time = Time.new
  @@time_stamp= time.day.to_s+'-'+time.month.to_s+'-'+time.year.to_s+'_'+time.hour.to_s+'-'+time.min.to_s+'-'+time.sec.to_s #Time.now.to_i.to_s
  @@automation_build_file_path=Dir.getwd+'/config/build.properties'
  @@scenario_fails = []
  @@email_properties = {}
  @@before_upgrade_timestamp=@@time_stamp
  $VERBOSE = nil
  @@old_ptrade_version_number = nil
  @@new_ptrade_version_number = nil
  @@ers_count_ptrade1 = 0
  @@ers_count_ptrade = 0

  Actions.removeOldOutput
  Actions.createLocalDirs
  @@automation_log_file='automation_log.html'
  @@automation_log_file_path=Dir.getwd+'/logs/logs_'+@@time_stamp+'/'+@@automation_log_file
  Actions.v "Dir.getwd #{Dir.getwd} ,@@automation_build_file_path #{@@automation_build_file_path}"
  File.open(@@automation_log_file_path, 'w')

  File.open(@@automation_build_file_path, 'w')
  Actions.setBuildProperty('SDATA1_SCHEMA_VERSION_packageName','Failed')
  Actions.setBuildProperty('SDATA_SCHEMA_VERSION_packageName','Failed')
  Actions.setBuildProperty('PTRADE1_SCHEMA_VERSION','Failed')
  Actions.setBuildProperty('PTRADE1_APP_VERSION','Failed')
  Actions.setBuildProperty('PTRADE_SCHEMA_VERSION','Failed')
  Actions.setBuildProperty('PTRADE_APP_VERSION','Failed')
  Actions.setBuildProperty('DEPLOY','Failed')
  Actions.setBuildProperty('STATUS','Failed')
end


After do
  if Dir.getwd.include?(@@CONFIG['JENKINS_JOB_NAME'])
    log_file_path =  @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME'].to_s+'/ws/logs/'+'logs_'+@@time_stamp+'/'+@@automation_log_file
  else
    log_file_path = Dir.getwd+'/logs/'+'logs_'+@@time_stamp+'/'+@@automation_log_file
  end
  Actions.p "<a href='" + log_file_path.to_s+"'>Click to view detailed execution log: "+@@automation_log_file+"</a>"

  failed = Actions.isBuildPropertyFailed?(['SDATA1_SCHEMA_VERSION_packageName','SDATA_SCHEMA_VERSION_packageName','PTRADE1_SCHEMA_VERSION','PTRADE1_APP_VERSION','PTRADE_SCHEMA_VERSION','PTRADE_APP_VERSION'])
  Actions.setBuildProperty('DEPLOY','Passed') if(!failed)
  Actions.setBuildProperty('STATUS','Passed') if(@@scenario_fails.empty? && Actions.getBuildProperty('DEPLOY').to_s.downcase == 'passed')
  Actions.setBuildProperty('STATUS','Diff found') if(!@@scenario_fails.empty? && Actions.getBuildProperty('DEPLOY').to_s.downcase == 'passed')
  Actions.setBuildProperty('STATUS','Setup failed') if( Actions.getBuildProperty('DEPLOY').to_s.downcase == 'failed')
end


Before do |scenario|
  $world = self
  @@current_scenario_tag = scenario.source[1].tags[0].name.to_s
  Actions.v 'Scenario: #{scenario.source[1].tags[0].name.to_s}'

  #Actions.WINCMD_NO_FAIL("TASKKILL /F /IM cmd.exe /T",20)
  if (scenario.source[1].tags[0].name.to_s.include?('@sanity-sdata-only'))
      Actions.valid_IP_v4?(CONFIG.get['ORACLE_HOST'])
      Actions.isUp?(CONFIG.get['ORACLE_HOST'])
  elsif (scenario.source[1].tags[0].name.to_s.include?('@sdata_lab'))
      CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']
      Actions.valid_IP_v4?(CONFIG.get['ORACLE_HOST'])
      Actions.isUp?(CONFIG.get['ORACLE_HOST'])
  elsif (!scenario.source[1].tags[0].name.to_s.include?('@mslCleaner') && !scenario.source[1].tags[0].name.to_s.include?('@test'))
    if scenario.source[1].tags[0].name.to_s.downcase.include?('lab')
      CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']
      CONFIG.get['CORE_HOST'] = CONFIG.get['CORE_HOST_IP']
    end
    Actions.valid_IP_v4?(CONFIG.get['ORACLE_HOST'])
    Actions.isUp?(CONFIG.get['ORACLE_HOST'])
    Actions.valid_IP_v4?(CONFIG.get['CORE_HOST'])
    Actions.isUp?(CONFIG.get['CORE_HOST'])
=begin
    if !scenario.source[1].tags[0].name.to_s.downcase.include?('lab') && !scenario.source[1].tags[0].name.to_s.include?('performance')
      Actions.valid_IP_v4?(CONFIG.get['MSL_HOST_IP'])
      Actions.isUp?(CONFIG.get['MSL_HOST_IP'])
      Actions.valid_IP_v4?(CONFIG.get['MSL_HOST2_IP'])
      Actions.isUp?(CONFIG.get['MSL_HOST2_IP'])
      isMslRunning?(CONFIG.get['MSL_HOST_IP'])
      isMslRunning?(CONFIG.get['MSL_HOST2_IP'])
    end
=end
  end

  if (scenario.source[1].tags[0].name.to_s.include?('@scratch')) && !scenario.source[1].tags[0].name.to_s.include?('performance') && !scenario.source[1].tags[0].name.to_s.downcase.include?('lab')
    Actions.setEnvVar(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],'_PTRADE_ERS_COUNT','0')
    Actions.setEnvVar(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],'_PTRADE1_ERS_COUNT','0')

    Actions.valid_IP_v4?(CONFIG.get['MSL_HOST_IP'])
    Actions.isUp?(CONFIG.get['MSL_HOST_IP'])
    Actions.valid_IP_v4?(CONFIG.get['MSL_HOST2_IP'])
    Actions.isUp?(CONFIG.get['MSL_HOST2_IP'])
    isMslRunning?(CONFIG.get['MSL_HOST_IP'])
    isMslRunning?(CONFIG.get['MSL_HOST2_IP'])
  end


 #performance
  if (scenario.source[1].tags[0].name.to_s.include?('Perf'))
    Actions.valid_IP_v4?(CONFIG.get['ORACLE_HOST'])
    Actions.isUp?(CONFIG.get['ORACLE_HOST'])
    Actions.valid_IP_v4?(CONFIG.get['CORE_HOST'])
    Actions.isUp?(CONFIG.get['CORE_HOST'])
    Actions.valid_IP_v4?(CONFIG.get['MSL_HOST2_IP'])
    Actions.isUp?(CONFIG.get['MSL_HOST2_IP'])
    isMslRunning?(CONFIG.get['MSL_HOST2_IP'])

    #start Automation Service
    #Service.start
    Actions.WINCMD_NO_FAIL('for /f "tokens=5" %a in ('+"'netstat -aon ^| findstr :1234') do taskkill /f /pid %a",60)
    Actions.WINCMD_NO_FAIL2("ruby "+Dir.getwd+"/Service.rb start",60)

    # killing er2tickets processes
    cmd ="kill -9 $(/bin/ps -U '"+CONFIG.get['CORE_HOST_USER']+"' -f|egrep -i 'er2tickets'|grep -v grep|awk '{print $2}')"
    res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 10)
    Actions.v 'Kill er2tickets res: '+res if !res.nil?

    # killing mslersender processes
    cmd="kill -9 $(/bin/ps -U '"+CONFIG.get['CORE_HOST_USER']+"' -f|egrep -i 'sender'|grep -v grep|awk '{print $2}')"
    res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 10)
    Actions.v 'Kill mslersender res: '+res if !res.nil?

    #killing ptrade processes
    #cmd ="kill -9 $(/bin/ps -U '"+CONFIG.get['CORE_HOST_USER']+"' -f|egrep -i 'ptrade'|grep -v grep|awk '{print $2}')"
    cmd ="kill -9 $(/bin/ps -U '"+CONFIG.get['CORE_HOST_USER']+"' -f|egrep -i 'com.ebs.pts\|service_watchdog.sh'|grep -v grep|awk '{print $2}')"
    res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 10)
    Actions.v 'Kill ptrade res: '+res if !res.nil?

    #killing FIX mockers
    cmd ="kill -9 $(/bin/ps -U '"+CONFIG.get['CORE_HOST_USER']+"' -f|egrep -i 'inititator'|grep -v grep|awk '{print $2}')"
    res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 10)
    Actions.v 'Kill inititator res: '+res if !res.nil?
    cmd ="kill -9 $(/bin/ps -U '"+CONFIG.get['CORE_HOST_USER']+"' -f|egrep -i 'acceptor'|grep -v grep|awk '{print $2}')"
    res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 10)
    Actions.v 'Kill acceptor res: '+res if !res.nil?

  end

  #sanity
  if (!scenario.source[1].tags[0].name.to_s.include?('@sanity-sdata-only') && !scenario.source[1].tags[0].name.to_s.include?('@test') && !scenario.source[1].tags[0].name.to_s.include?('@lab') && !scenario.source[1].tags[0].name.to_s.include?('@mslCleaner'))
      # killing er2tickets processes
      cmd ="kill -9 $(/bin/ps -U '"+CONFIG.get['CORE_HOST_USER']+" -f|egrep -i 'er2tickets'|grep -v grep|awk '{print $2}')"
      res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 10)

      cmd ="kill -9 $(/bin/ps -U '"+CONFIG.get['CORE_HOST_USER1']+"' -f|egrep -i 'er2tickets'|grep -v grep|awk '{print $2}')"
      res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], cmd, 10)


      cmd="kill -9 $(/bin/ps -aef |egrep -i 'sender'|grep -v grep|awk '{print $2}')"
      res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], cmd, 10)
      Actions.v 'Kill mslersender res: '+res if !res.nil?

      #killing FIX mockers
      cmd ="kill -9 $(/bin/ps -U '"+CONFIG.get['CORE_HOST_USER']+"' -f|egrep -i 'inititator'|grep -v grep|awk '{print $2}')"
      res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 10)
      Actions.v 'Kill inititator res: '+res if !res.nil?
      cmd ="kill -9 $(/bin/ps -U '"+CONFIG.get['CORE_HOST_USER']+"' -f|egrep -i 'acceptor'|grep -v grep|awk '{print $2}')"
      res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 10)
      Actions.v 'Kill acceptor res: '+res if !res.nil?
  end

  if (!scenario.source[1].tags[0].name.to_s.include?('@test')  && !scenario.source[1].tags[0].name.to_s.include?('@mslCleaner'))
    Actions.killUserProcesses(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['CORE_HOST_USER'] , "ptrade")
    Actions.killUserProcesses(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['CORE_HOST_USER1'] , "ptrade")
    Actions.killUserProcesses(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_PWD'], CONFIG.get['ORACLE_HOST_USER'] , "sdata")
    Actions.killUserProcesses(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_PWD'], CONFIG.get['ORACLE_HOST_USER'] , "sdata")
    Actions.killUserProcesses(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_PWD'], CONFIG.get['ORACLE_HOST_USER'] , "ptrade")
    Actions.killUserProcesses(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_PWD'], CONFIG.get['ORACLE_HOST_USER'] , "ptrade")
  end

  if (scenario.source[1].tags[0].name.to_s.include?('@test'))
     #Service.start
    ####Actions.WINCMD_NO_FAIL2("ruby "+Dir.getwd+"/Service.rb start",60)

=begin
    begin
      server = WEBrick::HTTPServer.new(:Port => 1234)
      server.mount "/", Service
      trap "INT" do
        #Actions.v 'Service GOT Shutdown'
        server.shutdown
      end
      Thread.new{server.start}
      #server.start
      Actions.v 'Service started on port '+port.to_s
    rescue Exception=>e
      fail("Start Service failed: " + e.message)
    end
=end
  end

end


After do |scenario|

  Actions.v 'Starting post-scenario tasks...'

  #saving versions to file for email
=begin
  Actions.v 'Saving build versions for emailing'
    file = File.new(Dir.getwd+'/config/build.properties',"w+")
   @@email_properties.each_key{|key,value|
     begin
       file.puts "#{key}=#{@@email_properties[key]}\n"
     rescue Exception=>e
       self.f('ERROR on write build properties '+ e.message)
     end
   }
=end

=begin
  if !scenario.source[1].tags[0].name.to_s.downcase.include?('performance') && !scenario.source[1].tags[0].name.to_s.downcase.include?('mslCleaner') && !scenario.source[1].tags[0].name.to_s.downcase.include?('sanity-sdata-only')
    failed = Actions.isBuildPropertyFailed?(['SDATA1_SCHEMA_VERSION_packageName','SDATA_SCHEMA_VERSION_packageName','PTRADE1_SCHEMA_VERSION','PTRADE1_APP_VERSION','PTRADE_SCHEMA_VERSION','PTRADE_APP_VERSION'])
    Actions.setBuildProperty('DEPLOY','Passed') if(!failed)
    Actions.setBuildProperty('STATUS','Passed') if(@@scenario_fails.empty? && Actions.getBuildProperty('DEPLOY').to_s.downcase == 'passed')
    Actions.setBuildProperty('STATUS','Diff found') if(!@@scenario_fails.empty? && Actions.getBuildProperty('DEPLOY').to_s.downcase == 'passed')
    Actions.setBuildProperty('STATUS','Setup failed') if( Actions.getBuildProperty('DEPLOY').to_s.downcase == 'failed')
  end
=end

   #sanity scratch
   if scenario.source[1].tags[0].name.to_s.include?('@scratch')
    if (!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
      Actions.displaySanityLogs(true, true, true, true)

      Actions.moveToFolderByMask(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation','bash_scripts','*.sh')
      Actions.moveToFolderByMask(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation','bash_scripts','*.sh')
      Actions.moveToFolderByMask(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation','bash_scripts','*.sh')

      Actions.removeDos2unixTmpFiles(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER'])
      Actions.removeDos2unixTmpFiles(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')
      Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER'])
      Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
      Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1'])
      Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation')
    else
      Actions.displaySanityLogs(false, false, true, true)

      Actions.moveToFolderByMask(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation','bash_scripts','*.sh')
      Actions.moveToFolderByMask(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation','bash_scripts','*.sh')

      Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER'])
      Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
      Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1'])
      Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation')
    end
   elsif scenario.source[1].tags[0].name.to_s.include?('@sanity-sdata-only')
     Actions.displaySanityLogs(true, true, false, false)

     Actions.moveToFolderByMask(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation','bash_scripts','*.sh')

     Actions.removeDos2unixTmpFiles(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER'])
     Actions.removeDos2unixTmpFiles(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')
   end

   #sanity upgrade
   if scenario.source[1].tags[0].name.to_s.include?('@sanity-with-sdata-productionVsUpgrade2-concurrent') || scenario.source[1].tags[0].name.to_s.include?('@sanity-with-sdata-lastVsUpgrade2-concurrent')
     if (!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
       Actions.displaySanityLogs(true, true, true, true)

       Actions.moveToFolderByMask(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation','bash_scripts','*.sh')
       Actions.moveToFolderByMask(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation','bash_scripts','*.sh')
       Actions.moveToFolderByMask(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation','bash_scripts','*.sh')

       Actions.removeDos2unixTmpFiles(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER'])
       Actions.removeDos2unixTmpFiles(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')
       Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER'])
       Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
       Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1'])
       Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation')
     else
       Actions.displaySanityLogs(false, false, true, true)

       Actions.moveToFolderByMask(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation','bash_scripts','*.sh')
       Actions.moveToFolderByMask(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation','bash_scripts','*.sh')

       Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER'])
       Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
       Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1'])
       Actions.removeDos2unixTmpFiles(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation')
     end
   end

   #custom builds
  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    Actions.displaySanityLogs(true, false, true, false) if(scenario.source[1].tags[0].name.to_s.include?('@sdata_and_ptrade_lab'))
    Actions.displaySanityLogs(true, false, false, false) if(scenario.source[1].tags[0].name.to_s.include?('@sdata_lab'))
    Actions.displaySanityLogs(false, false, true, false) if(scenario.source[1].tags[0].name.to_s.include?('@ptrade_lab'))
    Actions.displaySanityLogs(true, false, true, false) if(scenario.source[1].tags[0].name.to_s.include?('@ptrade_upgrade_lab') && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    Actions.displaySanityLogs(false, false, true, false) if(scenario.source[1].tags[0].name.to_s.include?('@ptrade_upgrade_lab') && CONFIG.get['DEPLOY_SDATA'].to_s.downcase!='true')
    Actions.displaySanityLogs(true, false, true, false) if(scenario.source[1].tags[0].name.to_s.include?('@ptrade_scratch_and_upgrade_lab') && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    Actions.displaySanityLogs(false, false, true, false) if(scenario.source[1].tags[0].name.to_s.include?('@ptrade_scratch_and_upgrade_lab') && CONFIG.get['DEPLOY_SDATA'].to_s.downcase!='true')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    Actions.displaySanityLogs(false, true, false, true) if(scenario.source[1].tags[0].name.to_s.include?('@sdata_and_ptrade_lab'))
    Actions.displaySanityLogs(false, true, false, false) if(scenario.source[1].tags[0].name.to_s.include?('@sdata_lab'))
    Actions.displaySanityLogs(false, false, false, true) if(scenario.source[1].tags[0].name.to_s.include?('@ptrade_lab'))
    Actions.displaySanityLogs(false, true, false, true) if(scenario.source[1].tags[0].name.to_s.include?('@ptrade_upgrade_lab') && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    Actions.displaySanityLogs(false, false, false, true) if(scenario.source[1].tags[0].name.to_s.include?('@ptrade_upgrade_lab') && CONFIG.get['DEPLOY_SDATA'].to_s.downcase!='true')
    Actions.displaySanityLogs(false, true, false, true) if(scenario.source[1].tags[0].name.to_s.include?('@ptrade_scratch_and_upgrade_lab') && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    Actions.displaySanityLogs(false, false, false, true) if(scenario.source[1].tags[0].name.to_s.include?('@ptrade_scratch_and_upgrade_lab') && CONFIG.get['DEPLOY_SDATA'].to_s.downcase!='true')
  end

   #scenario.fail('See Errors in Red') if(!@@scenario_fails.empty?)
  if (scenario.source[1].tags[0].name.to_s.include?('performance'))

    # killing er2tickets processes
    cmd ="kill -9 $(/bin/ps -U '+CONFIG.get['CORE_HOST_USER']+' -f|egrep -i 'er2tickets'|grep -v grep|awk '{print $2}')"
    res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 10)
    Actions.v 'Kill er2tickets res: '+res if !res.nil?

    # killing mslersender processes
    cmd="kill -9 $(/bin/ps -aef |egrep -i 'mslersender'|grep -v grep|awk '{print $2}')"
    res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 10)
    Actions.v 'Kill mslersender res: '+res if !res.nil?

    #killing ptrade processes
    cmd ="kill -9 $(/bin/ps -U '+CONFIG.get['CORE_HOST_USER']+' -f|egrep -i 'ptrade'|grep -v grep|awk '{print $2}')"
    res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 10)
    Actions.v 'Kill ptrade res: '+res if !res.nil?
  end
end


Around('@test') do |scenario, block|
  Timeout.timeout(6000) do
    block.call
    #puts '@test TIMEOUT'
  end
end

Around('@sanity-sdata-only') do |scenario, block|
  #Actions.displaySanityLogs(true, true, false, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(3000) do
    block.call
  end
end

Around('@sanity-with-sdata-oldAndNewVsUpgrade2') do |scenario, block|
  #Actions.displaySanityLogs(true, true, true, true) if(!@@scenario_fails.empty?)
  Timeout.timeout(3600) do
    block.call
  end
end

Around('@sanity-with-sdata-lastVsUpgrade2-concurrent') do |scenario, block|
  #Actions.displaySanityLogs(true, true, true, true) if(!@@scenario_fails.empty?)
  Timeout.timeout(3600) do
    block.call
  end
end


Around('@sanity-with-sdata-productionVsUpgrade2-concurrent-submitERsOnce') do |scenario, block|
  #Actions.displaySanityLogs(true, true, true, true) if(!@@scenario_fails.empty?)
  Timeout.timeout(3600) do
    block.call
  end
end

### Custom Builds

Around('@sdata_and_ptrade_lab') do |scenario, block|
  #Actions.displaySanityLogs(true, false, true, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i) do
    block.call
  end
end

Around('@sdata_lab') do |scenario, block|
  #Actions.displaySanityLogs(true, false, true, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i) do
    block.call
  end
end

Around('@ptrade_lab') do |scenario, block|
  #Actions.displaySanityLogs(true, false, true, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i) do
    block.call
  end
end

Around('@ptrade_upgrade_lab') do |scenario, block|
  #Actions.displaySanityLogs(true, false, false, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i) do
    block.call
  end
end

Around('@ptrade_scratch_and_upgrade_lab') do |scenario, block|
  #Actions.displaySanityLogs(true, false, false, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i) do
    block.call
  end
end