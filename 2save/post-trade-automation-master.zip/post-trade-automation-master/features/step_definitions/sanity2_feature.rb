require 'cucumber'
require 'net/ssh'
require 'net/scp'
require 'time'
require 'thread'
require 'thwait'

begin
  require '../../features/helpers/Actions'
  require '../../features/helpers/Config.rb'
  require '../../features/helpers/Globals'
  require '../../features/helpers/Service'
  include Config
rescue LoadError
end



Given /^SDATA SCHEMAS Setup is Done - Parcippany and Last Lab versions$/ do
  steps %Q{
      Given beforeScenarioStepsSdata
    }

  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    res = ''
    begin
      res = buildSdataSchema('sdata1', CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
    rescue Exception=>e
      @@scenario_fails.push('sdata1 build failed for version "'+CONFIG.get['SDATA_OLD_SCHEMA_VERSION']+'"')
      # Actions.displaySanityLogs(false, true, false, false)
      if (!res.nil? && !res.to_s.empty?)
        Actions.f 'ERROR:'+"\n"+res
      end
      fail('sdata1 build failed for version '+CONFIG.get['SDATA_OLD_SCHEMA_VERSION']+'"')
    end

    begin
      res = buildSdataSchema('sdata', (CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?) ? '' : CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])
    rescue Exception=>e
      @@scenario_fails.push('sdata build failed for the Latest version ')
      # Actions.displaySanityLogs(true, false, false, false)
      if (!res.nil? && !res.to_s.empty?)
        Actions.f 'ERROR:'+"\n"+res
      end
      fail('sdata build failed for the Latest version ')
    end

    displaySdataSchemaOldVersion
    displaySdataSchemaNewVersion
  else
    Actions.c '<b>NOT deploying SDATA</b>'
  end
end


### Concurrent


#sdata
Given /^SDATA SCHEMAS Concurrent Setup is Done - Production and New versions$/ do
  steps %Q{
      Given beforeScenarioSteps
    }

  if (CONFIG.get['SDATA_OLD_SCHEMA_VERSION'].nil? || CONFIG.get['SDATA_OLD_SCHEMA_VERSION'].to_s.empty?)
    begin
      storagePath = '/export/home/oracle/build_server/Releases/db_sdata'
      tarFilter1 = 'db_sdata_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 45, true, '')
      CONFIG.get['SDATA_OLD_SCHEMA_VERSION'] = res.to_s.strip
    rescue Exception => e
      @@scenario_fails.push('Error: failed to retrieve SDATA OLD_SCHEMA latest package name')
      fail('Error: failed to retrieve SDATA OLD_SCHEMA latest package name')
    end
  end

  if (CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    begin
      storagePath = '/export/home/oracle/build_server/Releases/db_sdata'
      tarFilter1 = 'db_sdata_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 45, true, '')
      CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'] = res.to_s.strip
    rescue Exception => e
      @@scenario_fails.push('Error: failed to retrieve SDATA NEW_SCHEMA latest package name')
      fail('Error: failed to retrieve SDATA NEW_SCHEMA latest package name')
    end
  end

  Actions.setBuildProperty('SDATA1_SCHEMA_VERSION',CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
  Actions.setBuildProperty('SDATA_SCHEMA_VERSION',CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])
  Actions.setBuildProperty('SDATA1_SCHEMA_VERSION_packageName', CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
  Actions.setBuildProperty('SDATA_SCHEMA_VERSION_packageName', CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])

  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    threads = []
    t1=Thread.new{buildOldSdataSchemaThread(CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])}
    t1.abort_on_exception = true
    threads << t1
    t2=Thread.new{buildNewSdataSchemaThread(CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])}
    t2.abort_on_exception = true
    t1.join
    threads << t2
    t2.join
    ThreadsWait.all_waits(*threads )
    fail('buildOldSdataSchemaTrhead failed for sdata1') if(t1.status.nil?)
    fail('buildNewSdataSchemaThread failed for sdata') if(t2.status.nil?)

    displaySdataSchemaOldVersion
    displaySdataSchemaNewVersion
=begin
    steps %Q{
      Then SDATA schema compared
    }
=end
  else
    Actions.c '<b>NOT deploying SDATA</b>'
  end
end


Given /^only SDATA SCHEMAS Concurrent Setup is Done - Production and New versions$/ do
  steps %Q{
      Given beforeScenarioStepsSdata
    }

  if (CONFIG.get['SDATA_OLD_SCHEMA_VERSION'].nil? || CONFIG.get['SDATA_OLD_SCHEMA_VERSION'].to_s.empty?)
    begin
      storagePath = '/export/home/oracle/build_server/Releases/db_sdata'
      tarFilter1 = 'db_sdata_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 45, true, '')
      CONFIG.get['SDATA_OLD_SCHEMA_VERSION'] = res.to_s.strip
    rescue Exception => e
      @@scenario_fails.push('Error: failed to retrieve SDATA OLD_SCHEMA latest package name')
      fail('Error: failed to retrieve SDATA OLD_SCHEMA latest package name')
    end
  end

  if (CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    begin
      storagePath = '/export/home/oracle/build_server/Releases/db_sdata'
      tarFilter1 = 'db_sdata_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 45, true, '')
      CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'] = res.to_s.strip
    rescue Exception => e
      @@scenario_fails.push('Error: failed to retrieve SDATA NEW_SCHEMA latest package name')
      fail('Error: failed to retrieve SDATA NEW_SCHEMA latest package name')
    end
  end

  Actions.setBuildProperty('SDATA1_SCHEMA_VERSION',CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
  Actions.setBuildProperty('SDATA_SCHEMA_VERSION',CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])
  Actions.setBuildProperty('SDATA1_SCHEMA_VERSION_packageName', CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
  Actions.setBuildProperty('SDATA_SCHEMA_VERSION_packageName', CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])

  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    threads = []
    t1=Thread.new{buildOldSdataSchemaThread(CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])}
    t1.abort_on_exception = true
    threads << t1
    t2=Thread.new{buildNewSdataSchemaThread(CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])}
    t2.abort_on_exception = true
    t1.join
    threads << t2
    t2.join
    ThreadsWait.all_waits(*threads )
    fail('buildOldSdataSchemaTrhead failed for sdata1') if(t1.status.nil?)
    fail('buildNewSdataSchemaThread failed for sdata') if(t2.status.nil?)

    displaySdataSchemaOldVersion
    displaySdataSchemaNewVersion
    steps %Q{
      Then SDATA schema compared
    }
  else
    Actions.c '<b>NOT deploying SDATA</b>'
  end
end

Given /^SDATA Setup is Done$/ do
  steps %Q{
      Given beforeScenarioSteps
    }


  if (CONFIG.get['SDATA_OLD_SCHEMA_VERSION'].nil? || CONFIG.get['SDATA_OLD_SCHEMA_VERSION'].to_s.empty?)
    begin
      storagePath = '/export/home/oracle/build_server/Releases/db_sdata'
      tarFilter1 = 'db_sdata_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 45, true, '')
      CONFIG.get['SDATA_OLD_SCHEMA_VERSION'] = res.to_s.strip
    rescue Exception => e
      @@scenario_fails.push('Error: failed to retrieve OLD_SCHEMA latest package name for sdata')
      fail('Error: failed to retrieve OLD_SCHEMA latest package name for sdata')
    end
  end

  Actions.setBuildProperty('SDATA_SCHEMA_VERSION',CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
  Actions.setBuildProperty('SDATA_SCHEMA_VERSION_packageName', CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])


  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    buildNewSdataSchemaThread(CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
  else
    Actions.p '<b>NOT deploying SDATA</b>'
  end
  displaySdataSchemaNewVersion
end


Given /^SDATA SCHEMAS Concurrent Setup is Done - Production version for both users$/ do
  steps %Q{
      Given beforeScenarioSteps
    }

  if (CONFIG.get['SDATA_OLD_SCHEMA_VERSION'].nil? || CONFIG.get['SDATA_OLD_SCHEMA_VERSION'].to_s.empty?)
    begin
      storagePath = '/export/home/oracle/build_server/Releases/db_sdata'
      tarFilter1 = 'db_sdata_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 45, true, '')
      CONFIG.get['SDATA_OLD_SCHEMA_VERSION'] = res.to_s.strip
    rescue Exception => e
      @@scenario_fails.push('Error: failed to retrieve OLD_SCHEMA latest package name for sdata')
      fail('Error: failed to retrieve OLD_SCHEMA latest package name for sdata')
    end
  end

  Actions.setBuildProperty('SDATA1_SCHEMA_VERSION',CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
  Actions.setBuildProperty('SDATA_SCHEMA_VERSION',CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
  Actions.setBuildProperty('SDATA1_SCHEMA_VERSION_packageName', CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
  Actions.setBuildProperty('SDATA_SCHEMA_VERSION_packageName', CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])


if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    threads = []
    t1=Thread.new{buildOldSdataSchemaThread(CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])}
    t1.abort_on_exception = true
    threads << t1
    t2=Thread.new{buildNewSdataSchemaThread(CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])}
    t2.abort_on_exception = true
    t1.join
    threads << t2
    t2.join
    ThreadsWait.all_waits(*threads )
    fail('buildOldSdataSchemaThread failed for sdata1') if(t1.status.nil?)
    fail('buildNewSdataSchemaThread failed for sdata') if(t2.status.nil?)

    displaySdataSchemaOldVersion
    displaySdataSchemaNewVersion
    # steps %Q{
    #  Then $csv_compare_errors
    # }
  else
    Actions.c '<b>NOT deploying SDATA</b>'
  end
end


def buildOldSdataSchemaThread(schema_version)
  sleep CONFIG.get['WAIT_FOR_ONE_THREAD_SDATA'].to_i
  res = ''
  begin
    res = buildSdataSchema('sdata1', schema_version)
  rescue Exception => e
    @@scenario_fails.push('sdata1 build failed for version "'+CONFIG.get['SDATA_OLD_SCHEMA_VERSION']+'"')
    # Actions.displaySanityLogs(false, true, false, false)
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('sdata1 build failed for version "'+CONFIG.get['SDATA_OLD_SCHEMA_VERSION']+'"')
  end
end


def buildNewSdataSchemaThread(schema_version)
  res = ''
  begin
    res = buildSdataSchema('sdata', schema_version)
  rescue Exception => e
    @@scenario_fails.push('sdata build failed for version "'+schema_version+'"')
    # Actions.displaySanityLogs(true, false, false, false)
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('sdata build failed for version "'+schema_version+'"')
  end
end


### sdata end


###scratch
Given /^Ptrade App And Schema are built for performance(.*)$/ do |perf_index|

  #start Fix mockers
  Actions.v "Starting FIX mockers..."
  home=CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']
  mocker_bin=home+'/FixTools-1.7.0/bin/'
  cmd=mocker_bin+"acceptor.sh start"
  res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],cmd,60)
  Actions.v 'Acceptor Started: '+res if res
  cmd=mocker_bin+"acceptor.sh status"
  res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],cmd,60)
  Actions.v 'Acceptor Status: '+res if res
  cmd=mocker_bin+"initiator.sh start"
  res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],cmd,60)
  Actions.v 'Initiator Started: '+res if res
  cmd=mocker_bin+"initiator.sh status"
  res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],cmd,60)
  Actions.v 'Initiator Status: '+res if res

  Actions.v 'Deleting old previous logs'
  cmd="cd $HOME/PTS/logs/previous && rm -rf *"
  Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],cmd,20)

  if(!ENV['DEPLOY_PTRADE'].nil? && ENV['DEPLOY_PTRADE'].to_s.downcase=='true')
    if (CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
      begin
        storagePath = '/export/home/oracle/build_server/Releases/PTS'
        tarFilter1 = 'PTS_MAIN_'
        tarFilter2 = '.tar.gz'
        cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
        res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 45, true, '')
        CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'] = res.to_s.strip
      rescue Exception => e
        @@scenario_fails.push('Error: failed to retrieve PTRADE OLD_SCHEMA latest package name')
        fail('Error: failed to retrieve PTRADE NEW_SCHEMA latest package name')
      end
    end

    Actions.setBuildProperty('PTRADE_SCHEMA_VERSION',CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'])
    Actions.WINCMD('copy /Y c:\CPT_ERs_Scratch\*.* '+Dir.getwd.gsub('/','\\')+'\templates\ers', 60 ,'file')

    app_version=CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU']
    deleteFolderContentsOnRemoteServerIfFolderExist(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'Automation/ers')
    deleteFolderContentsOnRemoteServerIfFolderExist(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'Automation/ers2')
    createAutomationDirForUser(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
    uploadDir2RemoteAutomationFolder(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')
    buildPtradeNewSchema2(app_version) #CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU']
    uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
    uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/ers')
    uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/er_perf2', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/er_perf2/')
    uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/config',CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
    buildPtradeApp2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], app_version, false)  #CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU']
    displayPtradeAppVersion(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
    uploadFileToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'prod.conf', Dir.getwd+'/templates/upgrade_app_config2', CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/config') if perf_index.to_i==1
    if perf_index.to_i==2
      cmd = "cd $HOME/PTS/config && rm -rf *"
      Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],cmd,20)
      uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/perf2_app_config/config/', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/PTS/config/')
    end

    #createCsvDirsForUserOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
    deleteCsvFilesOnRemoteServerForNewVersion

  else
    Actions.p  'NOT deploying PTRADE'
    displayPtradeAppVersion(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

    deleteFolderContentsOnRemoteServerIfFolderExist(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'Automation/ers')
    deleteFolderContentsOnRemoteServerIfFolderExist(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'Automation/ers2')
    uploadDir2RemoteAutomationFolder(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')
    createAutomationDirForUser(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
    uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
    uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/ers')
    uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/config',CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
    uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/er_perf2', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/er_perf2/')
    uploadFileToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'prod.conf', Dir.getwd+'/templates/upgrade_app_config2', CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/config') if perf_index.to_i==1
    if perf_index.to_i==2
      cmd = "cd $HOME/PTS/config && rm -rf *"
      Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],cmd,20)
      uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/perf2_app_config/config/', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/PTS/config/')
    end
    #createCsvDirsForUserOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
    deleteCsvFilesOnRemoteServerForNewVersion


    schema=CONFIG.get['CORE_HOST_USER'].to_s.downcase
    query="DELETE from AUDIT_IN"
    Actions.insertToDbWithCommit(schema, schema, query)
    query="DELETE from FX_DEAL"
    Actions.insertToDbWithCommit(schema, schema, query)
    query="DELETE from FX_DEAL_LEG"
    Actions.insertToDbWithCommit(schema, schema, query)
    query="DELETE from FX_TICKET_LEG"
    Actions.insertToDbWithCommit(schema, schema, query)
    query="UPDATE SD_TARGET set LAST_ID = NULL, LAST_SESSION = NULL, LAST_SRC_SESSION = NULL, LAST_SRC_ID = NULL"
    Actions.insertToDbWithCommit(schema, schema, query)

  end



end


Given /^Ptrade Apps And Schemas are built for Production version and  New version$/ do
  Actions.v "JENKINS_JOB_NAME: "+(!@@CONFIG['JENKINS_JOB_NAME'].nil? ? @@CONFIG['JENKINS_JOB_NAME'] : " NOT_DEFINED ")

  if (CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].nil? || CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].to_s.empty?)
    begin
      storagePath = '/export/home/oracle/build_server/Releases/PTS'
      tarFilter1 = 'PTS_MAIN_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 45, true, '')
      CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'] = res.to_s.strip
    rescue Exception => e
      @@scenario_fails.push('Error: failed to retrieve PTRADE OLD_SCHEMA latest package name')
      fail('Error: failed to retrieve PTRADE OLD_SCHEMA latest package name')
    end
  end

  if (CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    begin
      storagePath = '/export/home/oracle/build_server/Releases/PTS'
      tarFilter1 = 'PTS_MAIN_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 45, true, '')
      CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'] = res.to_s.strip
    rescue Exception => e
      @@scenario_fails.push('Error: failed to retrieve PTRADE OLD_SCHEMA latest package name')
      fail('Error: failed to retrieve PTRADE NEW_SCHEMA latest package name')
    end
  end

  Actions.setBuildProperty('PTRADE1_SCHEMA_VERSION',CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'])
  Actions.setBuildProperty('PTRADE_SCHEMA_VERSION',CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'])
  Actions.WINCMD('copy /Y c:\CPT_ERs_Scratch\*.* '+Dir.getwd.gsub('/','\\')+'\templates\ers', 60 ,'file')
  Actions.WINCMD('copy /Y c:\CPT_ERs_Upgrade\*.* '+Dir.getwd.gsub('/','\\')+'\templates\ers2', 60 ,'file')

  threads = []
  old_app_version=CONFIG.get['PTRADE_OLD_SCHEMA_VERSION']
  @@old_ptrade_version_number = old_app_version.scan(/PTS_MAIN_\d+.\d+.\d+.\d+.(\d+)/)[0][0] if !old_app_version.to_s.strip.empty?
  t1=Thread.new{buildPtradeAppForProductionVersionThread(old_app_version)}
  t1.abort_on_exception = true
  threads << t1
  new_app_version=CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU']
  t2=Thread.new{buildPtradeAppForLatestLabVersionThread(new_app_version)}
  t2.abort_on_exception = true
  t1.join
  threads << t2
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('Ptrade App and Schema build failed for user ptrade1') if(t1.status.nil?)
  fail('Ptrade App and Schema build failed for user ptrade') if(t2.status.nil?)

end

def buildPtradeAppForProductionVersionThread(app_version)
  sleep CONFIG.get['WAIT_FOR_ONE_THREAD_PTRADE'].to_i
  ##Actions.createLocalDirs
  Actions.removeOldOutput
  deleteFolderContentsOnRemoteServerIfFolderExist(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], 'Automation/ers')
  deleteFolderContentsOnRemoteServerIfFolderExist(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], 'Automation/ers2')
  createAutomationDirForUser(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  buildPtradeOldSchema2(app_version)  if(!ENV['DEPLOY_PTRADE'].nil? && ENV['DEPLOY_PTRADE'].to_s.downcase=='true')
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation')
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/ers')
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/config', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation')
  Actions.cleanupMsl(CONFIG.get['CORE_HOST_USER1'], CONFIG.get['MSL_HOST_IP'])
  buildPtradeApp2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], app_version, false)  if(!ENV['DEPLOY_PTRADE'].nil? && ENV['DEPLOY_PTRADE'].to_s.downcase=='true')
  displayPtradeAppVersion(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  uploadFileToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], 'prod.conf', Dir.getwd+'/templates/old_app_config2', CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/config')
  #uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/old_app_config2/fix/rtns/qfj.cfg', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/PTS/config/fix/rtns/qfj.cfg')
begin
  deleteCsvFilesOnRemoteServerForOldVersion
  createCsvDirsForUserOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  restartRedisWithNewConfigForOldVersion2
  restartPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER1'], true, 'ers', CONFIG.get['MSL_HOST_IP'])
  Actions.downloadPTSLogs(true, false)
  runPtsLogParser(CONFIG.get['CORE_HOST_USER1'],CONFIG.get['REMOTE_PTRADE1_TEMPLATE_DIR_PATH']+'/'+'ers')
  downloadCsvFolderForOldVersion
  downloadJsonForOldVersion
  #downloadTidyLogForOldVersion
  #Actions.checkRtnsDelievery(Dir.getwd + '/templates/old_app_rtns/'+@@time_stamp+'/pts_tidy_3.log', CONFIG.get['CORE_HOST_USER1'])
  stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
rescue Exception=>e
  err_msg='Failed in one of [createCsvDirs, restartRedis, printMessagesCountFromMsl, runMslSender, runPtsLogParser, stopPtradeService ... ]'
  err_msg+=e.message if !e.message.nil
  fail(err_msg)
end
end




def buildPtradeAppForLatestLabVersionThread(app_version)
  #Actions.createLocalDirs
  #Actions.removeOldOutput
  deleteFolderContentsOnRemoteServerIfFolderExist(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'Automation/ers')
  deleteFolderContentsOnRemoteServerIfFolderExist(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'Automation/ers2')
  createAutomationDirForUser(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  uploadDir2RemoteAutomationFolder(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')
  buildPtradeNewSchema2(app_version)  if(!ENV['DEPLOY_PTRADE'].nil? && ENV['DEPLOY_PTRADE'].to_s.downcase=='true')
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/ers')
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/config',CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  Actions.cleanupMsl(CONFIG.get['CORE_HOST_USER'], CONFIG.get['MSL_HOST2_IP'])
  buildPtradeApp2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], app_version, false)   if(!ENV['DEPLOY_PTRADE'].nil? && ENV['DEPLOY_PTRADE'].to_s.downcase=='true')
  displayPtradeAppVersion(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
begin
  uploadFileToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'prod.conf', Dir.getwd+'/templates/upgrade_app_config2', CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/config')
  #uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/upgrade_app_config2/fix/rtns/qfj.cfg', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTS/config/fix/rtns/qfj.cfg')
  createCsvDirsForUserOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  deleteCsvFilesOnRemoteServerForNewVersion
  createCsvDirsForUserOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  restartRedisWithNewConfigForNewVersion2
  restartPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER'], true, 'ers', CONFIG.get['MSL_HOST2_IP'])
  Actions.downloadPTSLogs(false, true)
  runPtsLogParser(CONFIG.get['CORE_HOST_USER'],CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+'ers')
  downloadCsvFolderForNewVersion
  downloadJsonForNewVersion
  #downloadTidyLogForNewVersion
  #Actions.checkRtnsDelievery(Dir.getwd + '/templates/new_app_rtns/'+@@time_stamp+'/pts_tidy_3.log', CONFIG.get['CORE_HOST_USER'])
  stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
 rescue Exception=>e
  err_msg='Failed in one of [createCsvDirs, restartRedis, printMessagesCountFromMsl, runMslSender, runPtsLogParser, stopPtradeService ... ]'
  err_msg+=e.message if !e.message.nil
  fail(err_msg)
 end

end

### scratch end

### Start Upgrade
Given /^Ptrade Apps And Schemas are built for Production for both users and send ERs="(.*?)"$/ do |sendERs|
  if (CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].nil? || CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].to_s.empty?)
    begin
      storagePath = '/export/home/oracle/build_server/Releases/PTS'
      tarFilter1 = 'PTS_MAIN_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 45, true, '')
      CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'] = res.to_s.strip
    rescue Exception => e
      @@scenario_fails.push('Error: failed to retrieve PTRADE OLD_SCHEMA latest package name')
      fail('Error: failed to retrieve PTRADE OLD_SCHEMA latest package name')
    end
  end

  Actions.setBuildProperty('PTRADE1_SCHEMA_VERSION',CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'])
  Actions.setBuildProperty('PTRADE_SCHEMA_VERSION',CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'])

  Actions.WINCMD('copy /Y c:\CPT_ERs_Scratch\*.* '+Dir.getwd.gsub('/','\\')+'\templates\ers', 60 ,'file')
  Actions.WINCMD('copy /Y c:\CPT_ERs_Upgrade\*.* '+Dir.getwd.gsub('/','\\')+'\templates\ers2', 60 ,'file')

  threads = []
  old_app_version=CONFIG.get['PTRADE_OLD_SCHEMA_VERSION']
  @@old_ptrade_version_number = old_app_version.scan(/PTS_MAIN_\d+.\d+.\d+.\d+.(\d+)/)[0][0] if !old_app_version.to_s.strip.empty?
  mustSendERs = sendERs.to_bool
  t1=Thread.new{buildPtradeAppForProductionVersionAsSourceThread(old_app_version,old_app_version,mustSendERs)}
  t1.abort_on_exception = true
  threads << t1
  new_app_version=CONFIG.get['PTRADE_OLD_SCHEMA_VERSION']
  t2=Thread.new{buildPtradeAppAndUpgradeProductionWithLatestLabVersionThread(new_app_version,mustSendERs)}
  t2.abort_on_exception = true
  t1.join
  threads << t2
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('Ptrade App and Schema build failed for user ptrade1') if(t1.status.nil?)
  fail('Ptrade App and Schema build failed for user ptrade') if(t2.status.nil?)
end


Given /^Ptrade Apps And Schemas are built for New and Production versions and send ERs="(.*?)"$/ do |sendERs|
  threads = []
  old_app_version=CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.strip.empty? ? '' : CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.strip
  # old_app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER1'],true) if old_app_version.nil? || old_app_version.to_s.strip.empty?
  if old_app_version.nil? || old_app_version.to_s.strip.empty?
    begin
      storagePath = '/export/home/oracle/build_server/Releases/PTS'
      tarFilter1 = 'PTS_MAIN_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 45, true, '')
      old_app_version = res.to_s.strip
    rescue Exception => e
      @@scenario_fails.push('Error: failed to retrieve PTRADE NEW_SCHEMA latest package name')
      fail('Error: failed to retrieve PTRADE NEW_SCHEMA latest package name')
    end
  end

  new_app_version=CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].nil? || CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].to_s.strip.empty? ? '' : CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].to_s.strip
  if new_app_version.nil? || new_app_version.to_s.strip.empty?
    begin
      storagePath = '/export/home/oracle/build_server/Releases/PTS'
      tarFilter1 = 'PTS_MAIN_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 45, true, '')
      new_app_version = res.to_s.strip
    rescue Exception => e
      @@scenario_fails.push('Error: failed to retrieve PTRADE OLD_SCHEMA latest package name')
      fail('Error: failed to retrieve PTRADE OLD_SCHEMA latest package name')
    end
  end

  Actions.setBuildProperty('PTRADE1_SCHEMA_VERSION',old_app_version)
  Actions.setBuildProperty('PTRADE1_APP_VERSION',old_app_version)
  Actions.setBuildProperty('PTRADE_SCHEMA_VERSION',new_app_version)
  Actions.setBuildProperty('PTRADE_APP_VERSION',new_app_version)
  Actions.WINCMD('copy /Y c:\CPT_ERs_Scratch\*.* '+Dir.getwd.gsub('/','\\')+'\templates\ers', 60 ,'file')
  Actions.WINCMD('copy /Y c:\CPT_ERs_Upgrade\*.* '+Dir.getwd.gsub('/','\\')+'\templates\ers2', 60 ,'file')

  @@old_ptrade_version_number = old_app_version.scan(/PTS_MAIN_\d+.\d+.\d+.\d+.(\d+)/)[0][0] if !old_app_version.to_s.strip.empty?
  t1=Thread.new{buildPtradeAppForProductionVersionAsSourceThread(old_app_version,old_app_version,sendERs.to_bool)}
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new{buildPtradeAppAndUpgradeProductionWithLatestLabVersionThread(new_app_version,sendERs.to_bool)}
  t2.abort_on_exception = true
  t1.join
  threads << t2
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('Ptrade App and Schema build failed for user ptrade1') if(t1.status.nil?)
  fail('Ptrade App and Schema build failed for user ptrade') if(t2.status.nil?)
end


def buildPtradeAppForProductionVersionAsSourceThread(app_version,schema_version,mustSendERs)
  sleep CONFIG.get['WAIT_FOR_ONE_THREAD_PTRADE'].to_i
  createAutomationDirForUser(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  buildPtradeOldSchema2(schema_version)
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation')
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/ers')
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/config', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation')
  Actions.cleanupMsl(CONFIG.get['CORE_HOST_USER1'], CONFIG.get['MSL_HOST_IP'])
  buildPtradeApp2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], app_version, false)
  displayPtradeAppVersion(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/old_app_config2/prod.conf', CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/config/prod.conf')

 begin
  #uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/old_app_config2/fix/rtns/qfj.cfg', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/PTS/config/fix/rtns/qfj.cfg')
  createCsvDirsForUserOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  if (mustSendERs)
    Actions.v app_version+' mustSendERs: '+mustSendERs.to_s
    restartRedisWithNewConfigForOldVersion2
    restartPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
    Actions.printMessagesCountFromMsl(CONFIG.get['MSL_HOST_IP'],CONFIG.get['MSL_HOST_USER'],CONFIG.get['MSL_HOST_PWD'])
    runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER1'], true, 'ers', CONFIG.get['MSL_HOST_IP'])
    Actions.printMessagesCountFromMsl(CONFIG.get['MSL_HOST_IP'],CONFIG.get['MSL_HOST_USER'],CONFIG.get['MSL_HOST_PWD'])
    runPtsLogParser(CONFIG.get['CORE_HOST_USER1'],CONFIG.get['REMOTE_PTRADE1_TEMPLATE_DIR_PATH']+'/'+'ers')
    #Actions.checkRtnsDelievery(Dir.getwd + '/templates/old_app_rtns/'+@@time_stamp+'/pts_tidy_3.log', CONFIG.get['CORE_HOST_USER1'])
    stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  end
 rescue Exception=>e
   err_msg='Failed in one of [createCsvDirs, restartRedis, printMessagesCountFromMsl, runMslSender, runPtsLogParser, stopPtradeService ... ]'
   err_msg+=e.message if !e.message.nil
   fail(err_msg)
 end
end


def buildPtradeAppAndUpgradeProductionWithLatestLabVersionThread(app_version,mustSendERs)
  createAutomationDirForUser(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  uploadDir2RemoteAutomationFolder(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')
  buildPtradeNewSchema2(app_version)
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/ers')
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/config',CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  Actions.cleanupMsl(CONFIG.get['CORE_HOST_USER'], CONFIG.get['MSL_HOST2_IP'])
  buildPtradeApp2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], app_version, false)
  displayPtradeAppVersion(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/upgrade_app_config2/prod.conf', CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/config/prod.conf')
  #uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/upgrade_app_config2/fix/rtns/qfj.cfg', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTS/config/fix/rtns/qfj.cfg')
  createCsvDirsForUserOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
 begin
  if (mustSendERs)
    Actions.v app_version+' mustSendERs: '+mustSendERs.to_s
    restartRedisWithNewConfigForNewVersion2
    restartPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
    Actions.printMessagesCountFromMsl(CONFIG.get['MSL_HOST2_IP'],CONFIG.get['MSL_HOST_USER'],CONFIG.get['MSL_HOST_PWD'])
    runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER'], true, 'ers', CONFIG.get['MSL_HOST2_IP'])
    Actions.printMessagesCountFromMsl(CONFIG.get['MSL_HOST2_IP'],CONFIG.get['MSL_HOST_USER'],CONFIG.get['MSL_HOST_PWD'])
    runPtsLogParser(CONFIG.get['CORE_HOST_USER'],CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+'ers')
    #Actions.checkRtnsDelievery(Dir.getwd + '/templates/new_app_rtns/'+@@time_stamp+'/pts_tidy_3.log', CONFIG.get['CORE_HOST_USER'])
    stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  end
 rescue Exception=>e
  err_msg='Failed in one of [createCsvDirs, restartRedis, printMessagesCountFromMsl, runMslSender, runPtsLogParser, stopPtradeService ...]'
  err_msg+=e.message if !e.message.nil
  fail(err_msg)
 end
end


Given /^MslErSender sent another tickets dir for both users$/ do
  er_folder='ers2'
  threads = []
  t1=Thread.new{runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER1'], true, er_folder, CONFIG.get['MSL_HOST_IP'])}
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new{runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER'], true, er_folder, CONFIG.get['MSL_HOST2_IP'])}
  t2.abort_on_exception = true
  t1.join
  threads << t2
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('MslErSender failed for user ptrade1 with folder ' + er_folder) if(t1.status.nil?)
  fail('MslErSender failed for user ptrade with folder ' + er_folder) if(t2.status.nil?)
end


Given /^Ptrade App and Schemas are Upgraded to the New Sdata and New Ptrade version$/ do
  ### Upgrade 2nd App to the latest lab version (or to Custom version if needed)

  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')

    if (CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
      storagePath = '/export/home/oracle/build_server/Releases/db_sdata'
      tarFilter1 = 'db_sdata_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 45, true, '')
      CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'] = res.to_s.strip
    end

    Actions.setBuildProperty('SDATA_SCHEMA_VERSION',CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])
    Actions.setBuildProperty('SDATA_SCHEMA_VERSION_packageName', CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])

    res = ''
    begin
      res = buildSdataSchema('sdata', CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])
      displaySdataSchemaNewVersion
    rescue Exception=>e
      @@scenario_fails.push('Sdata schema deployment failed for version '+CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU']) if(!CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? && !CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
      @@scenario_fails.push('Sdata schema deployment failed for the last version') if(CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? && CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
      # Actions.displaySanityLogs(false, false, true, false)
      if (!res.nil? && !res.to_s.empty?)
        Actions.f 'ERROR:'+"\n"+res
      end
      fail('Sdata schema deployment failed for version '+CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU']) if(!CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? && !CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
      fail('Sdata schema deployment failed for the last version') if(CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? && CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    end
  else
    Actions.v 'NOT deploying SDATA for Upgrade version'
  end

  if (CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    storagePath = '/export/home/oracle/build_server/Releases/PTS'
    tarFilter1 = 'PTS_MAIN_'
    tarFilter2 = '.tar.gz'
    cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 45, true, '')
    CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'] = res.to_s.strip
  end

  Actions.setBuildProperty('PTRADE_SCHEMA_VERSION',CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'])
  Actions.setBuildProperty('PTRADE_APP_VERSION',CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'])

  res = ''
  begin
    res = upgradePtradeSchemaToNewLabVersion
  rescue Exception=>e
    @@scenario_fails.push('Ptrade schema upgrade failed')
    # Actions.displaySanityLogs(false, false, true, false)
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('Ptrade schema upgrade failed for version '+CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU']) if(!CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && !CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    fail('Ptrade schema upgrade failed for the last version') if(CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
  end

  buildPtradeApp2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'], true)
  displayPtradeAppAndDbVersionForUpgrade(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/upgrade_app_config2/prod.conf', CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/config/prod.conf')
  #uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/upgrade_app_config2/fix/rtns/qfj.cfg', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTS/config/fix/rtns/qfj.cfg')

end


Then /^Ptrade App is restarted and ERs sent after upgrade restart="(.*?)"$/ do |sendERsAfterRestart|
 return if(!sendERsAfterRestart.to_bool)
  threads = []
  t1=Thread.new{sendErsRestartAndDownloadDataForOldVersion(CONFIG.get['CORE_HOST_USER1'], true)}
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new{sendErsRestartAndDownloadDataForNewVersion(CONFIG.get['CORE_HOST_USER'], true)}
  t2.abort_on_exception = true
  t1.join
  threads << t2
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('restartAndDownloadDataForOldVersion failed for user ptrade1') if(t1.status.nil?)
  fail('restartAndDownloadDataForNewVersion failed for user ptrade') if(t2.status.nil?)
end


Then /^ERs sent after upgrade restart$/ do
     threads = []
     t1=Thread.new{sendErsRestartAndDownloadDataForOldVersion(CONFIG.get['CORE_HOST_USER1'], true, true, true)}
     t1.abort_on_exception = true
     threads << t1
     t2=Thread.new{sendErsRestartAndDownloadDataForNewVersion(CONFIG.get['CORE_HOST_USER'], true, true, false)}
     t2.abort_on_exception = true
     t1.join
     threads << t2
     t2.join
     ThreadsWait.all_waits(*threads )
     fail('restartAndDownloadDataForOldVersion failed for user ptrade1') if(t1.status.nil?)
     fail('restartAndDownloadDataForNewVersion failed for user ptrade') if(t2.status.nil?)
end


Then /^Msl is restarted$/ do
  mslIP=CONFIG.get['MSL_HOST2_IP']
  mslCount=Actions.printMessagesCountFromMsl(mslIP,CONFIG.get['MSL_HOST_USER'],CONFIG.get['MSL_HOST_PWD'])
  mslCount=mslCount.scan(/\d+/)[0]
  Actions.v 'mslCount: '+mslCount.to_s+" messages found in MSL table 'messages'"+mslIP

  Actions.cleanupMsl(CONFIG.get['CORE_HOST_USER'], CONFIG.get['MSL_HOST2_IP'])

  mslIP=CONFIG.get['MSL_HOST2_IP']
  mslCount=Actions.printMessagesCountFromMsl(mslIP,CONFIG.get['MSL_HOST_USER'],CONFIG.get['MSL_HOST_PWD'])
  mslCount=mslCount.scan(/\d+/)[0]
  Actions.v 'mslCount: '+mslCount.to_s+" messages found in MSL table 'messages'"+mslIP
end


Then /^ERs sent for DB presetup(.*)$/ do |perf_index|
  ENV["ptrade_is_stopped"]=nil
  ENV["no_tidy_tickets_found"]=nil

  wait_secs = 60
  wait_secs = ENV['LOOP_MSL_SECS'].to_i if(!ENV['LOOP_MSL_SECS'].nil? && ENV['LOOP_MSL_SECS'].is_number?)
  cmd = "rm -rf $HOME/Automation/mslErSenderPerf1.log && cd $HOME/MSLErSender_1.2_"+CONFIG.get['MSL_HOST2_IP']+"/bin && ./mslErSender.sh -s $HOME/Automation/ers/ -i 1 -p 50  >> $HOME/Automation/mslErSenderPerf1.log" if perf_index.to_i == 1
  cmd = "rm -rf $HOME/Automation/mslErSenderPerf2.log && cd $HOME/MSLErSender_1.2_"+CONFIG.get['MSL_HOST2_IP']+"/bin && ./mslErSender.sh -s $HOME/Automation/er_perf2/ -i 1 -p 10  >> $HOME/Automation/mslErSenderPerf2.log" if perf_index.to_i == 2 #er_perf2/  -i 1 -p 50

  Actions.cleanupMsl(CONFIG.get['CORE_HOST_USER'], CONFIG.get['MSL_HOST2_IP'],60)
  restartRedisWithNewConfigForNewVersion2
  #delete logs from the previous run
  del_cmd="cd $HOME/PTS/logs/previous && rm -rf *"
  Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],del_cmd,20)
  del_cmd="cd $HOME/PTS/logs && rm -rf *"
  Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],del_cmd,20)
  Actions.restartPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  runRemoteMslSender2(CONFIG.get['CORE_HOST_USER'], CONFIG.get['MSL_HOST2_IP'], cmd, wait_secs)

  home=CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']
  Actions.v 'Run stopPtradeIfNoTickets.sh'
  cmd="cd "+home+'/Automation && ./stopPtradeIfNoTickets'+".sh"
  res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 600)
  Actions.v 'stopPtradeIfNoTickets res: '+res if !res.nil?

  wait_notifications_secs = 0 #Loop forever
  wait_notifications_secs = ENV['NOTIFICATON_WAIT'].to_i if(!defined?(ENV['NOTIFICATON_WAIT']).nil? && !ENV['NOTIFICATON_WAIT'].nil? && ENV['NOTIFICATON_WAIT'].is_number? && ENV['NOTIFICATON_WAIT'].to_i>0)
  while(wait_notifications_secs>=0)
    Actions.getEnvParamsFromService(ENV['serviceIPandPORT'])
    sleep 30
    wait_notifications_secs-=30 if(wait_notifications_secs>0)
    break if(!ENV["ptrade_is_stopped"].nil? && ENV["no_tidy_tickets_found"].nil?)
    #fail("NO_TIDY_TICKETS_FOUND for Online presetup") if(!ENV["ptrade_is_stopped"].nil? && !ENV["no_tidy_tickets_found"].nil?)
  end
  fail("Error found: "+ENV["error"].to_s) if(defined?(ENV["error"]) && !ENV["error"].to_s.empty?)
  fail("NO_TIDY_TICKETS_FOUND for Online presetup") if(!ENV["ptrade_is_stopped"].nil? && !ENV["no_tidy_tickets_found"].nil?)
  #fail("Ptrade Not Stopped after Online presetup") if(!ENV["ptrade_is_stopped"].nil?)
  #fail("NO_TIDY_TICKETS_FOUND for Online presetup") if(!ENV["no_tidy_tickets_found"].nil?)


=begin
  waitCptSecs = 60
  waitCptSecs = ENV['WAIT_CPT_SECS'].to_i if(!ENV['WAIT_CPT_SECS'].nil? && ENV['WAIT_CPT_SECS'].is_number?)
  sleep waitCptSecs #same time as for recovery in order to deliver Tidy
  stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
=end

end


Then /^Oracle stats being reset$/ do
  Actions.v 'Reset Oracle statistics for user: ' + CONFIG.get['CORE_HOST_USER']
  #cmd="date && echo 'EXEC dbms_stats.gather_schema_stats(user,estimate_percent => null);' | $ORACLE_HOME/bin/sqlplus "+CONFIG.get['CORE_HOST_USER']+"/"+CONFIG.get['CORE_HOST_USER'] +" && date"
  cmd="export LD_LIBRARY_PATH=/ora01/app/oracle/product/12.1.0/dbhome_1/lib::/usr/lib:/usr/local/lib; \n \
       export ORACLE_SID=PTDB; \n \
       export DB_UNIQUE_NAME=PTDB_NYCAPDB01M_TLVP.am.icap.com; \n \
       export ORACLE_BASE=/ora01/app/oracle; \n \
       export PATH=/ora01/app/oracle/product/12.1.0/dbhome_1/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/sbin:/usr/sbin:/usr/local/bin:.; \n \
       export ORA_NLS33=/ora01/app/oracle/product/12.1.0/dbhome_1/ocommon/nls/admin/data; \n \
       export ORACLE_HOME=/ora01/app/oracle/product/12.1.0/dbhome_1; \n \
       date && echo 'EXEC \n \
       begin \n \
        dbms_stats.gather_schema_stats(user,estimate_percent => null); \n \
       end; \n \
       /' | $ORACLE_HOME/bin/sqlplus "+CONFIG.get['CORE_HOST_USER']+"/"+CONFIG.get['CORE_HOST_USER'] +" && date;"


       #date && echo 'EXEC dbms_stats.gather_schema_stats(user,estimate_percent => null);/' | $ORACLE_HOME/bin/sqlplus "+CONFIG.get['CORE_HOST_USER']+"/"+CONFIG.get['CORE_HOST_USER'] +" && date"
  res=Actions.SSH(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],cmd,600,true,'SQL procedure successfully completed')
  Actions.v 'Oracle Reset Stats res: ' + res if !res.nil?
end


Then /^ERs sent for performance(.*)$/ do |perf_index|

=begin
  mslIP=CONFIG.get['MSL_HOST2_IP']
  mslCount=Actions.printMessagesCountFromMsl(mslIP,CONFIG.get['MSL_HOST_USER'],CONFIG.get['MSL_HOST_PWD'])
  mslCount=mslCount.scan(/\d+/)[0]
  Actions.v 'mslCount: '+mslCount.to_s+" messages found in MSL table 'messages' before Recovery "+mslIP
=end

  wait_secs = 60
  wait_secs = ENV['LOOP_MSL_SECS'].to_i if(!ENV['LOOP_MSL_SECS'].nil? && ENV['LOOP_MSL_SECS'].is_number?)
  cmd = "rm -rf $HOME/Automation/mslErSenderPerf1.log && cd $HOME/MSLErSender_1.2_"+CONFIG.get['MSL_HOST2_IP']+"/bin && ./mslErSender.sh -s $HOME/Automation/ers/ -i 1 -p 50  >> $HOME/Automation/mslErSenderPerf1.log" if perf_index.to_i == 1
  cmd = "rm -rf $HOME/Automation/mslErSenderPerf2.log && cd $HOME/MSLErSender_1.2_"+CONFIG.get['MSL_HOST2_IP']+"/bin && ./mslErSender.sh -s $HOME/Automation/er_perf2/ -i 1 -p 10  >> $HOME/Automation/mslErSenderPerf2.log" if perf_index.to_i == 2 # er_perf2/  -i 1 -p 50
  runRemoteMslSender2(CONFIG.get['CORE_HOST_USER'], CONFIG.get['MSL_HOST2_IP'], cmd, wait_secs)


=begin
  mslIP=CONFIG.get['MSL_HOST2_IP']
  mslCount=Actions.printMessagesCountFromMsl(mslIP,CONFIG.get['MSL_HOST_USER'],CONFIG.get['MSL_HOST_PWD'])
  mslCount=mslCount.scan(/\d+/)[0]
  Actions.v 'mslCount: '+mslCount.to_s+" messages found in MSL table 'messages' after Recovery "+mslIP
=end
end

def printPerfFileToHtmlTable(strFile,report_header)
  Actions.pp report_header
  stats={}
  row_stat={}
  kvArr=strFile.split("\n")
  kvArr.each_with_index{|row,index|
    next if (index>0 && !index.to_i.even?)
    stats[kvArr[index]]=kvArr[index+1]
  }
  Actions.printHtmlTableBlack2(stats)

end

Then /^PostTrade is started for performance(.*) stats$/ do |perf_index|
  #uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  ENV["ptrade_is_stopped"]=nil
  ENV["no_tidy_tickets_found"]=nil
  Actions.resetEnvParamsInService(ENV["serviceIPandPORT"])

  schema=CONFIG.get['CORE_HOST_USER'].to_s.downcase
  query="SELECT count(*) as count from FX_TICKET_LEG"
  ticketCount0=Actions.getDbQueryResultsWithoutFailure4(schema, schema, query)
  ticketCount0=ticketCount0[0]['COUNT'].to_i.to_s
  Actions.v ticketCount0.to_s+' tickets are found in FX_TICKET_LEG before Recovery'
  query="SELECT count(*) as count from FX_DEAL"
  dealCount0=Actions.getDbQueryResultsWithoutFailure4(schema, schema, query)
  dealCount0=dealCount0[0]['COUNT'].to_i.to_s
  Actions.v dealCount0.to_s+' deals are found in FX_DEAL before Recovery'


  Actions.SSH(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],'mkdir -p $HOME/Automation/logs_debug_PT_APP',20,true,'')
=begin
  cmd = 'kill -9 $(/sbin/pidof redis-server) >/dev/null 2>&1'
  res = Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 20)
  Actions.v 'KillRedis res: ' + res if !res.nil?
  #Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],'cd $HOME/Automation && rm -rf RedisMonitor.txt',20)
  #Actions.v 'Restarting Redis' #Already started for previous start - needed after deleteing RedisMonitor
  #restartRedisWithNewConfigForNewVersion2  #Not needed for Performance1 scenario
=end
  Actions.v 'Restarting PostTrade for user ptrade '
  Actions.restartPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],false)
  #sleep 30
  home=CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']
  Actions.v 'Run stopPtradeIfNoTickets.sh'
  cmd="cd "+home+'/Automation && ./stopPtradeIfNoTickets'+".sh"
  res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 600)
  Actions.v 'stopPtradeIfNoTickets res: '+res if !res.nil?
  wait_notifications_secs = 0 #Loop forever
  wait_notifications_secs = ENV['NOTIFICATON_WAIT'].to_i if(!defined?(ENV['NOTIFICATON_WAIT']).nil? && !ENV['NOTIFICATON_WAIT'].nil? && ENV['NOTIFICATON_WAIT'].is_number? && ENV['NOTIFICATON_WAIT'].to_i>0)
  while(wait_notifications_secs>=0)
    Actions.getEnvParamsFromService(ENV['serviceIPandPORT'])
    sleep 30
    wait_notifications_secs-=30 if(wait_notifications_secs>0)
    break if(!ENV["ptrade_is_stopped"].nil? && ENV["no_tidy_tickets_found"].nil?)
    #fail("NO_TIDY_TICKETS_FOUND for Recovery") if(!ENV["ptrade_is_stopped"].nil? && !ENV["no_tidy_tickets_found"].nil?)
  end
  fail("Error found: "+ENV["error"].to_s) if(defined?(ENV["error"]) && !ENV["error"].to_s.empty?)
  fail("NO_TIDY_TICKETS_FOUND for Recovery") if(!ENV["ptrade_is_stopped"].nil? && !ENV["no_tidy_tickets_found"].nil?)
  #fail("PTRADE NOT Stopped after Recovery") if(!ENV["ptrade_is_stopped"].nil?)
  #fail("NO_TIDY_TICKETS_FOUND for Recovery") if(!ENV["no_tidy_tickets_found"].nil?)




=begin
  waitCptSecs = 60
  waitCptSecs = ENV['WAIT_CPT_SECS'].to_i if(!ENV['WAIT_CPT_SECS'].nil? && ENV['WAIT_CPT_SECS'].is_number?)
  sleep waitCptSecs #+5
  stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
=end

  #stop Fix mockers
  Actions.v "Stopping FIX mockers..."
  home=CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']
  mocker_bin=home+'/FixTools-1.7.0/bin/'
  cmd=mocker_bin+"initiator.sh stop"
  Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],cmd,60)
  cmd=mocker_bin+"acceptor.sh stop"
  Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],cmd,60)


  query="SELECT count(*) as count from FX_TICKET_LEG" if !ticketCount0.is_number?
  query="SELECT count(*)-"+ticketCount0+" as count from FX_TICKET_LEG" if ticketCount0.is_number?
  ticketCount=Actions.getDbQueryResultsWithoutFailure4(schema, schema, query)
  ticketCount=ticketCount[0]['COUNT'].to_i.to_s
  Actions.v ticketCount.to_s+' tickets are found in FX_TICKET_LEG after Recovery'
  query="SELECT count(*) as count from FX_DEAL" if !dealCount0.is_number?
  query="SELECT count(*)-"+dealCount0+" as count from FX_DEAL" if dealCount0.is_number?
  dealCount=Actions.getDbQueryResultsWithoutFailure4(schema, schema, query)
  dealCount=dealCount[0]['COUNT'].to_i.to_s
  Actions.v dealCount.to_s+' deals are found in FX_DEAL after Recovery'

  Actions.stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'],true) #after stop all logs are moved to previous folder


  Actions.v 'Run Performance stats'
  cmd="cd "+home+'/Automation && ./perf'+perf_index.to_s+".sh "+ticketCount+" "+dealCount  #+mslCount+" "+ticketCount
  res=Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 600)
  Actions.v 'perf res: '+res if !res.nil?

  Actions.p "<b>====================Performance Stats=======================<b>"

  if (perf_index.to_i==1)
    cmd="cat "+home+"/Automation/perf1.log"
    res=Actions.SSH(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 600, true, '')
    perf_report_header="<b>========================================Core & Tidy Stats====================<b>"
    printPerfFileToHtmlTable(res,perf_report_header)
  else
    STAT_FILE1="perf2core.log"
    STAT_FILE2="perf2tidy.log"
    STAT_FILE3="perf2db.log"
    STAT_FILE4="perf2adapters.log"

    cmd="cat "+home+"/Automation/"+STAT_FILE1
    res=Actions.SSH(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 600, true, '')
    perf_report_header="<b>========================================Core Stats==============================<b>"
    printPerfFileToHtmlTable(res,perf_report_header)

    cmd="cat "+home+"/Automation/"+STAT_FILE2
    res=Actions.SSH(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 600, true, '')
    perf_report_header="<b>========================================Tidy Stats=============================<b>"
    printPerfFileToHtmlTable(res,perf_report_header)

    cmd="cat "+home+"/Automation/"+STAT_FILE3
    res=Actions.SSH(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 600, true, '')
    perf_report_header="<b>========================================DB Stats===============================<b>"
    printPerfFileToHtmlTable(res,perf_report_header)

    cmd="cat "+home+"/Automation/"+STAT_FILE4
    res=Actions.SSH(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 600, true, '')
    perf_report_header="<b>========================================Adapters Stats=========================<b>"
    printPerfFileToHtmlTable(res,perf_report_header)
  end
end


Then /^ERs sent before upgrade restart$/ do
  threads = []
  t1=Thread.new{sendErsRestartAndDownloadDataForOldVersion(CONFIG.get['CORE_HOST_USER1'], true, false, true)}
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new{sendErsRestartAndDownloadDataForNewVersion(CONFIG.get['CORE_HOST_USER'], false, false, false)}
  t2.abort_on_exception = true
  t1.join
  threads << t2
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('restartAndDownloadDataForOldVersion failed for user ptrade1') if(t1.status.nil?)
  fail('restartAndDownloadDataForNewVersion failed for user ptrade') if(t2.status.nil?)
end


def sendErsRestartAndDownloadDataForOldVersion(user,after_upgrade_restart,start_redis=false,wait_for_second_thread=true) #if before_upgrade_restart=false then sending after restart
  Actions.v 'sending Ers after_upgrade_restart: ' +after_upgrade_restart.to_s+' for user: ' + user
  sleep CONFIG.get['WAIT_FOR_ONE_THREAD_PTRADE'].to_i if(wait_for_second_thread)
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers2', CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/ers2')
 ##uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/upgrade_app_config2/fix/rtns/qfj.cfg', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/PTS/config/fix/rtns/qfj.cfg')
  restartRedisWithNewConfig3(user) if(start_redis)#TEMP disabled - NO RESTART NEEDED FOR 2ND ERs package
  mslIP=CONFIG.get['MSL_HOST2_IP']
  mslIP=CONFIG.get['MSL_HOST_IP'] if(user==CONFIG.get['CORE_HOST_USER1'])
  Actions.printMessagesCountFromMsl(mslIP,CONFIG.get['MSL_HOST_USER'],CONFIG.get['MSL_HOST_PWD'])
  runRemoteMslSender4upgrade2(user, true, 'ers2', mslIP) if(!after_upgrade_restart)
  restartPtradeService(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'])
  runRemoteMslSender4upgrade2(user, true, 'ers2', mslIP) if(after_upgrade_restart)
  Actions.downloadPTSLogs(true, false) if(user==CONFIG.get['CORE_HOST_USER1'])
  Actions.downloadPTSLogs(false, true) if(user==CONFIG.get['CORE_HOST_USER'])
  Actions.printMessagesCountFromMsl(mslIP,CONFIG.get['MSL_HOST_USER'],CONFIG.get['MSL_HOST_PWD'])
  runPtsLogParser(user,CONFIG.get['REMOTE_'+user.to_s.upcase+'_TEMPLATE_DIR_PATH']+'/'+'ers2')
  downloadCsvFolder(user)
  downloadJson(user)
  #downloadTidyLogForOldVersion
  #Actions.checkRtnsDelievery(Dir.getwd + '/templates/old_app_rtns/'+@@time_stamp+'/pts_tidy_3.log', CONFIG.get['CORE_HOST_USER1'])
  stopPtradeService(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'])

end


def sendErsRestartAndDownloadDataForNewVersion(user,after_upgrade_restart,start_redis=false,wait_for_second_thread=false)
  Actions.v 'sending Ers after_upgrade_restart: ' +after_upgrade_restart.to_s+' for user: ' + user
  sleep CONFIG.get['WAIT_FOR_ONE_THREAD_PTRADE'].to_i if(wait_for_second_thread)
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers2', CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/ers2')
  #uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/upgrade_app_config2/fix/rtns/qfj.cfg', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTS/config/fix/rtns/qfj.cfg')
  restartRedisWithNewConfig3(user) if(start_redis) #TEMP disabled - NO RESTART NEEDED FOR 2ND ERs package
  #sleep 60 ##TEMP
  mslIP=CONFIG.get['MSL_HOST2_IP']
  mslIP=CONFIG.get['MSL_HOST_IP'] if(user==CONFIG.get['CORE_HOST_USER1'])
  Actions.printMessagesCountFromMsl(mslIP,CONFIG.get['MSL_HOST_USER'],CONFIG.get['MSL_HOST_PWD'])
  runRemoteMslSender4upgrade2(user, true, 'ers2', mslIP) if(!after_upgrade_restart)
  restartPtradeService(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'])
  runRemoteMslSender4upgrade2(user, true, 'ers2', mslIP) if(after_upgrade_restart)
  Actions.downloadPTSLogs(true, false) if(user==CONFIG.get['CORE_HOST_USER1'])
  Actions.downloadPTSLogs(false, true) if(user==CONFIG.get['CORE_HOST_USER'])
  Actions.printMessagesCountFromMsl(mslIP,CONFIG.get['MSL_HOST_USER'],CONFIG.get['MSL_HOST_PWD'])
  runPtsLogParser(user,CONFIG.get['REMOTE_'+user.to_s.upcase+'_TEMPLATE_DIR_PATH']+'/'+'ers2')
  downloadCsvFolder(user)
  downloadJson(user)
  #downloadTidyLogForNewVersion
  #Actions.checkRtnsDelievery(Dir.getwd + '/templates/new_app_rtns/'+@@time_stamp+'/pts_tidy_3.log', CONFIG.get['CORE_HOST_USER'])
  stopPtradeService(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'])

end



### Upgrade scenario end










#########



Then /^DB tables DEAL TICKETS LEGS SD_TARGET compared for both versions$/ do
  Actions.compareDbTableResults(CONFIG.get['ORACLE_HOST_TEMPLATE_SCHEMA'],CONFIG.get['ORACLE_HOST_SCHEMA'],@@time_stamp) #PTRADE1,PTRADE
end


Then /^MYT and COMMON Adapter  comparing the CSV format files$/ do
  Actions.compareCsvFolders(@@time_stamp)
end


Then /^Old and New versions csv Folders are Matched excluding timestamps atfer scratch$/ do
  Actions.compareCsvFolders(@@before_upgrade_timestamp)
end


Then /^MYT Adapter  comparing the CSV format files after upgrade$/ do
  Actions.compareCsvFolders(@@time_stamp)
end


def compareCsvFolders(time_stamp)
  source_dir = Dir.getwd + '/templates/old_app_csv/'+time_stamp
  target_dir = Dir.getwd + '/templates/new_app_csv/'+time_stamp
  dir_count=Actions.compareCsvDirs2(source_dir+'/common', target_dir+'/common',CONFIG.get['MYT_CSV_EXCLUDED_COLUMNS'],"csv","c")
  Actions.c (dir_count-2).to_s+' folders have been tested in folder common' if(!$csv_folders_count.nil? && !dir_count.nil? && !dir_count[0].to_s.downcase.include?('error'))
  dir_count=Actions.compareCsvDirs2(source_dir+'/myt', target_dir+'/myt',CONFIG.get['MYT_CSV_EXCLUDED_COLUMNS'],"csv","m")
  Actions.c (dir_count-2).to_s+' folders have been tested in folder myt' if(!$csv_folders_count.nil? && !dir_count.nil? && !dir_count[0].to_s.downcase.include?('error'))
  Actions.c $csv_files_count.to_s+' files have been compared' if(!$csv_files_count.nil?)

  if($csv_folders_count.nil? || $csv_folders_count==0)
    @@scenario_fails.push('0 Folders compared')
    Actions.f('0 Folders compared')
    return
  end
  if($csv_files_count.nil? || $csv_files_count==0)
    @@scenario_fails.push('0 Files compared')
    Actions.f('0 Files compared')
  else
    Actions.p $csv_files_count.to_s + " files compared in " + $csv_folders_count.to_s + " folders"
  end
end


def compareCsvFolders2(source_dir,target_dir,excluded_fields_arr)
  Actions.v 'Comparing CSV folders source: ' + source_dir + ' and ' + target_dir
  dir_count=Actions.compareCsvDirs2(source_dir,target_dir,excluded_fields_arr)
  Actions.c (dir_count-2).to_s+' folders have been tested in '+source_dir if(!$csv_folders_count.nil? && !dir_count.nil? && !dir_count[0].to_s.downcase.include?('error'))
  Actions.c $csv_files_count.to_s+' files have been compared' if(!$csv_files_count.nil?)

  if($csv_folders_count.nil? || $csv_folders_count==0)
    @@scenario_fails.push('0 Folders compared')
    Actions.f('0 Folders compared')
    return
  end
  if($csv_files_count.nil? || $csv_files_count==0)
    @@scenario_fails.push('0 Files compared')
    Actions.f('0 Files compared')
  end
end


Then /^REDIS Adapter  comparing the JSON format files$/ do
  struct_str = []
  old_schema =  (@@email_properties['PTRADE1_APP_VERSION']+' - ptrade1') || 'Source Version - ptrade1'
  new_schema =  (@@email_properties['PTRADE_APP_VERSION']+' - ptrade') || 'Target Version - ptrade'
  struct_str.push(Actions.pSpaces('Ticket ID',30)<< Actions.pSpaces(old_schema,30)<<Actions.pSpaces(new_schema,30))
  struct_str.push(" ")
  log_file='Diff_Jsons.txt'
  log_file_path=Dir.getwd+'/templates/new_app_json/'+@@time_stamp+'/'+log_file
  File.open(log_file_path, 'w')
  Actions.writeDiffToFile(struct_str,log_file_path)

  template_json =  Dir.getwd + '/templates/old_app_json/'+@@time_stamp+'/RedisMonitor1.txt'
  build_json =  Dir.getwd + '/templates/new_app_json/'+@@time_stamp+'/RedisMonitor.txt'
  @@json_fails=[]
  Actions.c '<b>Comparing Sapphire Jsons...</b>'
  json_compare_errors=Actions.compareSaphireOutputJsons(template_json, build_json) if(@@json_fails.empty?)

  if Dir.getwd.include?(@@CONFIG['JENKINS_JOB_NAME'])
    log_file_path =  @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME'].to_s+'/ws/templates/new_app_json/'+@@time_stamp+'/'+log_file
  else
    log_file_path = Dir.getwd+'/templates/new_app_json/'+@@time_stamp+'/'+log_file
  end
  Actions.f "<a href='" + log_file_path.to_s+"'>Click to View Json Diff      "+log_file.to_s+"</a>" if(!json_compare_errors.nil? && !json_compare_errors.to_a.empty?)

end


Then /^Old and New Saphire Jsons are Matched excluding sequence after scratch$/ do
  template_json =  Dir.getwd + '/templates/old_app_json/'+@@before_upgrade_timestamp+'/RedisMonitor1.txt'
  build_json =  Dir.getwd + '/templates/new_app_json/'+@@before_upgrade_timestamp+'/RedisMonitor.txt'
  @@json_fails=[]

  Actions.c '<b>Comparing Sapphire Jsons...</b>'
  Actions.compareSaphireOutputJsons(template_json, build_json) if(@@json_fails.empty?)
end


Then /^REDIS Adapter  comparing the JSON format files after upgrade$/ do
  template_json =  Dir.getwd + '/templates/old_app_json/'+@@time_stamp+'/RedisMonitor1.txt'
  build_json =  Dir.getwd + '/templates/new_app_json/'+@@time_stamp+'/RedisMonitor.txt'
  @@json_fails=[]

  Actions.c '<b>Comparing Sapphire Jsons...</b>'
  Actions.compareSaphireOutputJsons(template_json, build_json) if(@@json_fails.empty?)
end


Then /^Old and New versions RTNS outgoing data compared$/ do
  downloadTidyLogForOldVersion
  downloadTidyLogForNewVersion
  log_file_path1=Dir.getwd + '/templates/old_app_rtns/'+@@time_stamp+'/pts_tidy_3.log'
  log_file_path2=Dir.getwd + '/templates/new_app_rtns/'+@@time_stamp+'/pts_tidy_3.log'
  Actions.compareOutgoingRtns(log_file_path1,log_file_path2)
end


Then /^RTNS Adapter  comparing the TEXT format files$/ do
   Actions.compareKvTxtFiles(Dir.getwd + "/templates/old_app_csv_traiana/"+@@time_stamp,Dir.getwd + "/templates/new_app_csv_traiana/" + @@time_stamp,"rtns")
end


Then /^FIX4_4 Adapter  comparing the TEXT format files$/ do
  Actions.compareKvTxtFiles(Dir.getwd + "/templates/old_app_csv_traiana/"+@@time_stamp,Dir.getwd + "/templates/new_app_csv_traiana/" + @@time_stamp,"fix44")
end


Then /^TUDOR Adapter  comparing the TEXT format files$/ do
  Actions.compareKvTxtFiles(Dir.getwd + "/templates/old_app_csv_traiana/"+@@time_stamp,Dir.getwd + "/templates/new_app_csv_traiana/" + @@time_stamp,"t1")
end


Then /^TOF Adapter  comparing the TEXT format files$/ do
  Actions.compareTsvTxtFiles(Dir.getwd + "/templates/old_app_csv_traiana/"+@@time_stamp,Dir.getwd + "/templates/new_app_csv_traiana/" + @@time_stamp,"tof")
end


Then /^TRAIANA Adapter and Common and MyT  comparing the CSV format files$/ do
  approved_version = 520
  if (@@old_ptrade_version_number.nil?  || @@old_ptrade_version_number.to_s.empty? || @@old_ptrade_version_number.to_i < approved_version )
    Actions.f 'Escaping tests of Traiana - will run with version >= ' + approved_version.to_s + ' actual version is ' + '"' + @@old_ptrade_version_number.to_s + '"'
    #return
  else

  ers_folder = CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/ers'
  csv_folder = CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/ers_csv'
  Actions.v 'Creating csv from ers for user: ' + CONFIG.get['CORE_HOST_USER1']
  # cmd = 'cd '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/'+'Automation/PTS/bin && ./er2tickets.sh ../../'+ers_folder+' ../../'+csv_folder
  cmd = 'cd '+CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/bin && ./er2tickets.sh '+ers_folder+' '+csv_folder
  #cmd = 'cd /export/home/ptrade1/Automation/PTS/bin && ./er2tickets.sh /export/home/ptrade1/Automation/ers /export/home/ptrade1/Automation/ers_csv'
  res = Actions.SSH(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], cmd, 120, true, '')

  Actions.v res.to_s
  downloadTraianaCsvFolderForOldVersion('old_app_csv_traiana',csv_folder)

  ers_folder = CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/ers'
  csv_folder = CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/ers_csv'
  Actions.v 'Creating csv from ers for user: ' + CONFIG.get['CORE_HOST_USER']
  # cmd = 'cd '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/'+'Automation/PTS/bin && ./er2tickets.sh ../../'+ers_folder+' ../../'+csv_folder
  cmd = 'cd '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/bin && ./er2tickets.sh '+ers_folder+' '+csv_folder
  res = Actions.SSH(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 120, true, '')
  Actions.v res.to_s
  downloadTraianaCsvFolderForNewVersion('new_app_csv_traiana',csv_folder)

  Actions.c('<b> Old and New versions Traiana <t>, Common <c>, MyT <m> outgoing data compared as CSV </b>')
  res1=Actions.compareCsvFolders2(Dir.getwd + '/templates/old_app_csv_traiana/'+@@time_stamp,Dir.getwd + '/templates/new_app_csv_traiana/'+@@time_stamp,CONFIG.get['TRAIANA_CSV_EXCLUDED_COLUMNS'],'csv','t')
  Actions.writeToHtml('csv_t_'+@@time_stamp+'.html',res1,goodMsg='',badMsg=(res1.nil? || res1.empty?  ? '' : 'Diff Found for csv t files' ))
  res2=Actions.compareCsvFolders2(Dir.getwd + '/templates/old_app_csv_traiana/'+@@time_stamp,Dir.getwd + '/templates/new_app_csv_traiana/'+@@time_stamp,CONFIG.get['TRAIANA_CSV_EXCLUDED_COLUMNS'],'csv','c')
  Actions.writeToHtml('csv_c_'+@@time_stamp+'.html',res2,goodMsg='',badMsg=(res2.nil? || res2.empty?  ? '' : 'Diff Found for csv c files' ))
  res3=Actions.compareCsvFolders2(Dir.getwd + '/templates/old_app_csv_traiana/'+@@time_stamp,Dir.getwd + '/templates/new_app_csv_traiana/'+@@time_stamp,CONFIG.get['TRAIANA_CSV_EXCLUDED_COLUMNS'],'csv','m')
  Actions.writeToHtml('csv_m_'+@@time_stamp+'.html',res3,goodMsg='',badMsg=(res3.nil? || res3.empty?  ? '' : 'Diff Found for csv m files' ))
  end
end


Then /^Build and App logs are displayed in Report$/ do
  Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], '/export/home/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTSlogsParser_ptrade.sh ers_path: '+CONFIG.get['REMOTE_HOME']+CONFIG.get['CORE_HOST_USER']+'/Automation/ers'+' pts_logs_path: '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/logs', 120)
  Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], '/export/home/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/PTSlogsParser_ptrade.sh ers_path: '+CONFIG.get['REMOTE_HOME']+CONFIG.get['CORE_HOST_USER1']+'/Automation/ers'+' pts_logs_path: '+CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/logs', 120)
  sleep 20
  Actions.displayFilesForDownloadInFolder(Dir.getwd+'/logs/logs_'+@@time_stamp)
end


########


def createLocalDirs
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates'+' && mkdir db', 10)
  Actions.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir new_app_csv', 10)
  Actions.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir old_app_csv', 10)
  Actions.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir new_app_json', 10)
  Actions.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir old_app_json', 10)
  Actions.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates/myt'+' && mkdir source', 10)
  Actions.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates/myt'+' && mkdir target', 10)
end


def createAutomationDirForUser(host, user, pwd)
  Actions.v 'Creating Automation dir on host '+host+' for user '+user+'... '
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/ers'
  res = Actions.SSH(host, user, pwd, cmd, 10, true, '')

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/ers2'
  res = Actions.SSH(host, user, pwd, cmd, 10, true, '')

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/er_perf1'
  res = Actions.SSH(host, user, pwd, cmd, 10, true, '')

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data/tickets'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data/tickets/common'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data/tickets/myt'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/logs_debug_PT_APP'
  res = Actions.SSH(host, user, pwd, cmd, 10, true, '')

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/er_perf2'
  res = Actions.SSH(host, user, pwd, cmd, 10, true, '')
end


def createDirForUser(host, user, pwd, dir_path)
  Actions.c 'Creating directory '+dir_path+' on host '+host+' for user '+user+'...'
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+dir_path
  res = Actions.SSH(host, user, pwd, cmd, 10, true, '')
end


def createCsvDirsForUserOnRemoteServer(host, user, pwd)
  Actions.v 'Creating CSV and MyT folders on host '+host+' for user '+user+'... '
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/data/tickets/myt'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/data/tickets/common'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)
end


def buildPtradeApp(host, user, pwd, script_file, script_path_from, script_path_to,script_param)
  begin
    Actions.v 'Copying build scripts to build App on Ptrade server for user '+user+'... '
    Actions.uploadTemplates2(host, user, pwd, script_path_from+script_file, script_path_to+'/'+script_file,40)

    Actions.v 'Building App on Ptrade server for user '+user+'... '
    cmd = "dos2unix "+script_path_to+'/'+script_file
    res = Actions.SSH(host, user, pwd, cmd, 20, true, '')

    cmd ="chmod 755 "+script_path_to+'/'+script_file
    res = Actions.SSH(host, user, pwd, cmd, 20, false, '')

    cmd << ' && '+script_path_to+'/'+script_file
    cmd << " -n " + script_param if(!script_param.nil? && !script_param.to_s.empty?)
    res = Actions.SSH(host, user, pwd, cmd, 180, false, '')
  rescue Exception=>e
    @@scenario_fails.push('PtradeApp build failed for user ' + user)
    Actions.displaySanityLogs(false, false, true, false) if(user==CONFIG.get['CORE_HOST_USER'])
    Actions.displaySanityLogs(false, false, false, true) if(user==CONFIG.get['CORE_HOST_USER1'])
    fail('PtradeApp build failed for user ' + user)
  end
end


def buildPtradeApp2(host, user, pwd, script_param, isUpgrade)
  res = ''
  begin
    actionName='Building'
    actionName='Upgrading' if(isUpgrade)
    Actions.c actionName+' Ptrade App for user "'+user+'" at "'+host+'"'
    Actions.v 'Copying files to build Ptrade App...'

    appInstallScript = ''

    if (user==CONFIG.get['CORE_HOST_USER1'])
      if isUpgrade
        appInstallScript = 'ptradeAPP_build1_upgrade_automatic.sh'
      else
        appInstallScript = 'ptradeAPP_build1_install_automatic.sh'
      end
      Actions.uploadTemplates2(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],Dir.getwd+'/templates/bash/'+appInstallScript,CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/'+appInstallScript,40)
      Actions.rigthsForFile(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation',appInstallScript,'755')
    elsif (user==CONFIG.get['CORE_HOST_USER'])
      if isUpgrade
        appInstallScript = 'ptradeAPP_build_upgrade_automatic.sh'
      else
        appInstallScript = 'ptradeAPP_build_install_automatic.sh'
      end
      Actions.uploadTemplates2(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],Dir.getwd+'/templates/bash/'+appInstallScript,CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/'+appInstallScript,40)
      Actions.rigthsForFile(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation',appInstallScript,'755')
    else
      fail('Not supported user to launch Ptrade App installation: '+user+'. Only users '+CONFIG.get['CORE_HOST_USER']+', '+CONFIG.get['CORE_HOST_USER1']+' allowed')
    end
    Actions.v 'Files for installing the application are copied'

    addition='extract_to: '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'packages/'+user.to_s.capitalize+'_APP'+' install_to: '+CONFIG.get['REMOTE_HOME']+'/'+user
    addition='extract_to: '+CONFIG.get['PTRADE_APP_EXTRACT_FOLDER']+' install_to: '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER'] if(user==CONFIG.get['CORE_HOST_USER'])
    addition='extract_to: '+CONFIG.get['PTRADE1_APP_EXTRACT_FOLDER']+' install_to: '+CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'] if(user==CONFIG.get['CORE_HOST_USER1'])
    appInstallScript+=' '+addition

    if (script_param.nil? || script_param.to_s.strip.empty?)
      cmd = 'cd '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation && ./'+appInstallScript
    else
      cmd = 'cd '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation && ./'+appInstallScript+' -n '+script_param.to_s.strip
    end
    Actions.v 'For user "'+user+'" script_param is "'+script_param.to_s+'", cmd for execution is ' + cmd
    res = Actions.SSH(host, user, pwd, cmd, 300, true, '')

  rescue Exception=>e
    @@scenario_fails.push('PtradeApp build failed for user ' + user) if(!isUpgrade)
    @@scenario_fails.push('PtradeApp upgrade failed for user ' + user) if(isUpgrade)
    # Actions.displaySanityLogs(false, false, true, false) if(user==CONFIG.get['CORE_HOST_USER'])
    # Actions.displaySanityLogs(false, false, false, true) if(user==CONFIG.get['CORE_HOST_USER1'])
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('PtradeApp build failed for user ' + user) if(!isUpgrade)
    fail('PtradeApp upgrade failed for user ' + user) if(isUpgrade)
  end
end


def uploadDirToRemoteAutomationFolder(host, user, pwd, dir_from_path, dir_to_path)
  Actions.v 'Uploading Templates files and scripts from ' +dir_from_path +' to Automation folder on remote server for user '+user+' started... '
  Actions.uploadTemplates2(host, user, pwd, dir_from_path, dir_to_path, 60)
  Actions.v 'Upload of Templates files and scripts from ' +dir_from_path +' to Automation folder on remote server for user '+user+' finished '
  # Actions.SSH_NO_FAIL(host, user, pwd, "dos2unix "+dir_to_path+"/*",40)
  Actions.SSH_NO_FAIL(host, user, pwd, 'cd '+dir_to_path+' && find . -type f -print0 | xargs -0 dos2unix',40)
  Actions.SSH_NO_FAIL(host, user, pwd, 'chmod 755 '+dir_to_path+'/*.sh',40)
end

def uploadDir2RemoteAutomationFolder(host, user, pwd, dir_from_path, dir_to_path)
  Actions.v 'Uploading files from ' +dir_from_path +' to Automation folder on remote server for user '+user+'... '
  Actions.uploadTemplates2(host, user, pwd, dir_from_path, dir_to_path,60)
  # Actions.SSH(host, user, pwd, 'dos2unix '+dir_to_path+'/*', 20, true, '')
  Actions.SSH(host, user, pwd, 'cd '+dir_to_path+' && find . -type f -print0 | xargs -0 dos2unix', 20, true, '')
  Actions.SSH(host, user, pwd, 'chmod 755 '+dir_to_path+'/*.sh', 20, true, '')
end

def uploadDirToRemoteFolder(host, user, pwd, dir_from_path, dir_to_path)
  Actions.v 'Uploading Local folder contents from ' + dir_from_path+' to ' +dir_to_path+' on remote server for user '+user+'... '
  Actions.uploadTemplates2(host, user, pwd, dir_from_path, dir_to_path,60)
  # Actions.SSH_NO_FAIL(host, user, pwd, "dos2unix "+dir_to_path+"/*",40)
  Actions.SSH_NO_FAIL(host, user, pwd, 'cd '+dir_to_path+' && find . -type f -print0 | xargs -0 dos2unix',40)
  Actions.SSH_NO_FAIL(host, user, pwd, 'chmod 755 '+dir_to_path+'/*.sh',40)
end


def uploadFileToRemoteFolder(host, user, pwd, file_name, path_from, path_to)
  Actions.v 'Uploading file '+path_from+'/'+file_name+' to ' + path_to+'/'+file_name +' for user '+user+' on host '+host+'... '
  Actions.uploadTemplates2(host, user, pwd, path_from+'/'+file_name, path_to+'/'+file_name,60)
  Actions.SSH_NO_FAIL(host, user, pwd, 'dos2unix '+path_to+'/'+file_name,20)
  Actions.SSH_NO_FAIL(host, user, pwd, 'chmod 755 '+path_to+'/'+file_name,60)
end

def uploadFile2RemoteFolder(host, user, pwd, file_name, path_from, path_to)
  Actions.v 'Uploading file '+path_from+'/'+file_name+' to ' + path_to+'/'+file_name +' for user '+user+' on host '+host+'... '
  Actions.uploadTemplates2(host, user, pwd, path_from+'/'+file_name, path_to,60)
end

def stopPtradeService(host, user, pwd)#TODO
  Actions.v 'Stopping PTS services for '+user
  # cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/bin/service.sh stop'
  cmd = CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh stop' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  cmd = CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh stop' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  expected_output_rows=['pts_tidy stopped successfully','pts_core stopped successfully','pts_http stopped successfully']
  res = Actions.SSH(host, user, pwd, cmd, 60, true, expected_output_rows)
  Actions.v res.to_s
end


def stopPtradeServiceNoFail(host, user, pwd)
  Actions.v 'Stopping PTS services for '+user
  # cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/bin/service.sh stop'
  cmd = CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh stop' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  cmd = CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh stop' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 60)
  # Actions.c res.to_s
  Actions.v res.to_s
end

def stopPtradeOldServiceNoFail(host, user, pwd)
  Actions.v 'Stopping PTS services in Automation_old for '+user
  # cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation_old/PTS/bin/service.sh stop'
  cmd = CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh stop' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  cmd = CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh stop' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 60)
  Actions.v res.to_s
end


def restartPtradeService(host, user, pwd)
  Actions.v 'Restarting PTS service for '+user
  # cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/bin/service.sh restart'
  cmd = CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh restart' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  cmd = CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh restart' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  # expected_output_rows=['The PTS (module: tidy) is alive','The PTS (module: core) is alive','The PTS (module: http) is alive']
  unexpected_output_rows=['The PTS (module: tidy) is not running','The PTS (module: core) is not running','The PTS (module: http) is not running']
  res = Actions.SSH(host, user, pwd, cmd, 60, true, '')
  Actions.v res.to_s
  unexpected_output_rows.each { |procMsg|
    if res.to_s.downcase.include?(procMsg)
      Actions.f 'PTS process is not alive: '+procMsg+' for user "'+user+'"'
      @@scenario_fails.push('<br>PTS process is not alive: '+procMsg+' for user "'+user+'"')
      fail('PTS process is not alive: '+procMsg+' for user "'+user+'"')
    end
  }
  sleep 120 #Waiting for Ptrade started

  # cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/bin/service.sh status'
  cmd = CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh status' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  cmd = CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh status' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  unexpected_output_rows=['The PTS (module: tidy) is not running','The PTS (module: core) is not running','The PTS (module: http) is not running']
  res = Actions.SSH(host, user, pwd, cmd, 60, true, '')
  Actions.v res.to_s
  unexpected_output_rows.each { |procMsg|
    if res.to_s.downcase.include?(procMsg)
      Actions.f 'PTS process is not alive: '+procMsg+' for user "'+user+'"'
      @@scenario_fails.push('<br>PTS process is not alive: '+procMsg+' for user "'+user+'"')
      fail('PTS process is not alive: '+procMsg+' for user "'+user+'"')
    end
  }

  # cmd ='cat ' + CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/logs/pts_core_*.log'
  cmd = 'cat ' + CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/logs/pts_core_*.log' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  cmd = 'cat ' + CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/logs/pts_core_*.log' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 60) #Display log
  Actions.v '<br>Core Logs -'+res.to_s if(!res.nil?)

  cmd = 'cat ' + CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+"/PTS/logs/pts_core_*.log | egrep -i 'error|exception' | egrep -v '\\-XX\\:\\+HeapDumpOnOutOfMemoryError'" if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  cmd = 'cat ' + CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+"/PTS/logs/pts_core_*.log | egrep -i 'error|exception' | egrep -v '\\-XX\\:\\+HeapDumpOnOutOfMemoryError'" if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 60)
  # Actions.v 'Found "exception|error" in pts_core log'+' for user "'+user+'"' if(res.to_s.downcase.include?('exception') || res.to_s.downcase.include?('error'))
  # Actions.v 'No contents found in pts_core log'+' for user "'+user+'"' if(res.nil? || res.to_s.empty?)
  @@scenario_fails.push('Found "exception|error" in pts_core logs'+' for user "'+user+'":'+"\n"+res.to_s) if(!res.to_s.empty?)
  fail('Found "exception|error" in pts_core logs'+' for user "'+user+'":'+"\n"+res.to_s) if(!res.to_s.empty?)
  Actions.v 'No "exception|error" found in pts_core logs'+' for user "'+user+'"' if(res.to_s.empty?)
=begin
  if(!res.nil? && (res.to_s.downcase.include?('error') || res.to_s.downcase.include?('exception')))
    Actions.f '<br>Exceptions or Errors are found in Core Logs -'+res.to_s
    @@scenario_fails.push('<br>Exceptions or Errors are found in Core Logs -'+res.to_s)
    #fail('<br>Exceptions found in Core Logs -'+res.to_s)
  end
=end

  # cmd ='cat ' + CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/logs/pts_tidy_*.log'
  cmd = 'cat ' + CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/logs/pts_tidy_*.log' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  cmd = 'cat ' + CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/logs/pts_tidy_*.log' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 60) #Display log
  Actions.v '<br>Tidy Logs -'+res.to_s if(!res.nil?)

  # Actions.v 'Found "exception|error" in pts_tidy log'+' for user "'+user+'"' if(res.to_s.downcase.include?('exception') || res.to_s.downcase.include?('error'))
  # Actions.v 'No contents found in pts_core log'+' for user "'+user+'"' if(res.nil? || res.to_s.empty?)
  cmd = 'cat ' + CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+"/PTS/logs/pts_tidy_*.log | egrep -i 'error|exception' | egrep -v '\\-XX\\:\\+HeapDumpOnOutOfMemoryError'" if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  cmd = 'cat ' + CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+"/PTS/logs/pts_tidy_*.log | egrep -i 'error|exception' | egrep -v '\\-XX\\:\\+HeapDumpOnOutOfMemoryError'" if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 60)
  @@scenario_fails.push('Found "exception|error" in pts_tidy logs'+' for user "'+user+'":'+"\n"+res.to_s) if(!res.to_s.empty?)
  fail('Found "exception|error" in pts_tidy logs'+' for user "'+user+'":'+"\n"+res.to_s) if(!res.to_s.empty?)
  Actions.v 'No "exception|error" found in pts_tidy logs'+' for user "'+user+'"' if(res.to_s.empty?)
=begin
  if(!res.nil? && (res.to_s.downcase.include?('error') || res.to_s.downcase.include?('exception')))
    Actions.f '<br>Exceptions found in Tidy Logs -'+res.to_s
    @@scenario_fails.push('<br>Exceptions or Errors are found in Tidy Logs -'+res.to_s)
    #fail('<br>Exceptions or Errors are found in Tidy Logs -'+res.to_s)
  end
=end
end


def killRedis(host, user, pwd)
  Actions.v 'Killing Redis and RedisCli... '

  cmd = 'kill -9 $(/sbin/pidof redis-server) >/dev/null 2>&1'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 20)
  #Actions.c 'SSH command output:' +res.to_s

  cmd = 'sleep 3 && /sbin/pidof redis-server'
  res = Actions.SSH(host, user, pwd, cmd, 20, false, '')
  Actions.v 'SSH command output:' +res.to_s if(!res.nil? && !res.to_s.empty?)

  cmd = 'kill -9 $(/sbin/pidof startRedisCli) >/dev/null 2>&1' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
  cmd = 'kill -9 $(/sbin/pidof startRedisCli1) >/dev/null 2>&1' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 20)
  #Actions.c 'SSH command output:' +res.to_s
end


def killRedisRoot(host)
  #sleep 60
  Actions.v 'Killing Redis and RedisCli... '

  cmd = 'kill -9 $(/sbin/pidof redis-server) >/dev/null 2>&1'
  res = Actions.SSH_NO_FAIL(host, 'root', '123456', cmd, 20)
  #Actions.v 'SSH command output:' +res.to_s

  cmd = 'sleep 5 && /sbin/pidof redis-server'
  res = Actions.SSH(host, 'root', '123456', cmd, 20, false, '')
  Actions.v 'SSH command output:' +res.to_s if(!res.nil? && !res.to_s.empty?)

  cmd = 'kill -9 $(/sbin/pidof startRedisCli) >/dev/null 2>&1'
  res = Actions.SSH_NO_FAIL(host, 'root', '123456', cmd, 10)
  #Actions.v 'SSH command output:' +res.to_s
end

def killRedisRoot2(host, port)
  #sleep 60
  Actions.v 'Killing Redis and RedisCli from root on '+host+':'+port

  rs_existed = false
  rc_existed = false
  # cmd = "/sbin/pidof 'redis-server *:"+port+"'"
  cmd = "/bin/ps -aef|egrep './redis-server'|grep "+port+"|awk '{print $2}'|egrep -v egrep"
  res_pid = Actions.SSH(host, 'root', '123456', cmd, 20, true, '')
  res_pid = res_pid.to_s.strip
  if (!res_pid.nil? && !res_pid.to_s.empty?)
    rs_existed = true
    Actions.v 'Found redis-server process pid ('+res_pid+'), killing it'
    cmd = "kill -9 "+res_pid
    res = Actions.SSH(host, 'root', '123456', cmd, 20, true, '')
    Actions.v 'killRedisRoot2 output: '+res.to_s
  else
    Actions.v 'redis-server process pid not found'
  end

  cmd = "/bin/ps -aef|egrep 'redis-cli -p'|grep "+port+"|awk '{print $2}'|egrep -v egrep"
  res_pid = Actions.SSH(host, 'root', '123456', cmd, 20, true, '')
  res_pid = res_pid.to_s.strip
  if (!res_pid.nil? && !res_pid.to_s.empty?)
    rc_existed = true
    Actions.v 'Found redis-cli process pid ('+res_pid+'), killing it'
    cmd = "kill -9 "+res_pid
    res = Actions.SSH(host, 'root', '123456', cmd, 20, true, '')
    Actions.v 'killRedisRoot2 output: '+res.to_s
  else
    Actions.v 'redis-cli process pid not found'
  end

  # cmd = "sleep 3 && /bin/ps -aef|egrep 'redis-server'|grep "+port+"|awk '{print $2}'"
  if rs_existed
    cmd = "/bin/ps -aef|egrep './redis-server'|grep "+port+"|awk '{print $2}'|egrep -v egrep"
    res = Actions.SSH(host, 'root', '123456', cmd, 20, true, '')
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'Found redis-server process pid after killing it: '+res.to_s
    else
      Actions.v 'redis-server process pid was not found after killing it'
    end
  end

  # cmd = "sleep 3 && /bin/ps -aef|egrep 'redis-cli'|grep "+port+"|awk '{print $2}'"
  if rc_existed
    cmd = "/bin/ps -aef|egrep 'redis-cli -p'|grep "+port+"|awk '{print $2}'|egrep -v egrep"
    res = Actions.SSH(host, 'root', '123456', cmd, 20, true, '')
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'Found redis-cli process pid after killing it: '+res.to_s
    else
      Actions.v 'redis-cli process pid was not found after killing it'
    end
  end
end

def killRedisForUser(host, user, port)
  if (user != CONFIG.get['CORE_HOST_USER'] && user != CONFIG.get['CORE_HOST_USER1'])
    fail('Only users "'+CONFIG.get['CORE_HOST_USER']+'" and "'+CONFIG.get['CORE_HOST_USER1']+'" are allowed for killRedisForUser')
  end
  Actions.v 'Killing Redis and RedisCli on '+host+':'+port+' for user '+user

  cmd = "kill -9 $(/bin/ps -u "+user+" -f|egrep 'redis-server'|grep "+port+"|awk '{print $2}')"
  res = Actions.SSH(host, user, CONFIG.get['CORE_HOST_PWD'], cmd, 20, true, '')
  Actions.v 'killRedisOfUser output:' +res.to_s if(!res.nil? || !res.to_s.empty?)

  cmd = "kill -9 $(/bin/ps -u "+user+" -f|egrep 'redis-cli'|grep "+port+"|awk '{print $2}')"
  res = Actions.SSH(host, user, CONFIG.get['CORE_HOST_PWD'], cmd, 20, true, '')
  Actions.v 'killRedisOfUser output:' +res.to_s if(!res.nil? || !res.to_s.empty?)
end


def displayPtradeAppVersion(host, user, pwd)
  if (user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
    cmd =  'ls -l '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS' if(CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil? || CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].to_s.empty?)
    cmd =  'ls -l '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS' if(!CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil? || !CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].to_s.empty?)
  elsif (user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
    cmd =  'ls -l '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS' if(CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].nil? || CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].to_s.empty?)
    cmd =  'ls -l '+CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS' if(!CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].nil? || !CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].to_s.empty?)
  else
    fail('Only users '+CONFIG.get['CORE_HOST_USER']+' or '+CONFIG.get['CORE_HOST_USER1']+' are allowed to perform displayPtradeAppVersion')
  end
  res = Actions.SSH(host, user, pwd, cmd, 20, true, '')
  Actions.c '<b>App Version - '+res.to_s+'</b>'

  r=res.split(' ')
  fail('An App is not installed') if(r[10].nil?)
  #$app_version=r[10].gsub!('/export/home/'+user+'/Automation/packages/','').to_s
  if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
    $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER'], false)
    #@@new_ptrade_version_number = $app_version.scan(/PTS_MAIN_\d+.\d+.\d+.\d+.(\d+)/)[0][0]
  end
  if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
    $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER1'], false)
    #@@old_ptrade_version_number = $app_version.scan(/PTS_MAIN_\d+.\d+.\d+.\d+.(\d+)/)[0][0]
  end
  Actions.p '<b>'+$app_version.to_s+' (' + user+ ') </b>' if(user==CONFIG.get['CORE_HOST_USER1']) #Production version -
  Actions.p '<b>'+$app_version.to_s+' (' + user+ ') </b>'  if(user==CONFIG.get['CORE_HOST_USER']) #New version -
  Actions.setBuildProperty('PTRADE_APP_VERSION', $app_version.to_s) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'].to_s.downcase)
  Actions.setBuildProperty('PTRADE1_APP_VERSION', $app_version.to_s) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'].to_s.downcase)
end


def displayPtradeAppOnlyVersion(host, user, pwd)
  if (user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
    cmd =  'ls -l '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS' if(CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil? || CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].to_s.empty?)
    cmd =  'ls -l '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS' if(!CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil? || !CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].to_s.empty?)
  elsif (user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
    cmd =  'ls -l '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS' if(CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].nil? || CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].to_s.empty?)
    cmd =  'ls -l '+CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS' if(!CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].nil? || !CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].to_s.empty?)
  else
    fail('Only users '+CONFIG.get['CORE_HOST_USER']+' or '+CONFIG.get['CORE_HOST_USER1']+' are allowed to perform displayPtradeAppOnlyVersion')
  end
  res = Actions.SSH(host, user, pwd, cmd, 20, true, '')
  r=res.split(' ')
  fail('The App is not installed') if(r[10].nil?)
  Actions.v 'App version from PTS link: '+r

  #$app_version=r[10].gsub!('/export/home/'+user+'/Automation/packages/','').to_s
  $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER'], false) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
  $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER1'], false) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
  Actions.c '<b>Ptrade App version - '+$app_version.to_s+'</b>'
  Actions.setBuildProperty('PTRADE_APP_VERSION', $app_version.to_s) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
  Actions.setBuildProperty('PTRADE1_APP_VERSION', $app_version.to_s) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
end


def displayPtradeAppOnlyVersion2(host, user, pwd)
  if (user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
    cmd =  'ls -l '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS' if(CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil? || CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].to_s.empty?)
    cmd =  'ls -l '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS' if(!CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil? || !CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].to_s.empty?)
  elsif (user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
    cmd =  'ls -l '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS' if(CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].nil? || CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].to_s.empty?)
    cmd =  'ls -l '+CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS' if(!CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].nil? || !CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].to_s.empty?)
  else
    fail('Only users '+CONFIG.get['CORE_HOST_USER']+' or '+CONFIG.get['CORE_HOST_USER1']+' are allowed to perform displayPtradeAppOnlyVersion2')
  end
  res = Actions.SSH(host, user, pwd, cmd, 20, true, '')
  r=res.split(' ')
  fail('The App is not installed') if(r[10].nil?)
  Actions.v 'App version from PTS link: '+r.to_s if(!r.nil?)

  $app_version =  Actions.displayTarVersion2(CONFIG.get['CORE_HOST_USER'], false) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  $app_version =  Actions.displayTarVersion2(CONFIG.get['CORE_HOST_USER1'], false) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  Actions.p '<b>Ptrade App version - '+$app_version.to_s+'</b>'
  Actions.setBuildProperty('PTRADE_APP_VERSION', $app_version.to_s) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  Actions.setBuildProperty('PTRADE1_APP_VERSION', $app_version.to_s) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
end

def displayPtradeDbVersion(host, user, pwd)
  $app_version =  Actions.displayTarVersion2(CONFIG.get['CORE_HOST_USER'], true) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
  $app_version =  Actions.displayTarVersion2(CONFIG.get['CORE_HOST_USER1'], true) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
  Actions.c '<b>Ptrade DB Schema version - '+$app_version.to_s+'</b>'
  Actions.setBuildProperty('PTRADE_SCHEMA_VERSION', $app_version.to_s) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
  Actions.setBuildProperty('PTRADE1_SCHEMA_VERSION', $app_version.to_s) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
end


def displayPtradeAppAndDbVersionForUpgrade(host, user, pwd)

  if (user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
    cmd =  'ls -l '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS' if(CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil? || CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].to_s.empty?)
    cmd =  'ls -l '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS' if(!CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil? || !CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].to_s.empty?)
  elsif (user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
    cmd =  'ls -l '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS' if(CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].nil? || CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].to_s.empty?)
    cmd =  'ls -l '+CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS' if(!CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].nil? || !CONFIG.get['PTRADE1_APP_INSTALL_FOLDER'].to_s.empty?)
  else
    fail('Only users '+CONFIG.get['CORE_HOST_USER']+' or '+CONFIG.get['CORE_HOST_USER1']+' are allowed to perform displayPtradeAppAndDbVersionForUpgrade')
  end
  res = Actions.SSH(host, user, pwd, cmd, 20, true, '')
  Actions.v '<b>App Version - '+res.to_s+'</b>'
  r=res.split(' ')
  fail('An App is not installed') if(r[10].nil?)
  #$app_version=r[10].gsub!('/export/home/'+user+'/Automation/packages/','').to_s

  $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER'], true) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
  $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER1'], true) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
  Actions.p '<b>'+$app_version.to_s+' (' + user+ ') </b>' if(user==CONFIG.get['CORE_HOST_USER1']) #Production version -
  Actions.p '<b>'+$app_version.to_s+' (' + user+ ') </b>'  if(user==CONFIG.get['CORE_HOST_USER']) #New version -
  Actions.setBuildProperty('PTRADE_APP_VERSION', $app_version.to_s) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
  Actions.setBuildProperty('PTRADE_APP_VERSION', $app_version.to_s) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
end


def displayPtradeDbVersionForUpgrade(user)
  $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER'], true) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER1'], true) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  Actions.p '<b>'+$app_version.to_s+' (' + user+ ') </b>' if(user==CONFIG.get['CORE_HOST_USER1']) #Production version -
  Actions.p '<b>'+$app_version.to_s+' (' + user+ ') </b>'  if(user==CONFIG.get['CORE_HOST_USER']) #New version -
  Actions.setBuildProperty('PTRADE_APP_VERSION', $app_version.to_s) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  Actions.setBuildProperty('PTRADE_APP_VERSION', $app_version.to_s) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
end


def displaySdataSchemaOldVersion
  $app_version = Actions.displayTarVersion(CONFIG.get['ORACLE_SDATA_HOST_TEMPLATE_SCHEMA'], true)#sdata1
  Actions.p '<b>'+$app_version.to_s+' (sdata1) '+'</b>' #Sdata Production Schema Version
  Actions.setBuildProperty('SDATA1_SCHEMA_VERSION', $app_version.to_s)
end


def displaySdataSchemaNewVersion
  $app_version = Actions.displayTarVersion(CONFIG.get['ORACLE_SDATA_HOST_SCHEMA'], true)#sdata
  Actions.p '<b>'+$app_version.to_s+' (sdata) '+'</b>' #Sdata Last Schema Version -
  Actions.setBuildProperty('SDATA_SCHEMA_VERSION', $app_version.to_s)
end


def deleteSaphireRedisOutputOnRemoteServerForOldVersion
  deleteSaphireRedisOutputOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
end


def deleteSaphireRedisOutputOnRemoteServerForNewVersion
  deleteSaphireRedisOutputOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end


def deleteSaphireRedisOutputOnRemoteServer(host, user, pwd)
  fail('Expecting users - ' +CONFIG.get['CORE_HOST_USER']+ ' or ' +CONFIG.get['CORE_HOST_USER']) if(user!=CONFIG.get['CORE_HOST_USER'] || user!=CONFIG.get['CORE_HOST_USER1'])
  cmd = 'rm -f /export/home/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/RedisMonitor1.txt' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  cmd = 'rm -f /export/home/'+CONFIG.get['CORE_HOST_USER']+'/Automation/RedisMonitor.txt' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)
end


def deleteFolderContentsOnRemoteServer(host, user, pwd, dir_path)
  cmd = 'mkdir -p '+dir_path+' && cd '+dir_path+' && rm -rf *'
  res = Actions.SSH(host, user, pwd, cmd, 20, false, '')
end


def deleteFolderContentsOnRemoteServerIfFolderExist(host, user, pwd, dir_path)
  cmd = 'cd /export/home/'+user+'/'+dir_path+' && rm -rf *'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 20)
end


def deleteCsvFilesOnRemoteServerForOldVersion
  Actions.v 'Deleting contents of MyT csv tickets - ' + @@CONFIG['MYT_CSV_REMOTE_DIR_PATH1'] + ' on ' + CONFIG.get['CORE_HOST']
  deleteFolderContentsOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/data/tickets')
  deleteFolderContentsOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/data/tickets/common')
  deleteFolderContentsOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/data/tickets/myt')
end


def deleteCsvFilesOnRemoteServerForNewVersion
  Actions.v 'Deleting contents of MyT csv tickets - ' + @@CONFIG['MYT_CSV_REMOTE_DIR_PATH'] + ' on ' + CONFIG.get['CORE_HOST']
  deleteFolderContentsOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/data/tickets')
  deleteFolderContentsOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/data/tickets/common')
  deleteFolderContentsOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/data/tickets/myt')
end


def deleteCsvFilesOnRemoteServer(user)
  suffix = ''
  suffix = '1' if(user==CONFIG.get['CORE_HOST_USER1'])
  Actions.v 'Deleting contents of MyT csv tickets - ' + @@CONFIG['MYT_CSV_REMOTE_DIR_PATH' +suffix] + ' on ' + CONFIG.get['CORE_HOST']
  deleteFolderContentsOnRemoteServer(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'],  CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/data/tickets')
  deleteFolderContentsOnRemoteServer(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/data/tickets/common')
  deleteFolderContentsOnRemoteServer(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/data/tickets/myt')
end


def restartRedisWithNewConfig(host, user, pwd, remote_dir, script_name)
  Actions.v 'Copying redis-cli script to redis src for user '+user+' ... '
  cmd = "cp -f "+remote_dir+'/'+script_name+' '+'$HOME/redis/src' \
         +" && sleep 3"\
         +" && dos2unix $HOME/redis/src/"+script_name\
         +" && chmod 755 "+ '$HOME/redis/src/'+script_name \
         +" && sleep 1"

  res = Actions.SSH(host, user, pwd, cmd, 20, true, '') #TODO fetch output
  Actions.v 'Restarting Redis with new config... Redis output redirected to $HOME/Automation/RedisMonitor*.txt'

  cmd = "cd $HOME/redis/src && ./startRedisCli.sh" if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
  cmd = "cd $HOME/redis/src && ./startRedisCli1.sh" if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 20)
end


def restartRedisWithNewConfig2(host, user, pwd, remote_dir, script_name, port)
  if (user != CONFIG.get['CORE_HOST_USER'] && user != CONFIG.get['CORE_HOST_USER1'])
    fail('Only users '+CONFIG.get['CORE_HOST_USER']+' and '+CONFIG.get['CORE_HOST_USER1']+' are allowed for restartRedisWithNewConfig2')
  end

  Actions.v 'Copying startRedisCli script to redis src for user '+user+' on '+host
  cmd = "cp -f "+remote_dir+"/"+script_name+" /export/home/"+user+"/redis/src"\
         +" && dos2unix /export/home/"+user+"/redis/src/"+script_name\
         +" && chmod 755 /export/home/"+user+"/redis/src/"+script_name
  res = Actions.SSH(host, user, pwd, cmd, 30, true, '')
  Actions.v 'Restarting Redis with new config on '+host+':'+port+' for user '+user+'... Redis output redirected to /export/home/'+user+'/Automation/RedisMonitor*.txt'

  cmd = "cd /export/home/"+user+"/redis/src && ./"+script_name+" redisPort: "+port
  res = Actions.SSH(host, user, pwd, cmd, 20, false, '')
  # Actions.f 'Output found while starting redis: '+res.to_s if(!res.nil? && !res.to_s.empty?)

  cmd = "sleep 3 && /bin/ps -aef|egrep './redis-server'|grep "+port+"|awk '{print $2}'|egrep -v egrep"
  res = Actions.SSH(host, user, pwd, cmd, 20, true, '')
  res = res.to_s.strip
  if (res.nil? && res.to_s.empty?)
    Actions.f 'redis-server process pid NOT FOUND after starting redis'
  else
    Actions.v 'Found redis-server process pid after starting redis: '+res
  end
end


def restartRedisWithNewConfigForOldVersion
  restartRedisWithNewConfig(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation', 'startRedisCli1.sh')
end


def restartRedisWithNewConfigForOldVersion2
  restartRedisWithNewConfig2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation', 'startRedisCli1_custom.sh', '6389')
end


def restartRedisWithNewConfigForNewVersion
  restartRedisWithNewConfig(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation', 'startRedisCli.sh')
end


def restartRedisWithNewConfigForNewVersion2
  restartRedisWithNewConfig2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation', 'startRedisCli_custom.sh', '6399')
end


def restartRedisWithNewConfig3(user)
  restartRedisWithNewConfig2(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation', 'startRedisCli1_custom.sh', '6389') if(user==CONFIG.get['CORE_HOST_USER1'])
  restartRedisWithNewConfig2(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation', 'startRedisCli_custom.sh', '6399') if(user==CONFIG.get['CORE_HOST_USER'])
end


def submitErs
  $cmd_res=nil
  $exec_id=nil
  $er=nil

  Actions.v 'Running MSLErSender with ers folder'
  $cmd_res = Actions::WINCMD('cd ' +Dir.getwd+'/libs/MSLErSender/bin & mslErSender.bat ers ', 120, 'txt with execId') #Run ER Simulator
  $exec_ids = $cmd_res.to_s.scan(/txt with execId(.*?)\[(.*?)\]/i)
  #$exec_id = $exec_ids[0][1]
  Actions.v '<br>'+'Following ExecIDs are Found - ' + $exec_ids.to_s + '<br>'
end


def runRemoteMslSenderForOldVersion
  runRemoteMslSender(CONFIG.get['CORE_HOST_USER1'], "Old")#ptrade1
end


def runRemoteMslSenderForNewVersion
  runRemoteMslSender(CONFIG.get['CORE_HOST_USER'], "New")#ptrade
end


def runRemoteMslSender(user, version)#TODO Actions
  cmd =  "cd $HOME/Automation && dos2unix *.sh"
  res = Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], cmd, 120)

  Actions.v('<b>Running MslErSender on '+CONFIG.get['CORE_HOST'].to_s+' with export/home/'+user+'/Automation/ers folder</b>')
  cmd =  "cd $HOME/MSLErSender_1.2/bin && ./mslErSender.sh -i 100 -s $HOME/Automation/ers/ -pid"
  res = Actions.SSH(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], cmd, 120, true, 'txt with execId')
  #Actions.v 'MslSender output - '+res.to_s



  e1='exception'
  e2='error'
  if (res.to_s.downcase.include?(e1) || res.to_s.downcase.include?(e2))
    @@scenario_fails.push('MslSender responded with errors for '+version+' version')
    fail('MslSender responded with errors for '+version+ ' version')
  end

  Actions.v 'Waiting for Core for ' + CONFIG.get['WAIT_FOR_MSL_PROCESSING_SECS'].to_s + ' secs'
  sleep CONFIG.get['WAIT_FOR_MSL_PROCESSING_SECS']
  Actions.v 'MslSender output - '+res.to_s

  runPtsLogParser(user, CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/ers') #for upgrade scenario1, not used in Upgrade2
end


def runRemoteMslSender2(user, mslIP, cmd, run_secs)#TODO Actions used for performance
  Actions.v "Kill MslErSender"
  cmd2 = "kill -9 $(/bin/ps -aef |egrep -i 'sender'|grep -v grep|awk '{print $2}')"
  res = Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], cmd2, 20)

  Actions.v('<b>Running MslErSender on '+CONFIG.get['CORE_HOST'].to_s+' user: '+user+' cmd: '+cmd+'</b>')
  res = Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], cmd, run_secs )


  sleep run_secs


  #Kill MslErSender after timeout
  Actions.v "Kill MslErSender"
  cmd2 = "kill -9 $(/bin/ps -aef |egrep -i 'sender'|grep -v grep|awk '{print $2}')"
  res = Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], cmd2, 20)
  Actions.v "Kill MslErSender cmd result: "+res.to_s if !res.nil?

  if(!res.nil? && (res.to_s.downcase.include?('error') || res.to_s.downcase.include?('exception')))
    Actions.f 'Exceptions or errors are found in MslSender logs for '+user+': '+res.to_s
    @@scenario_fails.push('Exceptions or errors are found in MslSender logs for '+user+': '+res.to_s)
    fail('Exceptions or errors are found in MslSender logs for '+user+': '+res.to_s)
  end

  Actions.v 'Waiting for Core for ' + CONFIG.get['WAIT_FOR_MSL_PROCESSING_SECS'].to_s + ' secs'
  sleep CONFIG.get['WAIT_FOR_MSL_PROCESSING_SECS'].to_i
  Actions.v 'MslErSender output - '+res.to_s
end


def runRemoteMslSender4upgrade2(user, randomExecId, er_folder, mslIP)#TODO Actions
  Actions.v('<b>Running MslErSender on '+CONFIG.get['CORE_HOST'].to_s+' with export/home/'+user+'/Automation/'+er_folder+' folder</b>')
  cmd =  "cd $HOME/MSLErSender_1.2_"+mslIP+"/bin && ./mslErSender.sh -i 100 -s $HOME/Automation/"+er_folder+"/ -pid" if(randomExecId)
  cmd =  "cd $HOME/MSLErSender_1.2_"+mslIP+"/bin && ./mslErSender.sh -i 100 -s $HOME/Automation/"+er_folder+"/" if(!randomExecId)
  res = Actions.SSH(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], cmd, 120, true, 'txt with execId')

  if(!res.nil? && (res.to_s.downcase.include?('error') || res.to_s.downcase.include?('exception')))
    Actions.f 'Exceptions or errors are found in MslSender logs for '+user+': '+res.to_s
    @@scenario_fails.push('Exceptions or errors are found in MslSender logs for '+user+': '+res.to_s)
    fail('Exceptions or errors are found in MslSender logs for '+user+': '+res.to_s)
  end

  #sleep 20
  #Actions.v 'MslSender output - '+res.to_s

  Actions.v 'Waiting for Core for ' + CONFIG.get['WAIT_FOR_MSL_PROCESSING_SECS'].to_s + ' secs'
  sleep CONFIG.get['WAIT_FOR_MSL_PROCESSING_SECS']
  Actions.v 'MslSender output - '+res.to_s
end


def runPtsLogParser(user,ers_path)
  Actions.v 'Running PtsLogParser to check ERs arrival for user: '+user

  if (user == CONFIG.get['CORE_HOST_USER1'] || user == CONFIG.get['CORE_HOST_USER'])
    Actions.rigthsForFile(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], '$HOME/Automation','PTSlogsParser_'+user+'.sh','755')
    res = Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], '$HOME/Automation/PTSlogsParser_'+user+'.sh counter: '+ers_path.to_s.downcase.split('/')[-1]+' ers_path: '+ers_path+' pts_logs_path: '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/logs', 120) if(user == CONFIG.get['CORE_HOST_USER'])
    res = Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], '$HOME/Automation/PTSlogsParser_'+user+'.sh counter: '+ers_path.to_s.downcase.split('/')[-1]+' ers_path: '+ers_path+' pts_logs_path: '+CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/logs', 120) if(user == CONFIG.get['CORE_HOST_USER1'])
  else
    Actions.f('Invalid user "'+user+'", exiting PtsLogParser')
    return
  end

  if (!res.to_s.include?('No difference found'))
    @@scenario_fails.push('PtsLogParser responded with errors for '+user+res.to_s)
    Actions.f('PtsLogParser Error output - ' + res.to_s)
    fail('PtsLogParser responded with errors for '+user)
  else
    Actions.v('PtsLogParser output - ' + res.to_s)
=begin
    ers_log_count=res.to_s.match('(^PtsLogParser output - No difference found: )(\d+)(.*)')
    v 'ers_log_count: ' + ers_log_count[2].to_s + 'for user: ' + user  if(!ers_log_count.nil?)
    @@ers_count_ptrade+=ers_log_count[2].to_i if(!ers_log_count.nil? && user.to_s.downcase=='ptrade')
    @@ers_count_ptrade1+=ers_log_count[2].to_i if(!ers_log_count.nil? && user.to_s.downcase=='ptrade1')
=end
    @@ers_count_ptrade1 = Actions.getEnvVar(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], '_PTRADE1_ERS_COUNT') if(user.to_s.downcase=='ptrade1')
    @@ers_count_ptrade = Actions.getEnvVar(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], '_PTRADE_ERS_COUNT') if(user.to_s.downcase=='ptrade')
  end
end


def downloadFileFromRemote(host, user, pwd, local_target_dir, remote_dir, file_name)#TODO Actions
  Actions.WINCMD_NO_FAIL('cd ' +local_target_dir+' & mkdir ' +  @@time_stamp, 10)
  sleep 3
  Actions.downloadRemoteFile(host, user, pwd, remote_dir+'/'+file_name, local_target_dir+'/'+@@time_stamp+'/'+file_name)
  #sleep 5
end


def downloadJsonForOldVersion
  Actions.v('Downloading Sapphire Json for Old Version')
  downloadFileFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'],Dir.getwd+'/templates/old_app_json', '/export/home/'+CONFIG.get['CORE_HOST_USER1']+'/Automation', 'RedisMonitor1.txt')
  #downloadFileFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'],Dir.getwd+'/templates/old_app_json', '/export/home/'+CONFIG.get['CORE_HOST_USER1']+'/Automation', 'RedisMonitor1.txt')
end


def downloadJsonForNewVersion
  Actions.v('Downloading Sapphire Json for New Version')
  downloadFileFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/new_app_json', '/export/home/'+CONFIG.get['CORE_HOST_USER']+'/Automation',  'RedisMonitor.txt')
end


def downloadJson(user)
  Actions.v('Downloading Sapphire Json for user: ' +user)
  downloadFileFromRemote(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'],Dir.getwd+'/templates/old_app_json', '/export/home/'+user+'/Automation', 'RedisMonitor1.txt') if(user==CONFIG.get['CORE_HOST_USER1'])
  downloadFileFromRemote(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/new_app_json', '/export/home/'+user+'/Automation',  'RedisMonitor.txt') if(user==CONFIG.get['CORE_HOST_USER'])
end


def downloadTidyLogForOldVersion
  Actions.v('Downloading Sapphire Json for Old Version')
  # downloadFileFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'],Dir.getwd+'/templates/old_app_rtns', '/export/home/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/PTS/logs', 'pts_tidy_3.log')
  downloadFileFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'],Dir.getwd+'/templates/old_app_rtns', '/export/home/'+CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/logs', 'pts_tidy_3.log')
end


def downloadTidyLogForNewVersion
  Actions.v('Downloading Sapphire Json for New Version')
  downloadFileFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/new_app_rtns', '/export/home/'+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/logs', 'pts_tidy_3.log')
end


def downloadDirFromRemote(host, user, pwd, local_target_dir, remote_dir)
  Actions.WINCMD_NO_FAIL('cd ' +local_target_dir+' & mkdir ' +  @@time_stamp, 10)
  Actions.v ' Download to '+local_target_dir+'/'+@@time_stamp+ ' started...'
  Actions.downloadRemoteDir(host, user, pwd, remote_dir, local_target_dir+'/'+@@time_stamp)
  Actions.v ' Download to '+local_target_dir+'/'+@@time_stamp+ ' finished'
end

def downloadDirFromRemoteWithCreateDir(host, user, pwd, local_target_dir, create_dir, remote_dir)
  Actions.WINCMD_NO_FAIL('cd ' +local_target_dir+' & mkdir ' +  create_dir, 10)
  Actions.downloadRemoteDir(host, user, pwd, remote_dir, local_target_dir+'/'+create_dir)
end


def downloadDirFromRemote2(host, user, pwd, local_target_dir, remote_dir)
  begin
    Actions.downloadRemoteDir(host, user, pwd, remote_dir, local_target_dir)
  rescue Exception=>e
    Actions.f('No logs found on remote server ' + host + ' for user ' + user + ' in folder' + remote_dir + ' Error - '+e.message)
    @@scenario_fails.push(e.message)
  end
end


def downloadCsvFolderForOldVersion
  Actions.v 'Downloading MyT And Common csv files from Remote Folder for Old Version'
  downloadDirFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/old_app_csv', CONFIG.get['MYT_CSV_REMOTE_DIR_PATH1'])
end


def downloadCsvFolder(user)
  Actions.v 'Downloading MyT And Common csv files from Remote Folder for user: '+user
  downloadDirFromRemote(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/old_app_csv', CONFIG.get['MYT_CSV_REMOTE_DIR_PATH1']) if(user==CONFIG.get['CORE_HOST_USER1'])
  downloadDirFromRemote(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/new_app_csv', CONFIG.get['MYT_CSV_REMOTE_DIR_PATH']) if(user==CONFIG.get['CORE_HOST_USER'])
end


def downloadTraianaCsvFolderForOldVersion(local_folder_path,remote_folder_path)
  Actions.v 'Downloading Traiana csv files from Remote Folder for Old Version'
  downloadDirFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/'+local_folder_path, remote_folder_path)
end


###logs
def downloadDblogsForPtradeOldVersion
  Actions.v 'Downloading DB install logs for PTRADE schema old version '
  downloadDirFromRemote2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/logs_PT_DB1')
  #Actions.displayFilesForDownloadInFolder(folder_path)
end


def downloadDblogsForPtradeNewVersion
  Actions.v 'Downloading DB install logs for PTRADE schema last version '
  downloadDirFromRemote2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/logs_PT_DB')
end


def downloadDblogsForSdataOldVersion
  Actions.v 'Downloading DB install logs for SDATA schema old version '
  downloadDirFromRemote2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/logs_SDATA1')
end


def downloadDblogsForSdataNewVersion
  Actions.v 'Downloading DB install logs for SDATA schema last version '
  downloadDirFromRemote2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/logs_SDATA')
end


def downloadAppLogsForOldVersion
  Actions.v 'Downloading App install logs for old version '
  downloadDirFromRemote2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/logs_PT_APP1')
end


def downloadAppLogsForNewVersion
  Actions.v 'Downloading App install logs for last version '
  downloadDirFromRemote2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/logs_PT_APP')
end


#### end logs


def downloadCsvFolderForNewVersion
  Actions.v 'Downloading MyT And Common csv files from Remote Folder for New Version'
  downloadDirFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/new_app_csv', CONFIG.get['MYT_CSV_REMOTE_DIR_PATH'])
end


def downloadTraianaCsvFolderForNewVersion(local_folder_path,remote_folder_path)
  Actions.v 'Downloading Traiana csv files from Remote Folder for New Version'
  downloadDirFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/'+local_folder_path, remote_folder_path)
end


def buildPtradeOldSchema(version)
  begin
    customPtradeOldSchemaDeploy(version)
  rescue Exception=>e
    @@scenario_fails.push('PtradeOldSchemaDeploy failed for version ' + version)
    Actions.displaySanityLogs(false, false, false, true)
    fail('PtradeOldSchemaDeploy failed for version ' + version)
  end
end


def buildPtradeOldSchema2(version)
  res = ''
  begin
    res = customPtradeOldSchemaDeploy2(version)
  rescue Exception=>e
    @@scenario_fails.push('PtradeOldSchemaDeploy failed for version ' + version + (e.message.nil? ? '' : e.message))
    # Actions.displaySanityLogs(false, false, false, true)
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('PtradeOldSchemaDeploy failed for version ' + version)
  end
end


def buildPtradeNewSchema(version)
  begin
    customPtradeNewSchemaDeploy(version)
  rescue Exception=>e
    @@scenario_fails.push('PtradeNewSchemaDeploy failed for version ' + version)
    Actions.displaySanityLogs(false, false, true, false)
    fail('PtradeNewSchemaDeploy failed for version ' + version) if(!version.to_s.strip.empty?)
    fail('PtradeNewSchemaDeploy failed for the Last version ') if(version.to_s.strip.empty?)
  end
end


def buildPtradeNewSchema2(version)
  res = ''
  begin
    res = customPtradeNewSchemaDeploy2(version)
  rescue Exception=>e
    @@scenario_fails.push('PtradeNewSchemaDeploy failed for version ' + version)
    # Actions.displaySanityLogs(false, false, true, false)
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('PtradeNewSchemaDeploy failed for version ' + version) if(!version.to_s.strip.empty? || !version.nil?)
    fail('PtradeNewSchemaDeploy failed for the Last version ') if(version.to_s.strip.empty? || version.nil?)
  end
end


def buildSdataSchema(user, version)
  if(!user.nil? && !user.to_s.empty? && user.to_s.downcase=='sdata1')
    Actions.v 'Building SDATA schema version "'+version+'" on Oracle server '+CONFIG.get['ORACLE_HOST']+' for user '+user
    #Old Schema
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/buildSchema_sdata1.sh', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/buildSchema_sdata1.sh',40)
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/db_config_sdata1_example.sql', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/db_config_sdata1_example.sql',40)
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/db_config_sdata1_example2.sql', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/db_config_sdata1_example2.sql',40)
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/sdata_schema1_install_automatic.sh', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/sdata_schema1_install_automatic.sh',40)
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/sdata_schema1_install_automatic.cfg', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/sdata_schema1_install_automatic.cfg',40)

    #Old Schema
    Actions.v 'Building SDATA DB Schema version "'+CONFIG.get['SDATA_OLD_SCHEMA_VERSION']+'" for '+CONFIG.get['ORACLE_HOST']+':sdata1 from scratch...'

    cmd = 'dos2unix '+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/*.sh && chmod 755 '+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/*.sh && dos2unix '+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/*.sql'
    Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

    scriptInstall='sdata_schema1_install_automatic.sh'
    # addition='extract_to: '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/'+user.to_s.capitalize+'_'+versionLabel.sub(/\..*/, '').to_s
    addition='extract_to: '+CONFIG.get['SDATA1_EXTRACT_FOLDER']
    scriptInstall+=' '+addition

    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+scriptInstall+' -n '+version if(!version.nil? && !version.to_s.strip.empty?)
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+scriptInstall if(version.nil? || version.to_s.strip.empty?)
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 600, true, '')

    Actions.v '<b>SDATA DB Schema Version "'+CONFIG.get['SDATA_OLD_SCHEMA_VERSION']+'" is built for user '+user+' on '+CONFIG.get['ORACLE_HOST']+'</b>'

    return res
  end

  if(!user.nil? && !user.to_s.empty? && user.to_s.downcase=='sdata')    # sdata new version

    Actions.v 'Building SDATA schema version "'+version+'" on Oracle server '+CONFIG.get['ORACLE_HOST']+' for user '+user
    #Last Schema
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/db_config_sdata_example.sql', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/db_config_sdata_example.sql',40)
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/db_config_sdata_example2.sql', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/db_config_sdata_example2.sql',40)
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/sdata_schema_install_automatic.sh', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/sdata_schema_install_automatic.sh',40)
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/sdata_schema_install_automatic.cfg', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/sdata_schema_install_automatic.cfg',40)

    #Last Schema
    Actions.v 'Building LAST SDATA DB Schema for '+CONFIG.get['ORACLE_HOST']+':sdata from scratch... '
    cmd =  'dos2unix '+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/sdata_schema_install_automatic.sh'\
         +' && chmod 755 '+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/sdata_schema_install_automatic.sh'
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

    cmd='chmod 755 '+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/sdata_schema_install_automatic.sh'
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, false, '')

    scriptInstall='sdata_schema_install_automatic.sh'
    # addition='extract_to: '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/'+user.to_s.capitalize+'_'+versionLabel.sub(/\..*/, '').to_s
    addition='extract_to: '+CONFIG.get['SDATA_EXTRACT_FOLDER']
    scriptInstall+=' '+addition

    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+scriptInstall+' -n '+version if(!version.nil? && !version.to_s.strip.empty?)
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+scriptInstall  if(version.nil? || version.to_s.strip.empty?)
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 600, true, '')

    Actions.v '<b>SDATA DB Schema Last version is built for user '+user+' on '+CONFIG.get['ORACLE_HOST']+'</b>'
  end
end


def moveAutomationDir(host, user, pwd)
  Actions.v 'Renaming Automation into Automation_old and creating empty Automation dir on host '+host+' for user '+user+'... '
  cmd = 'rm -rf Automation_old && mv Automation Automation_old && mkdir -p Automation' #'mkdir -p Automation && mv Automation Automation_old && mkdir -p Automation'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 20)
end


#########Custom Build##########
Given /^Sdata Schema is Built$/ do
  #Actions.createLocalDirs
  steps %Q{
    Given Automation dir exist on oracle server
    Given DB Sdata Custom Schema is built
  }
  displaySdataSchemaNewVersion

end

Given /^Sdata Schema is built for LAB$/ do
  Actions.isIpValidInParams
  CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']
  CONFIG.get['CORE_HOST'] = CONFIG.get['CORE_HOST_IP']

  if (CONFIG.get['PTRADE_SCHEMA'] != 'ptrade' && CONFIG.get['PTRADE_SCHEMA'] != 'ptrade1')
    Actions.f 'ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"'
    fail('ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"')
  end

  Actions.createLocalDirsTemplatesLogsDb
  steps %Q{
    Given Automation dir exist on oracle server
    Given DB Sdata Custom Schema is built for LAB
  }

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('SDATA')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    displayDbSchemaVersion2('SDATA1')
  end
end


Given /^Ptrade App and Schema are Built$/ do
  #Actions.createLocalDirs
  steps %Q{
    Given Automation dir exist on oracle server
  }

  if(ENV['PTRADE_OLD_SCHEMA_VERSION'].nil?)
    customPtradeSchemaDeploy(nil)
    customPtradeAppDeploy(nil)
    #downloadDblogsForPtradeNewVersion
    #downloadAppLogsForNewVersion

  else
    customPtradeSchemaDeploy(ENV['PTRADE_OLD_SCHEMA_VERSION'])
    customPtradeAppDeploy(ENV['PTRADE_OLD_SCHEMA_VERSION'])
    #downloadDblogsForPtradeOldVersion
    #downloadAppLogsForOldVersion
  end
end


def failIfNotArray(examinee)
  if examinee.kind_of?(Array)
    # Actions.v ''
  else
    fail('Please give a correct array of parameters to check')
  end
end


def checkMandatoryParams(params_array)
  failIfNotArray(params_array)
  params_array.each { |param| fail('Please define missing mandatory parameter "'+param+'"') if(CONFIG.get[param].nil? || CONFIG.get[param.to_s].to_s.empty?) }
  Actions.v 'Mandatory parameters "'+params_array.join(",")+'" are not empty'
end

Given /^Ptrade App and Schema are built for LAB$/ do
  Actions.isIpValidInParams
  CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']
  CONFIG.get['CORE_HOST'] = CONFIG.get['CORE_HOST_IP']

  if (CONFIG.get['PTRADE_SCHEMA'] != 'ptrade' && CONFIG.get['PTRADE_SCHEMA'] != 'ptrade1')
    Actions.f 'ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"'
    fail('ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"')
  end

  ENV['PTRADE_NEW_APP_VERSION_OU'] = ENV['PTRADE_NEW_SCHEMA_VERSION_OU'] if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)

  Actions.createLocalDirsTemplatesLogsDb
  steps %Q{
    Given Automation dir exists on oracle server2
    Given Automation dir exists on ptrade server2
  }

  stopRegularPtradeServiceNoFails(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

  if(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    customPtradeSchemaDeployLab(nil)
    #downloadDblogsForPtradeNewVersion
  else
    customPtradeSchemaDeployLab(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'])
    #downloadDblogsForPtradeNewVersion
  end

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('PTRADE')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    displayDbSchemaVersion2('PTRADE1')
  end

  if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)
    customPtradeAppDeployLab(nil, false)
    #downloadAppLogsForNewVersion
  else
    customPtradeAppDeployLab(ENV['PTRADE_NEW_APP_VERSION_OU'], false)
    #downloadAppLogsForNewVersion
  end

  displayPtradeAppOnlyVersion2(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end


Given /^Ptrade App, Schema and optional Sdata are upgraded for LAB$/ do
  Actions.isIpValidInParams
  CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']
  CONFIG.get['CORE_HOST'] = CONFIG.get['CORE_HOST_IP']

  if (CONFIG.get['PTRADE_SCHEMA'] != 'ptrade' && CONFIG.get['PTRADE_SCHEMA'] != 'ptrade1')
    Actions.f 'ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"'
    fail('ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"')
  end

  ENV['PTRADE_NEW_APP_VERSION_OU'] = ENV['PTRADE_NEW_SCHEMA_VERSION_OU'] if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)

  Actions.createLocalDirsTemplatesLogsDb
  steps %Q{
    Given Automation dir exists on oracle server2
    Given Automation dir exists on ptrade server2
  }

  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    steps %Q{
      Given DB Sdata Custom Schema is built for LAB
    }
  else
    Actions.c '<b>NOT deploying SDATA for scratch</b>'
  end

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('SDATA')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    displayDbSchemaVersion2('SDATA1')
  end

  stopRegularPtradeServiceNoFails(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

  if(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    upgradePtradeToNewLabVersionLab(nil)
  else
    upgradePtradeToNewLabVersionLab(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'])
  end

  #downloadDblogsForPtradeNewVersion

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('PTRADE')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
  displayDbSchemaVersion2('PTRADE1')
  end

  if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)
    customPtradeAppDeployLab(nil, true)
    #downloadAppLogsForNewVersion
  else
    customPtradeAppDeployLab(ENV['PTRADE_NEW_APP_VERSION_OU'], true)
    #downloadAppLogsForNewVersion
  end

  displayPtradeAppOnlyVersion2(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end


Given /^Sdata and Ptrade App and Schema are Built$/ do
  #Actions.createLocalDirs
  steps %Q{
    Given Sdata Schema is Built
  }
  stopPtradeServiceNoFail(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  deleteFolderContentsOnRemoteServerIfFolderExist(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'Automation/ers')
  buildPtradeNewSchema(CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'])
  uploadDirToRemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  displayPtradeDbVersionForUpgrade(CONFIG.get['CORE_HOST_USER'])
end


Given /^Ptrade App, Schema and optional Sdata are built for LAB$/ do
  Actions.isIpValidInParams
  CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']
  CONFIG.get['CORE_HOST'] = CONFIG.get['CORE_HOST_IP']

  if (CONFIG.get['PTRADE_SCHEMA'] != 'ptrade' && CONFIG.get['PTRADE_SCHEMA'] != 'ptrade1')
    Actions.f 'ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"'
    fail('ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"')
  end

  ENV['PTRADE_NEW_APP_VERSION_OU'] = ENV['PTRADE_NEW_SCHEMA_VERSION_OU'] if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)

  Actions.createLocalDirsTemplatesLogsDb
  steps %Q{
    Given Automation dir exists on oracle server2
    Given Automation dir exists on ptrade server2
  }

  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    steps %Q{
      Given DB Sdata Custom Schema is built for LAB
    }
  else
    Actions.c '<b>NOT deploying SDATA for scratch</b>'
  end

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('SDATA')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    displayDbSchemaVersion2('SDATA1')
  end

  stopRegularPtradeServiceNoFails(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

  if(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    customPtradeSchemaDeployLab(nil)
    #downloadDblogsForPtradeNewVersion
  else
    customPtradeSchemaDeployLab(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'])
    #downloadDblogsForPtradeNewVersion
  end

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('PTRADE')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    displayDbSchemaVersion2('PTRADE1')
  end

  if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)
    customPtradeAppDeployLab(nil, false)
    #downloadAppLogsForNewVersion
  else
    customPtradeAppDeployLab(ENV['PTRADE_NEW_APP_VERSION_OU'], false)
    #downloadAppLogsForNewVersion
  end

  displayPtradeAppOnlyVersion2(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end

Given /^Old Ptrade App, Schema and optional Sdata are built for LAB$/ do
  Actions.isIpValidInParams
  CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']
  CONFIG.get['CORE_HOST'] = CONFIG.get['CORE_HOST_IP']

  if (CONFIG.get['PTRADE_SCHEMA'] != 'ptrade' && CONFIG.get['PTRADE_SCHEMA'] != 'ptrade1')
    Actions.f 'ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"'
    fail('ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"')
  end

  if (ENV['PTRADE_OLD_SCHEMA_VERSION'].nil? && ENV['PTRADE_OLD_SCHEMA_VERSION'].to_s.empty?)
    Actions.f 'ERROR: "PTRADE_OLD_SCHEMA_VERSION" not given'
    fail('ERROR: "PTRADE_OLD_SCHEMA_VERSION" not given')
  end

  ENV['PTRADE_OLD_APP_VERSION'] = ENV['PTRADE_OLD_SCHEMA_VERSION'] if(ENV['PTRADE_OLD_APP_VERSION'].nil? && ENV['PTRADE_OLD_APP_VERSION'].to_s.empty?)

  Actions.createLocalDirsTemplatesLogsDb
  steps %Q{
    Given Automation dir exists on oracle server2
    Given Automation dir exists on ptrade server2
  }

  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    steps %Q{
      Given Old DB Sdata Custom Schema is built for LAB
    }
  else
    Actions.c '<b>NOT deploying SDATA for scratch</b>'
  end

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('SDATA')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    displayDbSchemaVersion2('SDATA1')
  end

  stopRegularPtradeServiceNoFails(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

  customPtradeSchemaDeployLab(ENV['PTRADE_OLD_SCHEMA_VERSION'])
  #downloadDblogsForPtradeNewVersion

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('PTRADE')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    displayDbSchemaVersion2('PTRADE1')
  end

  customPtradeAppDeployLab(ENV['PTRADE_OLD_APP_VERSION'], false)
  #downloadAppLogsForNewVersion
  displayPtradeAppOnlyVersion2(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end


Given /^Upgrade Ptrade to the Latest Lab version$/ do
  stopPtradeServiceNoFail(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  upgradePtradeSchemaToNewLabVersion
  buildPtradeApp(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'ptradeAPP_build_install_automatic.sh', Dir.getwd+'/templates/bash/', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation','')
  displayPtradeAppAndDbVersionForUpgrade(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end

Given /^Totals are being displayed$/ do
  ver1 = Actions.getBuildProperty('PTRADE1_SCHEMA_VERSION')
  v1 = ver1.scan(/\d+.\d+.\d+.\d+.(\d+)/)
  v11 = ver1.scan(/(\d+.\d+.\d+.\d+.\d+)/)
  !v1.nil? ? ver1 = v1[0][0].to_s : ver1=''
  ver2 = Actions.getBuildProperty('PTRADE_SCHEMA_VERSION')
  v2 = ver2.scan(/\d+.\d+.\d+.\d+.(\d+)/)
  v22 = ver2.scan(/(\d+.\d+.\d+.\d+.\d+)/)
  !v2.nil? ? ver2 = v2[0][0].to_s : ver2=''
  old_ver = 'Production version' #old version is more correct,since we can input versions :)
  new_ver = 'New version'
  if(!ver1.nil? && !ver2.nil? && !ver1.to_s.empty? && !ver2.to_s.empty?)
     old_ver = 'New version' if(ver1.to_i==ver2.to_i)
  end
  ticket_count_ptrade1 = Actions.getTicketsCount('ptrade1')
  ticket_count_ptrade = Actions.getTicketsCount('ptrade')
  old_hash_print = {old_ver+' (ptrade1)'=>(!v11.nil? ? v11[0][0].to_s : ver1),'ERs'=>@@ers_count_ptrade1.to_s,'Tickets'=>ticket_count_ptrade1.to_s}
  Actions.printHtmlTableBlack(old_hash_print)
  new_hash_print = {new_ver+' (ptrade)'=>(!v22.nil? ? v22[0][0].to_s : ver2),'ERs'=>@@ers_count_ptrade.to_s,'Tickets'=>ticket_count_ptrade.to_s}
  Actions.printHtmlTableBlack(new_hash_print)
end

Given /^Jenkins will email PassedOrFailed$/ do
  Actions.c 'See Your email :-)'
end


Given /^DB Sdata Custom Schema is built$/ do
  if(ENV['SDATA_OLD_SCHEMA_VERSION'].nil? || ENV['SDATA_OLD_SCHEMA_VERSION'].to_s.empty?)
    customSdataSchemaDeploy(nil)
    downloadDblogsForSdataNewVersion
  else
    customSdataSchemaDeploy(ENV['SDATA_OLD_SCHEMA_VERSION'])
    downloadDblogsForSdataOldVersion
  end
end

Given /^DB Sdata Custom Schema is built for LAB$/ do
  if(ENV['SDATA_NEW_SCHEMA_VERSION_OU'].nil? || ENV['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    customSdataSchemaDeployLab(nil)
    downloadDblogsForSdataNewVersion
  else
    customSdataSchemaDeployLab(ENV['SDATA_NEW_SCHEMA_VERSION_OU'])
    downloadDblogsForSdataOldVersion
  end
end


Given /^Old DB Sdata Custom Schema is built for LAB$/ do
  if (ENV['SDATA_OLD_SCHEMA_VERSION'].nil? && ENV['SDATA_OLD_SCHEMA_VERSION'].to_s.empty?)
    Actions.f 'ERROR: "SDATA_OLD_SCHEMA_VERSION" not given'
    fail('ERROR: "SDATA_OLD_SCHEMA_VERSION" not given')
  end

  customSdataSchemaDeployLab(ENV['SDATA_OLD_SCHEMA_VERSION'])
  downloadDblogsForSdataOldVersion
end


Given /^Sdata Schema Installed$/ do
  target_schema = 'SDATA'
  t_schema = Actions.getDbQueryResultsWithoutFailure4(target_schema,target_schema.to_s.downcase,"select * from "+target_schema+".SCHEMA_VERSION")
  t_schema_version=t_schema[0]['VERSION_NAME'].to_s
  t_schema_created=t_schema[0]['CREATION_TIME'].to_s
  if (t_schema_version.nil? || t_schema_created.nil? )
    fail('SDATA Schema is NOT installed')
  else
    Actions.c '<b>SDATA Schema Version - '+t_schema_version+' '+t_schema_created+'</b>'
    Actions.setBuildProperty('SDATA_SCHEMA_VERSION', t_schema_version.to_s)
  end

  moveAutomationDir(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end


def displayDbSchemaVersion(schema)
  t_schema = Actions.getDbQueryResultsWithoutFailure4(schema,schema.to_s.downcase,"select * from "+schema+".SCHEMA_VERSION")
  t_schema_version=t_schema[0]['VERSION_NAME'].to_s
  t_schema_created=t_schema[0]['CREATION_TIME'].to_s
  if (t_schema_version.nil? || t_schema_created.nil? )
    fail('Error: '+schema+' Schema is NOT installed')
  else
    Actions.c schema+'<b> Schema Version: '+t_schema_version+' '+t_schema_created+'</b>'
    Actions.setBuildProperty('PTRADE_SCHEMA_VERSION',t_schema_version.to_s) if schema.to_s.downcase=='ptrade'
    Actions.setBuildProperty('PTRADE1_SCHEMA_VERSION',t_schema_version.to_s) if schema.to_s.downcase=='ptrade1'
    Actions.setBuildProperty('SDATA_SCHEMA_VERSION',t_schema_version.to_s) if schema.to_s.downcase=='sdata'
    Actions.setBuildProperty('SDATA1_SCHEMA_VERSION',t_schema_version.to_s) if schema.to_s.downcase=='sdata1'
    Actions.setBuildProperty('SDATA1_SCHEMA_VERSION_packageName', CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
    Actions.setBuildProperty('SDATA_SCHEMA_VERSION_packageName', CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])
  end
end


def displayDbSchemaVersion2(schema)
  t_schema = Actions.getDbQueryResultsWithoutFailure2("select * from "+schema+".SCHEMA_VERSION")
  t_schema_version=t_schema[0]['VERSION_NAME'].to_s
  t_schema_created=t_schema[0]['CREATION_TIME'].to_s
  if (t_schema_version.nil? || t_schema_created.nil? )
    fail('Error: '+schema+' Schema is NOT installed')
  else
    Actions.p schema+'<b> Schema Version: '+t_schema_version+' '+t_schema_created+'</b>'
    Actions.setBuildProperty('PTRADE_SCHEMA_VERSION',t_schema_version.to_s) if schema.to_s.downcase=='ptrade'
    Actions.setBuildProperty('PTRADE1_SCHEMA_VERSION',t_schema_version.to_s) if schema.to_s.downcase=='ptrade1'
    Actions.setBuildProperty('SDATA_SCHEMA_VERSION',t_schema_version.to_s) if schema.to_s.downcase=='sdata'
    Actions.setBuildProperty('SDATA1_SCHEMA_VERSION',t_schema_version.to_s) if schema.to_s.downcase=='sdata1'
    Actions.setBuildProperty('SDATA1_SCHEMA_VERSION_packageName', CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
    Actions.setBuildProperty('SDATA_SCHEMA_VERSION_packageName', CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])
  end
end


def stopPtradeServiceNoFails(host, user, pwd)
  Actions.v 'Stopping PTS services...'
  # cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/bin/service.sh stop'
  cmd = CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh stop' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  cmd = CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/bin/service.sh stop' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 30)
  Actions.v res.to_s
end


def stopRegularPtradeServiceNoFails(host, user, pwd)
  cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/PTS/bin/service.sh stop'
  Actions.v 'Stopping PTS services on '+host+': '+cmd
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 30)
  Actions.v res.to_s
end


def customSdataSchemaDeploy(version)
  fail('Please define missing params ORACLE_HOST...') if (CONFIG.get['ORACLE_HOST'].nil?)

  Actions.v 'Copying script and building Old schema to Oracle server... '
  #Custom Schema
  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/db_config_sdata_example.sql', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/db_config_sdata_example.sql',40)
  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/sdata_schema_install_automatic.sh', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/sdata_schema_install_automatic.sh',40)

  #Custom Schema
  Actions.v 'Building SDATA DB Schema version '+version+' from scratch on '+CONFIG.get['ORACLE_HOST']+'...' if (!version.nil?)
  Actions.v 'Building SDATA DB Schema LAST version from scratch on '+CONFIG.get['ORACLE_HOST']+'...' if (version.nil?)

  cmd = "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/sdata_schema_install_automatic.sh"\
           +" && chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/sdata_schema_install_automatic.sh'
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/sdata_schema_install_automatic.sh" if (version.nil?)
  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/sdata_schema_install_automatic.sh -n "+version  if (!version.nil?)
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 600, true, '')
end


def customSdataSchemaDeployLab(version)
  fail('Please define missing params ORACLE_HOST_IP') if (CONFIG.get['ORACLE_HOST_IP'].nil?)

  mountHost = CONFIG.get['MOUNT_HOST']
  mountUser = CONFIG.get['MOUNT_USER']
  mountPwd = CONFIG.get['MOUNT_PWD']
  downloadFolder = "/export/home/"+mountUser+"/Automation_download"
  installScript = "sdata_schema_install_automatic.sh"
  installSupportFile = "db_config_sdata_example.sql"
  installSupportFile2 = ""
  downloadScript = "sdata_schema_download_automatic.sh"
  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    installScript = "sdata_schema1_install_automatic.sh"
    installSupportFile = "db_config_sdata1_example.sql"
    installSupportFile2 = "buildSchema_sdata1.sh"
    downloadScript = "sdata_schema1_download_automatic.sh"
  end
  scpScript = "scpFileRemotely.sh"

  sdata_schema = ''
  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    sdata_schema = 'sdata'
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    sdata_schema = 'sdata1'
  end
  Actions.c '<b>Getting SDATA DB Schema version '+version+' for "'+sdata_schema+'"...</b>' if (!version.nil?)
  Actions.c '<b>Getting the LAST version of SDATA DB Schema for "'+sdata_schema+'"...</b>' if (version.nil?)

  cmd = "rm -rf "+downloadFolder+" && mkdir -p "+downloadFolder
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,20,false,'')

  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+downloadScript,downloadFolder+'/'+downloadScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,downloadScript,'755')
  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+scpScript,downloadFolder+'/'+scpScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,scpScript,'755')

  cmd = downloadFolder+'/'+downloadScript if (version.nil?)
  cmd = downloadFolder+'/'+downloadScript+" -n "+version  if (!version.nil?)
  res = Actions.SSH(mountHost, mountUser, mountPwd, cmd, 500, true, '')

  env_version = Actions.displayDownloadedTarVersion(sdata_schema,true,mountHost,mountUser,mountPwd)
  downloadedPackage = downloadFolder+'/'+env_version
  targetPackage = CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version

  cmd = 'ls -lA '+downloadedPackage
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,5,true,'')
  Actions.c 'Package found: '+res if(res)

  Actions.c 'Copying files to '+CONFIG.get['ORACLE_HOST_IP']+'...'
  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/'+installSupportFile, CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installSupportFile,40)
  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/'+installSupportFile2, CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installSupportFile2,40)
    Actions.rigthsForFile(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH'], installSupportFile2, '755')
  end
  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/'+installScript, CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript,40)
  Actions.rigthsForFile(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH'], installScript, '755')
  Actions.transferFileRemotely(scpScript,mountHost,mountUser,mountPwd,CONFIG.get['ORACLE_HOST_IP'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],downloadFolder,CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH'],env_version)
  Actions.c '<b>Downloaded package '+env_version+' to '+targetPackage+'</b>'

  #Custom Schema
  Actions.v 'Building SDATA DB Schema version '+version+' for "'+sdata_schema+'" from scratch on '+CONFIG.get['ORACLE_HOST_IP'] if (!version.nil?)
  Actions.v 'Building SDATA DB Schema LAST version for "'+sdata_schema+'" from scratch on '+CONFIG.get['ORACLE_HOST_IP'] if (version.nil?)

  cmd = "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" && chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" && chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+"db_config_sdata_example.sql"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

  if (!CONFIG.get['SDATA_EXTRACT_FOLDER'].nil?)
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" extract_to: "+CONFIG.get['SDATA_EXTRACT_FOLDER']+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version
    Actions.c 'Using SDATA_EXTRACT_FOLDER = '+CONFIG.get['SDATA_EXTRACT_FOLDER']
  else
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version
  end

  res = Actions.SSH(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i, false, '')
end


def customPtradeSchemaDeploy(version)
  fail('Please define missing params ORACLE_HOST...') if (CONFIG.get['ORACLE_HOST'].nil?)

  Actions.v 'Building PTRADE DB Schema Version - '+version+' from scratch... ' if (!version.nil?)
  Actions.v 'Building PTRADE DB Schema LAST Version from scratch... ' if (version.nil?)

  createAutomationDirForUser(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  uploadDirToRemoteAutomationFolder(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')

  if (version.nil? || version.to_s.empty?)

    cmd = "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh "
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

    cmd ="chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh"
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, false, '')

    #cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh -n "+version  if (!version.nil?)
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh" if (version.nil?)
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 300, false, '')
  else

    cmd =  "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/buildSchema_ptrade.sh"
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

    cmd ="chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/buildSchema_ptrade.sh"
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, false, '')

    cmd =  "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh"
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

    cmd ="chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh"
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, false, '')

    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh -n "+version
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 300, false, '')
  end
end


def customPtradeSchemaDeployLab(version)
  fail('Please define missing params ORACLE_HOST_IP') if (CONFIG.get['ORACLE_HOST_IP'].nil?)

  mountHost = CONFIG.get['MOUNT_HOST']
  mountUser = CONFIG.get['MOUNT_USER']
  mountPwd = CONFIG.get['MOUNT_PWD']
  downloadFolder = "/export/home/"+mountUser+"/Automation_download"
  installScript = "ptradeDB_schema_install_automatic.sh"
  installSupportFile = ""
  downloadScript = "ptradeDB_schema_download_automatic.sh"
  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    installScript = "ptradeDB_schema1_install_automatic.sh"
    downloadScript = "ptradeDB_schema1_download_automatic.sh"
  end
  scpScript = "scpFileRemotely.sh"

  Actions.c '<b>Getting PTRADE DB Schema version '+version+' for "'+CONFIG.get['PTRADE_SCHEMA']+'"...</b>' if (!version.nil?)
  Actions.c '<b>Getting the LAST version of PTRADE DB Schema for "'+CONFIG.get['PTRADE_SCHEMA']+'"...</b>' if (version.nil?)

  cmd = "rm -rf "+downloadFolder+" && mkdir -p "+downloadFolder
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,20,false,'')

  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+downloadScript,downloadFolder+'/'+downloadScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,downloadScript,'755')
  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+scpScript,downloadFolder+'/'+scpScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,scpScript,'755')

  cmd = downloadFolder+'/'+downloadScript if (version.nil?)
  cmd = downloadFolder+'/'+downloadScript+" -n "+version  if (!version.nil?)
  res = Actions.SSH(mountHost, mountUser, mountPwd, cmd, 500, true, '')

  env_version = Actions.displayDownloadedTarVersion(CONFIG.get['PTRADE_SCHEMA'],true,mountHost,mountUser,mountPwd)
  downloadedPackage = downloadFolder+'/'+env_version
  targetPackage = CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version

  cmd = 'ls -lA '+downloadedPackage
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,5,true,'')
  Actions.c 'Package found: '+res if(res)
  Actions.c 'Copying files to '+CONFIG.get['ORACLE_HOST_IP']+'...'

  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/'+installScript, CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript,40)
  Actions.rigthsForFile(CONFIG.get['ORACLE_HOST_IP'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH'],installScript,'755')
  Actions.transferFileRemotely(scpScript,mountHost,mountUser,mountPwd,CONFIG.get['ORACLE_HOST_IP'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],downloadFolder,CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH'],env_version)

  Actions.c '<b>Downloaded package '+env_version+' to '+targetPackage+'</b>'
  Actions.c 'Building PTRADE DB Schema version '+version+' from scratch for "'+CONFIG.get['PTRADE_SCHEMA']+'"...' if (!version.nil?)
  Actions.c 'Building PTRADE DB Schema LAST version from scratch for "'+CONFIG.get['PTRADE_SCHEMA']+'"...' if (version.nil?)

  if (!CONFIG.get['PTRADE_DB_EXTRACT_FOLDER'].nil?)
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" extract_to: "+CONFIG.get['PTRADE_DB_EXTRACT_FOLDER']+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version
    Actions.c 'Using PTRADE_DB_EXTRACT_FOLDER = '+CONFIG.get['PTRADE_DB_EXTRACT_FOLDER']
  else
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version
  end

  res = Actions.SSH(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i, false, '')
end


def customPtradeOldSchemaDeploy(version)
  fail('Please define missing params ORACLE_HOST...') if (CONFIG.get['ORACLE_HOST'].nil?)

  Actions.v 'Building PTRADE DB Schema Version - '+version+' from scratch... ' if (!version.nil?)
  Actions.v 'Building PTRADE DB Schema LAST Version from scratch... ' if (version.nil?)

  createAutomationDirForUser(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  uploadDirToRemoteAutomationFolder(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')


  cmd =  "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/buildSchema_ptrade1.sh"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

  cmd ="chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/buildSchema_ptrade1.sh"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, false, '')

  cmd =  "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema1_install_automatic.sh"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

  cmd ="chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema1_install_automatic.sh"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, false, '')

  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema1_install_automatic.sh -n "+version if(!version.nil? && !version.to_s.empty?)
  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema1_install_automatic.sh"+version if(version.nil? || version.to_s.empty?) #WTF, man?
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 300, false, '')
end


def customPtradeOldSchemaDeploy2(version)
  fail('Please define missing params ORACLE_HOST') if (CONFIG.get['ORACLE_HOST'].nil?)

  Actions.v 'Building PTRADE DB Schema Version - '+version+' for '+CONFIG.get['CORE_HOST_USER1']+' from scratch... ' if (!version.nil?)
  Actions.v 'Building PTRADE DB Schema LAST Version  for '+CONFIG.get['CORE_HOST_USER1']+' from scratch... ' if (version.nil?)

  schemaInstallScript1 = 'ptradeDB_schema1_install_automatic.sh'
  schemaBuildScript1 = 'buildSchema_ptrade1.sh'

  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],Dir.getwd+'/templates/bash/'+schemaInstallScript1,CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/'+schemaInstallScript1,40)
  Actions.rigthsForFile(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation',schemaInstallScript1,'755')

  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],Dir.getwd+'/templates/bash/'+schemaBuildScript1,CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/'+schemaBuildScript1,40)
  Actions.rigthsForFile(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation',schemaBuildScript1,'755')

  addition='extract_to: '+CONFIG.get['PTRADE1_DB_EXTRACT_FOLDER']
  schemaInstallScript1+=' '+addition

  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+schemaInstallScript1+' -n '+version if(!version.nil? || !version.to_s.empty?)
  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+schemaInstallScript1 if(version.nil? || version.to_s.empty?)
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 600, true, '')

  return res
end


def customPtradeNewSchemaDeploy(version)
  fail('Please define missing params ORACLE_HOST...') if (CONFIG.get['ORACLE_HOST'].nil?)

  Actions.v 'Building PTRADE DB Schema Version - '+version+' for '+CONFIG.get['CORE_HOST_USER']+' from scratch... ' if (!version.nil?)
  Actions.v 'Building PTRADE DB Schema LAST Version  for '+CONFIG.get['CORE_HOST_USER']+' from scratch... ' if (version.nil?)

  createAutomationDirForUser(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  uploadDirToRemoteAutomationFolder(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')

  cmd = "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

  cmd ="chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, false, '')

  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh -n "+version  if(!version.nil? && !version.to_s.empty?)
  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh" if(version.nil? || version.to_s.empty?)
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 300, false, '')
end


def customPtradeNewSchemaDeploy2(version)
  fail('Please define missing params ORACLE_HOST') if (CONFIG.get['ORACLE_HOST'].nil?)

  Actions.v 'Building PTRADE DB Schema Version - '+version+' for ptrade from scratch... ' if (!version.nil?)
  Actions.v 'Building PTRADE DB Schema LAST Version for ptrade from scratch... ' if (version.nil?)

  schemaInstallScript = 'ptradeDB_schema_install_automatic.sh'

  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],Dir.getwd+'/templates/bash/'+schemaInstallScript,CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/'+schemaInstallScript,40)
  Actions.rigthsForFile(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation',schemaInstallScript,'755')

  addition='extract_to: '+CONFIG.get['PTRADE_DB_EXTRACT_FOLDER']
  schemaInstallScript+=' '+addition

  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+schemaInstallScript+' -n '+version if(!version.nil? || !version.to_s.empty?)
  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+schemaInstallScript if(version.nil? || version.to_s.empty?)
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 600, true, '')

  return res
end


def customPtradeAppDeploy(version)
  stopPtradeServiceNoFails(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  createAutomationDirForUser(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  uploadDirToRemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  buildPtradeApp(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'ptradeAPP_build_install_automatic.sh', Dir.getwd+'/templates/bash/', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation','') if(version.nil? || version.to_s.empty?)
  displayPtradeAppVersion(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end


def customPtradeAppDeployLab(version, isUpgrade)
  mountHost = CONFIG.get['MOUNT_HOST']
  mountUser = CONFIG.get['MOUNT_USER']
  mountPwd = CONFIG.get['MOUNT_PWD']
  downloadFolder = "/export/home/"+mountUser+"/Automation_download"
  if isUpgrade
    installScript = "ptradeAPP_build_upgrade_automatic.sh"
  else
    installScript = "ptradeAPP_build_install_automatic.sh"
  end
  downloadScript = "ptradeAPP_build_download_automatic_oracle.sh"
  scpScript = "scpFileRemotely.sh"

  Actions.c '<b>Getting PTRADE App version '+version+'...</b>' if (!version.nil?)
  Actions.c '<b>Getting the LAST version of PTRADE App...</b>' if (version.nil?)

  cmd = "rm -rf "+downloadFolder+" && mkdir -p "+downloadFolder
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,20,false,'')

  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+downloadScript,downloadFolder+'/'+downloadScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,downloadScript,'755')
  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+scpScript,downloadFolder+'/'+scpScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,scpScript,'755')

  cmd = "dos2unix "+downloadFolder+'/'+downloadScript+" && "+"chmod 755 "+downloadFolder+'/'+downloadScript
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,10,true,'')

  cmd = downloadFolder+'/'+downloadScript if (version.nil?)
  cmd = downloadFolder+'/'+downloadScript+" -n "+version  if (!version.nil?)
  res = Actions.SSH(mountHost, mountUser, mountPwd, cmd, 500, true, '')

  env_version = Actions.displayDownloadedTarVersion('ptrade',false,mountHost,mountUser,mountPwd)
  downloadedPackage = downloadFolder+'/'+env_version
  targetPackage = CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['CORE_HOST_USER']+"/Automation/"+env_version

  cmd = 'ls -lA '+downloadedPackage
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,5,true,'')
  Actions.c 'Package found: '+res if(res)
  Actions.c 'Copying files to '+CONFIG.get['CORE_HOST_IP']+'...'

  Actions.uploadTemplates2(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash/'+installScript, CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+installScript,40)
  Actions.transferFileRemotely(scpScript,mountHost,mountUser,mountPwd,CONFIG.get['CORE_HOST_IP'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],downloadFolder,CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH'],env_version)

  Actions.c '<b>Downloaded package '+env_version+' to '+targetPackage+'</b>'
  Actions.c 'Building the version '+version+' PTRADE App from scratch...' if (!version.nil?)
  Actions.c 'Building the LAST version of PTRADE App from scratch...' if (version.nil?)

  cmd = 'dos2unix '+CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+installScript+' && chmod 755 '+CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+installScript
  res = Actions.SSH(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 10, true, '')

  if (!CONFIG.get['PTRADE_APP_EXTRACT_FOLDER'].nil? && CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil?)
    cmd = CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+installScript+' extract_to: '+CONFIG.get['PTRADE_APP_EXTRACT_FOLDER']+' -p '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/'+env_version
    Actions.c 'Using PTRADE_APP_EXTRACT_FOLDER = '+CONFIG.get['PTRADE_APP_EXTRACT_FOLDER']
  elsif (CONFIG.get['PTRADE_APP_EXTRACT_FOLDER'].nil? && !CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil?)
    cmd = CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+installScript+' install_to: '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+' -p '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/'+env_version
    Actions.c 'Using PTRADE_APP_INSTALL_FOLDER = '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']
  elsif (!CONFIG.get['PTRADE_APP_EXTRACT_FOLDER'].nil? && !CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil?)
    cmd = CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+installScript+' extract_to: '+CONFIG.get['PTRADE_APP_EXTRACT_FOLDER']+' install_to: '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+' -p '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/'+env_version
    Actions.c 'Using PTRADE_APP_EXTRACT_FOLDER = '+CONFIG.get['PTRADE_APP_EXTRACT_FOLDER']+', PTRADE_APP_INSTALL_FOLDER = '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']
  else
    cmd = CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+installScript+' -p '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/'+env_version
  end

  res = Actions.SSH(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i, false, '')
end


def startRedis
  cmd = '/export/home/$USER/redis/src/startRedis.sh'
  res = Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 60)
end


def displaySanityLogs(with_sdata, with_sdata1, with_ptrade, with_ptrade1)
  downloadDblogsForSdataOldVersion if(with_sdata1)
  downloadDblogsForSdataNewVersion if(with_sdata)
  if(with_ptrade1)
    Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], '/export/home/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/PTSlogsParser_ptrade1.sh ers_path: '+CONFIG.get['REMOTE_HOME']+CONFIG.get['CORE_HOST_USER1']+'/Automation/ers'+' pts_logs_path: '+CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/logs', 120)
    sleep 15
    Actions.downloadCoreLogs(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  end
  if(with_ptrade)
    Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], '/export/home/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTSlogsParser_ptrade.sh ers_path: '+CONFIG.get['REMOTE_HOME']+CONFIG.get['CORE_HOST_USER']+'/Automation/ers'+' pts_logs_path: '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/logs', 120)
    sleep 15
    Actions.downloadCoreLogs(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  end
  Actions.displayFilesForDownloadInFolder(Dir.getwd+'/logs/logs_'+@@time_stamp)
end


def downloadCustomBuildLogs(with_sdata,with_ptrade)
  downloadDblogsForSdataNewVersion if(with_sdata)
  Actions.downloadCoreLogs(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD']) if(with_ptrade)
end


##########builds


############Upgrade
def createAutomationDirForUserUpgrade(host, user, pwd)
  Actions.v 'Creating Automation dir on host '+host+' for user '+user+'... '
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/ers'
  res = Actions.SSH(host, user, pwd, cmd, 10, true, '')

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/ers2'
  res = Actions.SSH(host, user, pwd, cmd, 10, true, '')

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data/tickets'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data/tickets/common'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data/tickets/myt'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)

end


Given /^beforeScenarioSteps$/ do
  #Actions.removeOldOutput
  #Actions.createLocalDirs
  stopPtradeServiceNoFail(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  stopPtradeServiceNoFail(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  steps %Q{
      Given Automation dir exist on oracle server
    }
end


Given /^beforeScenarioStepsSdata$/ do
  #Actions.removeOldOutput
  #Actions.createLocalDirs
  moveAutomationDir(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  steps %Q{
      Given Automation dir exist on oracle server
  }
end


def upgradePtradeSchemaToNewLabVersion
  fail('Please define missing params ORACLE_HOST...') if (CONFIG.get['ORACLE_HOST'].nil?)
  Actions.c '<b>Performing PTRADE Upgrade for schema "'+'ptrade'+'" at "'+CONFIG.get['ORACLE_HOST'].to_s+'"...</b>'

  createAutomationDirForUser(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  uploadDirToRemoteAutomationFolder(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')

  cmd = 'dos2unix '+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/ptradeDB_schema_upgrade_automatic.sh'
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

  cmd ='chmod 755 '+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/ptradeDB_schema_upgrade_automatic.sh'
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

  schemaUpgradeScript='ptradeDB_schema_upgrade_automatic.sh'
  addition='extract_to: '+CONFIG.get['PTRADE_DB_EXTRACT_FOLDER']
  schemaUpgradeScript+=' '+addition

  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+schemaUpgradeScript if(CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+schemaUpgradeScript+' -n ' +CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s if(!CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && !CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 600, true, '')

  return res
end


def upgradePtradeToNewLabVersionLab(version)
  fail('Please define missing params ORACLE_HOST_IP') if (CONFIG.get['ORACLE_HOST_IP'].nil?)

  mountHost = CONFIG.get['MOUNT_HOST']
  mountUser = CONFIG.get['MOUNT_USER']
  mountPwd = CONFIG.get['MOUNT_PWD']
  downloadFolder = "/export/home/"+mountUser+"/Automation_download"
  installScript = "ptradeDB_schema_upgrade_automatic.sh"
  downloadScript = "ptradeDB_schema_download_automatic.sh"
  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    installScript = "ptradeDB_schema1_upgrade_automatic.sh"
    downloadScript = "ptradeDB_schema1_download_automatic.sh"
  end
  scpScript = "scpFileRemotely.sh"

  Actions.c '<b>Getting PTRADE DB Schema version '+version+'...</b>' if (!version.nil?)
  Actions.c '<b>Getting the LAST version of PTRADE DB Schema...</b>' if (version.nil?)

  cmd = "rm -rf "+downloadFolder+" && mkdir -p "+downloadFolder
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,20,false,'')

  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+downloadScript,downloadFolder+'/'+downloadScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,downloadScript,'755')
  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+scpScript,downloadFolder+'/'+scpScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,scpScript,'755')

  cmd = downloadFolder+'/'+downloadScript if (version.nil?)
  cmd = downloadFolder+'/'+downloadScript+" -n "+version  if (!version.nil?)
  res = Actions.SSH(mountHost, mountUser, mountPwd, cmd, 500, true, '')

  env_version = Actions.displayDownloadedTarVersion(CONFIG.get['PTRADE_SCHEMA'],true,mountHost,mountUser,mountPwd)
  downloadedPackage = downloadFolder+'/'+env_version
  targetPackage = CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version

  cmd = 'ls -lA '+downloadedPackage
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,5,true,'')
  Actions.c 'Package found: '+res if(res)
  Actions.c 'Copying files to '+CONFIG.get['ORACLE_HOST_IP']+'...'

  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/'+installScript, CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript,40)
  Actions.rigthsForFile(CONFIG.get['ORACLE_HOST_IP'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH'],installScript,'755')
  Actions.transferFileRemotely(scpScript,mountHost,mountUser,mountPwd,CONFIG.get['ORACLE_HOST_IP'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],downloadFolder,CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH'],env_version)

  Actions.c '<b>Downloaded package '+env_version+' to '+targetPackage+'</b>'
  Actions.c 'Upgrading to PTRADE DB Schema version '+version+' for "'+CONFIG.get['PTRADE_SCHEMA']+'"...' if (!version.nil?)
  Actions.c 'Upgrading to PTRADE DB Schema LAST version for "'+CONFIG.get['PTRADE_SCHEMA']+'"...' if (version.nil?)

  if (!CONFIG.get['PTRADE_DB_EXTRACT_FOLDER'].nil?)
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" extract_to: "+CONFIG.get['PTRADE_DB_EXTRACT_FOLDER']+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version
    Actions.c 'Using PTRADE_DB_EXTRACT_FOLDER = '+CONFIG.get['PTRADE_DB_EXTRACT_FOLDER']
  else
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version
  end

  res = Actions.SSH(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i, false, '')
end


Then /^DB tables DEAL TICKETS LEGS compared for both versions with latest version$/ do
  Actions.compareDbTableResultsForUpgrade(CONFIG.get['ORACLE_HOST_TEMPLATE_SCHEMA'], CONFIG.get['ORACLE_HOST_SCHEMA']) #('PTRADE1','PTRADE')
end


Then /^Old and New versions csv Folders are Matched excluding timestamps with latest version$/ do
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_csv/'+@@time_stamp + ' & mkdir latestVsUpgrade', 10)
  source_dir = Dir.getwd + '/templates/old_app_csv/'+@@time_stamp+'/latestVsUpgrade/'+@@time_stamp
  target_dir = Dir.getwd + '/templates/new_app_csv/'+@@time_stamp
  dir_count=Actions.compareCsvDirs(source_dir+'/common', target_dir+'/common')
  Actions.c (count-2).to_s+' folders have been compared in common folder' if(!$csv_folders_count.nil? && !dir_count.nil? && !dir_count[0].to_s.downcase.include?('error'))
  count=Actions.compareCsvDirs(source_dir+'/myt', target_dir+'/myt')
  Actions.c (count-2).to_s+' folders have been compared in myt folder' if(!$csv_folders_count.nil? && !dir_count.nil? && !dir_count[0].to_s.downcase.include?('error'))
  Actions.c $csv_files_count.to_s+' files have been compared' if(!$csv_files_count.nil?)

  if($csv_folders_count.nil? || $csv_folders_count==0)
    @@scenario_fails.push('0 Folders compared')
    Actions.f('0 Folders compared')
  end
  if($csv_files_count.nil? || $csv_files_count==0)
    @@scenario_fails.push('0 Files compared')
    Actions.f('0 Files compared')
  end
end


Then /^Old and New Saphire Jsons are Matched excluding sequence with latest version$/ do
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_json/'+@@time_stamp + ' & mkdir latestVsUpgrade', 10)
  template_json = Dir.getwd + '/templates/old_app_json/'+@@time_stamp+'/latestVsUpgrade/'+@@time_stamp+'/RedisMonitor1.txt'
  build_json = Dir.getwd + '/templates/new_app_json/'+@@time_stamp+'/RedisMonitor.txt'

  @@json_fails=[]
  Actions.c '<b>Comparing Sapphire Jsons...</b>'
  Actions.compareSaphireOutputJsonsForUpgrade(template_json, build_json)
end


def downloadCsvFolderForLatestVersion
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_csv/'+@@time_stamp + ' & mkdir latestVsUpgrade', 10)
  Actions.v 'Downloading MyT And Common csv files from Remote Folder for the Latest Lab Version'
  downloadDirFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/old_app_csv/'+@@time_stamp+'/latestVsUpgrade', CONFIG.get['MYT_CSV_REMOTE_DIR_PATH1'])
end


def downloadJsonForLatestVersion
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_json/'+@@time_stamp + ' & mkdir latestVsUpgrade', 10)
  Actions.v('Downloading Sapphire Json for the Latest Lab Version')
  downloadFileFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'],Dir.getwd+'/templates/old_app_json/'+@@time_stamp+'/latestVsUpgrade',  '/export/home/'+CONFIG.get['CORE_HOST_USER1']+'/Automation', 'RedisMonitor1.txt')
end


def compareCsvWithDifferentTimestamps
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_csv/'+@@time_stamp + ' & mkdir latestVsUpgrade', 10)
  source_dir = Dir.getwd + '/templates/old_app_csv/'+@@time_stamp+'/latestVsUpgrade/'+@@time_stamp
  target_dir = Dir.getwd + '/templates/new_app_csv/'+$old_json_timestamp
  count=Actions.compareCsvDirs(source_dir+'/common', target_dir+'/common')
  Actions.c (count-2).to_s+' folders have been compared in common folder' if(!$csv_folders_count.nil?)
  count=Actions.compareCsvDirs(source_dir+'/myt', target_dir+'/myt')
  Actions.c (count-2).to_s+' folders have been compared in myt folder' if(!$csv_folders_count.nil?)
  #Actions.c $csv_files_count.to_s+' files have been compared' if(!$csv_files_count.nil?)

  if($csv_folders_count==0)
    @@scenario_fails.push('0 Folders compared')
    Actions.f('0 Folders compared')
  end
  if($csv_files_count==0)
    @@scenario_fails.push('0 Files compared')
    Actions.f('0 Files compared')
  end
end


def compareJsonWithDifferentTimestamps
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_json/'+@@time_stamp + ' & mkdir latestVsUpgrade', 10)
  template_json = Dir.getwd + '/templates/old_app_json/'+@@time_stamp+'/latestVsUpgrade/'+@@time_stamp+'/RedisMonitor1.txt'
  build_json = Dir.getwd + '/templates/new_app_json/'+$old_json_timestamp+'/RedisMonitor.txt'

  @@json_fails=[]
  Actions.compareSaphireOutputJsonsForUpgrade(template_json, build_json)
end


def changeTimeStamp
  time = Time.new
  @@time_stamp= time.day.to_s+'-'+time.month.to_s+'-'+time.year.to_s+'_'+time.hour.to_s+'-'+time.min.to_s+'-'+time.sec.to_s #Time.now.to_i.to_s
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/new_app_csv & mkdir '+@@time_stamp, 10)
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_csv'+' & mkdir '+@@time_stamp, 10)
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/new_app_json'+' & mkdir '+@@time_stamp, 10)
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_json'+' & mkdir '+@@time_stamp, 10)
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/myt/source'+' & mkdir '+@@time_stamp, 10)
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/myt/target'+' & mkdir '+@@time_stamp, 10)
end


def copyFile(file, from, to)
  Actions.v 'Copying file '+file+' from'+from+' to'+to
  cmd ="cp -f "+from+'/' + file+' '+to
  res = Actions.SSH(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 10, false, '')
end


def debugUpgrade
  ##temp
  killRedisRoot(CONFIG.get['CORE_HOST'])
  stopPtradeServiceNoFail(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  stopPtradeServiceNoFail(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  createAutomationDirForUserUpgrade(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  uploadDirToRemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  uploadDirToRemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/ers')
  uploadDirToRemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers2', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/ers2')
  uploadDirToRemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/config', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  buildPtradeNewSchema(CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'])
  buildPtradeApp(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'ptradeAPP_build_install_automatic.sh', Dir.getwd+'/templates/bash/', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation','') if(CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty? )
  buildPtradeApp(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'ptradeAPP_build_install_automatic.sh', Dir.getwd+'/templates/bash/', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/', CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU']) if(!CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? || !CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty? )
  displayPtradeAppAndDbVersionForUpgrade(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  upgradePtradeSchemaToNewLabVersion
  buildPtradeApp(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'ptradeAPP_build_install_automatic.sh', Dir.getwd+'/templates/bash/', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation','')
  uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/new_app_config2/prod.conf', CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS/config/prod.conf')
  uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/new_app_config2/fix/rtns/qfj.cfg', CONFIG.get['PTRADE1_APP_INSTALL_FOLDER']+'/PTS/config/fix/rtns/qfj.cfg')
  displayPtradeAppAndDbVersionForUpgrade(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

  Actions.cleanupMsl(CONFIG.get['CORE_HOST_USER1'], CONFIG.get['MSL_HOST']) #temp
  ### Run MslErSender with other folder <ers2> and Start 2nd app
  killRedisRoot(CONFIG.get['CORE_HOST'])
  restartRedisWithNewConfigForNewVersion
  restartPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER'], false, 'ers2', CONFIG.get['MSL_HOST'])
  stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  downloadCsvFolderForNewVersion
  downloadJsonForNewVersion
end


Given /^Automation dir is shifted on both oracle and app servers$/ do
  #Actions.createLocalDirs

  moveAutomationDir(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end

####


############Upgrade

Given /^Code Tested2$/  do
  #debugUpgrade
  #require '../helpers/Service'
  #Service.start
=begin
  begin
    server = WEBrick::HTTPServer.new(:Port => 4444)
    server.mount "/", Service.new

    trap("INT") {
      server.shutdown
    }
  rescue Exception=>e
    fail("Start Service failed: " + e.message)
  end
=end

=begin
  require 'webrick'
  server = WEBrick::HTTPServer.new :Port => 1234
  server.mount "/", WEBrick::HTTPServlet::FileHandler, './'
  trap('INT') { server.stop }
  server.start
=end
end
