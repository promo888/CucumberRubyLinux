require 'cucumber'
require 'net/ssh'
require 'net/scp'
require 'time'
require 'fastercsv'

begin
  require '../../features/helpers/Actions'
  require '../../features/helpers/Config.rb'
  include Config
rescue LoadError
end




def getChartService
  csvData=[{"date" => 1, "visits" => 12, "hits" => 16, "views" => 23},
           {"date" => 0, "visits" => 2, "hits" => 11, "views" => 20},
           {"date" => 3, "visits" => 15, "hits" => 17, "views" => 24}].to_json

  csvFile=Actions.getHashMapFromCsvFile(Dir.getwd+"/test1000.csv")

  separator=","
  $csv_headers = []
  $csv_hash_arr =[]
  begin

    file_csv = File.open(Dir.getwd+"/test.csv")
    #csv = CSV.new(file_csv, :headers => true) #, :header_converters => :symbol, :converters => [:all, :blank_to_nil]) #CSV.read('guests.csv', headers:true)

    #csv = CSV.read(file_csv, :headers => true)
    csv = FasterCSV.new(file_csv, :headers => true)
    #csv = FasterCSV.read(Dir.getwd+"/js_chart_test100k.csv", :headers => true)
=begin
    CSV.foreach(Dir.getwd+"/js_chart_test100k.csv", headers:true) do |csv_row|
      $csv_hash_arr.push(csv_row)
    end
=end
    csv.to_a.map { |row|
      csv_row_hash = row.to_hash #.tap{|h| h.delete('date')}
      $csv_hash_arr.push(csv_row_hash)
    }
      #c 'csv_file_hash ' + $csv_file_hash.to_s
  rescue Exception => e
    Actions.v e.message
  ensure
  end

  @timestamp_axis = [] #date - 1st Column in CSV
  @latency_arr_hashes = []
  x_axis=0
  start=1
  last=$csv_hash_arr[0].keys.length-1

  while (start<=last)
    if start==1
      tmp_arr=$csv_hash_arr.collect { |e| e[$csv_hash_arr[0].keys[0]] }.sort { |a, b| b <=> a } #Sort descending
      #arr_name = $csv_hash_arr[0].keys[0]
      @timestamp_axis=tmp_arr
    end
    tmp_arr=$csv_hash_arr.collect { |e| e[$csv_hash_arr[0].keys[start]] }.sort { |a, b| b <=> a } #Sort descending
    arr_name = $csv_hash_arr[0].keys[start]
    tmp_hash_values = Hash.new(arr_name+"_values")
    tmp_hash_times = Hash.new(arr_name+"_times")
    length = tmp_hash_values.length-1
    tmp_hash_values = {"100%" => tmp_arr.first, "99.9%" => tmp_arr[(length*0.999).to_i], "99.8%" => tmp_arr[(length*0.998).to_i], "99.5%" => tmp_arr[(length*0.995).to_i], "99%" => tmp_arr[(length*0.99).to_i], "95%" => tmp_arr[(length*0.95).to_i]}
    @latency_arr_hashes.push({arr_name => tmp_hash_values})

    start+=1
  end

  @latency_arr_hashes.each_with_index { |name, index|
    col=@latency_arr_hashes[index].keys[0]
    rows=@latency_arr_hashes[index][col]
    #HTML PRINT
    @latency_tables="" "
    <br>
    <p>
    #{col} Latency
    <table>
    <tr>
    " ""
    rows.keys.each { |k|
      @latency_tables+="<th> #{k.to_s}	</th>"
    }
    @latency_tables+="</tr>"
    @latency_tables+="<tr>"
    rows.values.each { |v|
      @latency_tables+="<td> #{v.to_s}	</td>"
    }
    @latency_tables+="</tr>"
    @latency_tables+="</table>"
  }
end


def generateTestCsv(size=1000,withDate=false,filename='test1000.csv')
File.open(Dir.getwd+'/'+filename, 'w') do |file|
  $i=1
  $max=size #1000
  file.puts "date,CPT,Tidy,Db,Json,Myt,Common,Rtns,Fix,Tudor,Email" #10adapters
    while $i<$max
      file.puts $i.to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s if(!withDate)
      file.puts Time.new.to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s if(withDate)
      $i+=1
    end
  end
end


Given /^Code Tested$/  do


  Actions.removeOldFiles(Dir.getwd + '/logs')

  $csv_hash_arr=[]
  file_csv = File.open(Dir.getwd+"/test.csv")
  csv = CSV.new(file_csv, :headers => true) #, :header_converters => :symbol, :converters => [:all, :blank_to_nil])
  csv.to_a.map {|row|
    csv_row_hash = row.to_hash #.tap{|h| h.delete('date')}
    $csv_hash_arr.push(csv_row_hash)
  }

  #getChartService
  #generateTestCsv(size=1000,withDate=false,filename='test1000.csv')

  puts 1

###generate test csv
  File.open(Dir.getwd+'/test100k.csv', 'w') do |file|
    $i=1
    $max=100000
    file.puts "date,CPT,Tidy,Db,Json,Myt,Common,Rtns,Fix,Tudor,Email" #10adapters
    while $i<$max
      #file.puts $i.to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s
      #file.puts Time.new.to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s+","+rand(1.0...99.9).round(1).to_s
      $i+=1
    end
  end

  ###Cut deltas in ms per adapter
  $deltas=Hash.new []
  def delta_ms(search_in_log,output_to,search1_str,search2_str=nil,search3_str=nil,search4_str=nil,search5_str=nil)
    filename=search_in_log
    previous_time = nil
    arr_deltas=[]
    File.open(filename).each do |line|
      if line_include?(line,search1_str,search2_str,search3_str,search4_str,search5_str)
        if previous_time.nil?
          previous_time=Time.parse(line.split[1]) #Time.parse(line.split[1]).to_i * 1000
          next
        end
        currrent_time=Time.parse(line.split[1])
        delta_ms=(currrent_time-previous_time)*1000
        previous_time=Time.parse(line.split[1])
        arr_deltas.push(delta_ms)
      end
    end
    arr_deltas.each do |word|
      $deltas[output_to] += [word]
    end
  end

  def line_include?(str,search1_str,search2_str,search3_str,search4_str,search5_str)
    if !search1_str.nil? && !search2_str.nil? && !search3_str.nil? && !search4_str.nil? && !search5_str.nil?
      return true if str.to_s.include?(search1_str) && str.to_s.include?(search2_str) && str.to_s.include?(search3_str) && str.to_s.include?(search4_str) && str.to_s.include?(search5_str)
    end
    if !search1_str.nil? && !search2_str.nil? && !search3_str.nil? && !search4_str.nil?
      return true if str.to_s.include?(search1_str) && str.to_s.include?(search2_str) && str.to_s.include?(search3_str) && str.to_s.include?(search4_str)
    end
    if !search1_str.nil? && !search2_str.nil? && !search3_str.nil?
      return true if str.to_s.include?(search1_str) && str.to_s.include?(search2_str) && str.to_s.include?(search3_str)
    end
    if !search1_str.nil? && !search2_str.nil?
      return true if str.to_s.include?(search1_str) && str.to_s.include?(search2_str)
    end
    if !search1_str.nil?
      return true if str.to_s.include?(search1_str)
    end

    return false
  end


  #CORE & TIDY & DB
  CORE_LOGS="pts_core*log"
  TIDY_LOGS="pts_tidy*log"
  CORE_ER_EVENT="PTS-C832"
  TIDY_ER_EVENT="PTS-C607"
  DB_EVENT="PTS-C550"
  DB_EVENT_FX_DEAL_MSG="FX_DEAL"
  DB_EVENT_FX_TICKET_LEG_MSG="FX_TICKET_LEG"

  #ADAPTERS
  TIDY_CSV_COMMON_EVENT="PTS-C601"
  TIDY_CSV_COMMON_EVENT_MSG1="routed"
  TIDY_CSV_COMMON_EVENT_MSG2="common"
  TIDY_CSV_MYT_EVENT="PTS-C601"
  TIDY_CSV_MYT_EVENT_MSG1="routed"
  TIDY_CSV_MYT_EVENT_MSG2="myt"
  TIDY_JSON_SAPPHIRE_EVENT="PTS-C650"
  TIDY_JSON_SAPPHIRE_MSG="Message was successfully sent to redis" #"routed by Persistent RedisSender"
  TIDY_FIX4_4_EVENT="PTS-C7316"
  TIDY_FIX4_4_EVENT_MSG="FIX44_ADAPTER"
  TIDY_TUDOR_EVENT="PTS-C7316"
  TIDY_TUDOR_EVENT_MSG="TUDOR_ADAPTER"
  TIDY_RTNS_EVENT="PTS-C7316"
  TIDY_RTNS_EVENT_MSG="RTNS"

  start_time=Time.now
  delta_ms(Dir.getwd+"/tmp/pts_core_1.log","CoreERs",CORE_ER_EVENT)
  delta_ms(Dir.getwd+"/tmp/pts_core_1.log","DbFxDeal",DB_EVENT, DB_EVENT_FX_DEAL_MSG)
  delta_ms(Dir.getwd+"/tmp/pts_core_1.log","DbFxTicketLeg",DB_EVENT, DB_EVENT_FX_TICKET_LEG_MSG)
  delta_ms(Dir.getwd+"/tmp/pts_tidy_3.log","TidyERs",TIDY_ER_EVENT)

  delta_ms(Dir.getwd+"/tmp/pts_tidy_3.log","CSV_COMMON",TIDY_CSV_COMMON_EVENT, TIDY_CSV_COMMON_EVENT_MSG1, TIDY_CSV_COMMON_EVENT_MSG2)
  delta_ms(Dir.getwd+"/tmp/pts_tidy_3.log","CSV_MYT",TIDY_CSV_MYT_EVENT, TIDY_CSV_MYT_EVENT_MSG1, TIDY_CSV_MYT_EVENT_MSG1)
  delta_ms(Dir.getwd+"/tmp/pts_tidy_3.log","JSON_SAPPHIRE",TIDY_JSON_SAPPHIRE_EVENT, TIDY_JSON_SAPPHIRE_MSG)
  delta_ms(Dir.getwd+"/tmp/pts_tidy_3.log","FIX4_4",TIDY_FIX4_4_EVENT, TIDY_FIX4_4_EVENT_MSG)
  delta_ms(Dir.getwd+"/tmp/pts_tidy_3.log","TUDOR",TIDY_TUDOR_EVENT, TIDY_TUDOR_EVENT_MSG)
  delta_ms(Dir.getwd+"/tmp/pts_tidy_3.log","RTNS",TIDY_RTNS_EVENT, TIDY_RTNS_EVENT_MSG)
  end_time=Time.now
  Actions.v "#{(end_time-start_time)*1000} ms processing"
  ################Cut deltas in ms per adapter

  #Actions.c('<b> Old and New versions Traiana outgoing data compared as CSV </b>')
  #Actions.compareCsvFolders2(Dir.getwd + '/templates/old_app_csv_traiana/8-5-2016_17-28-28',Dir.getwd + '/templates/new_app_csv_traiana/8-5-2016_17-28-28',CONFIG.get['TRAIANA_CSV_EXCLUDED_COLUMNS'],"csv","t")



=begin
  template_json =  Dir.getwd + '/templates/old_app_json/24-4-2016_12-49-57/RedisMonitor1.txt'
  build_json =  Dir.getwd + '/templates/new_app_json/24-4-2016_12-49-57/RedisMonitor.txt'
  @@json_fails=[]

  Actions.c '<b>Comparing Sapphire Jsons...</b>'
  json_compare_errors=Actions.compareSaphireOutputJsons(template_json, build_json) if(@@json_fails.empty?)


  expected_output_rows=['The PTS (module: tidy) is alive','The PTS (module: core) is alive','The PTS (module: http) is alive']
  res = Actions.SSH(host, user, pwd, cmd, 60, true, expected_output_rows)
=end


  #TODO insert call for SapLogFile
=begin
  log_file = 'diffJsons.txt'
  log_file_path = Dir.getwd+'/templates/old_app_json/'+log_file
  File.open(log_file_path, 'w')
  Actions.writeDiffToFile(json_compare_errors,log_file_path)
  if Dir.getwd.include?(@@CONFIG['JENKINS_JOB_NAME'])
    log_file_path =  @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME'].to_s+'/ws/templates/old_app_json/'+@@time_stamp+'/'+log_file
  end
  Actions.c "<a href='" + log_file_path.to_s+" '>Click to View Jsons Diff  [Source | Target]    "+log_file.to_s+"</a>" if(!json_compare_errors.nil? && !json_compare_errors.empty?)
=end
####

  # Actions.compareSdataDbTableResults(@@time_stamp)

=begin
  v1 = 'db_sdata_1.4.6.0.tgz'
  v2='PTS_MAIN_1.5.0.0.579.tar.gz'
  Actions.compareDbTableResults(CONFIG.get['ORACLE_HOST_TEMPLATE_SCHEMA'],CONFIG.get['ORACLE_HOST_SCHEMA'],@@time_stamp) #PTRADE1,PTRADE
=end


=begin
  Actions.setBuildProperty('SDATA_SCHEMA_VERSION','test1')
  Actions.setBuildProperty('SDATA_SCHEMA_VERSION','test2')
  Actions.setBuildProperty('SDATA1_SCHEMA_VERSION','test3')
=end
=begin
  require 'net/http'
  res = Net::HTTP.get('example.com', '/index.html')
  puts res
=end
=begin
  template_json =  Dir.getwd + '/templates/old_app_json/RedisMonitor1.txt'
  build_json =  Dir.getwd + '/templates/new_app_json/RedisMonitor.txt'
  @@json_fails=[]

  Actions.c '<b>Comparing Sapphire Jsons...</b>'
  Actions.compareSaphireOutputJsons(template_json, build_json) if(@@json_fails.empty?)
=end

  #  Actions.compareCsvFolders2(Dir.getwd + '/templates/old_app_csv_traiana/28-2-2016_15-12-26',Dir.getwd + '/templates/new_app_csv_traiana//28-2-2016_15-12-26',CONFIG.get['TRAIANA_CSV_EXCLUDED_COLUMNS'],"csv","t")
  # Actions.compareRtnsFiles(Dir.getwd + '/templates/old_app_csv_traiana/28-2-2016_15-12-26',Dir.getwd + '/templates/new_app_csv_traiana//28-2-2016_15-12-26')
  # Actions.compareCsvDirs(Dir.getwd + '/templates/old_app_csv_traiana/28-2-2016_15-12-26',Dir.getwd + '/templates/new_app_csv_traiana//28-2-2016_15-12-26')

=begin
  str = 'PTS_MAIN_1.4.4.0.520.tar.gz'
  res =str.scan(/PTS_MAIN_\d+.\d+.\d+.\d+.(\d+)/)
  #res[0][0].to_i
  puts res
=end
  #Actions.compareViews('sdata1','sdata1','sdata','sdata')
  #Actions.compareViews('ptrade1','ptrade1','ptrade','ptrade')
  # puts 1

  #res=Actions.checkRtnsDelievery(Dir.getwd + '/templates/old_app_rtns/pts_tidy_3.log', CONFIG.get['CORE_HOST_USER1'])
  #Actions.checkRtnsDelievery(Dir.getwd + '/templates/new_app_rtns/pts_tidy_3.log', CONFIG.get['CORE_HOST_USER'])

  #log_file_path1=Dir.getwd + '/templates/old_app_rtns/pts_tidy_3.log'
  #log_file_path2=Dir.getwd + '/templates/new_app_rtns/pts_tidy_3.log'
  #Actions.compareOutgoingRtns(log_file_path1,log_file_path2)

=begin
  steps %Q{
    Then Old and New versions Traiana outgoing data compared as CSV
  }
=end


  #Actions.compareRtnsFiles(Dir.getwd + "/templates/old_app_csv_traiana/28-2-2016_15-12-26",Dir.getwd + "/templates/new_app_csv_traiana/28-2-2016_15-12-26")

=begin
  old_files = Dir.glob(Dir.getwd + "/templates/old_app_rtns/**/*.rtns*")
  new_files = Dir.glob(Dir.getwd + "/templates/new_app_rtns/**/*.rtns*")
  matched_files_count = 0
  $rtns_compare_errors = []

  if (old_files.nil? || old_files.to_a.empty?)
    errMsg = 'No RTNS tickets found for Old version'
    #Actions.f errMsg
    $rtns_compare_errors.push(errMsg)
    @@scenario_fails.push(errMsg)
    #break
    Actions.displayRtnsErrors
    #pass()
    Proc.new {return $rtns_compare_errors}
  end
  if (new_files.nil? || new_files.to_a.empty?)
    errMsg = 'No RTNS tickets found for New version'
    #Actions.f errMsg
    $rtns_compare_errors.push(errMsg)
    @@scenario_fails.push(errMsg)
    #break
    Actions.displayRtnsErrors
    #pass()
    Proc.new {return $rtns_compare_errors}
  end
  if(old_files.length!=new_files.length)
    errMsg = old_files.length.to_s + 'files found for Old version, ' + new_files.length.to_s + ' files found for New version '+ \
             (old_files.length>new_files.length ? 'Missing files: '+(old_files-new_files).to_s : 'New files: ' +(new_files-old_files).to_s) +\
             ' - escaping folder compare'
    #Actions.f errMsg
    $rtns_compare_errors.push(errMsg)
    @@scenario_fails.push(errMsg)
    #break
    Actions.displayRtnsErrors
    #pass()
    Proc.new {return $rtns_compare_errors}
  end

  old_files.each_with_index { |file,index |
    old_file_name = File.basename(file).scan(/\w+-\w+-\w+-\w+-\w+.rtns*/)
    new_file_name = File.basename(new_files[index]).scan(/\w+-\w+-\w+-\w+-\w+.rtns*/)

    if old_file_name.to_s != new_file_name.to_s
      Actions.f old_file_name.to_s + ' is not found for New version'
      $rtns_compare_errors.push(errMsg)
      @@scenario_fails.push(errMsg)
      next
    end

   old_file =  File.readlines(file)
   new_file = File.readlines(new_files[index])
   old_file_hash_arr = old_file.to_s.scan(/\\u0001(\w+)=(\w+)/)
   new_file_hash_arr = new_file.to_s.scan(/\\u0001(\w+)=(\w+)/)

   old_file_hash_arr.each_with_index { |keyavlue, index |
     if old_file_hash_arr[index][0].to_s != new_file_hash_arr[index][0].to_s
       errMsg = 'Key "'+old_file_hash_arr[index][0].to_s+'" or its Value is NOT found - escaping next compares in file ' + File.basename(file.to_s)
       #Actions.f errMsg
       matched_files_count-=1
       $rtns_compare_errors.push(errMsg)
       @@scenario_fails.push(errMsg)
       Actions.printFailedFilePathLink(file)
       #break
       Actions.displayRtnsErrors
       #pass()
       Proc.new {return $rtns_compare_errors}
     end


     if old_file_hash_arr[index][1].to_s != new_file_hash_arr[index][1].to_s
       errMsg = 'Value "'+old_file_hash_arr[index][1].to_s+'" or its Key - escaping next compares in file ' + File.basename(file.to_s)
       #Actions.f errMsg
       matched_files_count-=1
       $rtns_compare_errors.push(errMsg)
       @@scenario_fails.push(errMsg)
       Actions.printFailedFilePathLink(file)
       #break
       Actions.displayRtnsErrors
       Proc.new {return $rtns_compare_errors}
     end


     #puts keyavlue.to_s
   }

    #puts file.to_s
    matched_files_count+=1
  }
  Actions.c matched_files_count.to_s + ' RTNS files matched successfully from Total ' + old_files.length.to_s + ' files'
  Actions.displayRtnsErrors


  def displayRtnsErrors
    $rtns_compare_errors.each { |entry|  Actions.f(entry.to_s)}
  end

  def printFailedFilePathLink(file_path)
    errMsg = "<a href='" + file_path.to_s+"'>"+file_path.to_s+" Click to View or Download</a>" #if(File.file?(file_path))
    Actions.f  errMsg
    $rtns_compare_errors.push(errMsg)
    @@scenario_fails.push(errMsg)
  end


=end


  #Actions.compareSdataDbTableResults(@@time_stamp)
  #Actions.compareViewsStructure('SDATA1','SDATA')
  #Actions.compareViewsStructure('PTRADE1','PTRADE')

  #Actions.compareCsvFolders2(Dir.getwd + '/templates/old_app_csv_traiana/validated',Dir.getwd + '/templates/new_app_csv_traiana/validated',CONFIG.get['TRAIANA_CSV_EXCLUDED_COLUMNS'])


=begin
  CONFIG.get['ORACLE_HOST']='10.20.42.50'
  CONFIG.get['ORACLE_HOST_USER']='oracle'
  CONFIG.get['ORACLE_HOST_PWD']='oracle1'

  old_app_version=''
  approved_version=520

  if old_app_version.nil? || old_app_version.to_s.strip.empty?
    storagePath = '/export/home/oracle/build_server/Releases/PTS'
    tarFilter1 = 'PTS_MAIN_'
    tarFilter2 = '.tar.gz'
    cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 45, true, '')
    puts 'res: '+res.to_s
    old_app_version = res.to_s.strip
  end
  @@old_ptrade_version_number = old_app_version.scan(/PTS_MAIN_\d+.\d+.\d+.\d+.(\d+)/)[0][0] if !old_app_version.to_s.strip.empty?
  puts 'old_app_version: '+old_app_version.to_s

  if (@@old_ptrade_version_number.nil?  || @@old_ptrade_version_number.to_s.empty? || @@old_ptrade_version_number.to_i < approved_version )
    Actions.f 'Escaping tests of Traiana - will run with version >= ' + approved_version.to_s + ' actual version is ' + '"' + @@old_ptrade_version_number.to_s + '"'
    #return
  end

  puts '@@old_ptrade_version_number: '+@@old_ptrade_version_number.to_s
=end

end
