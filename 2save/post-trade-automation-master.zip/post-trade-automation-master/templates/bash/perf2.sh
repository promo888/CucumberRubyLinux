#!/bin/bash

### debug features
logDebug="$HOME/Automation/perf2_debug.log"
exec 5> "$logDebug"
BASH_XTRACEFD="5"
PS4='$LINENO: '
set -x

param1=${1:NOT_SET}
param2=${2:NOT_SET}
param3=${3:NOT_SET}
param4=${4:NOT_SET}
param5=${5:NOT_SET}

MSL_SENDER_FILE="mslErSenderPerf2.log"
STAT_FILE1="$HOME/Automation/perf2core.log"
STAT_FILE2="$HOME/Automation/perf2tidy.log"
STAT_FILE3="$HOME/Automation/perf2db.log"
STAT_FILE4="$HOME/Automation/perf2adapters.log"
CORE_EVENT="PTS-C832" #"PTS-C306" #
CORE_START="Received MSL message"
CORE_END="successfully delivered to TiDy" #Component CoreMSLFeeder Feeder shutdown completed
TIDY_EVENT="PTS-C306" #"PTS-C607"
TIDY_START="Received MSL message"
TIDY_END="Component TidyMSLFeeder Feeder shutdown completed"
#rm -f "$STAT_FILE1 $STAT_FILE2 $STAT_FILE3 $STAT_FILE4"
#touch "$STAT_FILE1 $STAT_FILE2 $STAT_FILE3 $STAT_FILE4"

#remove previous stats
rm -f "$STAT_FILE1"
rm -f "$STAT_FILE2"
rm -f "$STAT_FILE3"
rm -f "$STAT_FILE4"

#create new stats
touch "$STAT_FILE1"
touch "$STAT_FILE2"
touch "$STAT_FILE3"
touch "$STAT_FILE4"

PTS_LOGS_DIR="$HOME/PTS/logs/previous"
cd "$PTS_LOGS_DIR"

#return if is a positive number,otherwise return 0
add()
{
	echo "add function"
    var_to_add=${1:-}
	echo "arg1: $var_to_add"
    val=0
    if [  ! -z "$var_to_add" -a "$var_to_add" -gt 0 ] 2>/dev/null; then
        val="$var_to_add"
    fi
	echo "val: $val"
	#exit 1
	
    echo "$val"
}

get_total_count()
{
   log_name=${1:-}
   grep1=${2:-}
   grep2=${3:-}
   grep3=${4:-}
   grep4=${5:-}
   grep_str=''
    # echo "get_total_count function"
    # echo "arg1: $log_name"
    # echo "arg2: $grep1"
    # echo "arg3: $grep2"
   if [ ! -z "$grep1" -a "$grep1" != " " ]; then
        grep_str+="egrep -h -i $grep1 |"
   fi
   if [ ! -z "$grep2" -a "$grep2" != " " ]; then
        grep_str+="egrep -h -i $grep2 |"
   fi
   if [ ! -z "$grep3" -a "$grep3" != " " ]; then
       grep_str+="egrep -h -i '${grep3}' |"
   fi
   if [ ! -z "$grep4" -a "$grep4" != " " ]; then
       grep_str+="egrep -h -i '${grep4}' |"
   fi
   # echo "grep_str: $grep_str"
   
   ((total=-1))

  cd "$PTS_LOGS_DIR"

    #echo "0.total_count_cmd: $total_count_cmd"
    total_count_cmd="ls -tr $PTS_LOGS_DIR/$log_name | xargs -d '\n' cat 2>/dev/null | $grep_str wc -l"
    #total_count_cmd="egrep -h -i $grep_str | wc -l"
    # echo "1.total_count_cmd: $total_count_cmd"
    #echo "0.total_count: $total_count"
    total_count="$(eval "$total_count_cmd")"
    #echo "1.total_count: $total_count"
   if [ ! -z "$total_count" -a "$total_count" -gt 0 ] 2>/dev/null; then
      total="$total_count"
   fi

   # echo "total: $total"
   echo "$total"
}




get_avg_time(){
   log_name=${1:-}
   grep1=${2:-}
   grep2=${3:-}
   grep3=${4:-}
   grep4=${5:-}
   grep_str=''
   
   #echo "get_avg_time function"
   #echo "arg1: $log_name"
   #echo "arg2: $grep1"
   #echo "arg3: $grep2"
   if [ ! -z "$grep1" -a "$grep1" != " " ]; then
       grep_str+="egrep -h -i '${grep1}' |"
   fi
   if [ ! -z "$grep2" -a "$grep2" != " " ]; then
       grep_str+="egrep -h -i '${grep2}' |"
   fi
   if [ ! -z "$grep3" -a "$grep3" != " " ]; then
       grep_str+="egrep -h -i '${grep3}' |"
   fi
   if [ ! -z "$grep4" -a "$grep4" != " " ]; then
       grep_str+="egrep -h -i '${grep4}' |"
   fi

   #echo "grep_str: $grep_str"

   cd "$PTS_LOGS_DIR"
   
   total_count_cmd="ls -tr $PTS_LOGS_DIR/${log_name} | xargs -d '\n' cat 2>/dev/null | ${grep_str} wc -l"
   #total_count_cmd="egrep -h -i ${grep_str} ${log_name} |  wc -l"
   total_count="$(eval "$total_count_cmd")"
   first_cmd="ls -tr $PTS_LOGS_DIR/${log_name} | xargs -d '\n' cat 2>/dev/null | ${grep_str} head -1 |cut -f 1"
   #echo "first_cmd: $first_cmd"
   first="$(eval "$first_cmd")"
   last_cmd="ls -tr $PTS_LOGS_DIR/${log_name} | xargs -d '\n' cat 2>/dev/null | ${grep_str} tail -1 |cut -f 1"
   last="$(eval "$last_cmd")"

   start_time_cmd="ls -tr $PTS_LOGS_DIR/${log_name} | xargs -d '\n' cat 2>/dev/null | cut -f 1"
   #echo "start_time_cmd: $start_time_cmd"
   start_time="$first" #"$(eval "$start_time_cmd")"
   end_time_cmd="ls -tr $PTS_LOGS_DIR/${log_name} | xargs -d '\n' cat 2>/dev/null | ${grep_str} tail -1|cut -f 1"
   end_time="$last" #"$(eval "$end_time_cmd")"
   #echo "start_time: $start_time"
   #echo "end_time: $end_time"

   StartDate=$(date -u -d "$start_time" +"%s")
   EndDate=$(date -u -d "$end_time" +"%s")
   s_diff=`echo $(($EndDate-$StartDate))` #$(date -u -d "0 $EndDate sec - $StartDate sec" +"%s")
   #echo "$time_diff ms"
   avg_time_ms="NONE"
   if [ $s_diff -ne 0 ] && [ $total_count -ne 0 ] ; then
    avg_time_ms=`echo $(($s_diff*1000/$total_count))`
    avg_time_ms=`bc -l <<< "$avg_time_ms"`
    avg_time_ms=`printf "%.2f" $avg_time_ms`
  fi


  echo "$avg_time_ms"
}

cd "$PTS_LOGS_DIR"
#Core & Tidy
#total_msl_ers=`cat "$HOME/Automation/$MSL_SENDER_FILE"| egrep '.txt with execId \[.*\]' | wc -l`
#total_core_ers=`ls -tr $PTS_LOGS_DIR/pts_core*| xargs -d '\n' cat cat 2>/dev/null |egrep -h -i "$CORE_EVENT"|wc -l`
total_core_ers=`egrep -h -i "$CORE_EVENT" pts_core*| wc -l`
#first_core_er=`ls -tr $PTS_LOGS_DIR/pts_core*| xargs -d '\n'  cat 2>/dev/null|egrep -h -i "$CORE_START"|head -1`
#last_core_er=`ls -tr $PTS_LOGS_DIR/pts_core*| xargs -d '\n'  cat 2>/dev/null|egrep -h -i "$CORE_END"|tail -1`
core_start_time=`ls -tr $PTS_LOGS_DIR/pts_core*| xargs -d '\n' cat 2>/dev/null|egrep -h -i "$CORE_START"|head -1|awk '{print $2}'`
core_end_time=`ls -tr $PTS_LOGS_DIR/pts_core*| xargs -d '\n' cat 2>/dev/null|egrep -h -i "$CORE_END"|tail -1|awk '{print $2}'`

StartDate1=$(date -u -d "$core_start_time" +"%s")
EndDate1=$(date -u -d "$core_end_time" +"%s")
s_diff=`echo $(($EndDate1-$StartDate1))` #$(date -u -d "0 $EndDate1 sec - $StartDate1 sec" +"%s")
core_total_time=$(date -u -d "0 $EndDate1 sec - $StartDate1 sec" +"%H:%M:%S.%3N")
#echo "$diff_ms"
avg_core_time="NONE"
if [ $s_diff -ne 0 ] && [ $total_core_ers -ne 0 ] ; then
    avg_core_time=`echo $(($s_diff*1000/$total_core_ers))`
    avg_core_time=`bc -l <<< "$avg_core_time"`
    avg_core_time=`printf "%.2f" $avg_core_time`
fi

#total_tidy_ers=`ls -tr $PTS_LOGS_DIR/pts_tidy*| xargs -d '\n' cat cat 2>/dev/null |egrep -h -i "$TIDY_EVENT"|wc -l`
total_tidy_ers=`egrep -h -i "$TIDY_EVENT" pts_tidy*| wc -l`
#first_tidy_er=`ls -tr $PTS_LOGS_DIR/pts_tidy*| xargs -d '\n'  cat 2>/dev/null |egrep -h -i "$TIDY_START"|head -1`
#last_tidy_er=`ls -tr $PTS_LOGS_DIR/pts_tidy*| xargs -d '\n'  cat 2>/dev/null |egrep -h -i "$TIDY_END"|tail -1`
tidy_start_time=`ls -tr $PTS_LOGS_DIR/pts_tidy*| xargs -d '\n' cat  2>/dev/null |egrep -h -i "$TIDY_START"|head -1|awk '{print $2}'`
tidy_end_time=`ls -tr $PTS_LOGS_DIR/pts_tidy*| xargs -d '\n' cat  2>/dev/null |egrep -h -i "$TIDY_END"|tail -1|awk '{print $2}'`

StartDate2=$(date -u -d "$tidy_start_time" +"%s")
EndDate2=$(date -u -d "$tidy_end_time" +"%s")
s_diff=`echo $(($EndDate2-$StartDate2))` #$(date -u -d "0 $EndDate2 sec - $StartDate2 sec" +"%s")
tidy_total_time=$(date -u -d "0 $EndDate2 sec - $StartDate2 sec" +"%H:%M:%S.%3N")
#echo "$diff_ms"
avg_tidy_time="NONE"
if [ $s_diff -ne 0 ] && [ $total_tidy_ers -ne 0 ] ; then
    avg_tidy_time=`echo $(($s_diff*1000/$total_tidy_ers))`
    avg_tidy_time=`bc -l <<< "$avg_tidy_time"`
    avg_tidy_time=`printf "%.2f" $avg_tidy_time`
fi

#TODO add MslStart-Core/Tidy ends
#TOD avg=0 if count=0

#adapter's tickets
total_adapters_count=0
TIDY_CSV_COMMON_EVENT="PTS-C601"
TIDY_CSV_COMMON_EVENT_MSG1="routed"
TIDY_CSV_COMMON_EVENT_MSG2="common"
TIDY_CSV_MYT_EVENT="PTS-C601"
TIDY_CSV_MYT_EVENT_MSG1="routed"
TIDY_CSV_MYT_EVENT_MSG2="myt"
TIDY_JSON_SAPPHIRE_EVENT="PTS-C650"
TIDY_JSON_SAPPHIRE_MSG="Message was successfully sent to redis" #"routed by Persistent RedisSender"
TIDY_FIX4_4_EVENT="PTS-C7316"
TIDY_FIX4_4_EVENT_MSG="FIX44_ADAPTER"
TIDY_TUDOR_EVENT="PTS-C7316"
TIDY_TUDOR_EVENT_MSG="TUDOR_ADAPTER"
TIDY_RTNS_EVENT="PTS-C7316"
TIDY_RTNS_EVENT_MSG="RTNS"
DB_EVENT="PTS-C550"
DB_EVENT_FX_DEAL_MSG="FX_DEAL"
DB_EVENT_FX_TICKET_LEG_MSG="FX_TICKET_LEG"


#echo "--Starting--"

total_adapters_count=0
total_csv_common_count=0
csv_common_avg=-1
  
  #echo "0.total_csv_common_count: $total_csv_common_count"
  total_csv_common_count="$(get_total_count "pts_tidy*" "${TIDY_CSV_COMMON_EVENT}" "${TIDY_CSV_COMMON_EVENT_MSG1}" "${TIDY_CSV_COMMON_EVENT_MSG2}")"
  #echo "1.total_csv_common_count: $total_csv_common_count"
    
  #echo "0.total_adapters_count: $total_adapters_count"
  #((total_adapters_count+="$total_csv_common_count"))
  #echo "1.total_adapters_count: $total_adapters_count"
  
  #echo "0.csv_common_avg: $csv_common_avg"
  csv_common_avg="$(get_avg_time "pts_tidy*" "${TIDY_CSV_COMMON_EVENT}" "${TIDY_CSV_COMMON_EVENT_MSG}" "${TIDY_CSV_COMMON_EVENT_MSG2}")"
  #echo "1.csv_common_avg: $csv_common_avg"

total_csv_myt_count=0
csv_myt_avg=-1
  total_csv_myt_count="$(get_total_count "pts_tidy*" "${TIDY_CSV_MYT_EVENT}" "${TIDY_CSV_MYT_EVENT_MSG1}" "${TIDY_CSV_MYT_EVENT_MSG2}")"
  #((total_adapters_count+="$total_csv_myt_count"))
  csv_myt_avg="$(get_avg_time "pts_tidy*" "${TIDY_CSV_MYT_EVENT}" "${TIDY_CSV_MYT_EVENT_MSG1}" "${TIDY_CSV_MYT_EVENT_MSG2}")"
total_json_sapphire_count=0
json_sapphire_avg=-1
   total_json_sapphire_count="$(get_total_count "pts_tidy*" "${TIDY_JSON_SAPPHIRE_EVENT}" "${TIDY_JSON_SAPPHIRE_EVENT_MSG}")"
   #((total_adapters_count+="$$total_json_sapphire_count"))
   json_sapphire_avg="$(get_avg_time "pts_tidy*" "${TIDY_JSON_SAPPHIRE_EVENT}" "${TIDY_JSON_SAPPHIRE_EVENT_MSG}")"
total_fix4_4_count=0
fix4_4_avg=-1
  total_fix4_4_count="$(get_total_count "pts_tidy*" "${TIDY_FIX4_4_EVENT}" "${TIDY_FIX4_4_EVENT_MSG}")"
  #((total_adapters_count+="$total_fix4_4_count"))
  fix4_4_avg="$(get_avg_time "pts_tidy*" "${TIDY_FIX4_4_EVENT}" "${TIDY_FIX4_4_EVENT_MSG}")"
total_tudor_count=0
tudor_avg=-1
  total_tudor_count="$(get_total_count "pts_tidy*" "${TIDY_TUDOR_EVENT}" "${TIDY_TUDOR_EVENT_MSG}")"
  #((total_adapters_count+="$total_tudor_count"))
  tudor_avg="$(get_avg_time "pts_tidy*" "${TIDY_TUDOR_EVENT}" "${TIDY_TUDOR_EVENT_MSG}")"
total_rtns_count=0
rtns_avg=-1
  total_rtns_count="$(get_total_count "pts_tidy*" "${TIDY_RTNS_EVENT}" "${TIDY_RTNS_EVENT_MSG}")"
  #((total_adapters_count+="$total_rtns_count"))
  rtns_avg="$(get_avg_time "pts_tidy*" "${TIDY_RTNS_EVENT}" "${TIDY_RTNS_EVENT_MSG}")"
db_fx_deal_avg=-1
  total_db_fx_deal_count="$(get_total_count "pts_core*" "${DB_EVENT}" "${DB_EVENT_FX_DEAL_MSG}")"
  db_fx_deal_avg="$(get_avg_time "pts_core*" "${DB_EVENT}" "${DB_EVENT_FX_DEAL_MSG}")"
db_fx_ticket_leg_avg=-1
  total_db_fx_ticket_leg_count="$(get_total_count "pts_core*" "${DB_EVENT}" "${DB_EVENT_FX_TICKET_LEG_MSG}")"
  db_fx_ticket_leg__avg="$(get_avg_time "pts_core*" "${DB_EVENT}" "${DB_EVENT_FX_TICKET_LEG_MSG}")"

#Stats

#MSL
#echo "MSG_PROCESSED_BY_MSL"         >> "$STAT_FILE"
 #echo "$total_msl_ers"              >> "$STAT_FILE"

#CORE
echo "MSG_PROCESSED_BY_CORE"         >> "$STAT_FILE1"
 echo "$total_core_ers"              >> "$STAT_FILE1"
echo "CORE_PROCESSING_TOTAL_TIME"    >> "$STAT_FILE1"
 echo "$core_total_time [H:M:S.MS]"  >> "$STAT_FILE1"
echo "CORE_RECEIVED_FIRST_MSG"       >> "$STAT_FILE1"
 echo "$core_start_time"             >> "$STAT_FILE1"
echo "CORE_RECEIVED_LAST_MSG"        >> "$STAT_FILE1"
 echo "$core_end_time"               >> "$STAT_FILE1"
echo "CORE_AVG_MSG_TIME"             >> "$STAT_FILE1"
 echo "$avg_core_time ms/er"         >>  "$STAT_FILE1"

#TIDY
echo "MSG_PROCESSED_BY_TIDY"         >> "$STAT_FILE2"
 echo "$total_tidy_ers"              >> "$STAT_FILE2"
echo "TIDY_PROCESSING_TOTAL_TIME"    >> "$STAT_FILE2"
 echo "$tidy_total_time  [H:M:S.MS]" >> "$STAT_FILE2"
echo "TIDY_DELIVERED_FIRST_MSG"      >> "$STAT_FILE2"
 echo "$tidy_start_time"             >> "$STAT_FILE2"
echo "TIDY_DELIVERED_LAST_MSG"       >> "$STAT_FILE2"
 echo "$tidy_end_time"               >> "$STAT_FILE2"
echo "TIDY_AVG_MSG_TIME"             >> "$STAT_FILE2"
 echo "$avg_tidy_time ms/deal"       >> "$STAT_FILE2"

#DB
echo "ERS_COUNT_BY_FX_DEAL"                    >> "$STAT_FILE3"
 echo "$param2"                                >> "$STAT_FILE3"
echo "FX_DEAL_INSERT_AVG"                      >> "$STAT_FILE3"
 echo "$db_fx_deal_avg ms/insert"              >> "$STAT_FILE3"
echo "TICKET_COUNT_BY_FX_TICKET_LEG"           >> "$STAT_FILE3"
 echo "$param1"                                >> "$STAT_FILE3"
echo "FX_TICKET_LEG_INSERT_AVG"                >> "$STAT_FILE3"
 echo "$db_fx_ticket_leg__avg ms/insert"       >> "$STAT_FILE3"


#ADAPTERS
#echo "TOTAL_ADAPTERS_COUNT"                >> "$STAT_FILE4"
 #echo "$total_adapters_count"              >> "$STAT_FILE4"
echo "MSG_PROCESSED_BY_CSV_COMMON"          >> "$STAT_FILE4"
 echo "$total_csv_common_count"             >> "$STAT_FILE4"
echo "CSV_COMMON_AVG_MSG_TIME"              >> "$STAT_FILE4"
 echo "$csv_common_avg ms/ticket"           >> "$STAT_FILE4"
echo "MSG_PROCESSED_BY_CSV_MYT"             >> "$STAT_FILE4"
 echo "$total_csv_myt_count"                >> "$STAT_FILE4"
echo "CSV_COMMON_AVG_MSG_TIME"              >> "$STAT_FILE4"
 echo "$csv_myt_avg ms/ticket"              >> "$STAT_FILE4"
echo "MSG_PROCESSED_BY_JSON_SAPPHIRE"       >> "$STAT_FILE4"
 echo "$total_json_sapphire_count"          >> "$STAT_FILE4"
echo "JSON_SAPPHIRE_AVG_MSG_TIME"           >> "$STAT_FILE4"
 echo "$json_sapphire_avg ms/ticket"        >> "$STAT_FILE4"
echo "MSG_PROCESSED_BY_FIX4_4"              >> "$STAT_FILE4"
 echo "$total_fix4_4_count"                 >> "$STAT_FILE4"
echo "FIX4_4_AVG_MSG_TIME"                  >> "$STAT_FILE4"
 echo "$fix4_4_avg ms/ticket"               >> "$STAT_FILE4"
echo "MSG_PROCESSED_BY_RTNS"                >> "$STAT_FILE4"
 echo "$total_rtns_count"                   >> "$STAT_FILE4"
echo "RTNS_AVG_MSG_TIME"                    >> "$STAT_FILE4"
 echo "$rtns_avg ms/ticket"                 >> "$STAT_FILE4"
echo "MSG_PROCESSED_BY_TUDOR"               >> "$STAT_FILE4"
 echo "$total_tudor_count"                  >> "$STAT_FILE4"
echo "TUDOR_AVG_MSG_TIME"                   >> "$STAT_FILE4"
 echo "$tudor_avg ms/ticket"                >> "$STAT_FILE4"


#MONITORS
#TODO APP & DB & REDIS SERVERS - cpu,mem,IO stats

