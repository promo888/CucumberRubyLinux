#!/bin/bash

### debug features
logDebug="$HOME/Automation/stopPtradeIfNoTickets.log"
exec 5> "$logDebug"
BASH_XTRACEFD="5"
PS4='$LINENO: '
set -x

param1=${1:NOT_SET} #Default Jenkins Service
if [ -z "$param1" ]; then
	param1="10.20.30.168:1234" #Service Host:Port
fi
param2=${2:NOT_SET}
param3=${3:NOT_SET}
param4=${4:NOT_SET}
param5=${5:NOT_SET}

PTS_LOGS_DIR="$HOME/PTS/logs"
cd "$PTS_LOGS_DIR"

### Tidy Logging 10-15k tickets ~ 11m = 150k tickets/per hour ,360 - 6hours for 900k/tickets as MAX
TIDY_LOG_SEARCH="Received MSL message"
FIRST_MATCH_TIME=""
LAST_MATCH_TIME=""

#sleep 60 #proper start of CPT - handled in Automation
FIRST_MATCH_TIME=$(find  pts_tidy_3*  | xargs egrep 2>/dev/null 'Received MSL message' | head -1 |awk {'print $2'})

if [  -z "$FIRST_MATCH_TIME" -o "$FIRST_MATCH_TIME" == " " -o "$FIRST_MATCH_TIME" == "" ]; then
       echo "$(date +%Y-%m-%d_%H:%M:%S,%3N) Tidy tickets are NOT FOUND"
       curl "http://$param1/set?no_tidy_tickets_found=true"
       exit 1
fi


while true
do
    sleep 120 #last 60sec acquired for new data match
    LAST_MATCH_TIME=$(find  pts_tidy_3* | xargs egrep 2>/dev/null 'Received MSL message'|tail -1|awk {'print $2'}) #pts_tidy_3*  -mmin -1
    if [  -z $LAST_MATCH_TIME -o $FIRST_MATCH_TIME=$LAST_MATCH_TIME  ]; then
        echo "$(date +%Y-%m-%d_%H:%M:%S,%3N) Tidy next ticket is not found within 70ms"
        stop_cmd="~/PTS/bin/service.sh stop"
        stop_cmd_res="$(eval "$stop_cmd")"
        echo "$(date +%Y-%m-%d_%H:%M:%S,%3N) stop_ptrade  res: $stop_cmd_res"
        status_cmd="~/PTS/bin/service.sh status"
        status_cmd_res="$(eval "$status_cmd")"
        echo "$(date +%Y-%m-%d_%H:%M:%S,%3N) status_ptrade  res: $status_cmd_res"
        curl "http://$param1//set?ptrade_is_stopped=true"
        exit 1
    else
        FIRST_MATCH_TIME="$LAST_MATCH_TIME"
    fi
done