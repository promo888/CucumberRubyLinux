#!/bin/bash

### debug features
logDebug=perf1_debug.log
exec 5> "$logDebug"
BASH_XTRACEFD="5"
PS4='$LINENO: '
set -x

param1=${1:NOT_SET}
param2=${2:NOT_SET}
param3=${3:NOT_SET}
param4=${4:NOT_SET}
param5=${5:NOT_SET}

MSL_SENDER_FILE="mslErSenderPerf1.log"
STAT_FILE="$HOME/Automation/perf1.log"
CORE_EVENT="PTS-C832"
TIDY_EVENT="PTS-C607"
rm -f "$STAT_FILE"
touch "$STAT_FILE"


cd "$HOME/PTS/logs"
total_msl_ers=`cat "$HOME/Automation/$MSL_SENDER_FILE"| egrep '.txt with execId \[.*\]' | wc -l`
total_core_ers=`ls -tr pts_core*log|xargs -d '\n' grep "$CORE_EVENT" -h|wc -l`
first_core_er=`ls -tr pts_core*log|xargs -d '\n' grep "$CORE_EVENT" -h|head -1`
last_core_er=`ls -tr pts_core*log|xargs -d '\n' grep "$CORE_EVENT" -h|tail -1`
core_start_time=`ls -tr pts_core*log|xargs -d '\n' grep "$CORE_EVENT" -h |head -1|awk '{ print $2}'`
core_end_time=`ls -tr pts_core*log|xargs -d '\n' grep "$CORE_EVENT" -h |tail -1|awk '{ print $2}'`
c1_m=`date --date="$core_start_time" +%M`
 c1_m=`echo $c1_m| sed 's/^0//'`
c1_s=`date --date="$core_start_time" +%S`
 c1_s=`echo $c1_s| sed 's/^0//'`
c1_ms=`date --date="$core_start_time" +%3N`
 c1_ms=`echo $c1_ms| sed 's/^0//'`
c2_m=`date --date="$core_end_time" +%M`
 c2_m=`echo $c2_m| sed 's/^0//'`
c2_s=`date --date="$core_end_time" +%S`
 c2_s=`echo $c2_s| sed 's/^0//'`
c2_ms=`date --date="$core_end_time" +%3N`
 c2_ms=`echo $c2_ms| sed 's/^0//'`
core_total_time=`echo $(($c2_m-$c1_m)) "mins" $(($c2_s-$c1_s)) "secs"` # $((($c2_ms-$c1_ms)/1000)) "millis"`
core_total_time_secs=$(($c2_ms-$c1_ms))
avg_core_time="-1"
if [ $core_total_time_secs -ne 0 ] && [ $total_core_ers -ne 0 ] ; then
 avg_core_time=`echo $(($core_total_time_secs/$total_core_ers*1000))`
 avg_core_time=`bc -l <<< "$core_total_time_secs/$total_core_ers*1000"`
 avg_core_time=`printf "%.2f" $avg_core_time`
fi
total_tidy_ers=`ls -tr pts_tidy*log|xargs -d '\n' grep "$TIDY_EVENT" -h|wc -l`
first_tidy_er=`ls -tr pts_tidy*log|xargs -d '\n' grep "$TIDY_EVENT" -h|head -1`
last_tidy_er=`ls -tr pts_tidy*log|xargs -d '\n' grep "$TIDY_EVENT" -h|tail -1`
tidy_start_time=`ls -tr pts_tidy*log|xargs -d '\n' grep "$TIDY_EVENT" -h |head -1|awk '{ print $2}'`
tidy_end_time=`ls -tr pts_tidy*log|xargs -d '\n' grep "$TIDY_EVENT" -h |tail -1|awk '{ print $2}'`
t1_m=`date --date="$tidy_start_time" +%M`
 t1_m=`echo $t1_m| sed 's/^0//'`
t1_s=`date --date="$tidy_start_time" +%S`
 t1_s=`echo $t1_s| sed 's/^0//'`
t1_ms=`date --date="$tidy_start_time" +%3N`
 t1_ms=`echo $t1_ms| sed 's/^0//'`
t2_m=`date --date="$tidy_end_time" +%M`
 t2_m=`echo $t2_m| sed 's/^0//'`
t2_s=`date --date="$tidy_end_time" +%S`
 t2_s=`echo $t2_s| sed 's/^0//'`
t2_ms=`date --date="$tidy_end_time" +%3N`
 t2_ms=`echo $t2_ms| sed 's/^0//'`
tidy_total_time=`echo $(($t2_m-$t1_m)) "mins" $(($t2_s-$t1_s)) "secs"` # $((($t2_ms-$t1_ms)/1000)) "millis"`
tidy_total_time_secs=$(($t2_ms-$t1_ms))
avg_tidy_time="-1"
if [ $tidy_total_time_secs -ne 0 ] && [ $total_tidy_ers -ne 0 ] ;then
 avg_tidy_time=`echo $(($tidy_total_time_secs/$total_tidy_ers*1000))`
 avg_tidy_time=`bc -l <<< "$tidy_total_time_secs/$total_tidy_ers*1000"`
 avg_tidy_time=`printf "%.2f" $avg_tidy_time`
fi



#Stats

#echo "MSG_PROCESSED_BY_MSL"          >> "$STAT_FILE"
 #echo "$total_msl_ers"              >> "$STAT_FILE"
echo "ERS_COUNT_BY_FX_DEAL"          >> "$STAT_FILE"
 echo "$param2"                      >> "$STAT_FILE"
echo "MSG_PROCESSED_BY_CORE"         >> "$STAT_FILE"
 echo "$total_core_ers"              >> "$STAT_FILE"
echo "CORE_PROCESSING_TOTAL_TIME"    >> "$STAT_FILE"
 echo "$core_total_time"             >> "$STAT_FILE"
echo "MSG_PROCESSED_BY_TIDY"         >> "$STAT_FILE"
 echo "$total_tidy_ers"              >> "$STAT_FILE"
echo "TIDY_PROCESSING_TOTAL_TIME"    >> "$STAT_FILE"
 echo "$tidy_total_time"             >> "$STAT_FILE"
echo "TICKET_COUNT_BY_FX_TICKET_LEG" >> "$STAT_FILE"
 echo "$param1"                      >> "$STAT_FILE"


echo "CORE_RECEIVED_FIRST_MSG"       >> "$STAT_FILE"
 echo "$core_start_time"             >> "$STAT_FILE"
echo "CORE_RECEIVED_LAST_MSG"        >> "$STAT_FILE"
 echo "$core_end_time"               >> "$STAT_FILE"
echo "CORE_AVG_MSG_TIME"             >> "$STAT_FILE"
 echo "$avg_core_time ms/er"        >> "$STAT_FILE"

echo "TIDY_DELIVERED_FIRST_MSG"      >> "$STAT_FILE"
 echo "$tidy_start_time"             >> "$STAT_FILE"
echo "TIDY_DELIVERED_LAST_MSG"       >> "$STAT_FILE"
 echo "$tidy_end_time"               >> "$STAT_FILE"
echo "TIDY_AVG_MSG_TIME"             >> "$STAT_FILE"
 echo "$avg_tidy_time ms/ticket"     >> "$STAT_FILE"




