require 'cucumber'
require 'net/ssh'
require 'net/scp'
require 'time'
require 'thread'
require 'thwait'

begin
  require '../../features/helpers/Actions'
  require '../../features/helpers/Config.rb'
  include Config
rescue LoadError
end



Given /^SDATA SCHEMAS Setup is Done - Parcippany and Last Lab versions$/ do
  steps %Q{
      Given beforeScenarioStepsSdata
    }

  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    res = ''
    begin
      res = buildSdataSchema('sdata1', CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
    rescue Exception=>e
      @@scenario_fails.push('sdata1 build failed for version ' + CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
      # Actions.displaySanityLogs(false, true, false, false)
      if (!res.nil? && !res.to_s.empty?)
        Actions.f 'ERROR:'+"\n"+res
      end
      fail('sdata1 build failed for version ' + CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
    end

    begin
      res = buildSdataSchema('sdata', (CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?) ? '' : CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])
    rescue Exception=>e
      @@scenario_fails.push('sdata build failed for the Latest version ')
      # Actions.displaySanityLogs(true, false, false, false)
      if (!res.nil? && !res.to_s.empty?)
        Actions.f 'ERROR:'+"\n"+res
      end
      fail('sdata build failed for the Latest version ')
    end

    displaySdataSchemaOldVersion
    displaySdataSchemaNewVersion
  else
    Actions.c '<b>NOT deploying SDATA</b>'
  end
end


### Concurrent


#sdata
Given /^SDATA SCHEMAS Concurrent Setup is Done - Parcippany and Last Lab versions$/ do
  steps %Q{
      Given beforeScenarioStepsSdata
    }

  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    threads = []
    t1=Thread.new{buildOldSdataSchemaThread(CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])}
    t1.abort_on_exception = true
    threads << t1
    t2=Thread.new{buildNewSdataSchemaThread((CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?) ? '' : CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'])}
    t2.abort_on_exception = true
    t1.join
    threads << t2
    t2.join
    ThreadsWait.all_waits(*threads )
    fail('buildOldSdataSchemaTrhead failed for sdata1') if(t1.status.nil?)
    fail('buildNewSdataSchemaThread failed for sdata') if(t2.status.nil?)

    displaySdataSchemaOldVersion
    displaySdataSchemaNewVersion
    steps %Q{
      Then SDATA schema compared
    }
  else
    Actions.c '<b>NOT deploying SDATA</b>'
  end
end


Given /^SDATA SCHEMAS Concurrent Setup is Done - Production version for both users$/ do
  steps %Q{
      Given beforeScenarioSteps
    }
if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    threads = []
    t1=Thread.new{buildOldSdataSchemaThread(CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])}
    t1.abort_on_exception = true
    threads << t1
    t2=Thread.new{buildNewSdataSchemaThread(CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])}
    t2.abort_on_exception = true
    t1.join
    threads << t2
    t2.join
    ThreadsWait.all_waits(*threads )
    fail('buildOldSdataSchemaThread failed for sdata1') if(t1.status.nil?)
    fail('buildNewSdataSchemaThread failed for sdata') if(t2.status.nil?)

    displaySdataSchemaOldVersion
    displaySdataSchemaNewVersion
    # steps %Q{
    #  Then SDATA schema compared
    # }
  else
    Actions.c '<b>NOT deploying SDATA</b>'
  end
end


Given /^MDS is deployed and launched for 2 users$/ do
  steps %Q{
      Given beforeScenarioStepsMDS
  }

  threads = []
  begin
    if (CONFIG.get['MDS_OLD_VERSION'].nil? || CONFIG.get['MDS_OLD_VERSION'].to_s.empty?)
      storagePath = '/export/home/'+CONFIG.get['MDS_HOST_USER']+'/build_server/Releases/MDS'
      tarFilter1 = 'MDS_FULL_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'], cmd, 45, true, '')
      @@CONFIG['MDS_OLD_VERSION'] = res.to_s.strip
    end
  rescue Exception=>e
    fail('Unable to retrieve last build filename for MDS_OLD_VERSION: '+e.to_s) if(!e.nil? || !e.to_s.empty?)
    fail('Unable to retrieve last build filename for MDS_OLD_VERSION') if(e.to_s.empty?)
  end
  old_version=CONFIG.get['MDS_OLD_VERSION'].nil? || CONFIG.get['MDS_OLD_VERSION'].to_s.strip.empty? ? '' : CONFIG.get['MDS_OLD_VERSION'].to_s.strip
  # @@old_ptrade_version_number = old_version.scan(/PTS_MAIN_\d+.\d+.\d+.\d+.(\d+)/)[0][0] if !old_version.to_s.strip.empty?
  t1=Thread.new{buildMDSforOldVersionThread(old_version)}
  t1.abort_on_exception = true
  threads << t1
  begin
    if (CONFIG.get['MDS_NEW_VERSION'].nil? || CONFIG.get['MDS_NEW_VERSION'].to_s.empty?)
      storagePath = '/export/home/'+CONFIG.get['MDS_HOST_USER']+'/build_server/Releases/MDS'
      tarFilter1 = 'MDS_FULL_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'], cmd, 45, true, '')
      @@CONFIG['MDS_NEW_VERSION'] = res.to_s.strip
    end
  rescue Exception=>e
    fail('Unable to retrieve last build filename for MDS_NEW_VERSION: '+e.to_s) if(!e.nil? || !e.to_s.empty?)
    fail('Unable to retrieve last build filename for MDS_NEW_VERSION') if(e.to_s.empty?)
  end
  new_version=CONFIG.get['MDS_NEW_VERSION'].nil? || CONFIG.get['MDS_NEW_VERSION'].to_s.strip.empty? ? '' : CONFIG.get['MDS_NEW_VERSION'].to_s.strip
  t2=Thread.new{buildMDSforNewVersionThread(new_version,true)}
  t2.abort_on_exception = true
  t1.join
  threads << t2
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('MDS installation failed for user dashboard1') if(t1.status.nil?)
  fail('MDS installation failed for user dashboard') if(t2.status.nil?)

=begin
  if(!ENV['AUTO_TOOL_WAIT'].nil? && !ENV['AUTO_TOOL_WAIT'].to_s.empty?)
    Actions.v 'Starting timeout "'+ENV['AUTO_TOOL_WAIT'].to_s+'" sec'
    sleep ENV['AUTO_TOOL_WAIT'].to_i
  end
=end
end


Given /^2 versions of MDS are deployed and launched$/ do
  threads = []
  begin
    if (CONFIG.get['MDS_OLD_VERSION'].nil? || CONFIG.get['MDS_OLD_VERSION'].to_s.empty?)
      storagePath = '/export/home/'+CONFIG.get['MOUNT_USER']+'/build_server/Releases/MDS'
      tarFilter1 = 'MDS_FULL_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(ENV['MOUNT_HOST'], ENV['MOUNT_USER'], ENV['MOUNT_PWD'], cmd, 45, true, '')
      @@CONFIG['MDS_OLD_VERSION'] = res.to_s.strip
    end
  rescue Exception=>e
    fail('Unable to retrieve last build filename for MDS_OLD_VERSION: '+e.to_s) if(!e.nil? || !e.to_s.empty?)
    fail('Unable to retrieve last build filename for MDS_OLD_VERSION') if(e.to_s.empty?)
  end
  old_version=CONFIG.get['MDS_OLD_VERSION'].nil? || CONFIG.get['MDS_OLD_VERSION'].to_s.strip.empty? ? '' : CONFIG.get['MDS_OLD_VERSION'].to_s.strip
  t1=Thread.new{buildMDSforOldVersionThread2(old_version)}
  t1.abort_on_exception = true
  threads << t1

  begin
    if (CONFIG.get['MDS_NEW_VERSION'].nil? || CONFIG.get['MDS_NEW_VERSION'].to_s.empty?)
      storagePath = '/export/home/'+CONFIG.get['MOUNT_USER']+'/build_server/Releases/MDS'
      tarFilter1 = 'MDS_FULL_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(ENV['MOUNT_HOST'], ENV['MOUNT_USER'], ENV['MOUNT_PWD'], cmd, 45, true, '')
      @@CONFIG['MDS_NEW_VERSION'] = res.to_s.strip
    end
  rescue Exception=>e
    fail('Unable to retrieve last build filename for MDS_NEW_VERSION: '+e.to_s) if(!e.nil? || !e.to_s.empty?)
    fail('Unable to retrieve last build filename for MDS_NEW_VERSION') if(e.to_s.empty?)
  end
  new_version=CONFIG.get['MDS_NEW_VERSION'].nil? || CONFIG.get['MDS_NEW_VERSION'].to_s.strip.empty? ? '' : CONFIG.get['MDS_NEW_VERSION'].to_s.strip
  t2=Thread.new{buildMDSforNewVersionThread2(new_version)}
  t2.abort_on_exception = true
  t1.join
  threads << t2
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('MDS old version installation failed for '+ENV['MDS_HOST_USER_OLD']+'@'+ENV['MDS_HOST_IP_OLD']) if(t1.status.nil?)
  fail('MDS new version installation failed for '+ENV['MDS_HOST_USER_NEW']+'@'+ENV['MDS_HOST_IP_NEW']) if(t2.status.nil?)
end


Given /^version of MDS is optionally deployed, MSL is optionally cleaned and MDS is launched$/ do
  host = ENV['MDS_PERF_HOST_IP']
  user = ENV['MDS_PERF_HOST_USER']
  pwd = ENV['MDS_PERF_HOST_PWD']

  if ENV['DEPLOY_MDS'] == 'true'
    fail('Please define MOUNT_HOST') if ENV['MOUNT_HOST'].to_s.empty?
    fail('Please define MOUNT_USER') if ENV['MOUNT_USER'].to_s.empty?
    fail('Please define MOUNT_PWD') if ENV['MOUNT_PWD'].to_s.empty?

    begin
      if (ENV['MDS_PERF_VERSION'].nil? || ENV['MDS_PERF_VERSION'].to_s.empty?)
        storagePath = '/export/home/'+ENV['MOUNT_USER']+'/build_server/Releases/MDS'
        tarFilter1 = 'MDS_FULL_'
        tarFilter2 = '.tar.gz'
        cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
        res = Actions.SSH(ENV['MOUNT_HOST'], ENV['MOUNT_USER'], ENV['MOUNT_PWD'], cmd, 45, true, '')
        ENV['MDS_PERF_VERSION'] = res.to_s.strip
        @@CONFIG['MDS_PERF_VERSION'] = ENV['MDS_PERF_VERSION']
      end
    rescue Exception => e
      fail('Unable to retrieve last build filename for MDS_PERF_VERSION: '+e.to_s) if (!e.nil? || !e.to_s.empty?)
      fail('Unable to retrieve last build filename for MDS_PERF_VERSION') if (e.to_s.empty?)
    end

    begin
      perf_version=ENV['MDS_PERF_VERSION'].nil? || ENV['MDS_PERF_VERSION'].to_s.strip.empty? ? '' : ENV['MDS_PERF_VERSION'].to_s.strip
      buildMDSforCustomVersion2(host, user, pwd, perf_version)
    rescue Exception => e
      errMsg = e.message.empty? ? '' : e.message
      errMsg = 'Error: MDS installation failed for '+user+'@'+host+' '+errMsg
      @@scenario_fails.push(errMsg)
      fail(errMsg)
    end
  end

  begin
    if ENV['USE_MSL_LOADER'] == 'true'
      fail('Please define MSL_LOADER_PATH') if ENV['MSL_LOADER_PATH'].to_s.empty?
      fail('Please define MSL_LOADER_ARB_LOG_PATH') if ENV['MSL_LOADER_ARB_LOG_PATH'].to_s.empty?
      fail('Please define MSL_IP') if ENV['MSL_IP'].to_s.empty?
      fail('Please define MSL_LOADER_START_TIME') if ENV['MSL_LOADER_START_TIME'].to_s.empty?
      fail('Please define MSL_LOADER_STOP_TIME') if ENV['MSL_LOADER_STOP_TIME'].to_s.empty?

      host_mds = ENV['MDS_PERF_HOST_IP']
      user_mds = ENV['MDS_PERF_HOST_USER']
      pwd_mds = ENV['MDS_PERF_HOST_PWD']

      Actions.v 'Killing MSL loader processes at '+user_mds+'@'+host_mds
      cmd = 'kill -9 $(/bin/ps -ef -U '+user_mds+" | grep app.MslLoader | awk '{print $2}')"
      res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 15, true, '')

      Actions.cleanupMslCustom2(ENV['MSL_IP'], 'msl', 'msl1', 'Automation')
    end
  rescue Exception => e
    fail('Cleaning MSL '+ENV['MSL_IP']+' failed for '+user_mds+'@'+host_mds)+' '+e.message
  end

  #------Renaming original config templates dir---------
  cmd = 'mv ~/MDS/config ~/MDS/config_orig_$(date +%Y-%m-%d_%H-%M-%S-%3N) && mkdir -p ~/MDS/config'
  res = Actions.SSH(host, user, pwd, cmd, 25, true, '')

  #------Uploading config templates---------
  mdsConfigSource = Dir.getwd+'/templates/mds_config_perf'
  mdsConfigDest = CONFIG.get['REMOTE_HOME']+'/'+user+'/MDS/config'
  Actions.v 'Uploading config templates for '+user+'@'+host
  begin
    uploadDirToRemoteFolder(host, user, pwd, mdsConfigSource, mdsConfigDest)
  rescue Exception=>e
    @@scenario_fails.push('Error while uploading config templates directory to '+mdsConfigDest+' at '+host+':'+user)
    fail('Error while uploading config templates directory to '+mdsConfigDest+' at '+host+':'+user+' '+e.message)
  end

  #------Preparing MDS files for launching---------
  mdsPath=CONFIG.get['REMOTE_HOME']+'/'+user+'/MDS/bin'
  cmd = 'chmod -R 755 '+mdsPath
  res = Actions.SSH(host, user, pwd, cmd, 25, true, '')

  #------Running MDS---------
  res = runMDS(host, user, pwd, mdsPath)
  Actions.v 'Res of starting MDS:'+"\n"+res.to_s
end


def deployMdsVersionThread(host, user, pwd, mdsVersion, prefix='MDS')
    begin
      perf_version=mdsVersion.nil? || mdsVersion.to_s.strip.empty? ? '' : mdsVersion.to_s.strip
      buildMDSforCustomVersion2(host, user, pwd, perf_version, prefix)
    rescue Exception => e
      errMsg = e.message.empty? ? '' : e.message
      errMsg = 'Error: MDS installation failed for '+user+'@'+host+' '+errMsg
      @@scenario_fails.push(errMsg)
      fail(errMsg)
    end
end


def cleanMslThread(mslIP) #, hostMslLoader, userMslLoader, pwdMslLoader
  begin
    fail('Please define MSL_LOADER_PATH') if ENV['MSL_LOADER_PATH'].to_s.empty?
    fail('Please define MSL_LOADER_ARB_LOG_PATH') if ENV['MSL_LOADER_ARB_LOG_PATH'].to_s.empty?
    fail('Please define MSL_IP') if ENV['MSL_IP'].to_s.empty?
    fail('Please define MSL_LOADER_START_TIME') if ENV['MSL_LOADER_START_TIME'].to_s.empty?
    fail('Please define MSL_LOADER_STOP_TIME') if ENV['MSL_LOADER_STOP_TIME'].to_s.empty?

    # Actions.v 'Killing MSL loader processes at '+userMslLoader+'@'+hostMslLoader
    # cmd = 'kill -9 $(/bin/ps -ef -U '+userMslLoader+" | grep app.MslLoader | awk '{print $2}')"
    # res = Actions.SSH(hostMslLoader, userMslLoader, pwdMslLoader, cmd, 15, true, '')

    Actions.cleanupMslCustom2(mslIP, 'msl', 'msl1', 'Automation')
  rescue Exception => e
    fail('Cleaning MSL '+mslIP+' failed for '+userMslLoader+'@'+hostMslLoader)+' '+e.message
  end
end


def launchMdsThread(host, user, pwd, mdsConfigDir, connectToSdata='true')
  #------Renaming original config templates dir---------
  cmd = 'mv ~/MDS/config ~/MDS/config_orig_$(date +%Y-%m-%d_%H-%M-%S-%3N) && mkdir -p ~/MDS/config'
  res = Actions.SSH(host, user, pwd, cmd, 25, true, '')

  #------Uploading config templates---------
  mdsConfigSource = mdsConfigDir
  mdsConfigDest = CONFIG.get['REMOTE_HOME']+'/'+user+'/MDS/config'
  Actions.v 'Uploading config templates for '+user+'@'+host
  begin
    uploadDirToRemoteFolder(host, user, pwd, mdsConfigSource, mdsConfigDest)
  rescue Exception=>e
    @@scenario_fails.push('Error while uploading config templates directory to '+mdsConfigDest+' at '+host+':'+user)
    fail('Error while uploading config templates directory to '+mdsConfigDest+' at '+host+':'+user+' '+e.message)
  end

  #------Preparing MDS files for launching---------
  mdsPath=CONFIG.get['REMOTE_HOME']+'/'+user+'/MDS/bin'
  cmd = 'chmod -R 755 '+mdsPath
  res = Actions.SSH(host, user, pwd, cmd, 25, true, '')

  #------Running MDS---------
  if connectToSdata == 'false'
    Actions.c 'Starting MDS without connecting to SDATA'
    res = runMDS(host, user, pwd, mdsPath, false)
  else
    ### removing sd directory if it exists in order not to use it in a case when MDS cannot connect to a specified static data schema
    cmd = 'rm -rf ~/MDS/config/sd'
    res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 25)

    res = runMDS(host, user, pwd, mdsPath, true)
  end
  Actions.v 'Res of starting MDS at '+user+'@'+host+':'+"\n"+res.to_s
end


Given /^2 versions of MDS are optionally deployed, MSL is optionally cleaned and MDS versions are launched$/ do
  begin
    if (ENV['MDS_PERF_VERSION'].nil? || ENV['MDS_PERF_VERSION'].to_s.empty?)
      storagePath = '/export/home/'+ENV['MOUNT_USER']+'/build_server/Releases/MDS'
      tarFilter1 = 'MDS_FULL_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(ENV['MOUNT_HOST'], ENV['MOUNT_USER'], ENV['MOUNT_PWD'], cmd, 45, true, '')
      ENV['MDS_PERF_VERSION'] = res.to_s.strip
      @@CONFIG['MDS_PERF_VERSION'] = ENV['MDS_PERF_VERSION']
    end
  rescue Exception => e
    fail('Unable to retrieve last build filename for MDS_PERF_VERSION: '+e.to_s) if (!e.nil? || !e.to_s.empty?)
    fail('Unable to retrieve last build filename for MDS_PERF_VERSION') if (e.to_s.empty?)
  end

  begin
    if (ENV['MDS_PERF_VERSION_2'].nil? || ENV['MDS_PERF_VERSION_2'].to_s.empty?)
      storagePath = '/export/home/'+ENV['MOUNT_USER']+'/build_server/Releases/MDS'
      tarFilter1 = 'MDS_FULL_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(ENV['MOUNT_HOST'], ENV['MOUNT_USER'], ENV['MOUNT_PWD'], cmd, 45, true, '')
      ENV['MDS_PERF_VERSION_2'] = res.to_s.strip
      @@CONFIG['MDS_PERF_VERSION_2'] = ENV['MDS_PERF_VERSION_2']
    end
  rescue Exception => e
    fail('Unable to retrieve last build filename for MDS_PERF_VERSION_2: '+e.to_s) if (!e.nil? || !e.to_s.empty?)
    fail('Unable to retrieve last build filename for MDS_PERF_VERSION_2') if (e.to_s.empty?)
  end

  path_config_perf='C:\MDS_config\MDS_perf\\'+ENV['MDS_PERF_VERSION'].to_s.chomp('.tar.gz')
  path_config_perf_2='C:\MDS_config\MDS_perf\\'+ENV['MDS_PERF_VERSION_2'].to_s.chomp('.tar.gz')

  res = Actions.WINCMD('IF exist '+path_config_perf+'\ ( echo Dir exists ) ELSE ( echo Dir DOES NOT exist )', 20, 'Dir')
  if res.to_s.strip.include?('Dir exists')
    # Actions.WINCMD('copy /Y '+path_config_perf+'\\'+'*.*'+' '+Dir.getwd.gsub('/', '\\')+'\templates\mds_config_perf', 20, 'file')
    Actions.WINCMD('xcopy /E /Y '+path_config_perf+'\\'+'*.*'+' '+Dir.getwd.gsub('/', '\\')+'\templates\mds_config_perf', 20, 'file')
  else
    fail('Error: config directory "'+path_config_perf+'" not found')
  end
  res = Actions.WINCMD('IF exist '+path_config_perf_2+'\ ( echo Dir exists ) ELSE ( echo Dir DOES NOT exist )', 20, 'Dir')
  if res.to_s.strip.include?('Dir exists')
    # Actions.WINCMD('copy /Y '+path_config_perf_2+'\\'+'*.*'+' '+Dir.getwd.gsub('/', '\\')+'\templates\mds_config_perf_2', 20, 'file')
    Actions.WINCMD('xcopy /E /Y '+path_config_perf_2+'\\'+'*.*'+' '+Dir.getwd.gsub('/', '\\')+'\templates\mds_config_perf_2', 20, 'file')
  else
    fail('Error: config directory "'+path_config_perf_2+'" not found')
  end

  if ENV['DEPLOY_MDS'] == 'true'
    deployMdsVersionThread(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'], ENV['MDS_PERF_VERSION'], 'MDS_perf')
  end

  if ENV['DEPLOY_MDS_2'] == 'true'
    deployMdsVersionThread(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'], ENV['MDS_PERF_VERSION_2'], 'MDS_perf_2')
  end
  # fail('Deploying MDS failed for '+ENV['MDS_PERF_HOST_USER']+'@'+ENV['MDS_PERF_HOST_IP']) if(t1.status.nil?)
  # fail('Deploying MDS failed for '+ENV['MDS_PERF_HOST_USER_2']+'@'+ENV['MDS_PERF_HOST_IP_2']) if(t2.status.nil?)

  Actions.killMslLoaderPerUser(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'])
  Actions.killMslLoaderPerUser(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'])

  if ENV['USE_MSL_LOADER'] == 'true'
    cleanMslThread(ENV['MSL_IP']) #, ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD']
  else
    Action.c 'Not cleaning MSL'
  end

  threads = []
  t1=Thread.new{ launchMdsThread(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'], Dir.getwd+'/templates/mds_config_perf', ENV['ConnectToSdata']) }
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new{ launchMdsThread(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'], Dir.getwd+'/templates/mds_config_perf_2', ENV['ConnectToSdata_2']) }
  t2.abort_on_exception = true
  threads << t2

  t1.join
  t2.join
  ThreadsWait.all_waits(*threads )

  fail('Launching MDS failed for '+ENV['MDS_PERF_HOST_USER']+'@'+ENV['MDS_PERF_HOST_IP']) if(t1.status.nil?)
  fail('Launching MDS failed for '+ENV['MDS_PERF_HOST_USER_2']+'@'+ENV['MDS_PERF_HOST_IP_2']) if(t2.status.nil?)
end


Given /^2 versions of MDS are optionally deployed, LFR processes are killed and MDS versions are launched$/ do
  begin
    if (ENV['MDS_PERF_VERSION'].nil? || ENV['MDS_PERF_VERSION'].to_s.empty?)
      storagePath = '/export/home/'+ENV['MOUNT_USER']+'/build_server/Releases/MDS'
      tarFilter1 = 'MDS_FULL_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(ENV['MOUNT_HOST'], ENV['MOUNT_USER'], ENV['MOUNT_PWD'], cmd, 45, true, '')
      ENV['MDS_PERF_VERSION'] = res.to_s.strip
      @@CONFIG['MDS_PERF_VERSION'] = ENV['MDS_PERF_VERSION']
    end
  rescue Exception => e
    fail('Unable to retrieve last build filename for MDS_PERF_VERSION: '+e.to_s) if (!e.nil? || !e.to_s.empty?)
    fail('Unable to retrieve last build filename for MDS_PERF_VERSION') if (e.to_s.empty?)
  end

  begin
    if (ENV['MDS_PERF_VERSION_2'].nil? || ENV['MDS_PERF_VERSION_2'].to_s.empty?)
      storagePath = '/export/home/'+ENV['MOUNT_USER']+'/build_server/Releases/MDS'
      tarFilter1 = 'MDS_FULL_'
      tarFilter2 = '.tar.gz'
      cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
      res = Actions.SSH(ENV['MOUNT_HOST'], ENV['MOUNT_USER'], ENV['MOUNT_PWD'], cmd, 45, true, '')
      ENV['MDS_PERF_VERSION_2'] = res.to_s.strip
      @@CONFIG['MDS_PERF_VERSION_2'] = ENV['MDS_PERF_VERSION_2']
    end
  rescue Exception => e
    fail('Unable to retrieve last build filename for MDS_PERF_VERSION_2: '+e.to_s) if (!e.nil? || !e.to_s.empty?)
    fail('Unable to retrieve last build filename for MDS_PERF_VERSION_2') if (e.to_s.empty?)
  end

  path_config_perf='C:\MDS_config\MDS_perf\\'+ENV['MDS_PERF_VERSION'].to_s.chomp('.tar.gz')
  path_config_perf_2='C:\MDS_config\MDS_perf\\'+ENV['MDS_PERF_VERSION_2'].to_s.chomp('.tar.gz')

  res = Actions.WINCMD('IF exist '+path_config_perf+'\ ( echo Dir exists ) ELSE ( echo Dir DOES NOT exist )', 20, 'Dir')
  if res.to_s.strip.include?('Dir exists')
    # Actions.WINCMD('copy /Y '+path_config_perf+'\\'+'*.*'+' '+Dir.getwd.gsub('/', '\\')+'\templates\mds_config_perf', 20, 'file')
    Actions.WINCMD('xcopy /E /Y '+path_config_perf+'\\'+'*.*'+' '+Dir.getwd.gsub('/', '\\')+'\templates\mds_config_perf', 20, 'file')
  else
    fail('Error: config directory "'+path_config_perf+'" not found')
  end
  res = Actions.WINCMD('IF exist '+path_config_perf_2+'\ ( echo Dir exists ) ELSE ( echo Dir DOES NOT exist )', 20, 'Dir')
  if res.to_s.strip.include?('Dir exists')
    # Actions.WINCMD('copy /Y '+path_config_perf_2+'\\'+'*.*'+' '+Dir.getwd.gsub('/', '\\')+'\templates\mds_config_perf_2', 20, 'file')
    Actions.WINCMD('xcopy /E /Y '+path_config_perf_2+'\\'+'*.*'+' '+Dir.getwd.gsub('/', '\\')+'\templates\mds_config_perf_2', 20, 'file')
  else
    fail('Error: config directory "'+path_config_perf_2+'" not found')
  end

  if ENV['DEPLOY_MDS'] == 'true'
    deployMdsVersionThread(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'], ENV['MDS_PERF_VERSION'], 'MDS_perf')
  end

  if ENV['DEPLOY_MDS_2'] == 'true'
    deployMdsVersionThread(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'], ENV['MDS_PERF_VERSION_2'], 'MDS_perf_2')
  end
  # fail('Deploying MDS failed for '+ENV['MDS_PERF_HOST_USER']+'@'+ENV['MDS_PERF_HOST_IP']) if(t1.status.nil?)
  # fail('Deploying MDS failed for '+ENV['MDS_PERF_HOST_USER_2']+'@'+ENV['MDS_PERF_HOST_IP_2']) if(t2.status.nil?)

  Actions.killArbStreamerPerUser(ENV['MDS_LFR_HOST_IP'], ENV['MDS_LFR_HOST_USER'], ENV['MDS_LFR_HOST_PWD'])
  Actions.killArbStreamerPerUser(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'])
  Actions.killArbStreamerPerUser(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'])
  Actions.killArbStreamerPerUser(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
  Actions.killArbStreamerPerUser(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'])

  threads = []
  t1=Thread.new{ launchMdsThread(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'], Dir.getwd+'/templates/mds_config_perf', ENV['ConnectToSdata']) }
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new{ launchMdsThread(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'], Dir.getwd+'/templates/mds_config_perf_2', ENV['ConnectToSdata_2']) }
  t2.abort_on_exception = true
  threads << t2

  t1.join
  t2.join
  ThreadsWait.all_waits(*threads )

  fail('Launching MDS failed for '+ENV['MDS_PERF_HOST_USER']+'@'+ENV['MDS_PERF_HOST_IP']) if(t1.status.nil?)
  fail('Launching MDS failed for '+ENV['MDS_PERF_HOST_USER_2']+'@'+ENV['MDS_PERF_HOST_IP_2']) if(t2.status.nil?)

  #TODO: temporary removing archiving logs from crontab, otherwise there is no enough time to concatenate files from perf logs and to archive them
  cmd = 'crontab -l | grep -v logs_backup.sh  | crontab -'
  res = Actions.SSH_NO_FAIL(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'], cmd, 20)
  res = Actions.SSH_NO_FAIL(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'], cmd, 20)
end


Given /^version of MDS is optionally deployed, then MSL loader tool is optionally launched and then MDS is launched$/ do
  host = ENV['MDS_PERF_HOST_IP']
  user = ENV['MDS_PERF_HOST_USER']
  pwd = ENV['MDS_PERF_HOST_PWD']

  if ENV['DEPLOY_MDS'] == 'true'
    fail('Please define MOUNT_HOST') if ENV['MOUNT_HOST'].to_s.empty?
    fail('Please define MOUNT_USER') if ENV['MOUNT_USER'].to_s.empty?
    fail('Please define MOUNT_PWD') if ENV['MOUNT_PWD'].to_s.empty?

    begin
      if (ENV['MDS_PERF_VERSION'].nil? || ENV['MDS_PERF_VERSION'].to_s.empty?)
        storagePath = '/export/home/'+ENV['MOUNT_USER']+'/build_server/Releases/MDS'
        tarFilter1 = 'MDS_FULL_'
        tarFilter2 = '.tar.gz'
        cmd = 'cd '+storagePath+' && find * -type f -printf \'%T@ %p\n\' | egrep '+tarFilter1+' | egrep '+tarFilter2+' | sort -n | tail -1 | cut -f2- -d" "|cut -d $\'/\' -f 2'
        res = Actions.SSH(ENV['MOUNT_HOST'], ENV['MOUNT_USER'], ENV['MOUNT_PWD'], cmd, 45, true, '')
        ENV['MDS_PERF_VERSION'] = res.to_s.strip
        @@CONFIG['MDS_PERF_VERSION'] = ENV['MDS_PERF_VERSION']
      end
    rescue Exception => e
      fail('Unable to retrieve last build filename for MDS_PERF_VERSION: '+e.to_s) if (!e.nil? || !e.to_s.empty?)
      fail('Unable to retrieve last build filename for MDS_PERF_VERSION') if (e.to_s.empty?)
    end

    begin
      perf_version=ENV['MDS_PERF_VERSION'].nil? || ENV['MDS_PERF_VERSION'].to_s.strip.empty? ? '' : ENV['MDS_PERF_VERSION'].to_s.strip
      buildMDSforCustomVersion2(host, user, pwd, perf_version)
    rescue Exception => e
      errMsg = e.message.empty? ? '' : e.message
      errMsg = 'Error: MDS installation failed for '+user+'@'+host+' '+errMsg
      @@scenario_fails.push(errMsg)
      fail(errMsg)
    end
  end

  begin
    if ENV['USE_MSL_LOADER'] == 'true'
      fail('Please define MSL_LOADER_PATH') if ENV['MSL_LOADER_PATH'].to_s.empty?
      fail('Please define MSL_LOADER_ARB_LOG_PATH') if ENV['MSL_LOADER_ARB_LOG_PATH'].to_s.empty?
      fail('Please define MSL_IP') if ENV['MSL_IP'].to_s.empty?
      fail('Please define MSL_LOADER_START_TIME') if ENV['MSL_LOADER_START_TIME'].to_s.empty?
      fail('Please define MSL_LOADER_STOP_TIME') if ENV['MSL_LOADER_STOP_TIME'].to_s.empty?

      host_mds = ENV['MDS_PERF_HOST_IP']
      user_mds = ENV['MDS_PERF_HOST_USER']
      pwd_mds = ENV['MDS_PERF_HOST_PWD']

      Actions.v 'Killing MSL loader processes at '+user_mds+'@'+host_mds
      cmd = 'kill -9 $(/bin/ps -ef -U '+user_mds+" | grep app.MslLoader | awk '{print $2}')"
      res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 15, true, '')

      Actions.cleanupMslCustom2(ENV['MSL_IP'], 'msl', 'msl1', 'Automation')
    end
  rescue Exception => e
    fail('Cleaning MSL '+ENV['MSL_IP']+' failed for '+user_mds+'@'+host_mds)+' '+e.message
  end

  begin
    if ENV['USE_MSL_LOADER'] == 'true'
      fail('Please define MSL_LOADER_PATH') if ENV['MSL_LOADER_PATH'].to_s.empty?
      fail('Please define MSL_LOADER_ARB_LOG_PATH') if ENV['MSL_LOADER_ARB_LOG_PATH'].to_s.empty?
      fail('Please define MSL_IP') if ENV['MSL_IP'].to_s.empty?
      fail('Please define MSL_LOADER_START_TIME') if ENV['MSL_LOADER_START_TIME'].to_s.empty?
      fail('Please define MSL_LOADER_STOP_TIME') if ENV['MSL_LOADER_STOP_TIME'].to_s.empty?

      # Actions.v 'Killing MSL loader processes at '+user_mds+'@'+host_mds
      # cmd = 'kill -9 $(/bin/ps -ef -U '+user_mds+" | grep app.MslLoader | awk '{print $2}')"
      # res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 15, true, '')

      res = runMSLloader(host_mds, user_mds, pwd_mds, ENV['MSL_LOADER_PATH'], ENV['MSL_LOADER_ARB_LOG_PATH'], ENV['MSL_IP'], ENV['MSL_LOADER_START_TIME'], ENV['MSL_LOADER_STOP_TIME'])
      Actions.v 'Res of starting MSL loader:'+"\n"+res.to_s if (!res.to_s.strip.empty?)
    end
  rescue Exception => e
    fail('Launching MSL loader tool failed for '+user_mds+'@'+host_mds)+' '+e.message
  end

  #------Renaming original config templates dir---------
  cmd = 'mv ~/MDS/config ~/MDS/config_orig_$(date +%Y-%m-%d_%H-%M-%S-%3N) && mkdir -p ~/MDS/config'
  res = Actions.SSH(host, user, pwd, cmd, 25, true, '')

  #------Uploading config templates---------
  mdsConfigSource = Dir.getwd+'/templates/mds_config_perf'
  mdsConfigDest = CONFIG.get['REMOTE_HOME']+'/'+user+'/MDS/config'
  Actions.v 'Uploading config templates for '+user+'@'+host
  begin
    uploadDirToRemoteFolder(host, user, pwd, mdsConfigSource, mdsConfigDest)
  rescue Exception=>e
    @@scenario_fails.push('Error while uploading config templates directory to '+mdsConfigDest+' at '+host+':'+user)
    fail('Error while uploading config templates directory to '+mdsConfigDest+' at '+host+':'+user+' '+e.message)
  end

  #------Preparing MDS files for launching---------
  mdsPath=CONFIG.get['REMOTE_HOME']+'/'+user+'/MDS/bin'
  cmd = 'chmod -R 755 '+mdsPath
  res = Actions.SSH(host, user, pwd, cmd, 25, true, '')

  #------Running MDS---------
  res = runMDS(host, user, pwd, mdsPath)
  Actions.v 'Res of starting MDS:'+"\n"+res.to_s
end


Given /^2 MDS clients are launched and output is gathered$/ do
  threads = []
  t1=Thread.new{launchMdsClientForOldVersionThread()}
  t1.abort_on_exception = true
  threads << t1

  t2=Thread.new{launchMdsClientForNewVersionThread()}
  t2.abort_on_exception = true
  t1.join
  threads << t2
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('Launching MDS old version client failed for '+ENV['MDS_HOST_USER_OLD']+'@'+ENV['MDS_HOST_IP_OLD']) if(t1.status.nil?)
  fail('Launching MDS new version client failed for '+ENV['MDS_HOST_USER_NEW']+'@'+ENV['MDS_HOST_IP_NEW']) if(t2.status.nil?)

  if ENV['USE_MSL_LOADER']
    fail('Please define MSL_LOADER_PATH') if ENV['MSL_LOADER_PATH'].to_s.empty?
    fail('Please define MSL_LOADER_ARB_LOG_PATH') if ENV['MSL_LOADER_ARB_LOG_PATH'].to_s.empty?
    fail('Please define MSL_IP') if ENV['MSL_IP'].to_s.empty?
    fail('Please define MSL_LOADER_START_TIME') if ENV['MSL_LOADER_START_TIME'].to_s.empty?
    fail('Please define MSL_LOADER_STOP_TIME') if ENV['MSL_LOADER_STOP_TIME'].to_s.empty?

    Actions.cleanupMslCustom2(ENV['MSL_IP'], 'msl', 'msl1', 'Automation')

    Actions.v 'Killing MSL loader processes at '+ENV['MDS_HOST_USER_OLD']+'@'+ENV['MDS_HOST_IP_OLD']
    cmd = 'kill -9 $(/bin/ps -ef -U '+ENV['MDS_HOST_USER_OLD']+" | grep app.MslLoader | awk '{print $2}')"
    res = Actions.SSH(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], cmd, 15, true, '')

  # res = runMSLloader(ENV['MSL_LOADER_HOST'], ENV['MSL_LOADER_USER'], ENV['MSL_LOADER_PWD'], ENV['MSL_LOADER_PATH'], ENV['MSL_LOADER_ARB_LOG_PATH'], ENV['MSL_IP'], ENV['MSL_LOADER_START_TIME'], ENV['MSL_LOADER_STOP_TIME'])
    res = runMSLloader(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], ENV['MSL_LOADER_PATH'], ENV['MSL_LOADER_ARB_LOG_PATH'], ENV['MSL_IP'], ENV['MSL_LOADER_START_TIME'], ENV['MSL_LOADER_STOP_TIME'])
    Actions.v 'Res of starting MSL loader:'+"\n"+res.to_s if (!res.to_s.strip.empty?)
  end

  threads = []
  t1=Thread.new{stopMdsForOldVersionThread()}
  t1.abort_on_exception = true
  threads << t1

  t2=Thread.new{stopMdsForNewVersionThread()}
  t2.abort_on_exception = true
  t1.join
  threads << t2
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('Stopping MDS old version & gathering output failed for '+ENV['MDS_HOST_USER_OLD']+'@'+ENV['MDS_HOST_IP_OLD']) if(t1.status.nil?)
  fail('Stopping MDS new version & gathering output failed for '+ENV['MDS_HOST_USER_NEW']+'@'+ENV['MDS_HOST_IP_NEW']) if(t2.status.nil?)
end


Given /^6 MDS clients are launched and output is gathered$/ do
  threads = []
  t1=Thread.new{launchMdsClientForCustomVersionThread(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], ENV['MDS_HOST_IP_OLD'])}
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new{launchMdsClientForCustomVersionThread(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], ENV['MDS_HOST_IP_NEW'])}
  t2.abort_on_exception = true
  threads << t2
  t3=Thread.new{launchMdsClientForCustomVersionThread(ENV['MDS_CLIENT_3_HOST'], ENV['MDS_CLIENT_3_USER'], ENV['MDS_CLIENT_3_PWD'], ENV['MDS_HOST_IP_OLD'])}
  t3.abort_on_exception = true
  threads << t3
  t4=Thread.new{launchMdsClientForCustomVersionThread(ENV['MDS_CLIENT_3_HOST'], ENV['MDS_CLIENT_3_USER_2'], ENV['MDS_CLIENT_3_PWD_2'], ENV['MDS_HOST_IP_NEW'])}
  t4.abort_on_exception = true
  threads << t4
  t5=Thread.new{launchMdsClientForCustomVersionThread(ENV['MDS_CLIENT_4_HOST'], ENV['MDS_CLIENT_4_USER'], ENV['MDS_CLIENT_4_PWD'], ENV['MDS_HOST_IP_OLD'])}
  t5.abort_on_exception = true
  threads << t5
  t6=Thread.new{launchMdsClientForCustomVersionThread(ENV['MDS_CLIENT_4_HOST'], ENV['MDS_CLIENT_4_USER_2'], ENV['MDS_CLIENT_4_PWD_2'], ENV['MDS_HOST_IP_NEW'])}
  t6.abort_on_exception = true
  threads << t6

  t1.join
  t2.join
  t3.join
  t4.join
  t5.join
  t6.join
  ThreadsWait.all_waits(*threads )

  fail('Launching MDS old version client failed for '+ENV['MDS_HOST_USER_OLD']+'@'+ENV['MDS_HOST_IP_OLD']) if(t1.status.nil?)
  fail('Launching MDS new version client failed for '+ENV['MDS_HOST_USER_NEW']+'@'+ENV['MDS_HOST_IP_NEW']) if(t2.status.nil?)
  fail('Launching MDS old version client failed for '+ENV['MDS_CLIENT_3_USER']+'@'+ENV['MDS_CLIENT_3_HOST']) if(t3.status.nil?)
  fail('Launching MDS new version client failed for '+ENV['MDS_CLIENT_3_USER_2']+'@'+ENV['MDS_CLIENT_3_HOST']) if(t4.status.nil?)
  fail('Launching MDS old version client failed for '+ENV['MDS_CLIENT_4_USER']+'@'+ENV['MDS_CLIENT_4_HOST']) if(t5.status.nil?)
  fail('Launching MDS new version client failed for '+ENV['MDS_CLIENT_4_USER_2']+'@'+ENV['MDS_CLIENT_4_HOST']) if(t6.status.nil?)

  timestamp = Actions.timeCurrent
  Actions.c timestamp+' -- Waiting '+ENV['MDS_WAIT_TIME'].to_s+' seconds for MDS to work'
  sleep ENV['MDS_WAIT_TIME'].to_i

  threads = []
  t1=Thread.new{stopMdsForCustomVersionThread(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'])}
  t1.abort_on_exception = true
  threads << t1

  t2=Thread.new{stopMdsForCustomVersionThread(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'])}
  t2.abort_on_exception = true
  threads << t2

  t1.join
  t2.join
  ThreadsWait.all_waits(*threads )

  Actions.c 'Old version output:'
  localDirMdsOld = Dir.getwd+'/logs/logs_'+@@time_stamp+'/mds_old'
  remoteDir = CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_NEW']+'/Automation/logs_telnet_expect'
  outputLog = Actions.getOneFileByRegexpOrFail(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], remoteDir, 'telnet_output_'+ENV['MDS_HOST_IP_NEW']+'_'+ENV['MDS_HOST_IP_OLD']+'*.log')
  downloadFileFromRemoteAndDisplayLink(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], remoteDir, localDirMdsOld, outputLog)

  remoteDir = CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_CLIENT_3_USER']+'/Automation/logs_telnet_expect'
  outputLog = Actions.getOneFileByRegexpOrFail(ENV['MDS_CLIENT_3_HOST'], ENV['MDS_CLIENT_3_USER'], ENV['MDS_CLIENT_3_PWD'], remoteDir, 'telnet_output_'+ENV['MDS_CLIENT_3_HOST']+'_'+ENV['MDS_HOST_IP_OLD']+'*.log')
  downloadFileFromRemoteAndDisplayLink(ENV['MDS_CLIENT_3_HOST'], ENV['MDS_CLIENT_3_USER'], ENV['MDS_CLIENT_3_PWD'], remoteDir, localDirMdsOld, outputLog)

  remoteDir = CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_CLIENT_4_USER']+'/Automation/logs_telnet_expect'
  outputLog = Actions.getOneFileByRegexpOrFail(ENV['MDS_CLIENT_4_HOST'], ENV['MDS_CLIENT_4_USER'], ENV['MDS_CLIENT_4_PWD'], remoteDir, 'telnet_output_'+ENV['MDS_CLIENT_4_HOST']+'_'+ENV['MDS_HOST_IP_OLD']+'*.log')
  downloadFileFromRemoteAndDisplayLink(ENV['MDS_CLIENT_4_HOST'], ENV['MDS_CLIENT_4_USER'], ENV['MDS_CLIENT_4_PWD'], remoteDir, localDirMdsOld, outputLog)

  Actions.c 'New version output:'
  localDirMdsNew = Dir.getwd+'/logs/logs_'+@@time_stamp+'/mds_new'
  remoteDir = CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_OLD']+'/Automation/logs_telnet_expect'
  outputLog = Actions.getOneFileByRegexpOrFail(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], remoteDir, 'telnet_output_'+ENV['MDS_HOST_IP_OLD']+'_'+ENV['MDS_HOST_IP_NEW']+'*.log')
  downloadFileFromRemoteAndDisplayLink(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], remoteDir, localDirMdsNew, outputLog)

  remoteDir = CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_CLIENT_3_USER_2']+'/Automation/logs_telnet_expect'
  outputLog = Actions.getOneFileByRegexpOrFail(ENV['MDS_CLIENT_3_HOST'], ENV['MDS_CLIENT_3_USER_2'], ENV['MDS_CLIENT_3_PWD_2'], remoteDir, 'telnet_output_'+ENV['MDS_CLIENT_3_HOST']+'_'+ENV['MDS_HOST_IP_NEW']+'*.log')
  downloadFileFromRemoteAndDisplayLink(ENV['MDS_CLIENT_3_HOST'], ENV['MDS_CLIENT_3_USER_2'], ENV['MDS_CLIENT_3_PWD_2'], remoteDir, localDirMdsNew, outputLog)

  remoteDir = CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_CLIENT_4_USER_2']+'/Automation/logs_telnet_expect'
  outputLog = Actions.getOneFileByRegexpOrFail(ENV['MDS_CLIENT_4_HOST'], ENV['MDS_CLIENT_4_USER_2'], ENV['MDS_CLIENT_4_PWD_2'], remoteDir, 'telnet_output_'+ENV['MDS_CLIENT_4_HOST']+'_'+ENV['MDS_HOST_IP_NEW']+'*.log')
  downloadFileFromRemoteAndDisplayLink(ENV['MDS_CLIENT_4_HOST'], ENV['MDS_CLIENT_4_USER_2'], ENV['MDS_CLIENT_4_PWD_2'], remoteDir, localDirMdsNew, outputLog)
end


Given /^MDS clients and launched, then MSL loader is optionally launched and the archived output is gathered$/ do
  fail('Please define MDS_CLIENTS_QUANTITY') if ENV['MDS_CLIENTS_QUANTITY'].to_s.empty?

  host = ENV['MDS_PERF_CLIENT_IP']
  user = ENV['MDS_PERF_CLIENT_USER']
  pwd = ENV['MDS_PERF_CLIENT_PWD']
  host_mds = ENV['MDS_PERF_HOST_IP']
  user_mds = ENV['MDS_PERF_HOST_USER']
  pwd_mds = ENV['MDS_PERF_HOST_PWD']
  automationPath = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation'
  mdsPath = CONFIG.get['REMOTE_HOME']+'/'+user_mds+'/MDS/bin'
  telnetLogsPath = 'logs_telnet_expect/'+@@time_stamp.to_s

  fail('Please define MDS_PERF_CLIENT_PORT') if ENV['MDS_PERF_CLIENT_PORT'].to_s.empty?
  Actions.removeOldFilesByQuantityRemoteBash(host, user, pwd, automationPath+'/logs_telnet_expect', '20')
  begin
    perfMdsPort = ENV['MDS_PERF_CLIENT_PORT']
    res = runMDSmultiClient(host, user, pwd, automationPath, ENV['MDS_PERF_HOST_IP'], perfMdsPort, ENV['MDS_CLIENTS_QUANTITY'], automationPath+'/'+telnetLogsPath)
    Actions.v 'Res of starting MDS clients:'+"\n"+res.to_s
  rescue Exception => e
    fail('Launching MDS clients failed for '+user+'@'+host)+' '+e.message
  end

  begin
    if ENV['USE_MSL_LOADER'] == 'true'
      fail('Please define MSL_LOADER_PATH') if ENV['MSL_LOADER_PATH'].to_s.empty?
      fail('Please define MSL_LOADER_ARB_LOG_PATH') if ENV['MSL_LOADER_ARB_LOG_PATH'].to_s.empty?
      fail('Please define MSL_IP') if ENV['MSL_IP'].to_s.empty?
      fail('Please define MSL_LOADER_START_TIME') if ENV['MSL_LOADER_START_TIME'].to_s.empty?
      fail('Please define MSL_LOADER_STOP_TIME') if ENV['MSL_LOADER_STOP_TIME'].to_s.empty?

      Actions.v 'Killing MSL loader processes at '+user_mds+'@'+host_mds
      cmd = 'kill -9 $(/bin/ps -ef -U '+user_mds+" | grep app.MslLoader | awk '{print $2}')"
      res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 15, true, '')

      res = runMSLloader(host_mds, user_mds, pwd_mds, ENV['MSL_LOADER_PATH'], ENV['MSL_LOADER_ARB_LOG_PATH'], ENV['MSL_IP'], ENV['MSL_LOADER_START_TIME'], ENV['MSL_LOADER_STOP_TIME'])
      Actions.v 'Res of starting MSL loader:'+"\n"+res.to_s if (!res.to_s.strip.empty?)
    end
  rescue Exception => e
    fail('Launching MSL loader tool failed for '+user_mds+'@'+host_mds)+' '+e.message
  end

  #------Stopping MDS---------
  fail('Please define MDS_WAIT_TIME') if ENV['MDS_WAIT_TIME'].to_s.empty?
  begin
    timestamp = Actions.timeCurrent
    Actions.c timestamp+' -- Waiting '+ENV['MDS_WAIT_TIME'].to_s+' seconds for MDS at '+user_mds+'@'+host_mds
    sleep ENV['MDS_WAIT_TIME'].to_i

    res = stopMDS(host_mds, user_mds, pwd_mds, mdsPath)
    Actions.v 'Res of stopping MDS for the old version:'+"\n"+res.to_s
  rescue Exception => e
    fail('Stopping MDS failed for '+user_mds+'@'+host_mds)+' '+e.message
  end

  #------Downloading archived clients and MDS output---------
  begin
    localDir = Dir.getwd+'/logs/logs_'+@@time_stamp+'/mds_perf'

    remoteDirMDSlogs = CONFIG.get['REMOTE_HOME']+'/'+user_mds+'/MDS/logs'
    remoteDirMDSlogsArchive = 'logs_MDS_'+@@time_stamp.to_s+'.zip'
    remoteDirMDSlogsArchiveRegexp = 'logs_MDS_'+@@time_stamp.to_s+'.*'
    # remoteDirMDSlogsArchivePath = remoteDirMDSlogs+'/'+remoteDirMDSlogsArchive

    cmd = 'cd '+remoteDirMDSlogs+' &&  ls -tr mds_perf* | xargs cat > MDS_PERF_general.csv'
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && sed -i '/mdsLatency/d' MDS_PERF_general.csv"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && cat MDS_PERF_general.csv | cut -d',' -f13,15,16 > mdsLatency.log"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && sed -i '/mdsLatency/d' mdsLatency.log"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    # cmd = 'cd '+remoteDirMDSlogs+" && find . -type f -name 'mds_perf*.csv' ! -name 'mds_perf_1.0.csv' -exec cat {} + > MDS_PERF_general_withoutFirst.csv"
    cmd = 'cd '+remoteDirMDSlogs+' && ls -tr mds_perf* | grep -v mds_perf_1.0.csv | xargs cat > MDS_PERF_general_withoutFirst.csv'
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && sed -i '/mdsLatency/d' MDS_PERF_general_withoutFirst.csv"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && cat MDS_PERF_general_withoutFirst.csv | cut -d',' -f13,15,16 > mdsLatency_withoutFirst.log"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && sed -i '/mdsLatency/d' mdsLatency_withoutFirst.log"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    # cmd = 'cd '+remoteDirMDSlogs+' && env GZIP=-9 tar cvzf '+remoteDirMDSlogsArchive+' *'
    cmd = 'cd '+remoteDirMDSlogs+' && zip -9 -s 100m '+remoteDirMDSlogsArchive+' *'
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 1500, true, '')
    Actions.v 'Res of archiving MDS logs: '+res.to_s.strip
    #TODO: archiving in bckgr, loop checking if there is .zip file

    filesMdsArr = Actions.getFilesArrayByRegexp(host_mds, user_mds, pwd_mds, remoteDirMDSlogs, remoteDirMDSlogsArchiveRegexp)
    Actions.v 'Found the following MDS logs archives: '+filesMdsArr.to_s
    filesMdsArr.each { |fileName| downloadFileFromRemoteWithoutTimestamp(host_mds, user_mds, pwd_mds, localDir, remoteDirMDSlogs, fileName) }

    Actions.c 'MDS output (listened to '+host_mds+' at '+host+':'+perfMdsPort+'):'
    Actions.displayFileLinkInReport(localDir+'/'+remoteDirMDSlogsArchive)

    remoteDirTelnetPerf = automationPath+'/'+telnetLogsPath
    remoteDirTelnetPerfArchive = 'logs_telnet_'+@@time_stamp.to_s+'.zip'
    remoteDirTelnetPerfArchiveRegexp = 'logs_telnet_'+@@time_stamp.to_s+'.*'
    # remoteDirTelnetPerfArchivePath = remoteDirTelnetPerf+'/'+remoteDirTelnetPerfArchive

    # cmd = 'cd '+remoteDirTelnetPerf+' && env GZIP=-9 tar cvzf '+remoteDirTelnetPerfArchive+' *'
    cmd = 'cd '+remoteDirTelnetPerf+' && zip -9 -s 100m '+remoteDirTelnetPerfArchive+' *'
    res = Actions.SSH(host, user, pwd, cmd, 1500, true, '')

    filesTelnetArr = Actions.getFilesArrayByRegexp(host, user, pwd, remoteDirTelnetPerf, remoteDirTelnetPerfArchiveRegexp)
    Actions.v 'Found the following telnet output archives: '+filesTelnetArr.to_s
    filesTelnetArr.each { |fileName| downloadFileFromRemoteWithoutTimestamp(host, user, pwd, localDir, remoteDirTelnetPerf, fileName) }

    Actions.c 'Telnet logs from client machine:'
    Actions.displayFileLinkInReport(localDir+'/'+remoteDirTelnetPerfArchive)

    mslLoaderLog = 'mslLoader_output_'+host_mds+'_'+ENV['MSL_IP']+'.log'
    mslLoaderLogPath = CONFIG.get['REMOTE_HOME']+'/'+user_mds+'/MDS_tools/arbLogsPlaying/MslLoader/bin/logs_msl_loader'
    downloadFileFromRemoteWithoutTimestamp(host_mds, user_mds, pwd_mds, localDir, mslLoaderLogPath, mslLoaderLog)
    Actions.c 'MSL loader output:'
    Actions.displayFileLinkInReport(localDir+'/'+mslLoaderLog)
  rescue Exception => e
    fail('Gathering output failed for '+user+'@'+host)+' '+e.message
  end
end


def launchMdsClientsThread(host, user, pwd, host_mds, mdsClientsQuantity, mdsPerfClientPort)
  automationPath = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation'
  telnetLogsPath = 'logs_telnet_expect/'+@@time_stamp.to_s

  Actions.removeOldFilesByQuantityRemoteBash(host, user, pwd, automationPath+'/logs_telnet_expect', '20')
  begin
    perfMdsPort = mdsPerfClientPort
    res = runMDSmultiClient(host, user, pwd, automationPath, host_mds, perfMdsPort, mdsClientsQuantity, automationPath+'/'+telnetLogsPath)
    Actions.v 'Res of starting MDS clients:'+"\n"+res.to_s
  rescue Exception => e
    fail('Launching MDS clients failed for '+user+'@'+host)+' '+e.message
  end

  sleep 120

  cmd = 'ps -aef|grep -v grep|grep telnet|wc -l'
  res = Actions.SSH(host, user, pwd, cmd, 15, true, '')
  if res.to_s.strip != mdsClientsQuantity.to_s
    @@scenario_fails.push('Launching the necessary quantity of MDS clients failed for '+user+'@'+host+', found '+res.to_s.strip+' processes instead of '+mdsClientsQuantity.to_s)
    fail('Launching the necessary quantity of MDS clients failed for '+user+'@'+host+', found '+res.to_s.strip+' processes instead of '+mdsClientsQuantity.to_s)
  else
    timestamp = Actions.timeCurrent
    Actions.c timestamp+' -- Found correct quantity of MDS clients connections ('+res.to_s.strip+') at '+user+'@'+host
  end

  telnProcCounterScript = 'telnConnCount.sh'
  telnProcCounterScriptPath = '/export/home/'+user+'/Automation'
  Actions.uploadTemplates2(host, user, pwd, Dir.getwd+'/templates/bash/'+telnProcCounterScript, telnProcCounterScriptPath+'/'+telnProcCounterScript, 20)
  Actions.rigthsForFile(host, user, pwd, telnProcCounterScriptPath, telnProcCounterScript, '755')
  cmd = 'nohup '+telnProcCounterScriptPath+'/'+telnProcCounterScript+' '+mdsClientsQuantity.to_s+' &'
  # res = Actions.SSH(host, user, pwd, cmd, 15, true, '')
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 15)
  Actions.v 'Telnet processes counter is launched:'+"\n"+res.to_s.strip
end


def launchMslLoaderThread(host, user, pwd, mslLoaderPath, mslLoaderArbLogPath, mslIP, mslLoaderStartTime, mslLoaderStopTime)
  begin
      Actions.v 'Killing MSL loader processes at '+user+'@'+host
      cmd = 'kill -9 $(/bin/ps -ef -U '+user+" | grep app.MslLoader | awk '{print $2}')"
      res = Actions.SSH(host, user, pwd, cmd, 15, true, '')

      res = runMSLloader(host, user, pwd, mslLoaderPath, mslLoaderArbLogPath, mslIP, mslLoaderStartTime, mslLoaderStopTime)
      Actions.v 'Res of starting MSL loader:'+"\n"+res.to_s if (!res.to_s.strip.empty?)
  rescue Exception => e
    fail('Launching MSL loader tool failed for '+user+'@'+host)+' '+e.message
  end
end


def stopMdsThread(host, user, pwd)
  Actions.v '#started stopMdsThread('+host+', '+user+', '+pwd+')'
  mdsPath = CONFIG.get['REMOTE_HOME']+'/'+user+'/MDS/bin'
  begin
    res = stopMDS(host, user, pwd, mdsPath)
    Actions.v 'Res of stopping MDS at '+user+'@'+host+":\n"+res.to_s
  rescue Exception => e
    fail('Stopping MDS failed for '+user+'@'+host)+' '+e.message
  end
end


def gatherMdsHostAndClientOutputThread(host_mds, user_mds, pwd_mds, host_client, user_client, pwd_client, mdsPackageName, gatherMslLoaderOutput=false)
  Actions.v '#started gatherMdsHostAndClientOutputThread('+host_mds+', '+user_mds+', '+pwd_mds+', '+host_client+', '+user_client+', '+pwd_client+', '+mdsPackageName+', '+gatherMslLoaderOutput.to_s+')'
  begin
    localDir = Dir.getwd+'/logs/logs_'+@@time_stamp+'/mds_perf'
    automationPathClient = CONFIG.get['REMOTE_HOME']+'/'+user_client+'/Automation'
    telnetLogsPath = 'logs_telnet_expect/'+@@time_stamp.to_s

    #TODO: temporary condition
    remoteDirMDSlogs = ''
    if mdsPackageName.to_s.gsub('MDS_FULL_MAIN_', '').gsub('.tar.gz', '').gsub(/.*?(?=_)/im, '').gsub('_b', '').to_i >= 238
      remoteDirMDSlogs = CONFIG.get['REMOTE_HOME']+'/'+user_mds+'/MDS/logs/previous'
    else
      remoteDirMDSlogs = CONFIG.get['REMOTE_HOME']+'/'+user_mds+'/MDS/logs'
    end
    remoteDirMDSlogsArchive = 'logs_MDS_'+@@time_stamp.to_s+'.zip'
    remoteDirMDSlogsArchiveRegexp = 'logs_MDS_'+@@time_stamp.to_s+'.*'
    # remoteDirMDSlogsArchivePath = remoteDirMDSlogs+'/'+remoteDirMDSlogsArchive

    cmd = 'cd '+remoteDirMDSlogs+' &&  ls -tr mds_perf* | xargs cat > MDS_PERF_general.csv'
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && sed -i '/mdsLatency/d' MDS_PERF_general.csv"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && cat MDS_PERF_general.csv | cut -d',' -f13,15,16 > mdsLatency.log"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && sed -i '/mdsLatency/d' mdsLatency.log"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    # cmd = 'cd '+remoteDirMDSlogs+" && find . -type f -name 'mds_perf*.csv' ! -name 'mds_perf_1.0.csv' -exec cat {} + > MDS_PERF_general_withoutFirst.csv"
    # cmd = 'cd '+remoteDirMDSlogs+' && cp -f previous/* .'
    # res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 60, true, '')

    cmd = 'cd '+remoteDirMDSlogs+' && ls -tr mds_perf* | head -n1'
    firstPerfLogName = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 20, true, '')

    cmd = 'cd '+remoteDirMDSlogs+' && ls -tr mds_perf* | grep -v '+firstPerfLogName.to_s.strip+' | xargs cat > MDS_PERF_general_withoutFirst.csv'
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && sed -i '/mdsLatency/d' MDS_PERF_general_withoutFirst.csv"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && cat MDS_PERF_general_withoutFirst.csv | cut -d',' -f13,15,16 > mdsLatency_withoutFirst.log"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 360, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && sed -i '/mdsLatency/d' mdsLatency_withoutFirst.log"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    user_mds_root = 'root'
    pwd_mds_root = '123456'
    graphOverall = 'graph.py'
    graphOverallImg = 'mdsLatency_overall.png'
    graphWithoutFirst = 'graphWithoutFirst.py'
    graphWithoutFirstImg = 'mdsLatency_withoutFirst.png'
    Actions.uploadTemplates2(host_mds, user_mds_root, pwd_mds_root, Dir.getwd+'/templates/mds_utilities_new/'+graphOverall, remoteDirMDSlogs+'/'+graphOverall, 20)
    Actions.uploadTemplates2(host_mds, user_mds_root, pwd_mds_root, Dir.getwd+'/templates/mds_utilities_new/'+graphWithoutFirst, remoteDirMDSlogs+'/'+graphWithoutFirst, 20)
    Actions.rigthsForFile(host_mds, user_mds_root, pwd_mds_root, remoteDirMDSlogs, graphOverall, '755')
    Actions.rigthsForFile(host_mds, user_mds_root, pwd_mds_root, remoteDirMDSlogs, graphWithoutFirst, '755')
    cmd = 'cd '+remoteDirMDSlogs+' && python '+graphOverall
    res = Actions.SSH(host_mds, user_mds_root, pwd_mds_root, cmd, 900, false, '')

    imgMdsLatencyOverall = 'mdsLatency_overall_'+mdsPackageName.gsub('MDS_FULL_MAIN_', '').gsub('.tar.gz', '')+'_'+host_mds+'.png'
    imgMdsLatencyWithoutFirst = 'mdsLatency_withoutFirst_'+mdsPackageName.gsub('MDS_FULL_MAIN_', '').gsub('.tar.gz', '')+'_'+host_mds+'.png'
    cmd = 'cd '+remoteDirMDSlogs+' && chown '+user_mds+':'+user_mds+' '+graphOverallImg+' && mv '+graphOverallImg+' '+imgMdsLatencyOverall
    res = Actions.SSH(host_mds, user_mds_root, pwd_mds_root, cmd, 30, false, '')
    cmd = 'cd '+remoteDirMDSlogs+' && python '+graphWithoutFirst
    res = Actions.SSH(host_mds, user_mds_root, pwd_mds_root, cmd, 900, false, '')
    cmd = 'cd '+remoteDirMDSlogs+' && chown '+user_mds+':'+user_mds+' '+graphWithoutFirstImg+' && mv '+graphWithoutFirstImg+' '+imgMdsLatencyWithoutFirst
    res = Actions.SSH(host_mds, user_mds_root, pwd_mds_root, cmd, 30, false, '')
    cmd = 'cd '+remoteDirMDSlogs+' && rm -f '+graphOverall+' && rm -f '+graphWithoutFirst
    res = Actions.SSH(host_mds, user_mds_root, pwd_mds_root, cmd, 30, true, '')

    # cmd = 'cd '+remoteDirMDSlogs+' && env GZIP=-9 tar cvzf '+remoteDirMDSlogsArchive+' *'
    cmd = 'cd '+remoteDirMDSlogs+' && zip -9 -s 100m '+remoteDirMDSlogsArchive+' *'
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 1500, true, '')
    Actions.v 'Res of archiving MDS logs: '+res.to_s.strip
    #TODO: archiving in bckgr, loop checking if there is .zip file ?

    filesMdsArr = Actions.getFilesArrayByRegexp(host_mds, user_mds, pwd_mds, remoteDirMDSlogs, remoteDirMDSlogsArchiveRegexp)
    Actions.v 'Found the following MDS logs archives: '+filesMdsArr.to_s
    # filesMdsArr.each { |fileName| downloadFileFromRemoteWithoutTimestamp(host_mds, user_mds, pwd_mds, localDir, remoteDirMDSlogs, fileName) }

    Actions.c 'MDS output from host machine ('+host_mds+'):'
    # Actions.displayFileLinkInReport(localDir+'/'+remoteDirMDSlogsArchive)
    Actions.c '<b>'+remoteDirMDSlogs.to_s+'</b>'
    # filesMdsArr.each { |fileName| Actions.c '<b>'+fileName.to_s.strip+'</b>'+"\n" }

=begin
    begin
      mdsClientsFilesDir = '/export/home/'+user_client+'/Automation/logs_telnet_expect'
      mdsClientsFilesDirName = Actions.getNewestFileByRegexp(host_client, user_client, pwd_client, mdsClientsFilesDir, '')
      mdsClientsFilesDir = mdsClientsFilesDir+'/'+mdsClientsFilesDirName
      Actions.checkMdsClientsSeqNumFilesInDir(host_client, user_client, pwd_client, mdsClientsFilesDir)
    rescue Exception => e
      fail('Checking MDS clients files failed for '+user_client+'@'+host_client+':'+mdsClientsFilesDir)+' '+e.message
    end
=end

    remoteDirTelnetPerf = automationPathClient+'/'+telnetLogsPath
    remoteDirTelnetPerfArchive = 'logs_telnet_'+@@time_stamp.to_s+'.zip'
    remoteDirTelnetPerfArchiveRegexp = 'logs_telnet_'+@@time_stamp.to_s+'.*'
    # remoteDirTelnetPerfArchivePath = remoteDirTelnetPerf+'/'+remoteDirTelnetPerfArchive

    # cmd = 'cd '+remoteDirTelnetPerf+' && env GZIP=-9 tar cvzf '+remoteDirTelnetPerfArchive+' *'
    cmd = 'cd '+remoteDirTelnetPerf+' && zip -9 -s 100m '+remoteDirTelnetPerfArchive+' *'
    res = Actions.SSH(host_client, user_client, pwd_client, cmd, 1500, true, '')

    filesTelnetArr = Actions.getFilesArrayByRegexp(host_client, user_client, pwd_client, remoteDirTelnetPerf, remoteDirTelnetPerfArchiveRegexp)
    Actions.v 'Found the following telnet output archives: '+filesTelnetArr.to_s
    # filesTelnetArr.each { |fileName| downloadFileFromRemoteWithoutTimestamp(host_client, user_client, pwd_client, localDir, remoteDirTelnetPerf, fileName) }

    Actions.c 'Telnet logs from client machine ('+host_client+'):'
    # Actions.displayFileLinkInReport(localDir+'/'+remoteDirTelnetPerfArchive)
    Actions.c '<b>'+remoteDirTelnetPerf.to_s+'</b>'
    # filesTelnetArr.each { |fileName| Actions.c '<b>'+fileName.to_s.strip+'</b>'+"\n" }

    telnCountLog = 'telnet_count_'+host_client+'_*.log'
    telnCountLogPath = CONFIG.get['REMOTE_HOME']+'/'+user_client+'/Automation/logs_telnet_count'
    telnCountLog = Actions.getNewestFileByRegexp(host_client, user_client, pwd_client, telnCountLogPath, telnCountLog)
    downloadFileFromRemoteWithoutTimestamp(host_client, user_client, pwd_client, localDir, telnCountLogPath, telnCountLog)
    if telnCountLog.to_s.empty?
      Actions.f 'Warning: no telnet processes counting log found at '+user_client+'@'+host_client
    else
      Actions.c 'Log below contains only incorrect quantity of telnet processes (other than given by parameters MDS_CLIENTS_QUANTITY and MDS_CLIENTS_QUANTITY_2): '
      Actions.displayFileLinkInReport(localDir+'/'+telnCountLog)
    end

    downloadFileFromRemoteWithoutTimestamp(host_mds, user_mds, pwd_mds, localDir, remoteDirMDSlogs, imgMdsLatencyOverall)
    Actions.c 'Graph of all performance values from '+user_mds+'@'+host_mds+':'
    Actions.displayFileLinkInReport(localDir+'/'+imgMdsLatencyOverall)
    downloadFileFromRemoteWithoutTimestamp(host_mds, user_mds, pwd_mds, localDir, remoteDirMDSlogs, imgMdsLatencyWithoutFirst)
    Actions.c 'Graph of performance values without beginning (without first performance log file) from '+user_mds+'@'+host_mds+':'
    Actions.displayFileLinkInReport(localDir+'/'+imgMdsLatencyWithoutFirst)

    if gatherMslLoaderOutput
      mslLoaderLog = 'mslLoader_output_'+ENV['MDS_MSL_LOADER_IP']+'_'+ENV['MSL_IP']+'.log'
      mslLoaderLogPath = CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_MSL_LOADER_USER']+'/MDS_tools/arbLogsPlaying/MslLoader/bin/logs_msl_loader'
      downloadFileFromRemoteWithoutTimestamp(ENV['MDS_MSL_LOADER_IP'], ENV['MDS_MSL_LOADER_USER'], ENV['MDS_MSL_LOADER_PWD'], localDir, mslLoaderLogPath, mslLoaderLog)
      Actions.c 'MSL loader output from '+ENV['MDS_MSL_LOADER_USER']+'@'+ENV['MDS_MSL_LOADER_IP']+':'
      Actions.displayFileLinkInReport(localDir+'/'+mslLoaderLog)
    end
  rescue Exception => e
    fail('Gathering output failed for '+user_client+'@'+host_client)+' '+e.message
  end
end


def checkMdsClientsFiles(host_client, user_client, pwd_client)
  Actions.v '#started checkMdsClientsFiles('+host_client+', '+user_client+', '+pwd_client+')'
  res_final = false
  begin
    mdsClientsFilesDir = '/export/home/'+user_client+'/Automation/logs_telnet_expect'
    mdsClientsFilesDirName = Actions.getNewestFileByRegexp(host_client, user_client, pwd_client, mdsClientsFilesDir, '')
    mdsClientsFilesDir = mdsClientsFilesDir+'/'+mdsClientsFilesDirName

    res_final = Actions.checkMdsClientsSeqNumFilesInDir(host_client, user_client, pwd_client, mdsClientsFilesDir)
  rescue Exception => e
    fail('Checking MDS clients files failed for '+user_client+'@'+host_client+':'+mdsClientsFilesDir)+' '+e.message
  end

  return res_final
end


def compareMdsClientsFiles(host_client_local, user_client_local, pwd_client_local, host_client_remote, user_client_remote, pwd_client_remote)
  Actions.v '#started compareMdsClientsFiles('+host_client_local+', '+user_client_local+', '+pwd_client_local+', '+host_client_remote+', '+user_client_remote+', '+pwd_client_remote+')'

  host = host_client_remote
  user = user_client_remote
  pwd = pwd_client_remote
  host2 = host_client_local
  user2 = user_client_local
  pwd2 = pwd_client_local
  mdsClientsFilesDir = ''
  mdsClientsFilesDirName = ''
  mdsClientsFilesDir2 = ''
  arr_local = []
  arr_remote = []
  clientLogsArchiveName = ''
  clientLogsDirName = ''

  begin
    mdsClientsFilesDir = '/export/home/'+user+'/Automation/logs_telnet_expect'
    mdsClientsFilesDirName = Actions.getNewestFileByRegexp(host, user, pwd, mdsClientsFilesDir, '')
    mdsClientsFilesDir = mdsClientsFilesDir+'/'+mdsClientsFilesDirName

    cmd = 'cd '+mdsClientsFilesDir+' && ls -tr telnet_output*.log'
    res = Actions.SSH(host, user, pwd, cmd, 30, true, '')
    arr_remote = res.split("\n")
  rescue Exception => e
    fail('Getting clients files list failed for '+user+'@'+host+':'+mdsClientsFilesDir)+' '+e.message
  end

  begin
    mdsClientsFilesDir2 = '/export/home/'+user2+'/Automation/logs_telnet_expect'
    mdsClientsFilesDirName2 = Actions.getNewestFileByRegexp(host2, user2, pwd2, mdsClientsFilesDir2, '')
    mdsClientsFilesDir2 = mdsClientsFilesDir2+'/'+mdsClientsFilesDirName2

    cmd = 'cd '+mdsClientsFilesDir2+' && ls -tr telnet_output*.log'
    res = Actions.SSH(host2, user2, pwd2, cmd, 30, true, '')
    arr_local = res.split("\n")
  rescue Exception => e
    fail('Getting clients files list failed for '+user2+'@'+host2+':'+mdsClientsFilesDir2)+' '+e.message
  end

  if arr_local.length.to_i != arr_remote.length.to_i
    Actions.f 'Found mismatch between quantities of clients xml output files:'+"\n"+arr_local.length.to_s+' files at '+user+'@'+host+':'+mdsClientsFilesDir+"\n"+arr_remote.length.to_s+' files at '+user2+'@'+host2+':'+mdsClientsFilesDir2
  else
    Actions.c 'No mismatches found between quantities of clients xml output files:'+"\n"+arr_local.length.to_s+' files at '+user+'@'+host+':'+mdsClientsFilesDir+"\n"+arr_remote.length.to_s+' files at '+user2+'@'+host2+':'+mdsClientsFilesDir2

    filesToArchive = 'telnet_output*.log'
    Actions.v '@@isCheckMdsClientsFilesSuccessful: '+@@isCheckMdsClientsFilesSuccessful.to_s
    Actions.v '@@isCheckMdsClientsFilesSuccessful2: '+@@isCheckMdsClientsFilesSuccessful2.to_s
    if @@isCheckMdsClientsFilesSuccessful && @@isCheckMdsClientsFilesSuccessful2
      arr_remote = arr_remote[0..0]
      arr_local = arr_local[0..0]
      filesToArchive = arr_remote[0].to_s
    end

    begin
      clientLogsArchiveName = 'copied_logs_telnet_expect_'+host+'_'+mdsClientsFilesDirName+'.tar.gz'
      clientLogsDirName = clientLogsArchiveName.chomp('.tar.gz')
      cmd = 'cd '+mdsClientsFilesDir+' && tar czf '+clientLogsArchiveName+' '+filesToArchive
      res = Actions.SSH(host, user, pwd, cmd, 300, true, '')
    rescue Exception => e
      fail('Archiving clients files failed for '+user+'@'+host+':'+mdsClientsFilesDir)+' '+e.message
    end

    begin
      scpScript = 'scpFileRemotely.sh'
      Actions.uploadTemplates2(host, user, pwd, Dir.getwd+'/templates/bash/'+scpScript, mdsClientsFilesDir+'/'+scpScript, 40)
      Actions.rigthsForFile(host, user, pwd, mdsClientsFilesDir, scpScript, '755')

      Actions.transferFileRemotely(scpScript, host, user, pwd, host2, user2, pwd2, mdsClientsFilesDir, mdsClientsFilesDir2, clientLogsArchiveName)
    rescue Exception => e
      fail('Copying clients files failed for '+user+'@'+host+':'+mdsClientsFilesDir)+' '+e.message
    end

    begin
      mdsClientsFilesDir2parent = '/export/home/'+user2+'/Automation/logs_telnet_expect'
      mdsClientsFilesDir2copied = mdsClientsFilesDir2parent+'/'+clientLogsDirName

      cmd = 'cd '+mdsClientsFilesDir2+' && mkdir -p '+mdsClientsFilesDir2copied+' && mv '+clientLogsArchiveName+' '+mdsClientsFilesDir2copied
      res = Actions.SSH(host2, user2, pwd2, cmd, 60, true, '')

      cmd = 'cd '+mdsClientsFilesDir2copied+' && tar xzf '+clientLogsArchiveName
      res = Actions.SSH(host2, user2, pwd2, cmd, 200, true, '')
    rescue Exception => e
      fail('Extracting clients files failed for '+user2+'@'+host2+':'+mdsClientsFilesDir2)+' '+e.message
    end

    counter = 0
    diffNotFound = false
    begin
      arr_local.zip(arr_remote).each do |file_local, file_remote|
        counter += 1
        Actions.v '### '+counter.to_s+'. Comparing '+mdsClientsFilesDir2+'/'+file_local+' and '+mdsClientsFilesDir2copied+'/'+file_remote+'...'
        cmd = 'cmp --silent '+mdsClientsFilesDir2+'/'+file_local+' '+mdsClientsFilesDir2copied+'/'+file_remote+' || echo "different" && echo "identical"'
        res = Actions.SSH(host2, user2, pwd2, cmd, 120, true, '')
        Actions.v 'res: '+res.to_s

        if res.to_s.strip == 'different'
          Actions.f 'Difference found between clients files '+mdsClientsFilesDir2+'/'+file_local+' and '+mdsClientsFilesDir2copied+'/'+file_remote
        else
          diffNotFound = true
        end
      end
      Actions.v 'diffNotFound: '+diffNotFound.to_s
      if diffNotFound
        Actions.c 'No differences found between clients xml output in '+mdsClientsFilesDir2+' and '+mdsClientsFilesDir2copied+' at '+user2+'@'+host2
      end
    rescue Exception => e
      fail('Comparing clients files failed at '+user2+'@'+host2+':'+mdsClientsFilesDir2+' vs. '+mdsClientsFilesDir2copied)+' '+e.message
    end
  end
end


Given /^MDS clients for 2 versions are launched, then MSL loader is optionally launched and the output is archived$/ do
  threads = []

  t1=Thread.new { launchMdsClientsThread(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'], ENV['MDS_PERF_HOST_IP'], ENV['MDS_CLIENTS_QUANTITY'], ENV['MDS_PERF_CLIENT_PORT']) }
  t1.abort_on_exception = true
  threads << t1

  t2=Thread.new { launchMdsClientsThread(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'], ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_CLIENTS_QUANTITY_2'], ENV['MDS_PERF_CLIENT_PORT_2']) }
  t2.abort_on_exception = true
  threads << t2

  t1.join
  t2.join
  ThreadsWait.all_waits(*threads )

  fail('Launching MDS clients failed for '+ENV['MDS_PERF_HOST_USER']+'@'+ENV['MDS_PERF_HOST_IP']) if(t1.status.nil?)
  fail('Launching MDS clients failed for '+ENV['MDS_PERF_HOST_USER_2']+'@'+ENV['MDS_PERF_HOST_IP_2']) if(t2.status.nil?)

  Actions.killMslLoaderPerUser(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'])
  Actions.killMslLoaderPerUser(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'])

  if ENV['USE_MSL_LOADER'] == 'true'
    launchMslLoaderThread(ENV['MDS_MSL_LOADER_IP'], ENV['MDS_MSL_LOADER_USER'], ENV['MDS_MSL_LOADER_PWD'], ENV['MSL_LOADER_PATH'], ENV['MSL_LOADER_ARB_LOG_PATH'], ENV['MSL_IP'], ENV['MSL_LOADER_START_TIME'], ENV['MSL_LOADER_STOP_TIME'])
  else
    Action.c 'Not launching MSL loader tool'
  end

  cmd = 'ps -aef|grep telnet|grep -v grep|wc -l'
  res = Actions.SSH(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'], cmd, 15, true, '')
  timestamp = Actions.timeCurrent
  if res.to_s.strip != ENV['MDS_CLIENTS_QUANTITY'].to_s
    Actions.f timestamp+' -- Found another quantity of MDS clients for '+ENV['MDS_PERF_CLIENT_USER']+'@'+ENV['MDS_PERF_CLIENT_IP']+': '+res.to_s.strip+' processes instead of '+ENV['MDS_CLIENTS_QUANTITY'].to_s
  end
  cmd = 'ps -aef|grep telnet|grep -v grep|wc -l'
  res = Actions.SSH(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'], cmd, 15, true, '')
  timestamp = Actions.timeCurrent
  if res.to_s.strip != ENV['MDS_CLIENTS_QUANTITY_2'].to_s
    Actions.f timestamp+' -- Found another quantity of MDS clients for '+ENV['MDS_PERF_CLIENT_USER_2']+'@'+ENV['MDS_PERF_CLIENT_IP_2']+': '+res.to_s.strip+' processes instead of '+ENV['MDS_CLIENTS_QUANTITY_2'].to_s
  end

  timestamp = Actions.timeCurrent
  if ENV['MSL_LOADER_WAIT_TIME'].to_s.empty?
    Actions.c timestamp+' -- Waiting '+ENV['MDS_WAIT_TIME'].to_s+' seconds for MDS to run'
    sleep ENV['MDS_WAIT_TIME'].to_i
  else
    Actions.c timestamp+' -- Waiting '+ENV['MSL_LOADER_WAIT_TIME'].to_s+' seconds for MSL loader to finish'
    stringToWait = 'End Time Reached: STOPPING...'
    stringToWait2 = 'Log Header READ Error: java.io.EOFException'
    stringToWait3 = 'THE END'
    Actions.waitForOutputInFile(ENV['MDS_MSL_LOADER_IP'], ENV['MDS_MSL_LOADER_USER'], ENV['MDS_MSL_LOADER_PWD'], ENV['MSL_LOADER_PATH']+'/logs_msl_loader/mslLoader_output_'+ENV['MDS_MSL_LOADER_IP']+'_'+ENV['MSL_IP']+'.log', stringToWait3, ENV['MSL_LOADER_WAIT_TIME'])

    #TODO: wait for the moment when a file stops changing its contents
    sleep 60
  end

  Actions.killTelnConnCountPerUser(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
  Actions.killTelnConnCountPerUser(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'])

  threads = []
  t1=Thread.new{ stopMdsThread(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD']) }
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new{ stopMdsThread(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2']) }
  t2.abort_on_exception = true
  threads << t2

  t1.join
  t2.join
  ThreadsWait.all_waits(*threads )

  fail('Stopping MDS failed for '+ENV['MDS_PERF_HOST_USER']+'@'+ENV['MDS_PERF_HOST_IP']) if(t1.status.nil?)
  fail('Stopping MDS failed for '+ENV['MDS_PERF_HOST_USER_2']+'@'+ENV['MDS_PERF_HOST_IP_2']) if(t2.status.nil?)

  threads = []
  t1=Thread.new{ gatherMdsHostAndClientOutputThread(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'], ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'], ENV['MDS_PERF_VERSION'], true) }
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new{ gatherMdsHostAndClientOutputThread(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'], ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'], ENV['MDS_PERF_VERSION_2'], false) }
  t2.abort_on_exception = true
  threads << t2

  t1.join
  t2.join
  ThreadsWait.all_waits(*threads )

  fail('Gathering output failed for '+ENV['MDS_PERF_HOST_USER']+'@'+ENV['MDS_PERF_HOST_IP']) if(t1.status.nil?)
  fail('Gathering output failed for '+ENV['MDS_PERF_HOST_USER_2']+'@'+ENV['MDS_PERF_HOST_IP_2']) if(t2.status.nil?)

  checkMdsClientsFiles(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
  checkMdsClientsFiles(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'])
end


Given /^MDS clients for 2 versions are launched, then LFR loader is launched and the output is archived$/ do
  threads = []
  t1=Thread.new { launchMdsClientsThread(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'], ENV['MDS_PERF_HOST_IP'], ENV['MDS_CLIENTS_QUANTITY'], ENV['MDS_PERF_CLIENT_PORT']) }
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new { launchMdsClientsThread(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'], ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_CLIENTS_QUANTITY_2'], ENV['MDS_PERF_CLIENT_PORT_2']) }
  t2.abort_on_exception = true
  threads << t2
  t1.join
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('Launching MDS clients failed for '+ENV['MDS_PERF_HOST_USER']+'@'+ENV['MDS_PERF_HOST_IP']) if(t1.status.nil?)
  fail('Launching MDS clients failed for '+ENV['MDS_PERF_HOST_USER_2']+'@'+ENV['MDS_PERF_HOST_IP_2']) if(t2.status.nil?)

  Actions.killArbStreamerPerUser(ENV['MDS_LFR_HOST_IP'], ENV['MDS_LFR_HOST_USER'], ENV['MDS_LFR_HOST_PWD'])
  Actions.killArbStreamerPerUser(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'])
  Actions.killArbStreamerPerUser(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'])
  Actions.killArbStreamerPerUser(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
  Actions.killArbStreamerPerUser(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'])

=begin
  @@lfrLoaderLogsDir = ENV['MDS_LFR_FOLDER_PATH']+'/logs'
  lfrLoaderLogsDir_1 = @@lfrLoaderLogsDir+'/'+@@time_stamp
  Actions.removeOldFilesByQuantityRemoteBash(ENV['MDS_LFR_HOST_IP'], ENV['MDS_LFR_HOST_USER'], ENV['MDS_LFR_HOST_PWD'], @@lfrLoaderLogsDir, 20)
  Actions.runArbStreamer(ENV['MDS_LFR_HOST_IP'], ENV['MDS_LFR_HOST_USER'], ENV['MDS_LFR_HOST_PWD'], ENV['MDS_LFR_FOLDER_PATH'], ENV['MDS_LFR_ARB_LOG_PATH'], ENV['MDS_LFR_HOST_IP'], ENV['MDS_LFR_PORT'], ENV['MDS_LFR_STOP_TIME'], lfrLoaderLogsDir_1)
=end

  @@lfrLoaderLogsDir = ENV['MDS_LFR_FOLDER_PATH']+'/logs'
  lfrLoaderLogsDir_1 = @@lfrLoaderLogsDir+'/'+@@time_stamp
  lfrLoaderLogsDir_2 = @@lfrLoaderLogsDir+'/'+@@time_stamp+'_2'
  threads = []
  t1=Thread.new{ Actions.runArbStreamer(ENV['MDS_LFR_HOST_IP'], ENV['MDS_LFR_HOST_USER'], ENV['MDS_LFR_HOST_PWD'], ENV['MDS_LFR_FOLDER_PATH'], ENV['MDS_LFR_ARB_LOG_PATH'], ENV['MDS_LFR_HOST_IP'], ENV['MDS_LFR_PORT'], ENV['MDS_LFR_STOP_TIME'], lfrLoaderLogsDir_1) }
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new{ Actions.runArbStreamer(ENV['MDS_LFR_HOST_IP'], ENV['MDS_LFR_HOST_USER'], ENV['MDS_LFR_HOST_PWD'], ENV['MDS_LFR_FOLDER_PATH'], ENV['MDS_LFR_ARB_LOG_PATH'], ENV['MDS_LFR_HOST_IP'], ENV['MDS_LFR_PORT_2'], ENV['MDS_LFR_STOP_TIME'], lfrLoaderLogsDir_2) }
  t2.abort_on_exception = true
  threads << t2
  t1.join
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('Launching LFR loader (ArbStreamer) failed for '+ENV['MDS_PERF_HOST_USER']+'@'+ENV['MDS_PERF_HOST_IP']) if(t1.status.nil?)
  fail('Launching LFR loader (ArbStreamer) failed for '+ENV['MDS_PERF_HOST_USER_2']+'@'+ENV['MDS_PERF_HOST_IP_2']) if(t2.status.nil?)

  cmd = 'ps -aef|grep telnet|grep -v grep|wc -l'
  res = Actions.SSH(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'], cmd, 15, true, '')
  timestamp = Actions.timeCurrent
  if res.to_s.strip != ENV['MDS_CLIENTS_QUANTITY'].to_s
    Actions.f timestamp+' -- Found another quantity of MDS clients for '+ENV['MDS_PERF_CLIENT_USER']+'@'+ENV['MDS_PERF_CLIENT_IP']+': '+res.to_s.strip+' processes instead of '+ENV['MDS_CLIENTS_QUANTITY'].to_s
  end
  cmd = 'ps -aef|grep telnet|grep -v grep|wc -l'
  res = Actions.SSH(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'], cmd, 15, true, '')
  timestamp = Actions.timeCurrent
  if res.to_s.strip != ENV['MDS_CLIENTS_QUANTITY_2'].to_s
    Actions.f timestamp+' -- Found another quantity of MDS clients for '+ENV['MDS_PERF_CLIENT_USER_2']+'@'+ENV['MDS_PERF_CLIENT_IP_2']+': '+res.to_s.strip+' processes instead of '+ENV['MDS_CLIENTS_QUANTITY_2'].to_s
  end

  timestamp = Actions.timeCurrent
  if ENV['LFR_LOADER_WAIT_TIME'].to_s.empty?
    Actions.c timestamp+' -- Waiting '+ENV['MDS_WAIT_TIME'].to_s+' seconds for MDS to run'
    sleep ENV['MDS_WAIT_TIME'].to_i
  else
    Actions.c timestamp+' -- Waiting '+ENV['LFR_LOADER_WAIT_TIME'].to_s+' seconds for LFR loader (ArbStreamer) to finish'
    stringToWait = 'End Time Reached: STOPPING...'
    stringToWait2 = 'Log Header READ Error: java.io.EOFException'
    stringToWait3 = 'THE END'
    res_2 = Actions.waitForOutputInFile(ENV['MDS_LFR_HOST_IP'], ENV['MDS_LFR_HOST_USER'], ENV['MDS_LFR_HOST_PWD'], lfrLoaderLogsDir_1+'/redirect_ArbStreamer*', stringToWait3, ENV['LFR_LOADER_WAIT_TIME'])
    lfrLoaderWaitTime_2 = (ENV['LFR_LOADER_WAIT_TIME'].to_i - res_2.to_i) + 30
    Actions.waitForOutputInFile(ENV['MDS_LFR_HOST_IP'], ENV['MDS_LFR_HOST_USER'], ENV['MDS_LFR_HOST_PWD'], lfrLoaderLogsDir_2+'/redirect_ArbStreamer*', stringToWait3, lfrLoaderWaitTime_2)
  end

  Actions.killTelnConnCountPerUser(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
  Actions.killTelnConnCountPerUser(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'])

  threads = []
  t1=Thread.new{ stopMdsThread(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD']) }
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new{ stopMdsThread(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2']) }
  t2.abort_on_exception = true
  threads << t2
  t1.join
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('Stopping MDS failed for '+ENV['MDS_PERF_HOST_USER']+'@'+ENV['MDS_PERF_HOST_IP']) if(t1.status.nil?)
  fail('Stopping MDS failed for '+ENV['MDS_PERF_HOST_USER_2']+'@'+ENV['MDS_PERF_HOST_IP_2']) if(t2.status.nil?)

  Actions.killArbStreamerPerUser(ENV['MDS_LFR_HOST_IP'], ENV['MDS_LFR_HOST_USER'], ENV['MDS_LFR_HOST_PWD'])

  threads = []
  t1=Thread.new{ gatherMdsHostAndClientOutputThread(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'], ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'], ENV['MDS_PERF_VERSION'], false) }
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new{ gatherMdsHostAndClientOutputThread(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'], ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'], ENV['MDS_PERF_VERSION_2'], false) }
  t2.abort_on_exception = true
  threads << t2
  t1.join
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('Gathering output failed for '+ENV['MDS_PERF_HOST_USER']+'@'+ENV['MDS_PERF_HOST_IP']) if(t1.status.nil?)
  fail('Gathering output failed for '+ENV['MDS_PERF_HOST_USER_2']+'@'+ENV['MDS_PERF_HOST_IP_2']) if(t2.status.nil?)

=begin
  threads = []
  t1=Thread.new{ checkMdsClientsFiles(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD']) }
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new{ checkMdsClientsFiles(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2']) }
  t2.abort_on_exception = true
  threads << t2
  t1.join
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('Checking MDS clients files failed for '+ENV['MDS_PERF_CLIENT_USER']+'@'+ENV['MDS_PERF_CLIENT_IP']) if(t1.status.nil?)
  fail('Checking MDS clients files failed for '+ENV['MDS_PERF_CLIENT_USER_2']+'@'+ENV['MDS_PERF_CLIENT_IP_2']) if(t2.status.nil?)
=end

  @@isCheckMdsClientsFilesSuccessful = false
  @@isCheckMdsClientsFilesSuccessful2 = false
  @@isCheckMdsClientsFilesSuccessful = checkMdsClientsFiles(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
  @@isCheckMdsClientsFilesSuccessful2 = checkMdsClientsFiles(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'])

  begin
    localDir = localDir = Dir.getwd+'/logs/logs_'+@@time_stamp+'/mds_perf'
    remoteLfrLoaderArchive = 'LFR_Loader_'+@@time_stamp+'.zip'
    cmd = 'cd '+@@lfrLoaderLogsDir+' && zip -r -9 -s 100m '+remoteLfrLoaderArchive+' '+@@time_stamp+'*'
    res = Actions.SSH(ENV['MDS_LFR_HOST_IP'], ENV['MDS_LFR_HOST_USER'], ENV['MDS_LFR_HOST_PWD'], cmd, 1500, true, '')

    downloadFileFromRemoteWithoutTimestamp(ENV['MDS_LFR_HOST_IP'], ENV['MDS_LFR_HOST_USER'], ENV['MDS_LFR_HOST_PWD'], localDir, @@lfrLoaderLogsDir, remoteLfrLoaderArchive)
    Actions.c 'LFR loader (ArbStreamer) output:'
    Actions.displayFileLinkInReport(localDir+'/'+remoteLfrLoaderArchive)
  rescue Exception => e
    fail('Gathering LFR loader (ArbStreamer) output failed for '+ENV['MDS_LFR_HOST_USER']+'@'+ENV['MDS_LFR_HOST_IP'])+' '+e.message
  end
end


Given /^MDS clients are launched and the archived output is gathered$/ do
  fail('Please define MDS_CLIENTS_QUANTITY') if ENV['MDS_CLIENTS_QUANTITY'].to_s.empty?

  host = ENV['MDS_PERF_CLIENT_IP']
  user = ENV['MDS_PERF_CLIENT_USER']
  pwd = ENV['MDS_PERF_CLIENT_PWD']
  host_mds = ENV['MDS_PERF_HOST_IP']
  user_mds = ENV['MDS_PERF_HOST_USER']
  pwd_mds = ENV['MDS_PERF_HOST_PWD']
  automationPath = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation'
  mdsPath = CONFIG.get['REMOTE_HOME']+'/'+user_mds+'/MDS/bin'
  telnetLogsPath = 'logs_telnet_expect/'+@@time_stamp.to_s

  fail('Please define MDS_PERF_CLIENT_PORT') if ENV['MDS_PERF_CLIENT_PORT'].to_s.empty?
  Actions.removeOldFilesByQuantityRemoteBash(host, user, pwd, automationPath+'/logs_telnet_expect', '20')
  begin
    perfMdsPort = ENV['MDS_PERF_CLIENT_PORT']
    res = runMDSmultiClient(host, user, pwd, automationPath, ENV['MDS_PERF_HOST_IP'], perfMdsPort, ENV['MDS_CLIENTS_QUANTITY'], automationPath+'/'+telnetLogsPath)
    Actions.v 'Res of starting MDS clients:'+"\n"+res.to_s
  rescue Exception => e
    fail('Launching MDS clients failed for '+user+'@'+host)+' '+e.message
  end

  #------Stopping MDS---------
  fail('Please define MDS_WAIT_TIME') if ENV['MDS_WAIT_TIME'].to_s.empty?
  begin
    timestamp = Actions.timeCurrent
    Actions.c timestamp+' -- Waiting '+ENV['MDS_WAIT_TIME'].to_s+' seconds for MDS at '+user_mds+'@'+host_mds
    sleep ENV['MDS_WAIT_TIME'].to_i

    res = stopMDS(host_mds, user_mds, pwd_mds, mdsPath)
    Actions.v 'Res of stopping MDS for the old version:'+"\n"+res.to_s
  rescue Exception => e
    fail('Stopping MDS failed for '+user_mds+'@'+host_mds)+' '+e.message
  end

  #------Downloading archived MDS and clients output---------
  begin
    localDir = Dir.getwd+'/logs/logs_'+@@time_stamp+'/mds_perf'

    remoteDirMDSlogs = CONFIG.get['REMOTE_HOME']+'/'+user_mds+'/MDS/logs'
    remoteDirMDSlogsArchive = 'logs_MDS_'+@@time_stamp.to_s+'.zip'
    remoteDirMDSlogsArchiveRegexp = 'logs_MDS_'+@@time_stamp.to_s+'.*'
    # remoteDirMDSlogsArchivePath = remoteDirMDSlogs+'/'+remoteDirMDSlogsArchive

    cmd = 'cd '+remoteDirMDSlogs+' &&  ls -tr mds_perf* | xargs cat > MDS_PERF_general.csv'
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && sed -i '/mdsLatency/d' MDS_PERF_general.csv"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && cat MDS_PERF_general.csv | cut -d',' -f13,15,16 > mdsLatency.log"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && sed -i '/mdsLatency/d' mdsLatency.log"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    # cmd = 'cd '+remoteDirMDSlogs+" && find . -type f -name 'mds_perf*.csv' ! -name 'mds_perf_1.0.csv' -exec cat {} + > MDS_PERF_general_withoutFirst.csv"
    cmd = 'cd '+remoteDirMDSlogs+' && ls -tr mds_perf* | grep -v mds_perf_1.0.csv | xargs cat > MDS_PERF_general_withoutFirst.csv'
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && sed -i '/mdsLatency/d' MDS_PERF_general_withoutFirst.csv"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && cat MDS_PERF_general_withoutFirst.csv | cut -d',' -f13,15,16 > mdsLatency_withoutFirst.log"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    cmd = 'cd '+remoteDirMDSlogs+" && sed -i '/mdsLatency/d' mdsLatency_withoutFirst.log"
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 180, true, '')

    # cmd = 'cd '+remoteDirMDSlogs+' && env GZIP=-9 tar cvzf '+remoteDirMDSlogsArchive+' *'
    cmd = 'cd '+remoteDirMDSlogs+' && zip -9 -s 100m '+remoteDirMDSlogsArchive+' *'
    res = Actions.SSH(host_mds, user_mds, pwd_mds, cmd, 1500, true, '')
    Actions.v 'Res of archiving MDS logs: '+res.to_s.strip
    #TODO: archiving in bckgr, loop checking if there is .zip file

    filesMdsArr = Actions.getFilesArrayByRegexp(host_mds, user_mds, pwd_mds, remoteDirMDSlogs, remoteDirMDSlogsArchiveRegexp)
    Actions.v 'Found the following MDS logs archives: '+filesMdsArr.to_s
    filesMdsArr.each { |fileName| downloadFileFromRemoteWithoutTimestamp(host_mds, user_mds, pwd_mds, localDir, remoteDirMDSlogs, fileName) }

    Actions.c 'MDS output (listened to '+host_mds+' at '+host+':'+perfMdsPort+'):'
    Actions.displayFileLinkInReport(localDir+'/'+remoteDirMDSlogsArchive)

    remoteDirTelnetPerf = automationPath+'/'+telnetLogsPath
    remoteDirTelnetPerfArchive = 'logs_telnet_'+@@time_stamp.to_s+'.zip'
    remoteDirTelnetPerfArchiveRegexp = 'logs_telnet_'+@@time_stamp.to_s+'.*'
    # remoteDirTelnetPerfArchivePath = remoteDirTelnetPerf+'/'+remoteDirTelnetPerfArchive

    # cmd = 'cd '+remoteDirTelnetPerf+' && env GZIP=-9 tar cvzf '+remoteDirTelnetPerfArchive+' *'
    cmd = 'cd '+remoteDirTelnetPerf+' && zip -9 -s 100m '+remoteDirTelnetPerfArchive+' *'
    res = Actions.SSH(host, user, pwd, cmd, 1500, true, '')

    filesTelnetArr = Actions.getFilesArrayByRegexp(host, user, pwd, remoteDirTelnetPerf, remoteDirTelnetPerfArchiveRegexp)
    Actions.v 'Found the following telnet output archives: '+filesTelnetArr.to_s
    filesTelnetArr.each { |fileName| downloadFileFromRemoteWithoutTimestamp(host, user, pwd, localDir, remoteDirTelnetPerf, fileName) }

    Actions.c 'Telnet logs from client machine:'
    Actions.displayFileLinkInReport(localDir+'/'+remoteDirTelnetPerfArchive)

    mslLoaderLog = 'mslLoader_output_'+host_mds+'_'+ENV['MSL_IP']+'.log'
    mslLoaderLogPath = CONFIG.get['REMOTE_HOME']+'/'+user_mds+'/MDS_tools/arbLogsPlaying/MslLoader/bin/logs_msl_loader'
    downloadFileFromRemoteWithoutTimestamp(host_mds, user_mds, pwd_mds, localDir, mslLoaderLogPath, mslLoaderLog)
    Actions.c 'MSL loader output:'
    Actions.displayFileLinkInReport(localDir+'/'+mslLoaderLog)
  rescue Exception => e
    fail('Gathering output failed for '+user+'@'+host)+' '+e.message
  end
end


def buildOldSdataSchemaThread(schema_version)
  sleep CONFIG.get['WAIT_FOR_ONE_THREAD_SDATA'].to_i
  res = ''
  begin
    res = buildSdataSchema('sdata1', schema_version)
  rescue Exception => e
    @@scenario_fails.push('sdata1 build failed for version ' + CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
    # Actions.displaySanityLogs(false, true, false, false)
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('sdata1 build failed for version ' + CONFIG.get['SDATA_OLD_SCHEMA_VERSION'])
  end
end


def buildNewSdataSchemaThread(schema_version)
  res = ''
  begin
    res = buildSdataSchema('sdata', schema_version)
  rescue Exception => e
    @@scenario_fails.push('sdata build failed for the Latest version ')
    # Actions.displaySanityLogs(true, false, false, false)
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('sdata build failed for the Latest version ')
  end
end


### sdata end


###scratch
Given /^Ptrade Apps And Schemas are built for Production version and  New Lab version$/ do
  threads = []
  old_app_version=CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].nil? || CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].to_s.strip.empty? ? '' : CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].to_s.strip
  @@old_ptrade_version_number = old_app_version.scan(/PTS_MAIN_\d+.\d+.\d+.\d+.(\d+)/)[0][0] if !old_app_version.to_s.strip.empty?
  t1=Thread.new{buildPtradeAppForProductionVersionThread(old_app_version)}
  t1.abort_on_exception = true
  threads << t1
  new_app_version=CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.strip.empty? ? '' : CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.strip
  t2=Thread.new{buildPtradeAppForLatestLabVersionThread(new_app_version)}
  t2.abort_on_exception = true
  t1.join
  threads << t2
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('Ptrade App and Schema build failed for user ptrade1') if(t1.status.nil?)
  fail('Ptrade App and Schema build failed for user ptrade') if(t2.status.nil?)

end

def buildPtradeAppForProductionVersionThread(app_version)
  sleep CONFIG.get['WAIT_FOR_ONE_THREAD_PTRADE'].to_i
  Actions.createLocalDirs
  Actions.removeOldOutput
  deleteFolderContentsOnRemoteServerIfFolderExist(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], 'Automation/ers')
  deleteFolderContentsOnRemoteServerIfFolderExist(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], 'Automation/ers2')
  createAutomationDirForUser(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  buildPtradeOldSchema2(app_version)
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation')
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/ers')
  uploadDir2RemoteAutomationFolder(CONFIG.get['SAPHIRE_REDIS_HOST1'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['SAPHIRE_REMOTE_HOST1_PWD'], Dir.getwd+'/templates/config', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation')
  Actions.cleanupMsl(CONFIG.get['CORE_HOST_USER1'], CONFIG.get['MSL_HOST_IP'])
  buildPtradeApp2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], app_version, false) #CONFIG.get['PTRADE_OLD_SCHEMA_VERSION']
  displayPtradeAppVersion(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/old_app_config2/prod.conf', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/PTS/config/prod.conf')
  #uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/old_app_config2/fix/rtns/qfj.cfg', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/PTS/config/fix/rtns/qfj.cfg')
  deleteCsvFilesOnRemoteServerForOldVersion
  createCsvDirsForUserOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  restartRedisWithNewConfigForOldVersion2
  restartPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER1'], true, 'ers', CONFIG.get['MSL_HOST_IP'])
  Actions.downloadPTSLogs(true, false)
  runPtsLogParser(CONFIG.get['CORE_HOST_USER1'],CONFIG.get['REMOTE_PTRADE1_TEMPLATE_DIR_PATH']+'/'+'ers')
  downloadCsvFolderForOldVersion
  downloadJsonForOldVersion
  #downloadTidyLogForOldVersion
  #Actions.checkRtnsDelievery(Dir.getwd + '/templates/old_app_rtns/'+@@time_stamp+'/pts_tidy_3.log', CONFIG.get['CORE_HOST_USER1'])
  stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
end


def buildMDSforOldVersionThread(version,sleep=false)
  if sleep
    Actions.v 'OldVersionThread: waiting '+CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_s
    sleep CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_i
  end

  buildMDSforOldVersion(version)

  automationPath=CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['MDS_HOST_USER1']+'/Automation'

  #------Renaming original config templates dir for the old version---------
  cmd = 'mv ~/MDS/config ~/MDS/config_orig_$(date +%Y-%m-%d_%H-%M-%S-%3N) && mkdir -p ~/MDS/config'
  res = Actions.SSH(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'], cmd, 25, true, '')

  #------Uploading config templates for the old version---------
  mdsConfigSourceOld = Dir.getwd+'/templates/mds_config_old'
  # mdsConfigDestOld='~/MDS/config'
  mdsConfigDestOld = CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['MDS_HOST_USER1']+'/MDS/config'
  Actions.v 'Uploading config templates for the old version'
  begin
    uploadDirToRemoteFolder(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'], mdsConfigSourceOld, mdsConfigDestOld)
  rescue Exception=>e
    @@scenario_fails.push('Error while uploading config templates directory to '+mdsConfigDestOld+' (old version) at '+CONFIG.get['MDS_HOST_IP']+':'+CONFIG.get['MDS_HOST_USER1'])
    fail('Error while uploading config templates directory to '+mdsConfigDestOld+' (old version) at '+CONFIG.get['MDS_HOST_IP']+':'+CONFIG.get['MDS_HOST_USER1']+' '+e.message)
  end

  #------Uploading arbFilter for the old version---------
  arbFilterSourceOld=Dir.getwd+'/templates/arbFilter'
  arbFilterDestOld=automationPath+'/arbFilter'
  Actions.v 'Uploading arbFilter for the old version'
  begin
    uploadDirToRemoteFolder(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'], arbFilterSourceOld, arbFilterDestOld)
  rescue Exception=>e
    @@scenario_fails.push('Error while uploading arbFilter directory to '+arbFilterDestOld+' (old version) at '+CONFIG.get['MDS_HOST_IP']+':'+CONFIG.get['MDS_HOST_USER1'])
    fail('Error while uploading arbFilter directory to '+arbFilterDestOld+' (old version) at '+CONFIG.get['MDS_HOST_IP']+':'+CONFIG.get['MDS_HOST_USER1']+' '+e.message)
  end

  #------Running arbFilter for the old version---------
  # arbFilterPath=automationPath+'/arbFilter/appassembler/bin'
  cmd = 'chmod -R 755 '+arbFilterDestOld
  res = Actions.SSH(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'], cmd, 25, true, '')

  arbFilterDestOld = arbFilterDestOld+'/appassembler/bin'
  runArbStreamer(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'], arbFilterDestOld, CONFIG.get['MDS_ARB_LOG_PATH1'], CONFIG.get['MDS_ARB_STREAMER_IP1'], CONFIG.get['MDS_ARB_STREAMER_PORT1'], CONFIG.get['MDS_ARB_STREAMER_STOP_TIME1'])

  #------Preparing MDS files for launching---------
  mdsPathOld=CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['MDS_HOST_USER1']+'/MDS/bin'
  cmd = 'chmod -R 755 '+mdsPathOld
  res = Actions.SSH(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'], cmd, 25, true, '')

  # launchMdsScript='MDS_launcher.sh'
  # Actions.uploadTemplates2(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'], Dir.getwd+'/templates/bash/'+launchMdsScript, mdsPathOld+'/'+launchMdsScript, 20)

  #------Running MDS sdsync for the old version---------
  # res=runMDS(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'], mdsPathOld, true)
  # Actions.v 'Res of sdsync for the old version:'+"\n"+res.to_s

  #------Running MDS for the old version---------
  res = runMDS(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'], mdsPathOld)
  Actions.v 'Res of starting MDS for the old version:'+"\n"+res.to_s
end


def buildMDSforOldVersionThread2(version,sleep=false)
  if sleep
    Actions.v 'OldVersionThread: waiting '+CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_s
    sleep CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_i
  end

  buildMDSforOldVersion2(version)

  automationPath=CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_OLD']+'/Automation'

  #------Renaming original config templates dir for the old version---------
  cmd = 'mv ~/MDS/config ~/MDS/config_orig_$(date +%Y-%m-%d_%H-%M-%S-%3N) && mkdir -p ~/MDS/config'
  res = Actions.SSH(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], cmd, 25, true, '')

  #------Uploading config templates for the old version---------
  mdsConfigSourceOld = Dir.getwd+'/templates/mds_config_old'
  # mdsConfigDestOld='~/MDS/config'
  mdsConfigDestOld = CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_OLD']+'/MDS/config'
  Actions.v 'Uploading config templates for the old version'
  begin
    uploadDirToRemoteFolder(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], mdsConfigSourceOld, mdsConfigDestOld)
  rescue Exception=>e
    @@scenario_fails.push('Error while uploading config templates directory to '+mdsConfigDestOld+' (old version) at '+ENV['MDS_HOST_IP_OLD']+':'+ENV['MDS_HOST_USER_OLD'])
    fail('Error while uploading config templates directory to '+mdsConfigDestOld+' (old version) at '+ENV['MDS_HOST_IP_OLD']+':'+ENV['MDS_HOST_USER_OLD']+' '+e.message)
  end

  #------Preparing MDS files for launching---------
  mdsPathOld=CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_OLD']+'/MDS/bin'
  cmd = 'chmod -R 755 '+mdsPathOld
  res = Actions.SSH(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], cmd, 25, true, '')

  #------Running MDS for the old version---------
  res = runMDS(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], mdsPathOld)
  Actions.v 'Res of starting MDS for the old version:'+"\n"+res.to_s
end


def buildMDSforNewVersionThread(version,sleep=false)
  if sleep
    Actions.v 'NewVersionThread: waiting '+CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_s
    sleep CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_i
  end

  buildMDSforNewVersion(version)

  automationPath=CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['MDS_HOST_USER']+'/Automation'

  #------Renaming original config templates dir for the new version---------
  cmd = 'mv ~/MDS/config ~/MDS/config_orig_$(date +%Y-%m-%d_%H-%M-%S-%3N) && mkdir -p ~/MDS/config'
  res = Actions.SSH(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'], cmd, 25, true, '')

  #------Uploading config templates for the new version---------
  mdsConfigSourceNew = Dir.getwd+'/templates/mds_config_new'
  # mdsConfigDestNew='~/MDS/config'
  mdsConfigDestNew = CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['MDS_HOST_USER']+'/MDS/config'
  Actions.v 'Uploading config templates for the new version'
  begin
    uploadDirToRemoteFolder(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'], mdsConfigSourceNew, mdsConfigDestNew)
  rescue Exception=>e
    @@scenario_fails.push('Error while uploading config templates directory to '+mdsConfigDestNew+' (new version) at '+CONFIG.get['MDS_HOST_IP']+':'+CONFIG.get['MDS_HOST_USER'])
    fail('Error while uploading config templates directory to '+mdsConfigDestNew+' (new version) at '+CONFIG.get['MDS_HOST_IP']+':'+CONFIG.get['MDS_HOST_USER']+' '+e.message)
  end

  #------Uploading arbFilter for the new version---------
  arbFilterSourceNew=Dir.getwd+'/templates/arbFilter'
  arbFilterDestNew=automationPath+'/arbFilter'
  Actions.v 'Uploading arbFilter for the new version'
  begin
    uploadDirToRemoteFolder(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'], arbFilterSourceNew, arbFilterDestNew)
  rescue Exception=>e
    @@scenario_fails.push('Error while uploading arbFilter directory to '+arbFilterDestNew+' (new version) at '+CONFIG.get['MDS_HOST_IP']+':'+CONFIG.get['MDS_HOST_USER'])
    fail('Error while uploading arbFilter directory to '+arbFilterDestNew+' (new version) at '+CONFIG.get['MDS_HOST_IP']+':'+CONFIG.get['MDS_HOST_USER']+' '+e.message)
  end

  #------Running arbFilter for the new version---------
  # arbFilterPath=automationPath+'/arbFilter/appassembler/bin'
  cmd = 'chmod -R 755 '+arbFilterDestNew
  res = Actions.SSH(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'], cmd, 25, true, '')
  arbFilterDestNew = arbFilterDestNew+'/appassembler/bin'
  runArbStreamer(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'], arbFilterDestNew, CONFIG.get['MDS_ARB_LOG_PATH'], CONFIG.get['MDS_ARB_STREAMER_IP'], CONFIG.get['MDS_ARB_STREAMER_PORT'], CONFIG.get['MDS_ARB_STREAMER_STOP_TIME'])

  #------Preparing MDS files for launching---------
  mdsPathNew=CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['MDS_HOST_USER']+'/MDS/bin'
  cmd = 'chmod -R 755 '+mdsPathNew
  res = Actions.SSH(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'], cmd, 25, true, '')

  # launchMdsScript='MDS_launcher.sh'
  # Actions.uploadTemplates2(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'], Dir.getwd+'/templates/bash/'+launchMdsScript, mdsPathOld+'/'+launchMdsScript, 20)

  #------Running MDS sdsync for the old version---------
  # res=runMDS(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'], mdsPathNew, true)
  # Actions.v 'Res of sdsync for the new version:'+"\n"+res.to_s

  #------Running MDS for the old version---------
  res = runMDS(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'], mdsPathNew)
  Actions.v 'Res of starting MDS for the new version:'+"\n"+res.to_s
end


def buildMDSforNewVersionThread2(version,sleep=false)
  if sleep
    Actions.v 'NewVersionThread: waiting '+CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_s
    sleep CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_i
  end

  buildMDSforNewVersion2(version, 'MDS_new', 'Automation_download_1')

  automationPath=CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_NEW']+'/Automation'

  #------Renaming original config templates dir for the new version---------
  cmd = 'mv ~/MDS/config ~/MDS/config_orig_$(date +%Y-%m-%d_%H-%M-%S-%3N) && mkdir -p ~/MDS/config'
  res = Actions.SSH(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], cmd, 25, true, '')

  #------Uploading config templates for the new version---------
  mdsConfigSourceNew = Dir.getwd+'/templates/mds_config_new'
  # mdsConfigDestOld='~/MDS/config'
  mdsConfigDestNew = CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_NEW']+'/MDS/config'
  Actions.v 'Uploading config templates for the new version'
  begin
    uploadDirToRemoteFolder(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], mdsConfigSourceNew, mdsConfigDestNew)
  rescue Exception=>e
    @@scenario_fails.push('Error while uploading config templates directory to '+mdsConfigDestNew+' (new version) at '+ENV['MDS_HOST_IP_NEW']+':'+ENV['MDS_HOST_USER_NEW'])
    fail('Error while uploading config templates directory to '+mdsConfigDestNew+' (new version) at '+ENV['MDS_HOST_IP_NEW']+':'+ENV['MDS_HOST_USER_NEW']+' '+e.message)
  end

  #------Preparing MDS files for launching---------
  mdsPathNew=CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_NEW']+'/MDS/bin'
  cmd = 'chmod -R 755 '+mdsPathNew
  res = Actions.SSH(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], cmd, 25, true, '')

  #------Running MDS for the new version---------
  res = runMDS(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], mdsPathNew)
  Actions.v 'Res of starting MDS for the new version:'+"\n"+res.to_s

=begin
  #------Launching Publisher client and gathering output for the old (! should be opposite to the current branch !) version---------
  oldMdsPort = '10001'
  res = runMDSclient(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], automationPath, ENV['MDS_HOST_IP_OLD'], oldMdsPort)
  Actions.v 'Res of starting MDS client for the old version:'+"\n"+res.to_s.strip if(!res.to_s.strip.empty?)

  #------Stopping MDS for the new version---------
  Actions.c 'Waiting '+ENV['MDS_WAIT_TIME'].to_s+' seconds for MDS at '+ENV['MDS_HOST_USER_NEW']+'@'+ENV['MDS_HOST_IP_NEW']
  sleep ENV['MDS_WAIT_TIME'].to_i

  res = stopMDS(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], mdsPathNew)
  Actions.v 'Res of stopping MDS for the new version:'+"\n"+res.to_s
=end
end


def launchMdsClientForOldVersionThread(sleep=false)
  if sleep
    Actions.v 'OldVersionThread: waiting '+CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_s
    sleep CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_i
  end

  automationPath=CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_OLD']+'/Automation'
  mdsPathOld=CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_OLD']+'/MDS/bin'

  #------Launching Publisher client and gathering output for the new (! should be opposite to the current branch !) version---------
  fail('Please define MDS_PORT_OLD') if ENV['MDS_PORT_OLD'].to_s.empty?
  newMdsPort = ENV['MDS_PORT_OLD']
  res = runMDSclient(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], automationPath, ENV['MDS_HOST_IP_NEW'], newMdsPort)
  Actions.v 'Res of starting MDS client for the new version:'+"\n"+res.to_s
end


def stopMdsForOldVersionThread(sleep=false)
  if sleep
    Actions.v 'OldVersionThread: waiting '+CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_s
    sleep CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_i
  end

  automationPath=CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_OLD']+'/Automation'
  mdsPathOld=CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_OLD']+'/MDS/bin'

  #------Stopping MDS for the old version---------
  timestamp = Actions.timeCurrent
  Actions.c timestamp+' -- Waiting '+ENV['MDS_WAIT_TIME'].to_s+' seconds for MDS at '+ENV['MDS_HOST_USER_OLD']+'@'+ENV['MDS_HOST_IP_OLD']
  sleep ENV['MDS_WAIT_TIME'].to_i

  res = stopMDS(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], mdsPathOld)
  Actions.v 'Res of stopping MDS for the old version:'+"\n"+res.to_s

  #------Downloading client output for the old version---------
  localDir = Dir.getwd+'/logs/logs_'+@@time_stamp+'/mds_old'
  remoteDir = automationPath+'/logs_telnet_expect'
  outputLog = 'telnet_output_'+ENV['MDS_HOST_IP_OLD']+'_'+ENV['MDS_HOST_IP_NEW']+'*.log'

  outputLog = Actions.getOneFileByRegexpOrFail(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], remoteDir, outputLog)

  downloadFileFromRemoteWithoutTimestamp(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], localDir, remoteDir, outputLog)
  Actions.c 'New version output (listened to '+ENV['MDS_HOST_IP_NEW']+'):'
  Actions.displayFileLinkInReport(localDir+'/'+outputLog)
end


def launchMdsClientForNewVersionThread(sleep=false)
  if sleep
    Actions.v 'OldVersionThread: waiting '+CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_s
    sleep CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_i
  end

  automationPath=CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_NEW']+'/Automation'
  mdsPathNew=CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_NEW']+'/MDS/bin'

#------Launching Publisher client and gathering output for the old (! should be opposite to the current branch !) version---------
  fail('Please define MDS_PORT_NEW') if ENV['MDS_PORT_NEW'].to_s.empty?
  newMdsPort = ENV['MDS_PORT_NEW']
  res = runMDSclient(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], automationPath, ENV['MDS_HOST_IP_OLD'], oldMdsPort)
  Actions.v 'Res of starting MDS client for the old version:'+"\n"+res.to_s.strip if(!res.to_s.strip.empty?)

end


def stopMdsForNewVersionThread(sleep=false)
  if sleep
    Actions.v 'OldVersionThread: waiting '+CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_s
    sleep CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_i
  end

  automationPath=CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_NEW']+'/Automation'
  mdsPathNew=CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_NEW']+'/MDS/bin'

#------Stopping MDS for the new version---------
  timestamp = Actions.timeCurrent
  Actions.c timestamp+' -- Waiting '+ENV['MDS_WAIT_TIME'].to_s+' seconds for MDS at '+ENV['MDS_HOST_USER_NEW']+'@'+ENV['MDS_HOST_IP_NEW']
  sleep ENV['MDS_WAIT_TIME'].to_i

  res = stopMDS(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], mdsPathNew)
  Actions.v 'Res of stopping MDS for the new version:'+"\n"+res.to_s

#------Downloading client output for the new version---------
  localDir = Dir.getwd+'/logs/logs_'+@@time_stamp+'/mds_new'
  remoteDir = automationPath+'/logs_telnet_expect'
  outputLog = 'telnet_output_'+ENV['MDS_HOST_IP_NEW']+'_'+ENV['MDS_HOST_IP_OLD']+'*.log'

  outputLog = Actions.getOneFileByRegexpOrFail(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], remoteDir, outputLog)

  downloadFileFromRemoteWithoutTimestamp(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], localDir, remoteDir, outputLog)
  Actions.c 'Old version output (listened to '+ENV['MDS_HOST_IP_OLD']+'):'
  Actions.displayFileLinkInReport(localDir+'/'+outputLog)
end


def downloadFileFromRemoteAndDisplayLink(host, user, pwd, remoteDir, localDir, file)
  downloadFileFromRemoteWithoutTimestamp(host, user, pwd, localDir, remoteDir, file)
  # Actions.c textToDisplay
  Actions.displayFileLinkInReport(localDir+'/'+file)
end


def launchMdsClientForCustomVersionThread(host, user, pwd, host2listen, sleep=false)
  if sleep
    Actions.v 'Launching MDS client at '+user+'@'+host+': waiting '+CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_s
    sleep CONFIG.get['WAIT_FOR_ONE_THREAD_MDS'].to_i
  end

  automationPath=CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation'
  cmd = 'mkdir -p '+automationPath
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 15)

#------Launching Publisher client---------
  clientMdsPort = ENV['MDS_CLIENT_PORT'].to_s
  res = runMDSclient(host, user, pwd, automationPath, host2listen, clientMdsPort)
  Actions.v 'Res of starting MDS client at '+host+'@'+user+"\n"+res.to_s.strip if(!res.to_s.strip.empty?)
end


def stopMdsForCustomVersionThread(host, user, pwd)
  mdsPath = CONFIG.get['REMOTE_HOME']+'/'+user+'/MDS/bin'
  res = stopMDS(host, user, pwd, mdsPath)
  Actions.v 'Res of stopping MDS for '+user+'@'+host+':'+"\n"+res.to_s
end


def buildPtradeAppForLatestLabVersionThread(app_version)
  Actions.createLocalDirs
  Actions.removeOldOutput
  deleteFolderContentsOnRemoteServerIfFolderExist(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'Automation/ers')
  deleteFolderContentsOnRemoteServerIfFolderExist(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'Automation/ers2')
  createAutomationDirForUser(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  uploadDir2RemoteAutomationFolder(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')
  buildPtradeNewSchema2(app_version) #CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU']
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/ers')
  uploadDir2RemoteAutomationFolder(CONFIG.get['SAPHIRE_REDIS_HOST1'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['SAPHIRE_REMOTE_HOST1_PWD'], Dir.getwd+'/templates/config',CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  Actions.cleanupMsl(CONFIG.get['CORE_HOST_USER'], CONFIG.get['MSL_HOST2_IP'])
  buildPtradeApp2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], app_version, false)  #CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU']
  displayPtradeAppVersion(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/upgrade_app_config2/prod.conf', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTS/config/prod.conf')
  #uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/upgrade_app_config2/fix/rtns/qfj.cfg', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTS/config/fix/rtns/qfj.cfg')
  createCsvDirsForUserOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  deleteCsvFilesOnRemoteServerForNewVersion
  createCsvDirsForUserOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  restartRedisWithNewConfigForNewVersion2
  restartPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER'], true, 'ers', CONFIG.get['MSL_HOST2_IP'])
  Actions.downloadPTSLogs(false, true)
  runPtsLogParser(CONFIG.get['CORE_HOST_USER'],CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+'ers')
  downloadCsvFolderForNewVersion
  downloadJsonForNewVersion
  #downloadTidyLogForNewVersion
  #Actions.checkRtnsDelievery(Dir.getwd + '/templates/new_app_rtns/'+@@time_stamp+'/pts_tidy_3.log', CONFIG.get['CORE_HOST_USER'])
  stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])


end

### scratch end

### Start Upgrade
Given /^Ptrade Apps And Schemas are built for Production for both users$/ do
  threads = []
  old_app_version=CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].nil? || CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].to_s.strip.empty? ? '' : CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].to_s.strip
  @@old_ptrade_version_number = old_app_version.scan(/PTS_MAIN_\d+.\d+.\d+.\d+.(\d+)/)[0][0] if !old_app_version.to_s.strip.empty?
  t1=Thread.new{buildPtradeAppForProductionVersionAsSourceThread(old_app_version)}
  t1.abort_on_exception = true
  threads << t1
  new_app_version=CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].nil? || CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].to_s.strip.empty? ? '' : CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'].to_s.strip
  t2=Thread.new{buildPtradeAppAndUpgradeProductionWithLatestLabVersionThread(new_app_version)}
  t2.abort_on_exception = true
  t1.join
  threads << t2
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('Ptrade App and Schema build failed for user ptrade1') if(t1.status.nil?)
  fail('Ptrade App and Schema build failed for user ptrade') if(t2.status.nil?)

end


def buildPtradeAppForProductionVersionAsSourceThread(app_version)
  sleep CONFIG.get['WAIT_FOR_ONE_THREAD_PTRADE'].to_i
  createAutomationDirForUser(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  # uploadDir2RemoteAutomationFolder(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')
  buildPtradeOldSchema2(CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'])
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation')
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/ers')
  uploadDir2RemoteAutomationFolder(CONFIG.get['SAPHIRE_REDIS_HOST1'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['SAPHIRE_REMOTE_HOST1_PWD'], Dir.getwd+'/templates/config', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation')
  Actions.cleanupMsl(CONFIG.get['CORE_HOST_USER1'], CONFIG.get['MSL_HOST_IP'])
  buildPtradeApp2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], app_version, false)
  displayPtradeAppVersion(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/old_app_config2/prod.conf', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/PTS/config/prod.conf')
  #uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/old_app_config2/fix/rtns/qfj.cfg', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/PTS/config/fix/rtns/qfj.cfg')
  createCsvDirsForUserOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  restartRedisWithNewConfigForOldVersion2
  restartPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER1'], true, 'ers', CONFIG.get['MSL_HOST_IP'])
  #Actions.downloadPTSLogs(true, false)
  runPtsLogParser(CONFIG.get['CORE_HOST_USER1'],CONFIG.get['REMOTE_PTRADE1_TEMPLATE_DIR_PATH']+'/'+'ers')
  stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])

end




def buildPtradeAppAndUpgradeProductionWithLatestLabVersionThread(app_version)
  createAutomationDirForUser(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  uploadDir2RemoteAutomationFolder(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')
  buildPtradeNewSchema2(app_version)
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/ers')
  uploadDir2RemoteAutomationFolder(CONFIG.get['SAPHIRE_REDIS_HOST1'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['SAPHIRE_REMOTE_HOST1_PWD'], Dir.getwd+'/templates/config',CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  Actions.cleanupMsl(CONFIG.get['CORE_HOST_USER'], CONFIG.get['MSL_HOST2_IP'])
  buildPtradeApp2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], app_version, false)
  displayPtradeAppVersion(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/upgrade_app_config2/prod.conf', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTS/config/prod.conf')
  #uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/upgrade_app_config2/fix/rtns/qfj.cfg', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTS/config/fix/rtns/qfj.cfg')
  createCsvDirsForUserOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  createCsvDirsForUserOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  restartRedisWithNewConfigForNewVersion2
  restartPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER'], true, 'ers', CONFIG.get['MSL_HOST2_IP'])
  Actions.downloadPTSLogs(false, true)
  runPtsLogParser(CONFIG.get['CORE_HOST_USER'],CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+'ers')
  #downloadTidyLogForNewVersion
  #Actions.checkRtnsDelievery(Dir.getwd + '/templates/new_app_rtns/'+@@time_stamp+'/pts_tidy_3.log', CONFIG.get['CORE_HOST_USER'])
  stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

end




Given /^MslErSender sent another tickets dir for both users$/ do
  er_folder='ers2'
  threads = []
  t1=Thread.new{runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER1'], true, er_folder, CONFIG.get['MSL_HOST_IP'])}
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new{runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER'], true, er_folder, CONFIG.get['MSL_HOST2_IP'])}
  t2.abort_on_exception = true
  t1.join
  threads << t2
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('MslErSender failed for user ptrade1 with folder ' + er_folder) if(t1.status.nil?)
  fail('MslErSender failed for user ptrade with folder ' + er_folder) if(t2.status.nil?)
end



Given /^Ptrade App and Schemas are Upgraded to the Last Sdata and Ptrade Lab version$/ do
  ### Upgrade 2nd App to the latest lab version (or to Custom version if needed)
  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    res = ''
    begin
      res = buildSdataSchema('sdata', (CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?) ? '' : CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'] )
      displaySdataSchemaNewVersion
    rescue Exception=>e
      @@scenario_fails.push('Sdata schema deployment failed for version '+CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU']) if(!CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? && !CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
      @@scenario_fails.push('Sdata schema deployment failed for the last version') if(CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? && CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
      # Actions.displaySanityLogs(false, false, true, false)
      if (!res.nil? && !res.to_s.empty?)
        Actions.f 'ERROR:'+"\n"+res
      end
      fail('Sdata schema deployment failed for version '+CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU']) if(!CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? && !CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
      fail('Sdata schema deployment failed for the last version') if(CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].nil? && CONFIG.get['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    end
  else
    Actions.v 'NOT deploying SDATA for Upgrade version'
  end

  res = ''
  begin
    res = upgradePtradeToNewLabVersion
  rescue Exception=>e
    @@scenario_fails.push('Ptrade schema upgrade failed')
    # Actions.displaySanityLogs(false, false, true, false)
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('Ptrade schema upgrade failed for version '+CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU']) if(CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    fail('Ptrade schema upgrade failed for the last version') if(CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
  end

  buildPtradeApp2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'], true)
  displayPtradeAppAndDbVersionForUpgrade(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/upgrade_app_config2/prod.conf', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTS/config/prod.conf')
  #uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/upgrade_app_config2/fix/rtns/qfj.cfg', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTS/config/fix/rtns/qfj.cfg')

end



Then /^Ptrade App is restarted and data downloaded for both users$/ do
  threads = []
  t1=Thread.new{sendErsRestartAndDownloadDataForOldVersion}
  t1.abort_on_exception = true
  threads << t1
  t2=Thread.new{sendErsRestartAndDownloadDataForNewVersion}
  t2.abort_on_exception = true
  t1.join
  threads << t2
  t2.join
  ThreadsWait.all_waits(*threads )
  fail('restartAndDownloadDataForOldVersion failed for user ptrade1') if(t1.status.nil?)
  fail('restartAndDownloadDataForNewVersion failed for user ptrade') if(t2.status.nil?)
end


def sendErsRestartAndDownloadDataForOldVersion
  sleep CONFIG.get['WAIT_FOR_ONE_THREAD_PTRADE'].to_i
  deleteCsvFilesOnRemoteServerForOldVersion
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers2', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/ers2')
  restartRedisWithNewConfigForOldVersion2
  runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER1'], true, 'ers2', CONFIG.get['MSL_HOST_IP'])
  restartPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  Actions.downloadPTSLogs(true, false)
  runPtsLogParser(CONFIG.get['CORE_HOST_USER1'],CONFIG.get['REMOTE_PTRADE1_TEMPLATE_DIR_PATH']+'/'+'ers2')
  downloadCsvFolderForOldVersion
  downloadJsonForOldVersion
  #downloadTidyLogForOldVersion
  #Actions.checkRtnsDelievery(Dir.getwd + '/templates/old_app_rtns/'+@@time_stamp+'/pts_tidy_3.log', CONFIG.get['CORE_HOST_USER1'])
  stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])

end




def sendErsRestartAndDownloadDataForNewVersion
  deleteCsvFilesOnRemoteServerForNewVersion
  uploadDir2RemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers2', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/ers2')
  #uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/upgrade_app_config2/fix/rtns/qfj.cfg', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTS/config/fix/rtns/qfj.cfg')
  restartRedisWithNewConfigForNewVersion2
  runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER'], true, 'ers2', CONFIG.get['MSL_HOST2_IP'])
  restartPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  Actions.downloadPTSLogs(false, true)
  runPtsLogParser(CONFIG.get['CORE_HOST_USER'],CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+'ers2')
  downloadCsvFolderForNewVersion
  downloadJsonForNewVersion
  #downloadTidyLogForNewVersion
  #Actions.checkRtnsDelievery(Dir.getwd + '/templates/new_app_rtns/'+@@time_stamp+'/pts_tidy_3.log', CONFIG.get['CORE_HOST_USER'])
  stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

end



### Upgrade scenario end










#########



Then /^DB tables DEAL TICKETS LEGS compared for both versions$/ do
  Actions.compareDbTableResults(CONFIG.get['ORACLE_HOST_TEMPLATE_SCHEMA'],CONFIG.get['ORACLE_HOST_SCHEMA'],@@time_stamp) #PTRADE1,PTRADE
end






Then /^Old and New versions csv Folders are Matched excluding timestamps$/ do
  compareCsvFolders(@@time_stamp)
end


Then /^Old and New versions csv Folders are Matched excluding timestamps atfer scratch$/ do
  compareCsvFolders(@@before_upgrade_timestamp)
end


Then /^Old and New versions csv Folders are Matched excluding timestamps after upgrade$/ do
  compareCsvFolders(@@time_stamp)
end


def compareCsvFolders(time_stamp)
  source_dir = Dir.getwd + '/templates/old_app_csv/'+time_stamp
  target_dir = Dir.getwd + '/templates/new_app_csv/'+time_stamp
  dir_count=Actions.compareCsvDirs(source_dir+'/common', target_dir+'/common')
  Actions.c (dir_count-2).to_s+' folders have been tested in folder common' if(!$csv_folders_count.nil? && !dir_count.nil? && !dir_count[0].to_s.downcase.include?('error'))
  dir_count=Actions.compareCsvDirs(source_dir+'/myt', target_dir+'/myt')
  Actions.c (dir_count-2).to_s+' folders have been tested in folder myt' if(!$csv_folders_count.nil? && !dir_count.nil? && !dir_count[0].to_s.downcase.include?('error'))
  Actions.c $csv_files_count.to_s+' files have been compared' if(!$csv_files_count.nil?)

  if($csv_folders_count.nil? || $csv_folders_count==0)
    @@scenario_fails.push('0 Folders compared')
    Actions.f('0 Folders compared')
    return
  end
  if($csv_files_count.nil? || $csv_files_count==0)
    @@scenario_fails.push('0 Files compared')
    Actions.f('0 Files compared')
  end
end




def compareCsvFolders2(source_dir,target_dir,excluded_fields_arr)
  Actions.v 'Comparing CSV folders source: ' + source_dir + ' and ' + target_dir
  dir_count=Actions.compareCsvDirs2(source_dir,target_dir,excluded_fields_arr)
  Actions.c (dir_count-2).to_s+' folders have been tested in '+source_dir if(!$csv_folders_count.nil? && !dir_count.nil? && !dir_count[0].to_s.downcase.include?('error'))
  Actions.c $csv_files_count.to_s+' files have been compared' if(!$csv_files_count.nil?)

  if($csv_folders_count.nil? || $csv_folders_count==0)
    @@scenario_fails.push('0 Folders compared')
    Actions.f('0 Folders compared')
    return
  end
  if($csv_files_count.nil? || $csv_files_count==0)
    @@scenario_fails.push('0 Files compared')
    Actions.f('0 Files compared')
  end
end


Then /^Old and New Saphire Jsons are Matched excluding sequence$/ do
  template_json =  Dir.getwd + '/templates/old_app_json/'+@@time_stamp+'/RedisMonitor1.txt'
  build_json =  Dir.getwd + '/templates/new_app_json/'+@@time_stamp+'/RedisMonitor.txt'
  @@json_fails=[]

  Actions.c '<b>Comparing Sapphire Jsons...</b>'
  Actions.compareSaphireOutputJsons(template_json, build_json) if(@@json_fails.empty?)
end


Then /^Old and New Saphire Jsons are Matched excluding sequence after scratch$/ do
  template_json =  Dir.getwd + '/templates/old_app_json/'+@@before_upgrade_timestamp+'/RedisMonitor1.txt'
  build_json =  Dir.getwd + '/templates/new_app_json/'+@@before_upgrade_timestamp+'/RedisMonitor.txt'
  @@json_fails=[]

  Actions.c '<b>Comparing Sapphire Jsons...</b>'
  Actions.compareSaphireOutputJsons(template_json, build_json) if(@@json_fails.empty?)
end


Then /^Old and New Saphire Jsons are Matched excluding sequence after upgrade$/ do
  template_json =  Dir.getwd + '/templates/old_app_json/'+@@time_stamp+'/RedisMonitor1.txt'
  build_json =  Dir.getwd + '/templates/new_app_json/'+@@time_stamp+'/RedisMonitor.txt'
  @@json_fails=[]

  Actions.c '<b>Comparing Sapphire Jsons...</b>'
  Actions.compareSaphireOutputJsons(template_json, build_json) if(@@json_fails.empty?)
end


Then /^Old and New versions RTNS outgoing data compared$/ do
  downloadTidyLogForOldVersion
  downloadTidyLogForNewVersion
  log_file_path1=Dir.getwd + '/templates/old_app_rtns/'+@@time_stamp+'/pts_tidy_3.log'
  log_file_path2=Dir.getwd + '/templates/new_app_rtns/'+@@time_stamp+'/pts_tidy_3.log'
  Actions.compareOutgoingRtns(log_file_path1,log_file_path2)
end


Then /^Old and New versions RTNS outgoing data compared as Text$/ do
   Actions.compareRtnsFiles(Dir.getwd + "/templates/old_app_csv_traiana/"+@@time_stamp,Dir.getwd + "/templates/new_app_csv_traiana/" + @@time_stamp)
end


Then /^the files created by old and new versions are compared$/ do
   Actions.compareCsvFolders2(CONFIG.get['MDS_SOURCE_CALCULATOR_DIR'], CONFIG.get['MDS_TARGET_CALCULATOR_DIR'],'','csv')
end


Then /^Old and New versions Traiana outgoing data compared as CSV$/ do
  approved_version = 518
  if (@@old_ptrade_version_number.nil?  || @@old_ptrade_version_number.to_s.empty? || @@old_ptrade_version_number.to_i < approved_version )
    Actions.f 'Escaping tests of Traiana - will run with version >= ' + approved_version.to_s + ' actual version is ' + '"' + @@old_ptrade_version_number.to_s + '"'
    return
  end
  ers_folder = 'ers'
  csv_folder = 'ers_csv'
  Actions.v 'Creating csv from ers for user: ' + CONFIG.get['CORE_HOST_USER1']
  cmd = 'cd '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/'+'Automation/PTS/bin && ./er2tickets.sh ../../'+ers_folder+' ../../'+csv_folder
  #cmd = 'cd /export/home/ptrade1/Automation/PTS/bin && ./er2tickets.sh /export/home/ptrade1/Automation/ers /export/home/ptrade1/Automation/ers_csv'
  res = Actions.SSH(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], cmd, 120, true, '')

  Actions.v res.to_s
  downloadTraianaCsvFolderForOldVersion('old_app_csv_traiana','/export/home/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/'+csv_folder)

  Actions.v 'Creating csv from ers for user: ' + CONFIG.get['CORE_HOST_USER']
  cmd = 'cd '+CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/'+'Automation/PTS/bin && ./er2tickets.sh ../../'+ers_folder+' ../../'+csv_folder
  res = Actions.SSH(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 120, true, '')
  Actions.v res.to_s
  downloadTraianaCsvFolderForNewVersion('new_app_csv_traiana','/export/home/'+CONFIG.get['CORE_HOST_USER']+'/Automation/'+csv_folder)

  Actions.c('<b> Old and New versions Traiana outgoing data compared as CSV </b>')
  compareCsvFolders2(Dir.getwd + '/templates/old_app_csv_traiana/'+@@time_stamp,Dir.getwd + '/templates/new_app_csv_traiana/'+@@time_stamp,CONFIG.get['TRAIANA_CSV_EXCLUDED_COLUMNS'])
end


Then /^Build and App logs are displayed in Report$/ do
  Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], "/export/home/"+CONFIG.get['CORE_HOST_USER']+'/Automation/PTSlogsParser_ptrade.sh', 120)
  Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], "/export/home/"+CONFIG.get['CORE_HOST_USER1']+'/Automation/PTSlogsParser_ptrade1.sh', 120)
  sleep 20
  Actions.displayFilesForDownloadInFolder(Dir.getwd+'/logs/logs_'+@@time_stamp)
end


Then /^xml output of 2 versions of MDS is compared$/ do
  compareMdsClientsFiles(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'], ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
end


########


def createLocalDirs
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates'+' && mkdir db', 10)
  Actions.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir new_app_csv', 10)
  Actions.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir old_app_csv', 10)
  Actions.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir new_app_json', 10)
  Actions.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates'+' && mkdir old_app_json', 10)
  Actions.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates/myt'+' && mkdir source', 10)
  Actions.WINCMD_NO_FAIL('cd '+ Dir.getwd+'/templates/myt'+' && mkdir target', 10)
end


def createAutomationDirForUser(host, user, pwd)
  Actions.v 'Creating Automation dir on host '+host+' for user '+user+'... '
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/ers'
  res = Actions.SSH(host, user, pwd, cmd, 10, true, '')

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/ers2'
  res = Actions.SSH(host, user, pwd, cmd, 10, true, '')


  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data/tickets'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data/tickets/common'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data/tickets/myt'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)
end


def createDirForUser(host, user, pwd, dir_path)
  Actions.c 'Creating directory '+dir_path+' on host '+host+' for user '+user+'...'
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+dir_path
  res = Actions.SSH(host, user, pwd, cmd, 10, true, '')
end


def createCsvDirsForUserOnRemoteServer(host, user, pwd)
  Actions.v 'Creating CSV and MyT folders on host '+host+' for user '+user+'... '
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/data/tickets/myt'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/data/tickets/common'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)
end


def buildPtradeApp(host, user, pwd, script_file, script_path_from, script_path_to,script_param)

  begin
    Actions.v 'Copying build scripts to build App on Ptrade server for user '+user+'... '
    Actions.uploadTemplates2(host, user, pwd, script_path_from+script_file, script_path_to+'/'+script_file,40)

    Actions.c 'Building App on Ptrade server for user '+user+'... '
    cmd = "dos2unix "+script_path_to+'/'+script_file
    res = Actions.SSH(host, user, pwd, cmd, 20, true, '')

    cmd ="chmod 755 "+script_path_to+'/'+script_file
    res = Actions.SSH(host, user, pwd, cmd, 20, false, '')

    cmd << ' && '+script_path_to+'/'+script_file
    cmd << " -n " + script_param if(!script_param.nil? && !script_param.to_s.empty?)
    res = Actions.SSH(host, user, pwd, cmd, 180, false, '')
  rescue Exception=>e
    @@scenario_fails.push('PtradeApp build failed for user ' + user)
    Actions.displaySanityLogs(false, false, true, false) if(user==CONFIG.get['CORE_HOST_USER'])
    Actions.displaySanityLogs(false, false, false, true) if(user==CONFIG.get['CORE_HOST_USER1'])
    fail('PtradeApp build failed for user ' + user)
  end
end


def buildPtradeApp2(host, user, pwd, script_param, isUpgrade)

  res = ''
  begin
    Actions.c 'Building Ptrade App for user '+user+' on '+host
    Actions.v 'Copying files to build Ptrade App...'

    appInstallScript = ''

    if (user==CONFIG.get['CORE_HOST_USER1'])
      if isUpgrade
        appInstallScript = 'ptradeAPP_build1_upgrade_automatic.sh'
      else
        appInstallScript = 'ptradeAPP_build1_install_automatic.sh'
      end
      Actions.uploadTemplates2(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],Dir.getwd+'/templates/bash/'+appInstallScript,CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/'+appInstallScript,40)
      Actions.rigthsForFile(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER1'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation',appInstallScript,'755')
    elsif (user==CONFIG.get['CORE_HOST_USER'])
      if isUpgrade
        appInstallScript = 'ptradeAPP_build_upgrade_automatic.sh'
      else
        appInstallScript = 'ptradeAPP_build_install_automatic.sh'
      end
      Actions.uploadTemplates2(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],Dir.getwd+'/templates/bash/'+appInstallScript,CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/'+appInstallScript,40)
      Actions.rigthsForFile(CONFIG.get['CORE_HOST'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation',appInstallScript,'755')
    else
      fail('Not supported user to launch Ptrade App installation: '+user+'. Only users '+CONFIG.get['CORE_HOST_USER']+', '+CONFIG.get['CORE_HOST_USER1']+' allowed')
    end
    Actions.v 'Files for installing the application are copied'

    if (script_param.nil? || script_param.to_s.strip.empty?)
      cmd = 'cd '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation && ./'+appInstallScript
    else
      cmd = 'cd '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation && ./'+appInstallScript+' -n '+script_param.to_s.strip
    end
    Actions.v 'For user ' +user+ ' script_param is '+script_param.to_s+ ' cmd for execution is ' + cmd
    res = Actions.SSH(host, user, pwd, cmd, 300, true, '')

  rescue Exception=>e
    @@scenario_fails.push('PtradeApp build failed for user ' + user) if(!isUpgrade)
    @@scenario_fails.push('PtradeApp upgrade failed for user ' + user) if(isUpgrade)
    # Actions.displaySanityLogs(false, false, true, false) if(user==CONFIG.get['CORE_HOST_USER'])
    # Actions.displaySanityLogs(false, false, false, true) if(user==CONFIG.get['CORE_HOST_USER1'])
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('PtradeApp build failed for user ' + user) if(!isUpgrade)
    fail('PtradeApp upgrade failed for user ' + user) if(isUpgrade)
  end
end


def uploadDirToRemoteAutomationFolder(host, user, pwd, dir_from_path, dir_to_path)
  Actions.v 'Uploading Templates files and scripts from ' +dir_from_path +' to Automation folder on remote server for user '+user+' started... '
  Actions.uploadTemplates2(host, user, pwd, dir_from_path, dir_to_path, 60)
  Actions.v 'Upload of Templates files and scripts from ' +dir_from_path +' to Automation folder on remote server for user '+user+' finished '
  Actions.SSH_NO_FAIL(host, user, pwd, "dos2unix "+dir_to_path+"/*",40)
  Actions.SSH_NO_FAIL(host, user, pwd, "chmod 755 "+dir_to_path+"/*.sh",40)
end


def uploadDir2RemoteAutomationFolder2(host, user, pwd, dir_from_path, dir_to_path)
  Actions.v 'Uploading files from ' +dir_from_path +' to Automation folder on remote server for user '+user+'... '
  cmd='mkdir -p '+dir_to_path
  Actions.SSH_NO_FAIL(host, user, pwd, cmd, CONFIG.get['SSH_TIMEOUT'].to_i)
  Actions.uploadTemplates2(host, user, pwd, dir_from_path, dir_to_path,CONFIG.get['SSH_TIMEOUT'].to_i)
  Actions.SSH_NO_FAIL(host, user, pwd, 'cd '+dir_to_path+'find . -type f -print0 | xargs -0 dos2unix',CONFIG.get['SSH_TIMEOUT'].to_i)
  Actions.SSH_NO_FAIL(host, user, pwd, 'chmod 755 '+dir_to_path+'/*.sh',CONFIG.get['SSH_TIMEOUT'].to_i)
end


def uploadDir2RemoteAutomationFolder(host, user, pwd, dir_from_path, dir_to_path)
  Actions.v 'Uploading files from ' +dir_from_path +' to Automation folder on remote server for user '+user+'... '
  Actions.uploadTemplates2(host, user, pwd, dir_from_path, dir_to_path,60)
  # Actions.SSH_NO_FAIL(host, user, pwd, "dos2unix "+dir_to_path+"/*",40)
  Actions.SSH_NO_FAIL(host, user, pwd, 'cd '+dir_to_path+' && find . -type f -print0 | xargs -0 dos2unix',40)
  Actions.SSH_NO_FAIL(host, user, pwd, "chmod 755 "+dir_to_path+"/*.sh",40)
end


def uploadDirToRemoteFolder(host, user, pwd, dir_from_path, dir_to_path)
  Actions.v 'Uploading Local folder contents from ' + dir_from_path+' to ' +dir_to_path+' on remote server for '+user+'@'+host+'... '
  cmd = 'mkdir -p '+dir_to_path
  res = Actions.SSH(host, user, pwd, cmd, 25, true, '')
  Actions.uploadTemplates2(host, user, pwd, dir_from_path, dir_to_path,60)
  # Actions.SSH_NO_FAIL(host, user, pwd, "dos2unix "+dir_to_path+"/*",40)
  Actions.SSH_NO_FAIL(host, user, pwd, 'cd '+dir_to_path+' && find . -type f -print0 | xargs -0 dos2unix',40)
  Actions.SSH_NO_FAIL(host, user, pwd, "chmod 755 "+dir_to_path+"/*.sh",40)
end


def uploadFileToRemoteFolder(host, user, pwd, file_name, path_from, path_to)
  Actions.v 'Uploading file '+path_from+'/'+file_name+' to ' + path_to+'/'+file_name +' for user '+user+' on host '+host+'... '
  Actions.uploadTemplates2(host, user, pwd, path_from+'/'+file_name, path_to+'/'+file_name,60)
  Actions.SSH_NO_FAIL(host, user, pwd, 'dos2unix '+path_to+'/'+file_name,20)
  Actions.SSH_NO_FAIL(host, user, pwd, "chmod 755 "+path_to+'/'+file_name,60)
end


def uploadFile2RemoteFolder(host, user, pwd, file_name, path_from, path_to)
  Actions.v 'Uploading file '+path_from+'/'+file_name+' to ' + path_to+'/'+file_name +' for user '+user+' on host '+host+'... '
  Actions.uploadTemplates2(host, user, pwd, path_from+'/'+file_name, path_to,60)
end


def uploadFile2RemoteFolder2(host, user, pwd, file_name, path_from, path_to)
  Actions.v 'Uploading file '+path_from+'/'+file_name+' to ' + path_to+'/'+file_name +' for user '+user+' on host '+host+'... '
  Actions.uploadTemplates2(host, user, pwd, path_from+'/'+file_name, path_to+'/'+file_name,CONFIG.get['SSH_TIMEOUT'].to_i)
end


def stopPtradeService(host, user, pwd)#TODO
  Actions.c 'Stopping PTS services for '+user
  cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/bin/service.sh stop'
  expected_output_rows=['pts_tidy stopped successfully','pts_core stopped successfully','pts_http stopped successfully']
  res = Actions.SSH(host, user, pwd, cmd, 60, true, expected_output_rows)
  Actions.c res.to_s
end


def stopPtradeServiceNoFail(host, user, pwd)
  Actions.c 'Stopping PTS services for '+user
  cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/bin/service.sh stop'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 60)
  # Actions.c res.to_s
  Actions.v res.to_s
end


def stopPtradeOldServiceNoFail(host, user, pwd)
  Actions.c 'Stopping PTS services in Automation_old for '+user
  cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation_old/PTS/bin/service.sh stop'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 60)
  Actions.c res.to_s
end


def restartPtradeService(host, user, pwd)
  Actions.c 'Restarting PTS service for '+user
  cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/bin/service.sh restart'
  expected_output_rows=['The PTS (module: tidy) is alive','The PTS (module: core) is alive','The PTS (module: http) is alive']
  res = Actions.SSH(host, user, pwd, cmd, 60, true, expected_output_rows) #The PTS (module: tidy) is alive
  Actions.c res.to_s
  sleep 120 #Waitng for Ptrade Started

  cmd ="cat " + CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/logs/pts_core_*.log'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 60) #Display Log
  Actions.v '<br>Core Logs -'+res.to_s if(!res.nil?) #if(!res.to_s.downcase.include?('exception')) #!res.to_s.downcase.include?('error') - error printed by default
=begin
  if(!res.nil? && (res.to_s.downcase.include?('error') || res.to_s.downcase.include?('exception')))
    Actions.f '<br>Exceptions or Errors are found in Core Logs -'+res.to_s
    @@scenario_fails.push('<br>Exceptions or Errors are found in Core Logs -'+res.to_s)
    #fail('<br>Exceptions found in Core Logs -'+res.to_s)
  end
=end

  cmd ="cat " + CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/logs/pts_tidy_*.log'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 60) #Display Log
  Actions.v '<br>Tidy Logs -'+res.to_s if(!res.nil?) #if(!res.to_s.downcase.include?('exception')) #!res.to_s.downcase.include?('error') - error printed by default
=begin
  if(!res.nil? && (res.to_s.downcase.include?('error') || res.to_s.downcase.include?('exception')))
    Actions.f '<br>Exceptions found in Tidy Logs -'+res.to_s
    @@scenario_fails.push('<br>Exceptions or Errors are found in Tidy Logs -'+res.to_s)
    #fail('<br>Exceptions or Errors are found in Tidy Logs -'+res.to_s)
  end
=end
end


def killRedis(host, user, pwd)
  Actions.v 'Killing Redis and RedisCli... '

  cmd = 'kill -9 $(/sbin/pidof redis-server) >/dev/null 2>&1'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 20)
  #Actions.c 'SSH command output:' +res.to_s

  cmd = 'sleep 3 && /sbin/pidof redis-server'
  res = Actions.SSH(host, user, pwd, cmd, 20, false, '')
  Actions.v 'SSH command output:' +res.to_s if(!res.nil? && !res.to_s.empty?)

  cmd = 'kill -9 $(/sbin/pidof startRedisCli) >/dev/null 2>&1' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
  cmd = 'kill -9 $(/sbin/pidof startRedisCli1) >/dev/null 2>&1' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 20)
  #Actions.c 'SSH command output:' +res.to_s


end



def killRedisRoot(host)
  #sleep 60
  Actions.v 'Killing Redis and RedisCli... '

  cmd = 'kill -9 $(/sbin/pidof redis-server) >/dev/null 2>&1'
  res = Actions.SSH_NO_FAIL(host, 'root', '123456', cmd, 20)
  #Actions.v 'SSH command output:' +res.to_s

  cmd = 'sleep 5 && /sbin/pidof redis-server'
  res = Actions.SSH(host, 'root', '123456', cmd, 20, false, '')
  Actions.v 'SSH command output:' +res.to_s if(!res.nil? && !res.to_s.empty?)

  cmd = 'kill -9 $(/sbin/pidof startRedisCli) >/dev/null 2>&1'
  res = Actions.SSH_NO_FAIL(host, 'root', '123456', cmd, 10)
  #Actions.v 'SSH command output:' +res.to_s
end

def killRedisRoot2(host, port)
  #sleep 60
  Actions.v 'Killing Redis and RedisCli from root on '+host+':'+port

  rs_existed = false
  rc_existed = false
  # cmd = "/sbin/pidof 'redis-server *:"+port+"'"
  cmd = "/bin/ps -aef|egrep './redis-server'|grep "+port+"|awk '{print $2}'|egrep -v egrep"
  res_pid = Actions.SSH(host, 'root', '123456', cmd, 20, true, '')
  res_pid = res_pid.to_s.strip
  if (!res_pid.nil? && !res_pid.to_s.empty?)
    rs_existed = true
    Actions.v 'Found redis-server process pid ('+res_pid+'), killing it'
    cmd = "kill -9 "+res_pid
    res = Actions.SSH(host, 'root', '123456', cmd, 20, true, '')
    Actions.v 'killRedisRoot2 output: '+res.to_s
  else
    Actions.v 'redis-server process pid not found'
  end


  cmd = "/bin/ps -aef|egrep 'redis-cli -p'|grep "+port+"|awk '{print $2}'|egrep -v egrep"
  res_pid = Actions.SSH(host, 'root', '123456', cmd, 20, true, '')
  res_pid = res_pid.to_s.strip
  if (!res_pid.nil? && !res_pid.to_s.empty?)
    rc_existed = true
    Actions.v 'Found redis-cli process pid ('+res_pid+'), killing it'
    cmd = "kill -9 "+res_pid
    res = Actions.SSH(host, 'root', '123456', cmd, 20, true, '')
    Actions.v 'killRedisRoot2 output: '+res.to_s
  else
    Actions.v 'redis-cli process pid not found'
  end

  # cmd = "sleep 3 && /bin/ps -aef|egrep 'redis-server'|grep "+port+"|awk '{print $2}'"
  if rs_existed
    cmd = "/bin/ps -aef|egrep './redis-server'|grep "+port+"|awk '{print $2}'|egrep -v egrep"
    res = Actions.SSH(host, 'root', '123456', cmd, 20, true, '')
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'Found redis-server process pid after killing it: '+res.to_s
    else
      Actions.v 'redis-server process pid was not found after killing it'
    end
  end

  # cmd = "sleep 3 && /bin/ps -aef|egrep 'redis-cli'|grep "+port+"|awk '{print $2}'"
  if rc_existed
    cmd = "/bin/ps -aef|egrep 'redis-cli -p'|grep "+port+"|awk '{print $2}'|egrep -v egrep"
    res = Actions.SSH(host, 'root', '123456', cmd, 20, true, '')
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'Found redis-cli process pid after killing it: '+res.to_s
    else
      Actions.v 'redis-cli process pid was not found after killing it'
    end
  end
end

def killRedisForUser(host, user, port)
  if (user != CONFIG.get['CORE_HOST_USER'] && user != CONFIG.get['CORE_HOST_USER1'])
    fail('Only users "'+CONFIG.get['CORE_HOST_USER']+'" and "'+CONFIG.get['CORE_HOST_USER1']+'" are allowed for killRedisForUser')
  end
  Actions.v 'Killing Redis and RedisCli on '+host+':'+port+' for user '+user

  cmd = "kill -9 $(/bin/ps -u "+user+" -f|egrep 'redis-server'|grep "+port+"|awk '{print $2}')"
  res = Actions.SSH(host, user, CONFIG.get['CORE_HOST_PWD'], cmd, 20, true, '')
  Actions.v 'killRedisOfUser output:' +res.to_s if(!res.nil? || !res.to_s.empty?)

  cmd = "kill -9 $(/bin/ps -u "+user+" -f|egrep 'redis-cli'|grep "+port+"|awk '{print $2}')"
  res = Actions.SSH(host, user, CONFIG.get['CORE_HOST_PWD'], cmd, 20, true, '')
  Actions.v 'killRedisOfUser output:' +res.to_s if(!res.nil? || !res.to_s.empty?)
end


def displayPtradeAppVersion(host, user, pwd)
  cmd =  'ls -l '+@@CONFIG['REMOTE_HOME']+'/'+user+'/Automation/PTS'
  res = Actions.SSH(host, user, pwd, cmd, 20, true, '')
  Actions.c '<b>App Version - '+res.to_s+'</b>'
  r=res.split(' ')
  fail('An App is not installed') if(r[10].nil?)
  #$app_version=r[10].gsub!('/export/home/'+user+'/Automation/packages/','').to_s
  if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
    $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER'], false)
    #@@new_ptrade_version_number = $app_version.scan(/PTS_MAIN_\d+.\d+.\d+.\d+.(\d+)/)[0][0]
  end
  if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
    $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER1'], false)
    #@@old_ptrade_version_number = $app_version.scan(/PTS_MAIN_\d+.\d+.\d+.\d+.(\d+)/)[0][0]
  end
  Actions.c '<b>Ptrade App and Schema version - '+$app_version.to_s+' for user ' + user+ '</b>'
  Actions.setBuildProperty('APP_VERSION', $app_version.to_s) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'].to_s.downcase)
end




def displayPtradeAppOnlyVersion(host, user, pwd)
  if (user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
    cmd =  'ls -l '+CONFIG['REMOTE_HOME']+'/'+user+'/Automation/PTS' if(CONFIG['PTRADE_APP_EXTRACT_FOLDER'].nil? || CONFIG['PTRADE_APP_EXTRACT_FOLDER'].to_s.empty?)
    cmd =  'ls -l '+CONFIG['PTRADE_APP_EXTRACT_FOLDER']+'PTS' if(!CONFIG['PTRADE_APP_EXTRACT_FOLDER'].nil? || !CONFIG['PTRADE_APP_EXTRACT_FOLDER'].to_s.empty?)
  elsif (user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
    cmd =  'ls -l '+CONFIG['REMOTE_HOME']+'/'+user+'/Automation/PTS' if(CONFIG['PTRADE_APP1_EXTRACT_FOLDER'].nil? || CONFIG['PTRADE_APP1_EXTRACT_FOLDER'].to_s.empty?)
    cmd =  'ls -l '+CONFIG['PTRADE_APP1_EXTRACT_FOLDER']+'PTS' if(!CONFIG['PTRADE_APP1_EXTRACT_FOLDER'].nil? || !CONFIG['PTRADE_APP1_EXTRACT_FOLDER'].to_s.empty?)
  else
    fail('Only users '+CONFIG.get['CORE_HOST_USER']+' or '+CONFIG.get['CORE_HOST_USER1']+' are allowed to perform an action')
  end
  res = Actions.SSH(host, user, pwd, cmd, 20, true, '')
  r=res.split(' ')
  fail('The App is not installed') if(r[10].nil?)
  Actions.v 'App version from PTS link: '+r

  #$app_version=r[10].gsub!('/export/home/'+user+'/Automation/packages/','').to_s
  $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER'], false) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
  $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER1'], false) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
  Actions.c '<b>Ptrade App version - '+$app_version.to_s+'</b>'
  Actions.setBuildProperty('APP_VERSION', $app_version.to_s)
end

def displayPtradeAppOnlyVersion2(host, user, pwd)
  if (user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
    cmd =  'ls -l '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS' if(CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil? || CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].to_s.empty?)
    cmd =  'ls -l '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+'/PTS' if(!CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil? || !CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].to_s.empty?)
  elsif (user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
    cmd =  'ls -l '+CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS' if(CONFIG.get['PTRADE_APP1_INSTALL_FOLDER'].nil? || CONFIG.get['PTRADE_APP1_INSTALL_FOLDER'].to_s.empty?)
    cmd =  'ls -l '+CONFIG.get['PTRADE_APP1_INSTALL_FOLDER']+'/PTS' if(!CONFIG.get['PTRADE_APP1_INSTALL_FOLDER'].nil? || !CONFIG.get['PTRADE_APP1_INSTALL_FOLDER'].to_s.empty?)
  else
    fail('Only users '+CONFIG.get['CORE_HOST_USER']+' or '+CONFIG.get['CORE_HOST_USER1']+' are allowed to perform an action')
  end
  res = Actions.SSH(host, user, pwd, cmd, 20, true, '')
  r=res.split(' ')
  fail('The App is not installed') if(r[10].nil?)
  Actions.v 'App version from PTS link: '+r.to_s if(!r.nil?)

  $app_version =  Actions.displayTarVersion2(CONFIG.get['CORE_HOST_USER'], false) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  $app_version =  Actions.displayTarVersion2(CONFIG.get['CORE_HOST_USER1'], false) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  Actions.c '<b>Ptrade App version - '+$app_version.to_s+'</b>'
  Actions.setBuildProperty('APP_VERSION', $app_version.to_s)
end

def displayPtradeDbVersion(host, user, pwd)
  $app_version =  Actions.displayTarVersion2(CONFIG.get['CORE_HOST_USER'], true) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
  $app_version =  Actions.displayTarVersion2(CONFIG.get['CORE_HOST_USER1'], true) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
  Actions.c '<b>Ptrade DB Schema version - '+$app_version.to_s+'</b>'
  Actions.setBuildProperty('DB_VERSION', $app_version.to_s)
end


def displayPtradeAppAndDbVersionForUpgrade(host, user, pwd)

  cmd =  'ls -l '+@@CONFIG['REMOTE_HOME']+'/'+user+'/Automation/PTS'
  res = Actions.SSH(host, user, pwd, cmd, 20, true, '')
  Actions.c '<b>App Version - '+res.to_s+'</b>'
  r=res.split(' ')
  fail('An App is not installed') if(r[10].nil?)
  #$app_version=r[10].gsub!('/export/home/'+user+'/Automation/packages/','').to_s

  $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER'], true) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
  $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER1'], true) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
  Actions.c '<b>Ptrade App and Schema version - '+$app_version.to_s+'</b>'
  Actions.setBuildProperty('APP_VERSION', $app_version.to_s)

end


def displayPtradeDbVersionForUpgrade(user)
  $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER'], true) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  $app_version =  Actions.displayTarVersion(CONFIG.get['CORE_HOST_USER1'], true) if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  Actions.c '<b>Ptrade App and Schema version - '+$app_version.to_s+'</b>'
  Actions.setBuildProperty('APP_VERSION', $app_version.to_s)

end


def displaySdataSchemaOldVersion
  $app_version = Actions.displayTarVersion(CONFIG.get['ORACLE_SDATA_HOST_TEMPLATE_SCHEMA'], true)#sdata1
  Actions.c '<b>Sdata Old Schema Version - '+$app_version.to_s+'</b>'
  Actions.setBuildProperty('SCHEMA_VERSION', $app_version.to_s)
end


def displaySdataSchemaNewVersion
  $app_version = Actions.displayTarVersion(CONFIG.get['ORACLE_SDATA_HOST_SCHEMA'], true)#sdata
  Actions.c '<b>Sdata Last Schema Version - '+$app_version.to_s+'</b>'
  Actions.setBuildProperty('SCHEMA_VERSION', $app_version.to_s)

end


def deleteSaphireRedisOutputOnRemoteServerForOldVersion
  deleteSaphireRedisOutputOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
end


def deleteSaphireRedisOutputOnRemoteServerForNewVersion
  deleteSaphireRedisOutputOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end


def deleteSaphireRedisOutputOnRemoteServer(host, user, pwd)
  fail('Expecting users - ' +CONFIG.get['CORE_HOST_USER']+ ' or ' +CONFIG.get['CORE_HOST_USER']) if(user!=CONFIG.get['CORE_HOST_USER'] || user!=CONFIG.get['CORE_HOST_USER1'])
  cmd = 'rm -f /export/home/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/RedisMonitor1.txt' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])
  cmd = 'rm -f /export/home/'+CONFIG.get['CORE_HOST_USER']+'/Automation/RedisMonitor.txt' if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)
end


def deleteFolderContentsOnRemoteServer(host, user, pwd, dir_path)
  cmd = 'mkdir -p '+dir_path+' && cd '+dir_path+' && rm -rf *'
  res = Actions.SSH(host, user, pwd, cmd, 20, false, '')
end


def deleteFolderContentsOnRemoteServerIfFolderExist(host, user, pwd, dir_path)
  cmd = 'cd /export/home/'+user+'/'+dir_path+' && rm -rf *'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 20)
end



def deleteCsvFilesOnRemoteServerForOldVersion
  Actions.v 'Deleting contents of MyT csv tickets - ' + @@CONFIG['MYT_CSV_REMOTE_DIR_PATH1'] + ' on ' + CONFIG.get['CORE_HOST']
  deleteFolderContentsOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/data/tickets')
  deleteFolderContentsOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/data/tickets/common')
  deleteFolderContentsOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/data/tickets/myt')
end


def deleteCsvFilesOnRemoteServerForNewVersion
  Actions.v 'Deleting contents of MyT csv tickets - ' + @@CONFIG['MYT_CSV_REMOTE_DIR_PATH'] + ' on ' + CONFIG.get['CORE_HOST']
  deleteFolderContentsOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/data/tickets')
  deleteFolderContentsOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/data/tickets/common')
  deleteFolderContentsOnRemoteServer(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/data/tickets/myt')
end


def restartRedisWithNewConfig(host, user, pwd, remote_dir, script_name)
  Actions.v 'Copying redis-cli script to redis src for user '+user+' ... '
  cmd = "cp -f "+remote_dir+'/'+script_name+' '+'$HOME/redis/src' \
         +" && sleep 3"\
         +" && dos2unix $HOME/redis/src/"+script_name\
         +" && chmod 755 "+ '$HOME/redis/src/'+script_name \
         +" && sleep 1"

  res = Actions.SSH(host, user, pwd, cmd, 20, true, '') #TODO fetch output
  Actions.c 'Restarting Redis with new config... Redis output redirected to $HOME/Automation/RedisMonitor*.txt'

  cmd = "cd $HOME/redis/src && ./startRedisCli.sh" if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER'])#ptrade
  cmd = "cd $HOME/redis/src && ./startRedisCli1.sh" if(user.to_s.downcase==CONFIG.get['CORE_HOST_USER1'])#ptrade1
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 20)


end

def restartRedisWithNewConfig2(host, user, pwd, remote_dir, script_name, port)
  if (user != CONFIG.get['CORE_HOST_USER'] && user != CONFIG.get['CORE_HOST_USER1'])
    fail('Only users '+CONFIG.get['CORE_HOST_USER']+' and '+CONFIG.get['CORE_HOST_USER1']+' are allowed for restartRedisWithNewConfig2')
  end

  Actions.v 'Copying startRedisCli script to redis src for user '+user+' on '+host
  cmd = "cp -f "+remote_dir+"/"+script_name+" /export/home/"+user+"/redis/src"\
         +" && dos2unix /export/home/"+user+"/redis/src/"+script_name\
         +" && chmod 755 /export/home/"+user+"/redis/src/"+script_name
  res = Actions.SSH(host, user, pwd, cmd, 30, true, '')
  Actions.c 'Restarting Redis with new config on '+host+':'+port+' for user '+user+'... Redis output redirected to /export/home/'+user+'/Automation/RedisMonitor*.txt'


  cmd = "cd /export/home/"+user+"/redis/src && ./"+script_name+" redisPort: "+port
  res = Actions.SSH(host, user, pwd, cmd, 20, false, '')
  # Actions.f 'Output found while starting redis: '+res.to_s if(!res.nil? && !res.to_s.empty?)

  cmd = "sleep 3 && /bin/ps -aef|egrep './redis-server'|grep "+port+"|awk '{print $2}'|egrep -v egrep"
  res = Actions.SSH(host, user, pwd, cmd, 20, true, '')
  res = res.to_s.strip
  if (res.nil? && res.to_s.empty?)
    Actions.f 'redis-server process pid NOT FOUND after starting redis'
  else
    Actions.v 'Found redis-server process pid after starting redis: '+res
  end
end


def restartRedisWithNewConfigForOldVersion
  restartRedisWithNewConfig(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation', 'startRedisCli1.sh')
end

def restartRedisWithNewConfigForOldVersion2
  restartRedisWithNewConfig2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation', 'startRedisCli1_custom.sh', '6389')
end

def restartRedisWithNewConfigForNewVersion
  restartRedisWithNewConfig(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation', 'startRedisCli.sh')
end

def restartRedisWithNewConfigForNewVersion2
  restartRedisWithNewConfig2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation', 'startRedisCli_custom.sh', '6399')
end


def submitErs
  $cmd_res=nil
  $exec_id=nil
  $er=nil

  Actions.c 'Running MSLErSender with ers folder'
  $cmd_res = Actions::WINCMD('cd ' +Dir.getwd+'/libs/MSLErSender/bin & mslErSender.bat ers ', 120, 'txt with execId') #Run ER Simulator
  $exec_ids = $cmd_res.to_s.scan(/txt with execId(.*?)\[(.*?)\]/i)
  #$exec_id = $exec_ids[0][1]
  Actions.c '<br>'+'Following ExecIDs are Found - ' + $exec_ids.to_s + '<br>'

end


def runRemoteMslSenderForOldVersion
  runRemoteMslSender(CONFIG.get['CORE_HOST_USER1'], "Old")#ptrade1
end


def runRemoteMslSenderForNewVersion
  runRemoteMslSender(CONFIG.get['CORE_HOST_USER'], "New")#ptrade
end


def runRemoteMslSender(user, version)#TODO Actions
  cmd =  "cd $HOME/Automation && dos2unix *.sh"
  res = Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], cmd, 120)

  Actions.c('<b>Running MslErSender on '+CONFIG.get['CORE_HOST'].to_s+' with export/home/'+user+'/Automation/ers folder</b>')
  cmd =  "cd $HOME/MSLErSender_1.2/bin && ./mslErSender.sh -i 100 -s $HOME/Automation/ers/ -pid"
  res = Actions.SSH(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], cmd, 120, true, 'txt with execId')
  Actions.v 'MslSender output - '+res.to_s

  e1='exception'
  e2='error'
  if (res.to_s.downcase.include?(e1) || res.to_s.downcase.include?(e2))
    @@scenario_fails.push('MslSender responded with Errors for '+version+' version')
    fail('MslSender responded with Errors for '+version+ ' version')
  end


  Actions.v 'Waiting for Core for ' + CONFIG.get['WAIT_FOR_MSL_PROCESSING_SECS'].to_s + ' secs'
  sleep CONFIG.get['WAIT_FOR_MSL_PROCESSING_SECS']

  runPtsLogParser(user, CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/ers') #for upgrade scenario1, not used in Upgrade2

end


def runRemoteMslSender4upgrade2(user, randomExecId, er_folder, mslIP)#TODO Actions
  Actions.c('<b>Running MslErSender on '+CONFIG.get['CORE_HOST'].to_s+' with export/home/'+user+'/Automation/'+er_folder+' folder</b>')
  cmd =  "cd $HOME/MSLErSender_1.2_"+mslIP+"/bin && ./mslErSender.sh -i 100 -s $HOME/Automation/"+er_folder+"/ -pid" if(randomExecId)
  cmd =  "cd $HOME/MSLErSender_1.2_"+mslIP+"/bin && ./mslErSender.sh -i 100 -s $HOME/Automation/"+er_folder+"/" if(!randomExecId)
  res = Actions.SSH(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], cmd, 120, true, 'txt with execId')

  if(!res.nil? && (res.to_s.downcase.include?('error') || res.to_s.downcase.include?('exception')))
    Actions.f 'Exceptions or errors are found in MslSender logs for '+user+': '+res.to_s
    @@scenario_fails.push('Exceptions or errors are found in MslSender logs for '+user+': '+res.to_s)
    fail('Exceptions or errors are found in MslSender logs for '+user+': '+res.to_s)
  end

  sleep 20
  Actions.v 'MslSender output - '+res.to_s

  Actions.v 'Waiting for Core for ' + CONFIG.get['WAIT_FOR_MSL_PROCESSING_SECS'].to_s + ' secs'
  sleep CONFIG.get['WAIT_FOR_MSL_PROCESSING_SECS']
end


def runPtsLogParser(user,ers_path)
  Actions.v 'Running PtsLogParser for Log Errors'

  if (user == CONFIG.get['CORE_HOST_USER1'] || user == CONFIG.get['CORE_HOST_USER'])
    Actions.rigthsForFile(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], '$HOME/Automation','PTSlogsParser_'+user+'.sh','755')
    res = Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], user, CONFIG.get['CORE_HOST_PWD'], '$HOME/Automation/PTSlogsParser_'+user+'.sh ers_path: '+ers_path, 120)
  else
    Actions.f('Invalid user '+user+' exiting PtsLogParser')
    return
  end

  if (!res.to_s.include?('No difference found'))
    @@scenario_fails.push('PtsLogParser responded with Errors for '+user+res.to_s)
    Actions.f('PtsLogParser Error output - ' + res.to_s)
    fail('PtsLogParser responded with Errors for '+user)
  else
    Actions.c('PtsLogParser output - ' + res.to_s)
  end
end


def runArbStreamer(host,user,pwd,pathToArbStreamer,pathToLog,ip,port,stopTime='')
  begin
    Actions.v 'Running arbStreamer from path "'+pathToArbStreamer+'" at '+host+':'+user
    # cmd = 'cd '+pathToArbStreamer.to_s+' && ./ArbStreamer -in '+pathToLog.to_s+' -ip '+ip.to_s+' -port '+port.to_s+' -stop '+stopTime.to_s
    cmd = 'cd '+pathToArbStreamer.to_s+' && ./launchArbStreamer.sh -in '+pathToLog.to_s+' -ip '+ip.to_s+' -port '+port.to_s+' -stop '+stopTime.to_s
    # res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 25)
    res = Actions.SSH(host, user, pwd, cmd, 25, true, '')
  rescue Exception=>e
    @@scenario_fails.push('Error while running arbStreamer from path '+pathToArbStreamer+' at '+host+':'+user)
    fail('Error while running arbStreamer from path '+pathToArbStreamer+' at '+host+':'+user+' '+e.message)
  end
end


def runMDS_orig(host,user,pwd,path,sdsync=false,rollback=false,rollbackHours='')
  begin
    if rollback
      Actions.v 'Running MDS with rollbackHours at "'+path+'" at '+host+':'+user
      cmd = 'cd '+path.to_s+' && chmod 755 *.sh && ./mds.sh start rollbackHours '+rollbackHours.to_s
    elsif sdsync
      Actions.v 'Running MDS with sdsync at "'+path+'" at '+host+':'+user
      cmd = 'cd '+path.to_s+' && chmod 755 *.sh && ./mds.sh sdsync'
    else
      Actions.v 'Running MDS at "'+path+'" at '+host+':'+user
      cmd = 'cd '+path.to_s+' && chmod 755 *.sh && ./mds.sh start'
    end
    res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 25)
    # res = Actions.SSH(host, user, pwd, cmd, 25, true, '')
    return res.to_s
  rescue Exception=>e
    @@scenario_fails.push('Error while running MDS at '+path+' at '+host+':'+user)
    fail('Error while running MDS at '+path+' at '+host+':'+user+' '+e.message)
  end
end


def runMDS(host,user,pwd,path,connectToSdata=true)
  begin
    Actions.v 'Running MDS at "'+path+'" at '+host+':'+user

    if connectToSdata
      cmd = 'cd '+path+' && ./service.sh start'
    else
      cmd = 'cd '+path+' && ./mds.sh start'
    end
    # res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 25)
    res = Actions.SSH(host, user, pwd, cmd, 1200, true, '')

    if res.to_s.strip.include?('is not running')
      @@scenario_fails.push('Error: MDS at '+user+'@'+host+' is not running')
      fail('Error: MDS at '+user+'@'+host+' is not running')
    end

    return res.to_s
  rescue Exception=>e
    @@scenario_fails.push('Error while running MDS at '+path+' at '+host+':'+user)
    fail('Error while running MDS at '+path+' at '+host+':'+user+' '+e.message)
  end
end


def runAutoTool(user)
  if (user == CONFIG.get['MDS_HOST_USER'] || user == CONFIG.get['MDS_HOST_USER1'])
    Actions.v 'Launching Auto tool for user "'+user+'"'
    # cmd =  'cd ~/MDS_tools/Auto && rm -f nohup.out && nohup python auto.py >> nohup.out 2>&1 &'
    cmd =  'cd ~/MDS_tools/Auto && ./auto_launcher.sh'
    res = Actions.SSH(CONFIG.get['MDS_HOST_IP'], user, CONFIG.get['MDS_HOST_PWD'], cmd, 10, true, '')
  else
    Actions.f('ERROR: invalid user "'+user+'"')
    fail('ERROR: invalid user "'+user+'"')
  end
end


def runMDSclient(host, user, pwd, path, host2connect, port2connect)
  begin
    telnetScript = 'MDS_client_conn.sh'
    Actions.uploadTemplates2(host, user, pwd, Dir.getwd+'/templates/bash/'+telnetScript, path+'/'+telnetScript, 20)
    Actions.rigthsForFile(host, user, pwd, path, telnetScript, '755')

    timestamp = Actions.timeCurrent
    Actions.c timestamp+' -- Launching MDS client at "'+path+'" for '+host+':'+user+', listening to '+host2connect+': '+port2connect

    cmd = 'cd '+path+' && /usr/bin/nohup ./'+telnetScript+' HOST: '+host2connect+' PORT: '+port2connect+' &'
    res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 15)
    # res = Actions.SSH(host, user, pwd, cmd, 15, true, '')

    return res.to_s
  rescue Exception=>e
    @@scenario_fails.push('Error while running MDS client at '+path+' at '+host+':'+user)
    fail('Error while running MDS client at '+path+' at '+host+':'+user+' '+e.message)
  end
end


def runMDSmultiClient(host, user, pwd, path, host2connect, port2connect, clientsQuantity, telnetPerfLogsDir)
  begin
    telnetScriptLauncher = 'MDS_client_conn_launcher.sh'
    telnetScript = 'MDS_client_conn.sh'
    Actions.uploadTemplates2(host, user, pwd, Dir.getwd+'/templates/bash/'+telnetScriptLauncher, path+'/'+telnetScriptLauncher, 20)
    Actions.rigthsForFile(host, user, pwd, path, telnetScriptLauncher, '755')
    Actions.uploadTemplates2(host, user, pwd, Dir.getwd+'/templates/bash/'+telnetScript, path+'/'+telnetScript, 20)
    Actions.rigthsForFile(host, user, pwd, path, telnetScript, '755')

    timestamp = Actions.timeCurrent
    Actions.c timestamp+' -- Launching '+clientsQuantity+' MDS clients at '+user+'@'+host+':'+path+', listening to '+host2connect+' at port '+port2connect

    cmd = 'cd '+path+' &&  ./'+telnetScriptLauncher+' LOGS_DIR: '+telnetPerfLogsDir+' HOST: '+host2connect+' PORT: '+port2connect+' QUANTITY: '+clientsQuantity+' >/dev/null &'
    # res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 45)
    res = Actions.SSH(host, user, pwd, cmd, 120, true, '')

    return res.to_s
  rescue Exception=>e
    @@scenario_fails.push('Error while running '+clientsQuantity+' MDS clients at '+path+' at '+host+':'+user)
    fail('Error while running '+clientsQuantity+' MDS clients at '+path+' at '+host+':'+user+' '+e.message)
  end
end


def runMSLloader(host, user, pwd, path, arbLogPath, ipOfMSL, startTime, stopTime)
  begin
    mslLoaderScript = 'launchMSLloader.sh'
    Actions.uploadTemplates2(host, user, pwd, Dir.getwd+'/templates/bash/'+mslLoaderScript, path+'/'+mslLoaderScript, 20)
    Actions.rigthsForFile(host, user, pwd, path, mslLoaderScript, '755')

    timestamp = Actions.timeCurrent
    Actions.c timestamp+' -- Launching MSL loader at "'+path+'" for '+host+':'+user+', playing arb log '+arbLogPath+' to MSL '+ipOfMSL.to_s+' since '+startTime.to_s+' until '+stopTime.to_s

    # cmd = 'cd '+path+' && nohup ./'+mslLoaderScript+' arbLogPath: '+arbLogPath+' mslIP: '+ipOfMSL+' startTime: '+startTime+' stopTime: '+stopTime+' &'
    cmd = 'cd '+path+' && ./'+mslLoaderScript+' arbLogPath: '+arbLogPath+' mslIP: '+ipOfMSL+' startTime: '+startTime+' stopTime: '+stopTime
    cmd = 'source /etc/profile; source ~/.bash_profile; source ~/.bashrc; '+cmd
    res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 15)
    # res = Actions.SSH(host, user, pwd, cmd, 15, true, '')

    return res.to_s
  rescue Exception=>e
    @@scenario_fails.push('Error while running MSL loader at '+path+' at '+host+':'+user)
    fail('Error while running MSL loader at '+path+' at '+host+':'+user+' '+e.message)
  end
end


def stopMDS(host,user,pwd,path)
  begin
    timestamp = Actions.timeCurrent
    Actions.c timestamp+' -- Stopping MDS in "'+path+'" at '+user+'@'+host

    # cmd = 'cd '+path+' && ./service.sh stop'
    cmd = path+'/service.sh stop'
    # res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 25)
    res = Actions.SSH(host, user, pwd, cmd, 40, true, '')

    return res.to_s
  rescue Exception=>e
    @@scenario_fails.push('Error while stopping MDS at '+path+' at '+host+':'+user)
    fail('Error while stopping MDS at '+path+' at '+host+':'+user+' '+e.message)
  end
end


def downloadFileFromRemote(host, user, pwd, local_target_dir, remote_dir, file_name)#TODO Actions
  res = Actions.WINCMD('IF exist '+local_target_dir+'\ ( echo Exists ) ELSE ( mkdir '+local_target_dir+' )', 20, '')
  Actions.v 'Directory '+local_target_dir+':'+res.to_s
  Actions.WINCMD_NO_FAIL('cd ' +local_target_dir+' & mkdir ' +  @@time_stamp, 10)
  sleep 3
  Actions.downloadRemoteFile(host, user, pwd, remote_dir+'/'+file_name, local_target_dir+'/'+@@time_stamp+'/'+file_name)
  #sleep 5
end


def downloadFileFromRemoteWithoutTimestamp(host, user, pwd, local_target_dir, remote_dir, file_name)#TODO Actions
  # Actions.WINCMD_NO_FAIL('cd ' +local_target_dir+' & mkdir ' +  @@time_stamp, 10)
  res = Actions.WINCMD('IF exist '+local_target_dir+'\ ( echo Exists ) ELSE ( mkdir '+local_target_dir+' )', 20, '')
  Actions.v 'Downloading file '+file_name+' from '+remote_dir+' to '+local_target_dir+'...'
  Actions.v 'Local directory '+local_target_dir+':'+res.to_s
  sleep 1
  Actions.downloadRemoteFile(host, user, pwd, remote_dir+'/'+file_name, local_target_dir+'/'+file_name)
  #sleep 5
end


def downloadJsonForOldVersion
  Actions.v('Downloading Sapphire Json for Old Version')
  downloadFileFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'],Dir.getwd+'/templates/old_app_json',  '/export/home/'+CONFIG.get['CORE_HOST_USER1']+'/Automation', 'RedisMonitor1.txt')
  downloadFileFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'],Dir.getwd+'/templates/old_app_json',  '/export/home/'+CONFIG.get['CORE_HOST_USER1']+'/Automation', 'RedisMonitor1.txt')
end


def downloadJsonForNewVersion
  Actions.v('Downloading Sapphire Json for New Version')
  downloadFileFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/new_app_json', '/export/home/'+CONFIG.get['CORE_HOST_USER']+'/Automation',  'RedisMonitor.txt')
end


def downloadTidyLogForOldVersion
  Actions.v('Downloading Sapphire Json for Old Version')
  downloadFileFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'],Dir.getwd+'/templates/old_app_rtns',  '/export/home/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/PTS/logs', 'pts_tidy_3.log')
end


def downloadTidyLogForNewVersion
  Actions.v('Downloading Sapphire Json for New Version')
  downloadFileFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/new_app_rtns', '/export/home/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTS/logs', 'pts_tidy_3.log')
end


def downloadDirFromRemote(host, user, pwd, local_target_dir, remote_dir)
  Actions.WINCMD_NO_FAIL('cd ' +local_target_dir+' & mkdir ' +  @@time_stamp, 10)
  Actions.v ' Download to '+local_target_dir+'/'+@@time_stamp+ ' started...'
  Actions.downloadRemoteDir(host, user, pwd, remote_dir, local_target_dir+'/'+@@time_stamp)
  Actions.v ' Download to '+local_target_dir+'/'+@@time_stamp+ ' finished'
end

def downloadDirFromRemoteWithCreateDir(host, user, pwd, local_target_dir, create_dir, remote_dir)
  Actions.WINCMD_NO_FAIL('cd ' +local_target_dir+' & mkdir ' +  create_dir, 10)
  Actions.downloadRemoteDir(host, user, pwd, remote_dir, local_target_dir+'/'+create_dir)
end



def downloadDirFromRemote2(host, user, pwd, local_target_dir, remote_dir)
  begin
    Actions.downloadRemoteDir(host, user, pwd, remote_dir, local_target_dir)
  rescue Exception=>e
    Actions.f('No logs found on remote server ' + host + ' for user ' + user + ' in folder' + remote_dir + ' Error - '+e.message)
    @@scenario_fails.push(e.message)
  end
end


def downloadCsvFolderForOldVersion
  Actions.c 'Downloading MyT And Common csv files from Remote Folder for Old Version'
  downloadDirFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/old_app_csv', CONFIG.get['MYT_CSV_REMOTE_DIR_PATH1'])
end


def downloadTraianaCsvFolderForOldVersion(local_folder_path,remote_folder_path)
  Actions.c 'Downloading Traiana csv files from Remote Folder for Old Version'
  downloadDirFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/'+local_folder_path, remote_folder_path)
end



###logs
def downloadDblogsForPtradeOldVersion
  Actions.v 'Downloading DB install logs for PTRADE schema old version '
  downloadDirFromRemote2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/logs_PT_DB1')
  #Actions.displayFilesForDownloadInFolder(folder_path)
end

def downloadDblogsForPtradeNewVersion
  Actions.v 'Downloading DB install logs for PTRADE schema last version '
  downloadDirFromRemote2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/logs_PT_DB')
end

def downloadDblogsForSdataOldVersion
  Actions.v 'Downloading DB install logs for SDATA schema old version '
  downloadDirFromRemote2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/logs_SDATA1')
end

def downloadDblogsForSdataNewVersion
  Actions.v 'Downloading DB install logs for SDATA schema last version '
  downloadDirFromRemote2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/logs_SDATA')
end


def downloadAppLogsForOldVersion
  Actions.v 'Downloading App install logs for old version '
  downloadDirFromRemote2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER1']+'/Automation/logs_PT_APP1')
end

def downloadAppLogsForNewVersion
  Actions.v 'Downloading App install logs for last version '
  downloadDirFromRemote2(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/logs/logs_'+@@time_stamp, CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/logs_PT_APP')
end


#### end logs


def downloadCsvFolderForNewVersion
  Actions.c 'Downloading MyT And Common csv files from Remote Folder for New Version'
  downloadDirFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/new_app_csv', CONFIG.get['MYT_CSV_REMOTE_DIR_PATH'])
end



def downloadTraianaCsvFolderForNewVersion(local_folder_path,remote_folder_path)
  Actions.c 'Downloading Traiana csv files from Remote Folder for New Version'
  downloadDirFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/'+local_folder_path, remote_folder_path)
end


def buildMDSforOldVersion(version)
  res = ''
  begin
    res = MdsAppDeploy(version, ENV['MDS_HOST_USER_OLD'])
  rescue Exception=>e
    @@scenario_fails.push('MDS old version installation failed for version '+version+'. // '+(e.message.nil? ? '' : e.message)) if (!version.nil? && !version.to_s.empty?)
    @@scenario_fails.push('MDS old version installation failed for the LAST version'+'. // '+(e.message.nil? ? '' : e.message)) if (version.nil? || version.to_s.empty?)
    # Actions.displaySanityLogs(false, false, false, true)
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('MDS old version installation failed for build '+version) if (!version.nil? && !version.to_s.empty?)
    fail('MDS old version installation failed for the LAST build') if (version.nil? || version.to_s.empty?)
  end
end


def buildMDSforOldVersion2(version, prefix='MDS_old')
  res = ''
  begin
    res = MdsAppDeploy2(version, ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], prefix)
  rescue Exception=>e
    @@scenario_fails.push('MDS old version installation failed for version '+version+'. // '+(e.message.nil? ? '' : e.message)) if (!version.nil? && !version.to_s.empty?)
    @@scenario_fails.push('MDS old version installation failed for the LAST version'+'. // '+(e.message.nil? ? '' : e.message)) if (version.nil? || version.to_s.empty?)
    # Actions.displaySanityLogs(false, false, false, true)
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('MDS old version installation failed for build '+version+' at '+ENV['MDS_HOST_USER_OLD']+'@'+ENV['MDS_HOST_IP_OLD']) if (!version.nil? && !version.to_s.empty?)
    fail('MDS old version installation failed for the LAST build'+' at '+ENV['MDS_HOST_USER_OLD']+'@'+ENV['MDS_HOST_IP_OLD']) if (version.nil? || version.to_s.empty?)
  end
end


def buildMDSforCustomVersion2(host, user, pwd, version, prefix='MDS_old')
  res = ''
  begin
    res = MdsAppDeploy2(version, host, user, pwd, prefix)
  rescue Exception=>e
    @@scenario_fails.push('MDS installation failed for version '+version+'. // '+(e.message.nil? ? '' : e.message)) if (!version.nil? && !version.to_s.empty?)
    @@scenario_fails.push('MDS installation failed for the LAST version'+'. // '+(e.message.nil? ? '' : e.message)) if (version.nil? || version.to_s.empty?)
    # Actions.displaySanityLogs(false, false, false, true)
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('MDS installation failed for build '+version+' at '+user+'@'+host) if (!version.nil? && !version.to_s.empty?)
    fail('MDS installation failed for the LAST build'+' at '+user+'@'+host) if (version.nil? || version.to_s.empty?)
  end
end


def buildMDSforNewVersion(version)
  res = ''
  begin
    res = MdsAppDeploy(version, CONFIG.get['MDS_HOST_USER'])
  rescue Exception=>e
    @@scenario_fails.push('MDS new version installation failed for version '+version+'. // '+(e.message.nil? ? '' : e.message))
    @@scenario_fails.push('MDS new version installation failed for the LAST version'+'. // '+(e.message.nil? ? '' : e.message)) if (version.nil? || version.to_s.empty?)
    # Actions.displaySanityLogs(false, false, false, true)
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('MDS new version installation failed for build '+version) if (!version.nil? && !version.to_s.empty?)
    fail('MDS new version installation failed for the LAST build') if (version.nil? || version.to_s.empty?)
  end
end


def buildMDSforNewVersion2(version, prefix='MDS_new', downloadFolder='Automation_download')
  res = ''
  begin
    res = MdsAppDeploy2(version, ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], prefix, downloadFolder)
  rescue Exception=>e
    @@scenario_fails.push('MDS new version installation failed for version '+version+'. // '+(e.message.nil? ? '' : e.message))
    @@scenario_fails.push('MDS new version installation failed for the LAST version'+'. // '+(e.message.nil? ? '' : e.message)) if (version.nil? || version.to_s.empty?)
    # Actions.displaySanityLogs(false, false, false, true)
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('MDS new version installation failed for build '+version+' at '+ENV['MDS_HOST_USER_NEW']+'@'+ENV['MDS_HOST_IP_NEW']) if (!version.nil? && !version.to_s.empty?)
    fail('MDS new version installation failed for the LAST build'+' at '+ENV['MDS_HOST_USER_NEW']+'@'+ENV['MDS_HOST_IP_NEW']) if (version.nil? || version.to_s.empty?)
  end
end


def buildPtradeOldSchema(version)
  begin
    customPtradeOldSchemaDeploy(version)
  rescue Exception=>e
    @@scenario_fails.push('PtradeOldSchemaDeploy failed for version ' + version)
    Actions.displaySanityLogs(false, false, false, true)
    fail('PtradeOldSchemaDeploy failed for version ' + version)
  end
end

def buildPtradeOldSchema2(version)
  res = ''
  begin
    res = customPtradeOldSchemaDeploy2(version)
  rescue Exception=>e
    @@scenario_fails.push('PtradeOldSchemaDeploy failed for version ' + version + (e.message.nil? ? '' : e.message))
    # Actions.displaySanityLogs(false, false, false, true)
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('PtradeOldSchemaDeploy failed for version ' + version)
  end
end

def buildPtradeNewSchema(version)
  begin
    customPtradeNewSchemaDeploy(version)
  rescue Exception=>e
    @@scenario_fails.push('PtradeNewSchemaDeploy failed for version ' + version)
    Actions.displaySanityLogs(false, false, true, false)
    fail('PtradeNewSchemaDeploy failed for version ' + version) if(!version.to_s.strip.empty?)
    fail('PtradeNewSchemaDeploy failed for the Last version ') if(version.to_s.strip.empty?)
  end
end

def buildPtradeNewSchema2(version)
  res = ''
  begin
    res = customPtradeNewSchemaDeploy2(version)
  rescue Exception=>e
    @@scenario_fails.push('PtradeNewSchemaDeploy failed for version ' + version)
    # Actions.displaySanityLogs(false, false, true, false)
    if (!res.nil? && !res.to_s.empty?)
      Actions.f 'ERROR:'+"\n"+res
    end
    fail('PtradeNewSchemaDeploy failed for version ' + version) if(!version.to_s.strip.empty? || !version.nil?)
    fail('PtradeNewSchemaDeploy failed for the Last version ') if(version.to_s.strip.empty? || version.nil?)
  end
end


def buildSdataSchema(user, version)
  if(!user.nil? && !user.to_s.empty? && user.to_s.downcase=='sdata1')
    Actions.v 'Building schema on Oracle server '+CONFIG.get['ORACLE_HOST']+' for user '+user
    #Old Schema
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/buildSchema_sdata1.sh', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/buildSchema_sdata1.sh',40)
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/db_config_sdata1_example.sql', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/db_config_sdata1_example.sql',40)
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/sdata_schema1_install_automatic.sh', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/sdata_schema1_install_automatic.sh',40)

    #Old Schema
    Actions.c 'Building SDATA DB Schema version "'+CONFIG.get['SDATA_OLD_SCHEMA_VERSION']+'" for '+CONFIG.get['ORACLE_HOST']+':sdata1 from scratch...'

    cmd =  "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/*.sh && chmod 755 '+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/*.sh && dos2unix '+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/*.sql'
    Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/sdata_schema1_install_automatic.sh -n " +version if(!version.nil? && !version.to_s.strip.empty?)
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/sdata_schema1_install_automatic.sh" +version if(version.nil? || version.to_s.strip.empty?)
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 600, true, '')

    Actions.v '<b>SDATA DB Schema Version "'+CONFIG.get['SDATA_OLD_SCHEMA_VERSION']+'" is built for user '+user+' on '+CONFIG.get['ORACLE_HOST']+'</b>'

    return res

  end

  if(!user.nil? && !user.to_s.empty? && user.to_s.downcase=='sdata')    # sdata new version

    Actions.v 'Building schema on Oracle server '+CONFIG.get['ORACLE_HOST']+' for user '+user
    #Last Schema
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/db_config_sdata_example.sql', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/db_config_sdata_example.sql',40)
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/sdata_schema_install_automatic.sh', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/sdata_schema_install_automatic.sh',40)

    #Last Schema
    Actions.c 'Building LAST SDATA DB Schema for '+CONFIG.get['ORACLE_HOST']+':sdata from scratch... '
    cmd =  "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/sdata_schema_install_automatic.sh"\
         +" && chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/sdata_schema_install_automatic.sh'
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

    cmd="chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/sdata_schema_install_automatic.sh'
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, false, '')


    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/sdata_schema_install_automatic.sh -n " +version if(!version.nil? && !version.to_s.strip.empty?)
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/sdata_schema_install_automatic.sh"  if(version.nil? || version.to_s.strip.empty?)
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 600, true, '')

    Actions.v '<b>SDATA DB Schema Last version is built for user '+user+' on '+CONFIG.get['ORACLE_HOST']+'</b>'
  end


end


def moveAutomationDir(host, user, pwd)
  Actions.v 'Renaming Automation into Automation_old and creating empty Automation dir on host '+host+' for user '+user+'... '
  cmd = 'mkdir -p Automation && rm -rf Automation_old && mv Automation Automation_old && mkdir -p Automation'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 20)
end


def moveLogsDirsMDS(host, user, pwd)
  cmd = 'cd ~/MDS_tools/app && mkdir -p logs && ls -A logs'
  res = Actions.SSH(host, user, pwd, cmd, 20, true, '')

  if !res.to_s.empty?
    # Actions.v 'Renaming "~/MDS_tools/app/logs" dir on host '+host+' for user '+user+'...'
    # cmd = 'cd ~/MDS_tools/app && mv logs logs_'+@@time_stamp+' && mkdir -p logs'
    Actions.v 'Removing "~/MDS_tools/app/logs" dir on host '+host+' for user '+user+'...'
    cmd = 'cd ~/MDS_tools/app && rm -rf logs'+' && mkdir -p logs'
    res = Actions.SSH(host, user, pwd, cmd, 40, false, '')
  end

  cmd = 'if test -d ~/MDS_tools/app/CALCS/Log/new_version; then echo "exists"; fi'
  res = Actions.SSH(host, user, pwd, cmd, 20, true, '')

  if res.to_s.strip == 'exists'
    # Actions.v 'Renaming "~/MDS_tools/app/CALCS/Log/new_version" dir on host '+host+' for user '+user+'...'
    # cmd = 'cd ~/MDS_tools/app/CALCS/Log && mv new_version new_version_'+@@time_stamp
    Actions.v 'Removing "~/MDS_tools/app/CALCS/Log/new_version" dir on host '+host+' for user '+user+'...'
    cmd = 'cd ~/MDS_tools/app/CALCS/Log && rm -rf new_version'
    res = Actions.SSH(host, user, pwd, cmd, 40, false, '')
  end
end


def moveLogsDirsMDS2(host, user, pwd)
  cmd = 'mkdir -p ~/MDS && cd ~/MDS && mkdir -p logs && ls -A logs'
  res = Actions.SSH(host, user, pwd, cmd, 20, true, '')

  if !res.to_s.strip.empty?
    Actions.v 'Removing "~/MDS_tools/app/logs" dir on host '+host+' for user '+user+'...'
    cmd = 'cd ~/MDS && mv logs logs_'+@@time_stamp+' && mkdir -p logs'
    res = Actions.SSH(host, user, pwd, cmd, 60, false, '')
  end
end


def killArpProcess(host, user, pwd)
  cmd = '/bin/ps -fu '+user+'|grep \'Arp.jar\'|grep -v \'grep\'|awk \'{print $2}\''
  res = Actions.SSH(host, user, pwd, cmd, 20, true, '')

  if !res.to_s.empty?
    Actions.c 'Killing ArpTool process on host '+host+' for user '+user+'...'
    cmd = 'kill -9 '+res.to_s.strip
    res = Actions.SSH(host, user, pwd, cmd, 20, false, '')
  end
end


def killMdsProcess(host, user, pwd)
  cmd = '/bin/ps -fu '+user+'|egrep -i \'mds\'|grep -v \'grep\'|awk \'{print $2}\''
  res = Actions.SSH(host, user, pwd, cmd, 20, true, '')

  if !res.to_s.empty?
    Actions.c 'Killing MDS processes on host '+host+' for user '+user+'...'
    cmd = 'kill -9 '+res.to_s.strip
    res = Actions.SSH(host, user, pwd, cmd, 20, false, '')
  end
end


#########Custom Build##########
Given /^Sdata Schema is Built$/ do
  Actions.createLocalDirs
  steps %Q{
    Given Automation dir exist on oracle server
    Given DB Sdata Custom Schema is built
  }
  displaySdataSchemaNewVersion

end

Given /^Sdata Schema is built for LAB$/ do
  Actions.isIpValidInParams
  CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']
  CONFIG.get['CORE_HOST'] = CONFIG.get['CORE_HOST_IP']

  if (CONFIG.get['PTRADE_SCHEMA'] != 'ptrade' && CONFIG.get['PTRADE_SCHEMA'] != 'ptrade1')
    Actions.f 'ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"'
    fail('ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"')
  end

  Actions.createLocalDirsTemplatesLogsDb
  steps %Q{
    Given Automation dir exist on oracle server
    Given DB Sdata Custom Schema is built for LAB
  }

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('SDATA')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    displayDbSchemaVersion2('SDATA1')
  end

end



Given /^Ptrade App and Schema are Built$/ do
  Actions.createLocalDirs
  steps %Q{
    Given Automation dir exist on oracle server
  }

  if(ENV['PTRADE_OLD_SCHEMA_VERSION'].nil?)
    customPtradeSchemaDeploy(nil)
    customPtradeAppDeploy(nil)
    #downloadDblogsForPtradeNewVersion
    #downloadAppLogsForNewVersion

  else
    customPtradeSchemaDeploy(ENV['PTRADE_OLD_SCHEMA_VERSION'])
    customPtradeAppDeploy(ENV['PTRADE_OLD_SCHEMA_VERSION'])
    #downloadDblogsForPtradeOldVersion
    #downloadAppLogsForOldVersion
  end

end

def failIfNotArray(examinee)
  if examinee.kind_of?(Array)
    # Actions.v ''
  else
    fail('Please give a correct array of parameters to check')
  end
end


def checkMandatoryParams(params_array)
  failIfNotArray(params_array)
  params_array.each { |param| fail('Please define missing mandatory parameter "'+param+'"') if(CONFIG.get[param].nil? || CONFIG.get[param.to_s].to_s.empty?) }
  Actions.v 'Mandatory parameters "'+params_array.join(",")+'" are not empty'
end

Given /^Ptrade App and Schema are built for LAB$/ do
  Actions.isIpValidInParams
  CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']
  CONFIG.get['CORE_HOST'] = CONFIG.get['CORE_HOST_IP']

  if (CONFIG.get['PTRADE_SCHEMA'] != 'ptrade' && CONFIG.get['PTRADE_SCHEMA'] != 'ptrade1')
    Actions.f 'ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"'
    fail('ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"')
  end

  ENV['PTRADE_NEW_APP_VERSION_OU'] = ENV['PTRADE_NEW_SCHEMA_VERSION_OU'] if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)

  Actions.createLocalDirsTemplatesLogsDb
  steps %Q{
    Given Automation dir exists on oracle server2
    Given Automation dir exists on ptrade server2
  }

  stopRegularPtradeServiceNoFails(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

  if(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    customPtradeSchemaDeployLab(nil)
    #downloadDblogsForPtradeNewVersion
  else
    customPtradeSchemaDeployLab(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'])
    #downloadDblogsForPtradeNewVersion
  end

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('PTRADE')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    displayDbSchemaVersion2('PTRADE1')
  end

  if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)
    customPtradeAppDeployLab(nil, false)
    #downloadAppLogsForNewVersion
  else
    customPtradeAppDeployLab(ENV['PTRADE_NEW_APP_VERSION_OU'], false)
    #downloadAppLogsForNewVersion
  end

  displayPtradeAppOnlyVersion2(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end


Given /^Ptrade App, Schema and optional Sdata are upgraded for LAB$/ do
  Actions.isIpValidInParams
  CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']
  CONFIG.get['CORE_HOST'] = CONFIG.get['CORE_HOST_IP']

  if (CONFIG.get['PTRADE_SCHEMA'] != 'ptrade' && CONFIG.get['PTRADE_SCHEMA'] != 'ptrade1')
    Actions.f 'ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"'
    fail('ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"')
  end

  ENV['PTRADE_NEW_APP_VERSION_OU'] = ENV['PTRADE_NEW_SCHEMA_VERSION_OU'] if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)

  Actions.createLocalDirsTemplatesLogsDb
  steps %Q{
    Given Automation dir exists on oracle server2
    Given Automation dir exists on ptrade server2
  }

  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    steps %Q{
      Given DB Sdata Custom Schema is built for LAB
    }
  else
    Actions.c '<b>NOT deploying SDATA for scratch</b>'
  end

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('SDATA')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    displayDbSchemaVersion2('SDATA1')
  end

  stopRegularPtradeServiceNoFails(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

  if(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    upgradePtradeToNewLabVersionLab(nil)
  else
    upgradePtradeToNewLabVersionLab(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'])
  end

  #downloadDblogsForPtradeNewVersion

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('PTRADE')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
  displayDbSchemaVersion2('PTRADE1')
  end

  if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)
    customPtradeAppDeployLab(nil, true)
    #downloadAppLogsForNewVersion
  else
    customPtradeAppDeployLab(ENV['PTRADE_NEW_APP_VERSION_OU'], true)
    #downloadAppLogsForNewVersion
  end

  displayPtradeAppOnlyVersion2(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end


Given /^Sdata and Ptrade App and Schema are Built$/ do
  Actions.createLocalDirs
  steps %Q{
    Given Sdata Schema is Built
  }
  stopPtradeServiceNoFail(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  deleteFolderContentsOnRemoteServerIfFolderExist(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'Automation/ers')
  buildPtradeNewSchema(CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'])
  uploadDirToRemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  displayPtradeDbVersionForUpgrade(CONFIG.get['CORE_HOST_USER'])

end


Given /^Ptrade App, Schema and optional Sdata are built for LAB$/ do
  Actions.isIpValidInParams
  CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']
  CONFIG.get['CORE_HOST'] = CONFIG.get['CORE_HOST_IP']

  if (CONFIG.get['PTRADE_SCHEMA'] != 'ptrade' && CONFIG.get['PTRADE_SCHEMA'] != 'ptrade1')
    Actions.f 'ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"'
    fail('ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"')
  end

  ENV['PTRADE_NEW_APP_VERSION_OU'] = ENV['PTRADE_NEW_SCHEMA_VERSION_OU'] if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)

  Actions.createLocalDirsTemplatesLogsDb
  steps %Q{
    Given Automation dir exists on oracle server2
    Given Automation dir exists on ptrade server2
  }

  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    steps %Q{
      Given DB Sdata Custom Schema is built for LAB
    }
  else
    Actions.c '<b>NOT deploying SDATA for scratch</b>'
  end

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('SDATA')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    displayDbSchemaVersion2('SDATA1')
  end

  stopRegularPtradeServiceNoFails(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

  if(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && ENV['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    customPtradeSchemaDeployLab(nil)
    #downloadDblogsForPtradeNewVersion
  else
    customPtradeSchemaDeployLab(ENV['PTRADE_NEW_SCHEMA_VERSION_OU'])
    #downloadDblogsForPtradeNewVersion
  end

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('PTRADE')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    displayDbSchemaVersion2('PTRADE1')
  end

  if(ENV['PTRADE_NEW_APP_VERSION_OU'].nil? && ENV['PTRADE_NEW_APP_VERSION_OU'].to_s.empty?)
    customPtradeAppDeployLab(nil, false)
    #downloadAppLogsForNewVersion
  else
    customPtradeAppDeployLab(ENV['PTRADE_NEW_APP_VERSION_OU'], false)
    #downloadAppLogsForNewVersion
  end

  displayPtradeAppOnlyVersion2(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end

Given /^Old Ptrade App, Schema and optional Sdata are built for LAB$/ do
  Actions.isIpValidInParams
  CONFIG.get['ORACLE_HOST'] = CONFIG.get['ORACLE_HOST_IP']
  CONFIG.get['CORE_HOST'] = CONFIG.get['CORE_HOST_IP']

  if (CONFIG.get['PTRADE_SCHEMA'] != 'ptrade' && CONFIG.get['PTRADE_SCHEMA'] != 'ptrade1')
    Actions.f 'ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"'
    fail('ERROR: "PTRADE_SCHEMA" can be either "ptrade" or "ptrade1"')
  end

  if (ENV['PTRADE_OLD_SCHEMA_VERSION'].nil? && ENV['PTRADE_OLD_SCHEMA_VERSION'].to_s.empty?)
    Actions.f 'ERROR: "PTRADE_OLD_SCHEMA_VERSION" not given'
    fail('ERROR: "PTRADE_OLD_SCHEMA_VERSION" not given')
  end

  ENV['PTRADE_OLD_APP_VERSION'] = ENV['PTRADE_OLD_SCHEMA_VERSION'] if(ENV['PTRADE_OLD_APP_VERSION'].nil? && ENV['PTRADE_OLD_APP_VERSION'].to_s.empty?)

  Actions.createLocalDirsTemplatesLogsDb
  steps %Q{
    Given Automation dir exists on oracle server2
    Given Automation dir exists on ptrade server2
  }

  if(!CONFIG.get['DEPLOY_SDATA'].nil? && CONFIG.get['DEPLOY_SDATA'].to_s.downcase=='true')
    steps %Q{
      Given Old DB Sdata Custom Schema is built for LAB
    }
  else
    Actions.c '<b>NOT deploying SDATA for scratch</b>'
  end

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('SDATA')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    displayDbSchemaVersion2('SDATA1')
  end

  stopRegularPtradeServiceNoFails(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

  customPtradeSchemaDeployLab(ENV['PTRADE_OLD_SCHEMA_VERSION'])
  #downloadDblogsForPtradeNewVersion

  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    displayDbSchemaVersion2('PTRADE')
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    displayDbSchemaVersion2('PTRADE1')
  end

  customPtradeAppDeployLab(ENV['PTRADE_OLD_APP_VERSION'], false)
  #downloadAppLogsForNewVersion
  displayPtradeAppOnlyVersion2(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end


Given /^Upgrade Ptrade to the Latest Lab version$/ do
  stopPtradeServiceNoFail(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  upgradePtradeToNewLabVersion
  buildPtradeApp(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'ptradeAPP_build_install_automatic.sh', Dir.getwd+'/templates/bash/', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation','')
  displayPtradeAppAndDbVersionForUpgrade(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

end



Given /^Jenkins will email PassedOrFailed$/ do
  Actions.c 'See Your email :-)'
end


Given /^DB Sdata Custom Schema is built$/ do
  if(ENV['SDATA_OLD_SCHEMA_VERSION'].nil? || ENV['SDATA_OLD_SCHEMA_VERSION'].to_s.empty?)
    customSdataSchemaDeploy(nil)
    downloadDblogsForSdataNewVersion
  else
    customSdataSchemaDeploy(ENV['SDATA_OLD_SCHEMA_VERSION'])
    downloadDblogsForSdataOldVersion
  end
end

Given /^DB Sdata Custom Schema is built for LAB$/ do
  if(ENV['SDATA_NEW_SCHEMA_VERSION_OU'].nil? || ENV['SDATA_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
    customSdataSchemaDeployLab(nil)
    downloadDblogsForSdataNewVersion
  else
    customSdataSchemaDeployLab(ENV['SDATA_NEW_SCHEMA_VERSION_OU'])
    downloadDblogsForSdataOldVersion
  end
end


Given /^Old DB Sdata Custom Schema is built for LAB$/ do
  if (ENV['SDATA_OLD_SCHEMA_VERSION'].nil? && ENV['SDATA_OLD_SCHEMA_VERSION'].to_s.empty?)
    Actions.f 'ERROR: "SDATA_OLD_SCHEMA_VERSION" not given'
    fail('ERROR: "SDATA_OLD_SCHEMA_VERSION" not given')
  end

  customSdataSchemaDeployLab(ENV['SDATA_OLD_SCHEMA_VERSION'])
  downloadDblogsForSdataOldVersion
end


Given /^Sdata Schema Installed$/ do
  target_schema = 'SDATA'
  t_schema = Actions.getDbQueryResultsWithoutFailure4(target_schema,target_schema.to_s.downcase,"select * from "+target_schema+".SCHEMA_VERSION")
  t_schema_version=t_schema[0]['VERSION_NAME'].to_s
  t_schema_created=t_schema[0]['CREATION_TIME'].to_s
  if (t_schema_version.nil? || t_schema_created.nil? )
    fail('SDATA Schema is NOT installed')
  else
    Actions.c '<b>SDATA Schema Version - '+t_schema_version+' '+t_schema_created+'</b>'
    Actions.setBuildProperty('APP_VERSION',t_schema_version.to_s)
  end

  moveAutomationDir(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

end


def displayDbSchemaVersion(schema)
  t_schema = Actions.getDbQueryResultsWithoutFailure4(schema,schema.to_s.downcase,"select * from "+schema+".SCHEMA_VERSION")
  t_schema_version=t_schema[0]['VERSION_NAME'].to_s
  t_schema_created=t_schema[0]['CREATION_TIME'].to_s
  if (t_schema_version.nil? || t_schema_created.nil? )
    fail('Error: '+schema+' Schema is NOT installed')
  else
    Actions.c schema+'<b> Schema Version: '+t_schema_version+' '+t_schema_created+'</b>'
    Actions.setBuildProperty('APP_VERSION',t_schema_version.to_s)
  end
end

def displayDbSchemaVersion2(schema)
  t_schema = Actions.getDbQueryResultsWithoutFailure2("select * from "+schema+".SCHEMA_VERSION")
  t_schema_version=t_schema[0]['VERSION_NAME'].to_s
  t_schema_created=t_schema[0]['CREATION_TIME'].to_s
  if (t_schema_version.nil? || t_schema_created.nil? )
    fail('Error: '+schema+' Schema is NOT installed')
  else
    Actions.c schema+'<b> Schema Version: '+t_schema_version+' '+t_schema_created+'</b>'
    Actions.setBuildProperty('APP_VERSION',t_schema_version.to_s)
  end
end


def stopPtradeServiceNoFails(host, user, pwd)
  Actions.c 'Stopping PTS services...'
  cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/PTS/bin/service.sh stop'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 30)
  Actions.c res.to_s
end

def stopRegularPtradeServiceNoFails(host, user, pwd)
  cmd = CONFIG.get['REMOTE_HOME']+'/'+user+'/PTS/bin/service.sh stop'
  Actions.c 'Stopping PTS services on '+host+': '+cmd
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 30)
  Actions.c res.to_s
end


def customSdataSchemaDeploy(version)
  fail('Please define missing params ORACLE_HOST...') if (CONFIG.get['ORACLE_HOST'].nil?)

  Actions.v 'Copying script and building Old schema to Oracle server... '
  #Custom Schema
  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/db_config_sdata_example.sql', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/db_config_sdata_example.sql',40)
  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/sdata_schema_install_automatic.sh', CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/sdata_schema_install_automatic.sh',40)

  #Custom Schema
  Actions.c 'Building SDATA DB Schema version '+version+' from scratch on '+CONFIG.get['ORACLE_HOST']+'...' if (!version.nil?)
  Actions.c 'Building SDATA DB Schema LAST version from scratch on '+CONFIG.get['ORACLE_HOST']+'...' if (version.nil?)

  cmd = "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/sdata_schema_install_automatic.sh"\
           +" && chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/sdata_schema_install_automatic.sh'
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/sdata_schema_install_automatic.sh" if (version.nil?)
  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/sdata_schema_install_automatic.sh -n "+version  if (!version.nil?)
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 600, true, '')

end



def customSdataSchemaDeployLab(version)
  fail('Please define missing params ORACLE_HOST_IP') if (CONFIG.get['ORACLE_HOST_IP'].nil?)

  mountHost = CONFIG.get['MOUNT_HOST']
  mountUser = CONFIG.get['MOUNT_USER']
  mountPwd = CONFIG.get['MOUNT_PWD']
  downloadFolder = "/export/home/"+mountUser+"/Automation_download"
  installScript = "sdata_schema_install_automatic.sh"
  installSupportFile = "db_config_sdata_example.sql"
  installSupportFile2 = ""
  downloadScript = "sdata_schema_download_automatic.sh"
  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    installScript = "sdata_schema1_install_automatic.sh"
    installSupportFile = "db_config_sdata1_example.sql"
    installSupportFile2 = "buildSchema_sdata1.sh"
    downloadScript = "sdata_schema1_download_automatic.sh"
  end
  scpScript = "scpFileRemotely.sh"

  sdata_schema = ''
  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade'
    sdata_schema = 'sdata'
  elsif CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    sdata_schema = 'sdata1'
  end
  Actions.c '<b>Getting SDATA DB Schema version '+version+' for "'+sdata_schema+'"...</b>' if (!version.nil?)
  Actions.c '<b>Getting the LAST version of SDATA DB Schema for "'+sdata_schema+'"...</b>' if (version.nil?)

  cmd = "rm -rf "+downloadFolder+" && mkdir -p "+downloadFolder
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,20,false,'')

  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+downloadScript,downloadFolder+'/'+downloadScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,downloadScript,'755')
  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+scpScript,downloadFolder+'/'+scpScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,scpScript,'755')

  cmd = downloadFolder+'/'+downloadScript if (version.nil?)
  cmd = downloadFolder+'/'+downloadScript+" -n "+version  if (!version.nil?)
  res = Actions.SSH(mountHost, mountUser, mountPwd, cmd, 500, true, '')

  env_version = Actions.displayDownloadedTarVersion(sdata_schema,true,mountHost,mountUser,mountPwd)
  downloadedPackage = downloadFolder+'/'+env_version
  targetPackage = CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version

  cmd = 'ls -lA '+downloadedPackage
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,5,true,'')
  Actions.c 'Package found: '+res if(res)

  Actions.c 'Copying files to '+CONFIG.get['ORACLE_HOST_IP']+'...'
  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/'+installSupportFile, CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installSupportFile,40)
  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/'+installSupportFile2, CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installSupportFile2,40)
    Actions.rigthsForFile(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH'], installSupportFile2, '755')
  end
  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/'+installScript, CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript,40)
  Actions.rigthsForFile(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH'], installScript, '755')
  Actions.transferFileRemotely(scpScript,mountHost,mountUser,mountPwd,CONFIG.get['ORACLE_HOST_IP'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],downloadFolder,CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH'],env_version)
  Actions.c '<b>Downloaded package '+env_version+' to '+targetPackage+'</b>'

  #Custom Schema
  Actions.c 'Building SDATA DB Schema version '+version+' for "'+sdata_schema+'" from scratch on '+CONFIG.get['ORACLE_HOST_IP'] if (!version.nil?)
  Actions.c 'Building SDATA DB Schema LAST version for "'+sdata_schema+'" from scratch on '+CONFIG.get['ORACLE_HOST_IP'] if (version.nil?)

  cmd = "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" && chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" && chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+"db_config_sdata_example.sql"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

  if (!CONFIG.get['SDATA_EXTRACT_FOLDER'].nil?)
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" extract_to: "+CONFIG.get['SDATA_EXTRACT_FOLDER']+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version
    Actions.c 'Using SDATA_EXTRACT_FOLDER = '+CONFIG.get['SDATA_EXTRACT_FOLDER']
  else
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version
  end

  res = Actions.SSH(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i, false, '')

end


def customPtradeSchemaDeploy(version)
  fail('Please define missing params ORACLE_HOST...') if (CONFIG.get['ORACLE_HOST'].nil?)

  Actions.c 'Building PTRADE DB Schema Version - '+version+' from scratch... ' if (!version.nil?)
  Actions.c 'Building PTRADE DB Schema LAST Version from scratch... ' if (version.nil?)

  createAutomationDirForUser(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  uploadDirToRemoteAutomationFolder(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')

  if (version.nil? || version.to_s.empty?)

    cmd = "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh "
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

    cmd ="chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh"
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, false, '')

    #cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh -n "+version  if (!version.nil?)
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh" if (version.nil?)
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 300, false, '')
  else

    cmd =  "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/buildSchema_ptrade.sh"
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

    cmd ="chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/buildSchema_ptrade.sh"
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, false, '')

    cmd =  "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh"
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

    cmd ="chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh"
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, false, '')

    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh -n "+version
    res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 300, false, '')

  end

end

def customPtradeSchemaDeployLab(version)
  fail('Please define missing params ORACLE_HOST_IP') if (CONFIG.get['ORACLE_HOST_IP'].nil?)

  mountHost = CONFIG.get['MOUNT_HOST']
  mountUser = CONFIG.get['MOUNT_USER']
  mountPwd = CONFIG.get['MOUNT_PWD']
  downloadFolder = "/export/home/"+mountUser+"/Automation_download"
  installScript = "ptradeDB_schema_install_automatic.sh"
  installSupportFile = ""
  downloadScript = "ptradeDB_schema_download_automatic.sh"
  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    installScript = "ptradeDB_schema1_install_automatic.sh"
    installSupportFile = "db_config_qa_ptrade_example.sql"
    downloadScript = "ptradeDB_schema1_download_automatic.sh"
  end
  scpScript = "scpFileRemotely.sh"

  Actions.c '<b>Getting PTRADE DB Schema version '+version+' for "'+CONFIG.get['PTRADE_SCHEMA']+'"...</b>' if (!version.nil?)
  Actions.c '<b>Getting the LAST version of PTRADE DB Schema for "'+CONFIG.get['PTRADE_SCHEMA']+'"...</b>' if (version.nil?)

  cmd = "rm -rf "+downloadFolder+" && mkdir -p "+downloadFolder
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,20,false,'')

  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+downloadScript,downloadFolder+'/'+downloadScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,downloadScript,'755')
  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+scpScript,downloadFolder+'/'+scpScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,scpScript,'755')

  cmd = downloadFolder+'/'+downloadScript if (version.nil?)
  cmd = downloadFolder+'/'+downloadScript+" -n "+version  if (!version.nil?)
  res = Actions.SSH(mountHost, mountUser, mountPwd, cmd, 500, true, '')

  env_version = Actions.displayDownloadedTarVersion(CONFIG.get['PTRADE_SCHEMA'],true,mountHost,mountUser,mountPwd)
  downloadedPackage = downloadFolder+'/'+env_version
  targetPackage = CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version

  cmd = 'ls -lA '+downloadedPackage
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,5,true,'')
  Actions.c 'Package found: '+res if(res)
  Actions.c 'Copying files to '+CONFIG.get['ORACLE_HOST_IP']+'...'

  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/'+installScript, CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript,40)
  Actions.rigthsForFile(CONFIG.get['ORACLE_HOST_IP'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH'],installScript,'755')
  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/'+installSupportFile, CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installSupportFile,40)
  end
  Actions.transferFileRemotely(scpScript,mountHost,mountUser,mountPwd,CONFIG.get['ORACLE_HOST_IP'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],downloadFolder,CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH'],env_version)

  Actions.c '<b>Downloaded package '+env_version+' to '+targetPackage+'</b>'
  Actions.c 'Building PTRADE DB Schema version '+version+' from scratch for "'+CONFIG.get['PTRADE_SCHEMA']+'"...' if (!version.nil?)
  Actions.c 'Building PTRADE DB Schema LAST version from scratch for "'+CONFIG.get['PTRADE_SCHEMA']+'"...' if (version.nil?)

  if (!CONFIG.get['PTRADE_DB_EXTRACT_FOLDER'].nil?)
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" extract_to: "+CONFIG.get['PTRADE_DB_EXTRACT_FOLDER']+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version
    Actions.c 'Using PTRADE_DB_EXTRACT_FOLDER = '+CONFIG.get['PTRADE_DB_EXTRACT_FOLDER']
  else
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version
  end

  res = Actions.SSH(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i, false, '')

end


def customPtradeOldSchemaDeploy(version)
  fail('Please define missing params ORACLE_HOST...') if (CONFIG.get['ORACLE_HOST'].nil?)

  Actions.c 'Building PTRADE DB Schema Version - '+version+' from scratch... ' if (!version.nil?)
  Actions.c 'Building PTRADE DB Schema LAST Version from scratch... ' if (version.nil?)

  createAutomationDirForUser(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  uploadDirToRemoteAutomationFolder(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')


  cmd =  "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/buildSchema_ptrade1.sh"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

  cmd ="chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/buildSchema_ptrade1.sh"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, false, '')

  cmd =  "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema1_install_automatic.sh"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

  cmd ="chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema1_install_automatic.sh"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, false, '')

  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema1_install_automatic.sh -n "+version if(!version.nil? && !version.to_s.empty?)
  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema1_install_automatic.sh"+version if(version.nil? || version.to_s.empty?) #WTF, man?
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 300, false, '')

end

def customPtradeOldSchemaDeploy2(version)
  fail('Please define missing params ORACLE_HOST') if (CONFIG.get['ORACLE_HOST'].nil?)

  Actions.c 'Building PTRADE DB Schema Version - '+version+' for '+CONFIG.get['CORE_HOST_USER1']+' from scratch... ' if (!version.nil?)
  Actions.c 'Building PTRADE DB Schema LAST Version  for '+CONFIG.get['CORE_HOST_USER1']+' from scratch... ' if (version.nil?)

  schemaInstallScript1 = 'ptradeDB_schema1_install_automatic.sh'
  schemaBuildScript1 = 'buildSchema_ptrade1.sh'
  dbConfigExample1 = 'db_config_qa_ptrade_example.sql'

  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],Dir.getwd+'/templates/bash/'+schemaInstallScript1,CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/'+schemaInstallScript1,40)
  Actions.rigthsForFile(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation',schemaInstallScript1,'755')

  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],Dir.getwd+'/templates/bash/'+schemaBuildScript1,CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/'+schemaBuildScript1,40)
  Actions.rigthsForFile(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation',schemaBuildScript1,'755')

  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],Dir.getwd+'/templates/bash/'+dbConfigExample1,CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/'+dbConfigExample1,40)
  Actions.rigthsForFile(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation',dbConfigExample1,'755')

  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/"+schemaInstallScript1+" -n "+version if(!version.nil? || !version.to_s.empty?)
  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/"+schemaInstallScript1 if(version.nil? || version.to_s.empty?)
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 600, true, '')

  return res
end


def customPtradeNewSchemaDeploy(version)
  fail('Please define missing params ORACLE_HOST...') if (CONFIG.get['ORACLE_HOST'].nil?)

  Actions.c 'Building PTRADE DB Schema Version - '+version+' for '+CONFIG.get['CORE_HOST_USER']+' from scratch... ' if (!version.nil?)
  Actions.c 'Building PTRADE DB Schema LAST Version  for '+CONFIG.get['CORE_HOST_USER']+' from scratch... ' if (version.nil?)

  createAutomationDirForUser(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  uploadDirToRemoteAutomationFolder(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')

  cmd = "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

  cmd ="chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, false, '')

  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh -n "+version  if(!version.nil? && !version.to_s.empty?)
  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_install_automatic.sh" if(version.nil? || version.to_s.empty?)
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 300, false, '')

end

def customPtradeNewSchemaDeploy2(version)
  fail('Please define missing params ORACLE_HOST') if (CONFIG.get['ORACLE_HOST'].nil?)

  Actions.c 'Building PTRADE DB Schema Version - '+version+' for ptrade from scratch... ' if (!version.nil?)
  Actions.c 'Building PTRADE DB Schema LAST Version for ptrade from scratch... ' if (version.nil?)

  schemaInstallScript = 'ptradeDB_schema_install_automatic.sh'

  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],Dir.getwd+'/templates/bash/'+schemaInstallScript,CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation/'+schemaInstallScript,40)
  Actions.rigthsForFile(CONFIG.get['ORACLE_HOST'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation',schemaInstallScript,'755')

  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/"+schemaInstallScript+" -n "+version if(!version.nil? || !version.to_s.empty?)
  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/"+schemaInstallScript if(version.nil? || version.to_s.empty?)
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 600, true, '')

  return res
end


def customPtradeAppDeploy(version)
  stopPtradeServiceNoFails(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  createAutomationDirForUser(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  uploadDirToRemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  buildPtradeApp(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'ptradeAPP_build_install_automatic.sh', Dir.getwd+'/templates/bash/', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation','') if(version.nil? || version.to_s.empty?)
  displayPtradeAppVersion(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end


def customPtradeAppDeployLab(version, isUpgrade)

  mountHost = CONFIG.get['MOUNT_HOST']
  mountUser = CONFIG.get['MOUNT_USER']
  mountPwd = CONFIG.get['MOUNT_PWD']
  downloadFolder = "/export/home/"+mountUser+"/Automation_download"
  if isUpgrade
    installScript = "ptradeAPP_build_upgrade_automatic.sh"
  else
    installScript = "ptradeAPP_build_install_automatic.sh"
  end
  downloadScript = "ptradeAPP_build_download_automatic_oracle.sh"
  scpScript = "scpFileRemotely.sh"

  Actions.c '<b>Getting PTRADE App version '+version+'...</b>' if (!version.nil?)
  Actions.c '<b>Getting the LAST version of PTRADE App...</b>' if (version.nil?)

  cmd = "rm -rf "+downloadFolder+" && mkdir -p "+downloadFolder
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,20,false,'')

  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+downloadScript,downloadFolder+'/'+downloadScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,downloadScript,'755')
  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+scpScript,downloadFolder+'/'+scpScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,scpScript,'755')

  cmd = "dos2unix "+downloadFolder+'/'+downloadScript+" && "+"chmod 755 "+downloadFolder+'/'+downloadScript
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,10,true,'')

  cmd = downloadFolder+'/'+downloadScript if (version.nil?)
  cmd = downloadFolder+'/'+downloadScript+" -n "+version  if (!version.nil?)
  res = Actions.SSH(mountHost, mountUser, mountPwd, cmd, 500, true, '')

  env_version = Actions.displayDownloadedTarVersion('ptrade',false,mountHost,mountUser,mountPwd)
  downloadedPackage = downloadFolder+'/'+env_version
  targetPackage = CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['CORE_HOST_USER']+"/Automation/"+env_version

  cmd = 'ls -lA '+downloadedPackage
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,5,true,'')
  Actions.c 'Package found: '+res if(res)
  Actions.c 'Copying files to '+CONFIG.get['CORE_HOST_IP']+'...'

  Actions.uploadTemplates2(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash/'+installScript, CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+installScript,40)
  Actions.transferFileRemotely(scpScript,mountHost,mountUser,mountPwd,CONFIG.get['CORE_HOST_IP'],CONFIG.get['CORE_HOST_USER'],CONFIG.get['CORE_HOST_PWD'],downloadFolder,CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH'],env_version)

  Actions.c '<b>Downloaded package '+env_version+' to '+targetPackage+'</b>'
  Actions.c 'Building the version '+version+' PTRADE App from scratch...' if (!version.nil?)
  Actions.c 'Building the LAST version of PTRADE App from scratch...' if (version.nil?)

  cmd = "dos2unix "+CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+"/"+installScript+" && chmod 755 "+CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+"/"+installScript
  res = Actions.SSH(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 10, true, '')

  if (!CONFIG.get['PTRADE_APP_EXTRACT_FOLDER'].nil? && CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil?)
    cmd = CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+installScript+" extract_to: "+CONFIG.get['PTRADE_APP_EXTRACT_FOLDER']+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['CORE_HOST_USER']+"/Automation/"+env_version
    Actions.c 'Using PTRADE_APP_EXTRACT_FOLDER = '+CONFIG.get['PTRADE_APP_EXTRACT_FOLDER']
  elsif (CONFIG.get['PTRADE_APP_EXTRACT_FOLDER'].nil? && !CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil?)
    cmd = CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+installScript+" install_to: "+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['CORE_HOST_USER']+"/Automation/"+env_version
    Actions.c 'Using PTRADE_APP_INSTALL_FOLDER = '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']
  elsif (!CONFIG.get['PTRADE_APP_EXTRACT_FOLDER'].nil? && !CONFIG.get['PTRADE_APP_INSTALL_FOLDER'].nil?)
    cmd = CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+installScript+" extract_to: "+CONFIG.get['PTRADE_APP_EXTRACT_FOLDER']+" install_to: "+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['CORE_HOST_USER']+"/Automation/"+env_version
    Actions.c 'Using PTRADE_APP_EXTRACT_FOLDER = '+CONFIG.get['PTRADE_APP_EXTRACT_FOLDER']+', PTRADE_APP_INSTALL_FOLDER = '+CONFIG.get['PTRADE_APP_INSTALL_FOLDER']
  else
    cmd = CONFIG.get['REMOTE_PTRADE_TEMPLATE_DIR_PATH']+'/'+installScript+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['CORE_HOST_USER']+"/Automation/"+env_version
  end

  res = Actions.SSH(CONFIG.get['CORE_HOST_IP'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i, false, '')

end


def MdsAppDeploy(version, user)

  if user == CONFIG.get['MDS_HOST_USER']
    installScript = 'MDS_build_install_automatic.sh'
    remoteAutomation = CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['MDS_HOST_USER']+'/Automation'
  elsif user == CONFIG.get['MDS_HOST_USER1']
    installScript = 'MDS_build1_install_automatic.sh'
    remoteAutomation = CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['MDS_HOST_USER1']+'/Automation'
  else
    Actions.f('ERROR: invalid user "'+user+'", only users '+CONFIG.get['MDS_HOST_USER']+' and '+CONFIG.get['MDS_HOST_USER1']+' are allowed')
    fail('ERROR: invalid user "'+user+'"')
  end

  Actions.uploadTemplates2(CONFIG.get['MDS_HOST_IP'], user, CONFIG.get['MDS_HOST_PWD'], Dir.getwd+'/templates/bash/'+installScript, remoteAutomation+'/'+installScript, 20)
  Actions.rigthsForFile(CONFIG.get['MDS_HOST_IP'], user, CONFIG.get['MDS_HOST_PWD'], remoteAutomation, installScript, '755')

  cmd = 'cd '+remoteAutomation+' && ./'+installScript if(version.nil? || version.to_s.empty?)
  cmd = 'cd '+remoteAutomation+' && ./'+installScript+' -n '+version.to_s if(!version.nil? && !version.to_s.empty?)
  res = Actions.SSH(CONFIG.get['MDS_HOST_IP'], user, CONFIG.get['MDS_HOST_PWD'], cmd, CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i, false, '')

  old_version = Actions.getEnvVar(CONFIG.get['MDS_HOST_IP'],CONFIG.get['MDS_HOST_USER1'],CONFIG.get['MDS_HOST_PWD'],'AUTOMATION_PACKAGE_NAME_MDS_APP1')
  Actions.c '<b>Source MDS version: </b>'+old_version.to_s if user == CONFIG.get['MDS_HOST_USER1'] if user == CONFIG.get['MDS_HOST_USER1']
  new_version = Actions.getEnvVar(CONFIG.get['MDS_HOST_IP'],CONFIG.get['MDS_HOST_USER'],CONFIG.get['MDS_HOST_PWD'],'AUTOMATION_PACKAGE_NAME_MDS_APP')
  Actions.c '<b>Target MDS version: </b>'+new_version.to_s if user == CONFIG.get['MDS_HOST_USER']

  return res.to_s
end


def MdsAppDeploy2(version, host, user, pwd, prefix='MDS', downloadFolder='Automation_download')

  fail('Please define missing param MOUNT_HOST') if (CONFIG.get['MOUNT_HOST'].nil?)
  fail('Please define missing param MOUNT_USER') if (CONFIG.get['MOUNT_USER'].nil?)
  fail('Please define missing param MOUNT_PWD') if (CONFIG.get['MOUNT_PWD'].nil?)

  installScript = 'MDS_build_install_automatic_custom.sh'
  remoteAutomation = '/export/home/'+user+'/Automation'
  mountHost = CONFIG.get['MOUNT_HOST']
  mountUser = CONFIG.get['MOUNT_USER']
  mountPwd = CONFIG.get['MOUNT_PWD']
  downloadFolder = '/export/home/'+mountUser+'/'+downloadFolder
  downloadScript = 'MDS_build_download_automatic.sh'
  scpScript = 'scpFileRemotely.sh'

  Actions.v '<b>Getting MDS package ver. '+version+'...</b>' if (!version.nil?)
  Actions.v '<b>Getting the LAST version of MDS...</b>' if (version.nil?)

  Actions.removeOldFilesByQuantityRemoteBash(mountHost,mountUser,mountPwd,downloadFolder)

  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+downloadScript,downloadFolder+'/'+downloadScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,downloadScript,'755')
  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+scpScript,downloadFolder+'/'+scpScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,scpScript,'755')

  downloadScript = downloadScript+' PREFIX: '+prefix+' USER_NAME: '+mountUser
  downloadScript = downloadScript+' -n '+version  if (!version.nil?)

  cmd = downloadFolder+'/'+downloadScript
  res = Actions.SSH(mountHost, mountUser, mountPwd, cmd, 500, false, '')

  env_version = Actions.displayDownloadedTarVersionCustom(prefix+'_'+mountUser,mountHost,mountUser,mountPwd)
  if (env_version.nil? || env_version.to_s.empty?)
    Actions.f 'ERROR: env var with the name of the downloaded package not found'
    fail('ERROR: env var with the name of the downloaded package name not found')
  end

  downloadedPackage = downloadFolder+'/'+env_version
  targetPackage = CONFIG.get['REMOTE_HOME']+'/'+user+'/Automation/'+env_version

  cmd = 'ls -lA '+downloadedPackage
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,5,true,'')
  Actions.v 'Package found: '+res if(res)
  Actions.v 'Copying files to '+user+'@'+host+'...'

  Actions.transferFileRemotely(scpScript,mountHost,mountUser,mountPwd,host,user,pwd,downloadFolder,remoteAutomation,env_version)

  cmd =  'ls -lA '+targetPackage
  res = Actions.SSH(host,user,pwd,cmd,20,true,'')
  Actions.v '<b>Downloaded package '+targetPackage+':</b>'+res.to_s

  Actions.c 'Building MDS version '+version+' from scratch at '+user+'@'+host+'...' if (!version.nil?)
  Actions.c 'Building MDS LAST version from scratch at '+user+'@'+host+'...' if (version.nil?)

  Actions.uploadTemplates2(host, user, pwd, Dir.getwd+'/templates/bash/'+installScript, remoteAutomation+'/'+installScript, 20)
  Actions.rigthsForFile(host, user, pwd, remoteAutomation, installScript, '755')

  cmd = 'dos2unix '+remoteAutomation+'/'+installScript+' && chmod 755 '+remoteAutomation+'/'+installScript
  res = Actions.SSH(host,user,pwd,cmd,20,true,'')

  cmd = 'cd '+remoteAutomation+' && ./'+installScript+' PREFIX: '+prefix+' USER_NAME: '+user if(version.nil? || version.to_s.empty?)
  cmd = 'cd '+remoteAutomation+' && ./'+installScript+' PREFIX: '+prefix+' USER_NAME: '+user+' -p '+remoteAutomation+'/'+version.to_s if(!version.nil? && !version.to_s.empty?)
  res = Actions.SSH(host, user, pwd, cmd, CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i, false, '')

  version = Actions.getEnvVar(host, user, pwd, 'AUTOMATION_PACKAGE_NAME_'+prefix+'_'+user)
  Actions.c '<b>MDS version at '+user+'@'+host+': </b>'+version.to_s

  return res.to_s
end


def startRedis
  cmd = "/export/home/$USER/redis/src/startRedis.sh"
  res = Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 60)
end


def displaySanityLogs(with_sdata, with_sdata1, with_ptrade, with_ptrade1)
  downloadDblogsForSdataOldVersion if(with_sdata1)
  downloadDblogsForSdataNewVersion if(with_sdata)
  if(with_ptrade1)
    Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], "/export/home/"+CONFIG.get['CORE_HOST_USER1']+'/Automation/PTSlogsParser_ptrade1.sh', 120)
    sleep 20
    Actions.downloadCoreLogs(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  end
  if(with_ptrade)
    Actions.SSH_NO_FAIL(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], "/export/home/"+CONFIG.get['CORE_HOST_USER']+'/Automation/PTSlogsParser_ptrade.sh', 120)
    sleep 20
    Actions.downloadCoreLogs(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  end
  Actions.displayFilesForDownloadInFolder(Dir.getwd+'/logs/logs_'+@@time_stamp)
end


def downloadCustomBuildLogs(with_sdata,with_ptrade)
  downloadDblogsForSdataNewVersion if(with_sdata)
  Actions.downloadCoreLogs(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD']) if(with_ptrade)
end

##########builds

############Upgrade
def createAutomationDirForUserUpgrade(host, user, pwd)
  Actions.v 'Creating Automation dir on host '+host+' for user '+user+'... '
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/ers'
  res = Actions.SSH(host, user, pwd, cmd, 10, true, '')

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/ers2'
  res = Actions.SSH(host, user, pwd, cmd, 10, true, '')

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)

  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data/tickets'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data/tickets/common'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)
  cmd = 'mkdir -p '+CONFIG.get['REMOTE_HOME']+'/'+user+'/'+'Automation/data/tickets/myt'
  res = Actions.SSH_NO_FAIL(host, user, pwd, cmd, 10)

end

Given /^beforeScenarioSteps$/ do
  Actions.removeOldOutput
  Actions.createLocalDirs
  stopPtradeServiceNoFail(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  stopPtradeServiceNoFail(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  steps %Q{
      Given Automation dir exist on oracle server
    }

end


Given /^beforeScenarioStepsSdata$/ do
  Actions.removeOldOutput
  Actions.createLocalDirs
  moveAutomationDir(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  steps %Q{
      Given Automation dir exist on oracle server
  }
end


Given /^beforeScenarioStepsMDS$/ do
  # Actions.removeOldOutput
  fail('Please define Source dir to compare') if CONFIG.get['MDS_SOURCE_CALCULATOR_DIR'].to_s.empty?
  fail('Please define Target dir to compare') if CONFIG.get['MDS_TARGET_CALCULATOR_DIR'].to_s.empty?
  # Actions.createLocalDirsMDS
  # moveLogsDirsMDS(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'])
  # moveLogsDirsMDS(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'])
  # killArpProcess(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'])
  # killArpProcess(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'])
  killMdsProcess(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'])
  killMdsProcess(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'])
  moveAutomationDir(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'])
  moveAutomationDir(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'])
end


Given /^before scenario steps for 2 versions of MDS with 1 client each$/ do
  # Actions.removeOldOutput
  fail('Please define MDS_HOST_IP_OLD') if ENV['MDS_HOST_IP_OLD'].to_s.empty?
  fail('Please define MDS_HOST_USER_OLD') if ENV['MDS_HOST_USER_OLD'].to_s.empty?
  fail('Please define MDS_HOST_PWD_OLD') if ENV['MDS_HOST_PWD_OLD'].to_s.empty?
  fail('Please define MDS_HOST_IP_NEW') if ENV['MDS_HOST_IP_NEW'].to_s.empty?
  fail('Please define MDS_HOST_USER_NEW') if ENV['MDS_HOST_USER_NEW'].to_s.empty?
  fail('Please define MDS_HOST_PWD_NEW') if ENV['MDS_HOST_PWD_NEW'].to_s.empty?
  Actions.createLocalDirsMDSsanityMSL(true)
  res = stopMDS(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_OLD']+'/MDS/bin')
  Actions.v 'Res of stopping MDS for the old version:'+"\n"+res.to_s
  res = stopMDS(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_IP_NEW']+'/MDS/bin')
  Actions.v 'Res of stopping MDS for the new version:'+"\n"+res.to_s
  moveAutomationDir(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'])
  moveAutomationDir(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'])
end


Given /^before scenario steps for 2 versions of MDS with 3 clients each/ do
  # Actions.removeOldOutput
  fail('Please define MDS_HOST_IP_OLD') if ENV['MDS_HOST_IP_OLD'].to_s.empty?
  fail('Please define MDS_HOST_USER_OLD') if ENV['MDS_HOST_USER_OLD'].to_s.empty?
  fail('Please define MDS_HOST_PWD_OLD') if ENV['MDS_HOST_PWD_OLD'].to_s.empty?
  fail('Please define MDS_HOST_IP_NEW') if ENV['MDS_HOST_IP_NEW'].to_s.empty?
  fail('Please define MDS_HOST_USER_NEW') if ENV['MDS_HOST_USER_NEW'].to_s.empty?
  fail('Please define MDS_HOST_PWD_NEW') if ENV['MDS_HOST_PWD_NEW'].to_s.empty?
  fail('Please define MDS_CLIENT_3_HOST') if ENV['MDS_CLIENT_3_HOST'].to_s.empty?
  fail('Please define MDS_CLIENT_3_USER') if ENV['MDS_CLIENT_3_USER'].to_s.empty?
  fail('Please define MDS_CLIENT_3_USER_2') if ENV['MDS_CLIENT_3_USER_2'].to_s.empty?
  fail('Please define MDS_CLIENT_3_PWD') if ENV['MDS_CLIENT_3_PWD'].to_s.empty?
  fail('Please define MDS_CLIENT_4_HOST') if ENV['MDS_CLIENT_4_HOST'].to_s.empty?
  fail('Please define MDS_CLIENT_4_USER') if ENV['MDS_CLIENT_4_USER'].to_s.empty?
  fail('Please define MDS_CLIENT_4_USER_2') if ENV['MDS_CLIENT_4_USER_2'].to_s.empty?
  fail('Please define MDS_CLIENT_4_PWD') if ENV['MDS_CLIENT_4_PWD'].to_s.empty?
  Actions.createLocalDirsMDSsanityMSL(true)
  res = stopMDS(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'], CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_USER_OLD']+'/MDS/bin')
  Actions.v 'Res of stopping MDS for the old version:'+"\n"+res.to_s
  res = stopMDS(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'], CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_HOST_IP_NEW']+'/MDS/bin')
  Actions.v 'Res of stopping MDS for the new version:'+"\n"+res.to_s
  moveAutomationDir(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'])
  moveAutomationDir(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'])
  moveAutomationDir(ENV['MDS_CLIENT_3_HOST'], ENV['MDS_CLIENT_3_USER'], ENV['MDS_CLIENT_3_PWD'])
  moveAutomationDir(ENV['MDS_CLIENT_3_HOST'], ENV['MDS_CLIENT_3_USER_2'], ENV['MDS_CLIENT_3_PWD_2'])
  moveAutomationDir(ENV['MDS_CLIENT_4_HOST'], ENV['MDS_CLIENT_4_USER'], ENV['MDS_CLIENT_4_PWD'])
  moveAutomationDir(ENV['MDS_CLIENT_4_HOST'], ENV['MDS_CLIENT_4_USER_2'], ENV['MDS_CLIENT_4_PWD_2'])
end


Given /^before scenario steps for performance testing$/ do
  # Actions.removeOldOutput
  fail('Please define MDS_PERF_HOST_IP') if ENV['MDS_PERF_HOST_IP'].to_s.empty?
  fail('Please define MDS_PERF_HOST_USER') if ENV['MDS_PERF_HOST_USER'].to_s.empty?
  fail('Please define MDS_PERF_HOST_PWD') if ENV['MDS_PERF_HOST_PWD'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_IP') if ENV['MDS_PERF_CLIENT_IP'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_USER') if ENV['MDS_PERF_CLIENT_USER'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_PWD') if ENV['MDS_PERF_CLIENT_PWD'].to_s.empty?

  Actions.createLocalDirsMdsPerformance(true)
  res = stopMDS(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_PERF_HOST_USER']+'/MDS/bin')
  Actions.v 'Res of stopping MDS:'+"\n"+res.to_s

  moveAutomationDir(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'])
  moveAutomationDir(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])

  moveLogsDirsMDS2(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'])
  moveLogsDirsMDS2(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
end


Given /^before scenario steps for 2 MDS versions concurrent performance testing via MSL$/ do
  # Actions.removeOldOutput
  fail('Please define MDS_PERF_HOST_IP') if ENV['MDS_PERF_HOST_IP'].to_s.empty?
  fail('Please define MDS_PERF_HOST_USER') if ENV['MDS_PERF_HOST_USER'].to_s.empty?
  fail('Please define MDS_PERF_HOST_PWD') if ENV['MDS_PERF_HOST_PWD'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_IP') if ENV['MDS_PERF_CLIENT_IP'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_USER') if ENV['MDS_PERF_CLIENT_USER'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_PWD') if ENV['MDS_PERF_CLIENT_PWD'].to_s.empty?
  fail('Please define MDS_PERF_VERSION') if ENV['MDS_PERF_VERSION'].to_s.empty?
  fail('Please define MDS_CLIENTS_QUANTITY') if ENV['MDS_CLIENTS_QUANTITY'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_PORT') if ENV['MDS_PERF_CLIENT_PORT'].to_s.empty?
  fail('Please define ConnectToSdata') if ENV['ConnectToSdata'].to_s.empty?

  fail('Please define MDS_PERF_HOST_IP_2') if ENV['MDS_PERF_HOST_IP_2'].to_s.empty?
  fail('Please define MDS_PERF_HOST_USER_2') if ENV['MDS_PERF_HOST_USER_2'].to_s.empty?
  fail('Please define MDS_PERF_HOST_PWD_2') if ENV['MDS_PERF_HOST_PWD_2'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_IP_2') if ENV['MDS_PERF_CLIENT_IP_2'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_USER_2') if ENV['MDS_PERF_CLIENT_USER_2'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_PWD_2') if ENV['MDS_PERF_CLIENT_PWD_2'].to_s.empty?
  fail('Please define MDS_PERF_VERSION_2') if ENV['MDS_PERF_VERSION_2'].to_s.empty?
  fail('Please define MDS_CLIENTS_QUANTITY_2') if ENV['MDS_CLIENTS_QUANTITY_2'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_PORT_2') if ENV['MDS_PERF_CLIENT_PORT_2'].to_s.empty?
  fail('Please define ConnectToSdata_2') if ENV['ConnectToSdata_2'].to_s.empty?

  fail('Please define USE_MSL_LOADER') if ENV['USE_MSL_LOADER'].to_s.empty?
  if ENV['USE_MSL_LOADER'] == 'true'
    fail('Please define MSL_LOADER_PATH') if ENV['MSL_LOADER_PATH'].to_s.empty?
    fail('Please define MSL_LOADER_ARB_LOG_PATH') if ENV['MSL_LOADER_ARB_LOG_PATH'].to_s.empty?
    fail('Please define MSL_IP') if ENV['MSL_IP'].to_s.empty?
    fail('Please define MSL_LOADER_START_TIME') if ENV['MSL_LOADER_START_TIME'].to_s.empty?
    fail('Please define MSL_LOADER_STOP_TIME') if ENV['MSL_LOADER_STOP_TIME'].to_s.empty?
  end
  if ENV['MSL_LOADER_WAIT_TIME'].to_s.empty?
    fail('Please define MDS_WAIT_TIME') if ENV['MDS_WAIT_TIME'].to_s.empty?
  end
  fail('Please define DEPLOY_MDS') if ENV['DEPLOY_MDS'].to_s.empty?
  fail('Please define DEPLOY_MDS_2') if ENV['DEPLOY_MDS_2'].to_s.empty?
  if (ENV['DEPLOY_MDS'] == 'true' || ENV['DEPLOY_MDS_2'] == 'true')
    fail('Please define MOUNT_HOST') if ENV['MOUNT_HOST'].to_s.empty?
    fail('Please define MOUNT_USER') if ENV['MOUNT_USER'].to_s.empty?
    fail('Please define MOUNT_PWD') if ENV['MOUNT_PWD'].to_s.empty?
  end

  Actions.createLocalDirsMdsPerformance(false)

  res = stopMDS(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_PERF_HOST_USER']+'/MDS/bin')
  Actions.v 'Res of stopping MDS:'+"\n"+res.to_s
  res = stopMDS(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'], CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_PERF_HOST_USER_2']+'/MDS/bin')
  Actions.v 'Res of stopping MDS:'+"\n"+res.to_s

  moveAutomationDir(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'])
  moveAutomationDir(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
  moveAutomationDir(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'])
  moveAutomationDir(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'])

  moveLogsDirsMDS2(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'])
  moveLogsDirsMDS2(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
  moveLogsDirsMDS2(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'])
  moveLogsDirsMDS2(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'])
end


Given /^before scenario steps for 2 MDS versions concurrent performance testing via LFR$/ do
  # Actions.removeOldOutput
  fail('Please define MDS_PERF_HOST_IP') if ENV['MDS_PERF_HOST_IP'].to_s.empty?
  fail('Please define MDS_PERF_HOST_USER') if ENV['MDS_PERF_HOST_USER'].to_s.empty?
  fail('Please define MDS_PERF_HOST_PWD') if ENV['MDS_PERF_HOST_PWD'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_IP') if ENV['MDS_PERF_CLIENT_IP'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_USER') if ENV['MDS_PERF_CLIENT_USER'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_PWD') if ENV['MDS_PERF_CLIENT_PWD'].to_s.empty?
  # fail('Please define MDS_PERF_VERSION') if ENV['MDS_PERF_VERSION'].to_s.empty?
  fail('Please define MDS_CLIENTS_QUANTITY') if ENV['MDS_CLIENTS_QUANTITY'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_PORT') if ENV['MDS_PERF_CLIENT_PORT'].to_s.empty?
  fail('Please define ConnectToSdata') if ENV['ConnectToSdata'].to_s.empty?

  fail('Please define MDS_PERF_HOST_IP_2') if ENV['MDS_PERF_HOST_IP_2'].to_s.empty?
  fail('Please define MDS_PERF_HOST_USER_2') if ENV['MDS_PERF_HOST_USER_2'].to_s.empty?
  fail('Please define MDS_PERF_HOST_PWD_2') if ENV['MDS_PERF_HOST_PWD_2'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_IP_2') if ENV['MDS_PERF_CLIENT_IP_2'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_USER_2') if ENV['MDS_PERF_CLIENT_USER_2'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_PWD_2') if ENV['MDS_PERF_CLIENT_PWD_2'].to_s.empty?
  # fail('Please define MDS_PERF_VERSION_2') if ENV['MDS_PERF_VERSION_2'].to_s.empty?
  fail('Please define MDS_CLIENTS_QUANTITY_2') if ENV['MDS_CLIENTS_QUANTITY_2'].to_s.empty?
  fail('Please define MDS_PERF_CLIENT_PORT_2') if ENV['MDS_PERF_CLIENT_PORT_2'].to_s.empty?
  fail('Please define ConnectToSdata_2') if ENV['ConnectToSdata_2'].to_s.empty?

  if ENV['LFR_LOADER_WAIT_TIME'].to_s.empty?
    fail('Please define MDS_WAIT_TIME') if ENV['MDS_WAIT_TIME'].to_s.empty?
  else
    fail('Please define LFR_LOADER_WAIT_TIME') if ENV['LFR_LOADER_WAIT_TIME'].to_s.empty?
  end

  fail('Please define MDS_LFR_HOST_IP') if ENV['MDS_LFR_HOST_IP'].to_s.empty?
  fail('Please define MDS_LFR_HOST_USER') if ENV['MDS_LFR_HOST_USER'].to_s.empty?
  fail('Please define MDS_LFR_HOST_PWD') if ENV['MDS_LFR_HOST_PWD'].to_s.empty?
  fail('Please define MDS_LFR_FOLDER_PATH') if ENV['MDS_LFR_FOLDER_PATH'].to_s.empty?
  fail('Please define MDS_LFR_ARB_LOG_PATH') if ENV['MDS_LFR_ARB_LOG_PATH'].to_s.empty?
  fail('Please define MDS_LFR_PORT') if ENV['MDS_LFR_PORT'].to_s.empty?
  fail('Please define MDS_LFR_PORT_2') if ENV['MDS_LFR_PORT_2'].to_s.empty?
  fail('Please define MDS_LFR_STOP_TIME') if ENV['MDS_LFR_STOP_TIME'].to_s.empty?

  fail('Please define DEPLOY_MDS') if ENV['DEPLOY_MDS'].to_s.empty?
  fail('Please define DEPLOY_MDS_2') if ENV['DEPLOY_MDS_2'].to_s.empty?
  if (ENV['DEPLOY_MDS'] == 'true' || ENV['DEPLOY_MDS_2'] == 'true')
    fail('Please define MOUNT_HOST') if ENV['MOUNT_HOST'].to_s.empty?
    fail('Please define MOUNT_USER') if ENV['MOUNT_USER'].to_s.empty?
    fail('Please define MOUNT_PWD') if ENV['MOUNT_PWD'].to_s.empty?
  end

  Actions.createLocalDirsMdsPerformance(false)

  res = stopMDS(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'], CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_PERF_HOST_USER']+'/MDS/bin')
  Actions.v 'Res of stopping MDS:'+"\n"+res.to_s
  res = stopMDS(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'], CONFIG.get['REMOTE_HOME']+'/'+ENV['MDS_PERF_HOST_USER_2']+'/MDS/bin')
  Actions.v 'Res of stopping MDS:'+"\n"+res.to_s

  moveAutomationDir(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'])
  moveAutomationDir(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
  moveAutomationDir(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'])
  moveAutomationDir(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'])

  moveLogsDirsMDS2(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'])
  moveLogsDirsMDS2(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
  moveLogsDirsMDS2(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'])
  moveLogsDirsMDS2(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'])

  patternRemove = 'MDS_MAIN_.*b.*_.*-.*'
  hostRemove = ENV['MDS_PERF_HOST_IP']
  userRemove = ENV['MDS_PERF_HOST_USER']
  pwdRemove = ENV['MDS_PERF_HOST_PWD']
  Actions.removeOldFilesByMaskAndByQuantityRemoteBash(hostRemove, userRemove, pwdRemove, 'export/home/'+userRemove, patternRemove, '4')
  hostRemove = ENV['MDS_PERF_HOST_IP_2']
  userRemove = ENV['MDS_PERF_HOST_USER_2']
  pwdRemove = ENV['MDS_PERF_HOST_PWD_2']
  Actions.removeOldFilesByMaskAndByQuantityRemoteBash(hostRemove, userRemove, pwdRemove, 'export/home/'+userRemove, patternRemove, '4')
end


def upgradePtradeToNewLabVersion
  fail('Please define missing params ORACLE_HOST...') if (CONFIG.get['ORACLE_HOST'].nil?)
  Actions.c '<b>Performing PTRADE Upgrade...</b>'

  createAutomationDirForUser(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  uploadDirToRemoteAutomationFolder(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['ORACLE_HOST_USER']+'/Automation')

  cmd = "dos2unix "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_upgrade_automatic.sh"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

  cmd ="chmod 755 "+CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_upgrade_automatic.sh"
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 20, true, '')

  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_upgrade_automatic.sh" if(CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
  cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+"/ptradeDB_schema_upgrade_automatic.sh -n " +CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s if(!CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? && !CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty?)
  res = Actions.SSH(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, 600, true, '')

  return res

end

def upgradePtradeToNewLabVersionLab(version)
  fail('Please define missing params ORACLE_HOST_IP') if (CONFIG.get['ORACLE_HOST_IP'].nil?)

  mountHost = CONFIG.get['MOUNT_HOST']
  mountUser = CONFIG.get['MOUNT_USER']
  mountPwd = CONFIG.get['MOUNT_PWD']
  downloadFolder = "/export/home/"+mountUser+"/Automation_download"
  installScript = "ptradeDB_schema_upgrade_automatic.sh"
  downloadScript = "ptradeDB_schema_download_automatic.sh"
  if CONFIG.get['PTRADE_SCHEMA'] == 'ptrade1'
    installScript = "ptradeDB_schema1_upgrade_automatic.sh"
    downloadScript = "ptradeDB_schema1_download_automatic.sh"
  end
  scpScript = "scpFileRemotely.sh"

  Actions.c '<b>Getting PTRADE DB Schema version '+version+'...</b>' if (!version.nil?)
  Actions.c '<b>Getting the LAST version of PTRADE DB Schema...</b>' if (version.nil?)

  cmd = "rm -rf "+downloadFolder+" && mkdir -p "+downloadFolder
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,20,false,'')

  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+downloadScript,downloadFolder+'/'+downloadScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,downloadScript,'755')
  Actions.uploadTemplates2(mountHost,mountUser,mountPwd,Dir.getwd+'/templates/bash/'+scpScript,downloadFolder+'/'+scpScript,40)
  Actions.rigthsForFile(mountHost,mountUser,mountPwd,downloadFolder,scpScript,'755')

  cmd = downloadFolder+'/'+downloadScript if (version.nil?)
  cmd = downloadFolder+'/'+downloadScript+" -n "+version  if (!version.nil?)
  res = Actions.SSH(mountHost, mountUser, mountPwd, cmd, 500, true, '')

  env_version = Actions.displayDownloadedTarVersion(CONFIG.get['PTRADE_SCHEMA'],true,mountHost,mountUser,mountPwd)
  downloadedPackage = downloadFolder+'/'+env_version
  targetPackage = CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version

  cmd = 'ls -lA '+downloadedPackage
  res = Actions.SSH(mountHost,mountUser,mountPwd,cmd,5,true,'')
  Actions.c 'Package found: '+res if(res)
  if res.to_s.strip.include?('No such file or directory')
    @@scenario_fails.push('Copying failed, package '+downloadedPackage+' at '+mountUser+'@'+mountHost+' not found')
    fail('Copying failed, package '+downloadedPackage+' at '+mountUser+'@'+mountHost+' not found')
  end
  Actions.c 'Copying files to '+CONFIG.get['ORACLE_HOST_IP']+'...'

  Actions.uploadTemplates2(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], Dir.getwd+'/templates/bash/'+installScript, CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript,40)
  Actions.rigthsForFile(CONFIG.get['ORACLE_HOST_IP'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH'],installScript,'755')
  Actions.transferFileRemotely(scpScript,mountHost,mountUser,mountPwd,CONFIG.get['ORACLE_HOST_IP'],CONFIG.get['ORACLE_HOST_USER'],CONFIG.get['ORACLE_HOST_PWD'],downloadFolder,CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH'],env_version)

  Actions.c '<b>Downloaded package '+env_version+' to '+targetPackage+'</b>'
  Actions.c 'Upgrading to PTRADE DB Schema version '+version+' for "'+CONFIG.get['PTRADE_SCHEMA']+'"...' if (!version.nil?)
  Actions.c 'Upgrading to PTRADE DB Schema LAST version for "'+CONFIG.get['PTRADE_SCHEMA']+'"...' if (version.nil?)

  if (!CONFIG.get['PTRADE_DB_EXTRACT_FOLDER'].nil?)
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" extract_to: "+CONFIG.get['PTRADE_DB_EXTRACT_FOLDER']+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version
    Actions.c 'Using PTRADE_DB_EXTRACT_FOLDER = '+CONFIG.get['PTRADE_DB_EXTRACT_FOLDER']
  else
    cmd = CONFIG.get['REMOTE_ORACLE_TEMPLATE_DIR_PATH']+'/'+installScript+" -p "+CONFIG.get['REMOTE_HOME']+"/"+CONFIG.get['ORACLE_HOST_USER']+"/Automation/"+env_version
  end

  res = Actions.SSH(CONFIG.get['ORACLE_HOST_IP'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'], cmd, CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i, false, '')
end


Then /^DB tables DEAL TICKETS LEGS compared for both versions with latest version$/ do
  Actions.compareDbTableResultsForUpgrade(CONFIG.get['ORACLE_HOST_TEMPLATE_SCHEMA'], CONFIG.get['ORACLE_HOST_SCHEMA']) #('PTRADE1','PTRADE')
end


Then /^Old and New versions csv Folders are Matched excluding timestamps with latest version$/ do
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_csv/'+@@time_stamp + ' & mkdir latestVsUpgrade', 10)
  source_dir = Dir.getwd + '/templates/old_app_csv/'+@@time_stamp+'/latestVsUpgrade/'+@@time_stamp
  target_dir = Dir.getwd + '/templates/new_app_csv/'+@@time_stamp
  dir_count=Actions.compareCsvDirs(source_dir+'/common', target_dir+'/common')
  Actions.c (count-2).to_s+' folders have been compared in common folder' if(!$csv_folders_count.nil? && !dir_count.nil? && !dir_count[0].to_s.downcase.include?('error'))
  count=Actions.compareCsvDirs(source_dir+'/myt', target_dir+'/myt')
  Actions.c (count-2).to_s+' folders have been compared in myt folder' if(!$csv_folders_count.nil? && !dir_count.nil? && !dir_count[0].to_s.downcase.include?('error'))
  Actions.c $csv_files_count.to_s+' files have been compared' if(!$csv_files_count.nil?)

  if($csv_folders_count.nil? || $csv_folders_count==0)
    @@scenario_fails.push('0 Folders compared')
    Actions.f('0 Folders compared')
  end
  if($csv_files_count.nil? || $csv_files_count==0)
    @@scenario_fails.push('0 Files compared')
    Actions.f('0 Files compared')
  end

end


Then /^Old and New Saphire Jsons are Matched excluding sequence with latest version$/ do
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_json/'+@@time_stamp + ' & mkdir latestVsUpgrade', 10)
  template_json = Dir.getwd + '/templates/old_app_json/'+@@time_stamp+'/latestVsUpgrade/'+@@time_stamp+'/RedisMonitor1.txt'
  build_json = Dir.getwd + '/templates/new_app_json/'+@@time_stamp+'/RedisMonitor.txt'

  @@json_fails=[]
  Actions.c '<b>Comparing Sapphire Jsons...</b>'
  Actions.compareSaphireOutputJsonsForUpgrade(template_json, build_json)

end


def downloadCsvFolderForLatestVersion
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_csv/'+@@time_stamp + ' & mkdir latestVsUpgrade', 10)
  Actions.c 'Downloading MyT And Common csv files from Remote Folder for the Latest Lab Version'
  downloadDirFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/old_app_csv/'+@@time_stamp+'/latestVsUpgrade', CONFIG.get['MYT_CSV_REMOTE_DIR_PATH1'])
end


def downloadJsonForLatestVersion
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_json/'+@@time_stamp + ' & mkdir latestVsUpgrade', 10)
  Actions.v('Downloading Sapphire Json for the Latest Lab Version')
  downloadFileFromRemote(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'],Dir.getwd+'/templates/old_app_json/'+@@time_stamp+'/latestVsUpgrade',  '/export/home/'+CONFIG.get['CORE_HOST_USER1']+'/Automation', 'RedisMonitor1.txt')
end



def compareCsvWithDifferentTimestamps
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_csv/'+@@time_stamp + ' & mkdir latestVsUpgrade', 10)
  source_dir = Dir.getwd + '/templates/old_app_csv/'+@@time_stamp+'/latestVsUpgrade/'+@@time_stamp
  target_dir = Dir.getwd + '/templates/new_app_csv/'+$old_json_timestamp
  count=Actions.compareCsvDirs(source_dir+'/common', target_dir+'/common')
  Actions.c (count-2).to_s+' folders have been compared in common folder' if(!$csv_folders_count.nil?)
  count=Actions.compareCsvDirs(source_dir+'/myt', target_dir+'/myt')
  Actions.c (count-2).to_s+' folders have been compared in myt folder' if(!$csv_folders_count.nil?)
  #Actions.c $csv_files_count.to_s+' files have been compared' if(!$csv_files_count.nil?)

  if($csv_folders_count==0)
    @@scenario_fails.push('0 Folders compared')
    Actions.f('0 Folders compared')
  end
  if($csv_files_count==0)
    @@scenario_fails.push('0 Files compared')
    Actions.f('0 Files compared')
  end
end





def compareJsonWithDifferentTimestamps
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_json/'+@@time_stamp + ' & mkdir latestVsUpgrade', 10)
  template_json = Dir.getwd + '/templates/old_app_json/'+@@time_stamp+'/latestVsUpgrade/'+@@time_stamp+'/RedisMonitor1.txt'
  build_json = Dir.getwd + '/templates/new_app_json/'+$old_json_timestamp+'/RedisMonitor.txt'

  @@json_fails=[]
  Actions.compareSaphireOutputJsonsForUpgrade(template_json, build_json)
end


def changeTimeStamp
  time = Time.new
  @@time_stamp= time.day.to_s+'-'+time.month.to_s+'-'+time.year.to_s+'_'+time.hour.to_s+'-'+time.min.to_s+'-'+time.sec.to_s #Time.now.to_i.to_s
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/new_app_csv & mkdir '+@@time_stamp, 10)
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_csv'+' & mkdir '+@@time_stamp, 10)
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/new_app_json'+' & mkdir '+@@time_stamp, 10)
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/old_app_json'+' & mkdir '+@@time_stamp, 10)
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/myt/source'+' & mkdir '+@@time_stamp, 10)
  Actions.WINCMD_NO_FAIL('cd '+Dir.getwd+'/templates/myt/target'+' & mkdir '+@@time_stamp, 10)

end



def copyFile(file, from, to)
  Actions.v 'Copying file '+file+' from'+from+' to'+to
  cmd ="cp -f "+from+'/' + file+' '+to
  res = Actions.SSH(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], cmd, 10, false, '')
end




def debugUpgrade
  ##temp
  killRedisRoot(CONFIG.get['CORE_HOST'])
  stopPtradeServiceNoFail(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  stopPtradeServiceNoFail(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  createAutomationDirForUserUpgrade(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  uploadDirToRemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/bash', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  uploadDirToRemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/ers')
  uploadDirToRemoteAutomationFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/ers2', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/ers2')
  uploadDirToRemoteAutomationFolder(CONFIG.get['SAPHIRE_REDIS_HOST1'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['SAPHIRE_REMOTE_HOST1_PWD'], Dir.getwd+'/templates/config', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation')
  buildPtradeNewSchema(CONFIG.get['PTRADE_OLD_SCHEMA_VERSION'])
  buildPtradeApp(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'ptradeAPP_build_install_automatic.sh', Dir.getwd+'/templates/bash/', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation','') if(CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? || CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty? )
  buildPtradeApp(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'ptradeAPP_build_install_automatic.sh', Dir.getwd+'/templates/bash/', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/', CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU']) if(!CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].nil? || !CONFIG.get['PTRADE_NEW_SCHEMA_VERSION_OU'].to_s.empty? )
  displayPtradeAppAndDbVersionForUpgrade(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  upgradePtradeToNewLabVersion
  buildPtradeApp(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], 'ptradeAPP_build_install_automatic.sh', Dir.getwd+'/templates/bash/', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation','')
  uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/new_app_config2/prod.conf', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTS/config/prod.conf')
  uploadDirToRemoteFolder(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'], Dir.getwd+'/templates/new_app_config2/fix/rtns/qfj.cfg', CONFIG.get['REMOTE_HOME']+'/'+CONFIG.get['CORE_HOST_USER']+'/Automation/PTS/config/fix/rtns/qfj.cfg')
  displayPtradeAppAndDbVersionForUpgrade(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])

  Actions.cleanupMsl(CONFIG.get['CORE_HOST_USER1'], CONFIG.get['MSL_HOST']) #temp
  ### Run MslErSender with other folder <ers2> and Start 2nd app
  killRedisRoot(CONFIG.get['CORE_HOST'])
  restartRedisWithNewConfigForNewVersion
  restartPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  runRemoteMslSender4upgrade2(CONFIG.get['CORE_HOST_USER'], false, 'ers2', CONFIG.get['MSL_HOST'])
  stopPtradeService(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
  downloadCsvFolderForNewVersion
  downloadJsonForNewVersion
end


Given /^Automation dir is shifted on both oracle and app servers$/ do
  Actions.createLocalDirs

  moveAutomationDir(CONFIG.get['ORACLE_HOST'], CONFIG.get['ORACLE_HOST_USER'], CONFIG.get['ORACLE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER1'], CONFIG.get['CORE_HOST_PWD'])
  moveAutomationDir(CONFIG.get['CORE_HOST'], CONFIG.get['CORE_HOST_USER'], CONFIG.get['CORE_HOST_PWD'])
end


Given /^initial preparation$/ do
  Actions.createLocalDirsMdsPublisher
  Actions.setBuildProperty('EMAIL_TO',ENV['EMAIL_TO'])
end

cnfgFilesPathServer=''
serverCnfgFilename=''
cnfgFilesPathClient=''
clientCnfgFilename=''
Given /^running Publisher$/ do
  storagePathCnfgParent='C:\MDS_Publisher'

  @cnfgFolder=ENV['PUBLISHER_CNFG_FOLDER'].to_s

  if (@cnfgFolder != '--disabled--' && !@cnfgFolder.empty?)
    hostServerUsr=ENV['PUBLISHER_SERVER_USER']
    hostServerPwd=ENV['PUBLISHER_SERVER_PWD']

    hostClientUsr=ENV['PUBLISHER_CLIENT_USER']
    hostClientPwd=ENV['PUBLISHER_CLIENT_PWD']

    hostServer=ENV['PUBLISHER_SERVER_HOST']
    pathServer=ENV['PUBLISHER_SERVER_PATH']

    hostClient=ENV['PUBLISHER_CLIENT_HOST']
    pathClient=ENV['PUBLISHER_CLIENT_PATH']

    cnfgFilesPathServer=pathServer+@cnfgFolder.gsub('\\','/')
    cnfgFilesPathClient=pathClient+@cnfgFolder.gsub('\\','/')
    uploadDir2RemoteAutomationFolder2(hostServer, hostServerUsr, hostServerPwd, storagePathCnfgParent+@cnfgFolder, cnfgFilesPathServer)
    uploadDir2RemoteAutomationFolder2(hostClient, hostClientUsr, hostClientPwd, storagePathCnfgParent+@cnfgFolder, cnfgFilesPathClient)

    cnfgFilesArrPath=storagePathCnfgParent+@cnfgFolder
    cnfgFilesArr = Actions.WINCMD('IF exist '+cnfgFilesArrPath+'\ ( dir /b /a-d '+cnfgFilesArrPath+'\*.cnfg ) ELSE ( echo Dir "'+cnfgFilesArrPath+'" DOES NOT exist )', 20, '')

    cnfgFilesSortedArr=[]
    patternServer='server'
    patternClient='client'

    cnfgFilesArr.each do |elem|
      postfix='.cnfg'
      prefix=''
      elem2=''
      hashCurr={}
      if elem.to_s.include?(patternServer+postfix)
        prefix=elem.to_s.gsub(patternServer+postfix, '')

        if cnfgFilesArr.include?(prefix+patternClient+postfix)
          elem2=prefix+patternClient+postfix
        else
          Actions.c 'Not found matching client config file for "'+elem+'", using the default one'
          elem2=prefix+'NOT_SET'
        end

        hashCurr[patternServer]=elem
        hashCurr[patternClient]=elem2
        cnfgFilesSortedArr.push(hashCurr)
      end
    end

    cnfgFilesSortedArr.each do |elem|
      serverCnfgFilename=elem[patternServer]
      clientCnfgFilename=elem[patternClient]
      steps %Q{
        Given Publisher server is launched with config file "#{cnfgFilesPathServer+'/'+serverCnfgFilename}"
        Given Publisher client is launched with config file "#{cnfgFilesPathClient+'/'+clientCnfgFilename}"
        Then wait for given time period
        Then Publisher server is stopped
        Then Publisher server is killed
        Then Publisher client is stopped
        Then Publisher client is killed
        Then Publisher output is gathered
      }
    end
  elsif @cnfgFolder == '--disabled--'
    Actions.c 'Using default config file'

    steps %Q{
      Given Publisher server is launched
      Given Publisher client is launched
      Then wait for given time period
      Then Publisher server is stopped
      Then Publisher server is killed
      Then Publisher client is stopped
      Then Publisher client is killed
      Then Publisher output is gathered
    }
  elsif @cnfgFolder.empty?
    fail('Error: parameter PUBLISHER_CNFG_FOLDER should not be empty')
  end
end

Given /^Publisher files are copied from the storage$/ do
  hostServerUsr=ENV['PUBLISHER_SERVER_USER']
  hostServerPwd=ENV['PUBLISHER_SERVER_PWD']

  hostClientUsr=ENV['PUBLISHER_CLIENT_USER']
  hostClientPwd=ENV['PUBLISHER_CLIENT_PWD']

  hostServer=ENV['PUBLISHER_SERVER_HOST']
  pathServer=ENV['PUBLISHER_SERVER_PATH']

  hostClient=ENV['PUBLISHER_CLIENT_HOST']
  pathClient=ENV['PUBLISHER_CLIENT_PATH']

  storagePathServer='C:\MDS_Publisher\Server'
  storagePathClient='C:\MDS_Publisher\Client'

  cmd='ls -A '+pathServer
  res = Actions.SSH(hostServer, hostServerUsr, hostServerPwd, cmd, CONFIG.get['SSH_TIMEOUT'].to_i, true, '')
  if !res.to_s.strip.empty?
    Actions.c 'Found not empty directory with the same name ('+hostServer+':"'+pathServer+'"), renaming it'
    cmd='mv -f -v '+pathServer+' '+pathServer+'_$(date -d "today" +"%Y_%m_%d_%H-%M-%S")'
    res = Actions.SSH(hostServer, hostServerUsr, hostServerPwd, cmd, CONFIG.get['SSH_TIMEOUT'].to_i, true, '')
    Actions.v 'Result of renaming:'+"\n"+res.to_s.strip

    cmd='mkdir -p '+pathServer
    res = Actions.SSH(hostServer, hostServerUsr, hostServerPwd, cmd, CONFIG.get['SSH_TIMEOUT'].to_i, true, '')
  else
    cmd='mkdir -p '+pathServer
    res = Actions.SSH(hostServer, hostServerUsr, hostServerPwd, cmd, CONFIG.get['SSH_TIMEOUT'].to_i, true, '')
  end

  uploadDir2RemoteAutomationFolder2(hostServer, hostServerUsr, hostServerPwd, storagePathServer, pathServer)
  Actions.SSH(hostServer, hostServerUsr, hostServerPwd, 'chmod 755 '+pathServer+'/*.jar', CONFIG.get['SSH_TIMEOUT'].to_i, true, '')

  cmd='ls -A '+pathClient
  res = Actions.SSH(hostClient, hostClientUsr, hostClientPwd, cmd, CONFIG.get['SSH_TIMEOUT'].to_i, true, '')
  if !res.to_s.strip.empty?
    Actions.c 'Found not empty directory with the same name ('+hostServer+':"'+pathClient+'"), renaming it'
    cmd='mv -f -v '+pathClient+' '+pathClient+'_$(date -d "today" +"%Y_%m_%d_%H-%M-%S")'
    res = Actions.SSH(hostClient, hostClientUsr, hostClientPwd, cmd, CONFIG.get['SSH_TIMEOUT'].to_i, true, '')
    Actions.v 'Result of renaming:'+"\n"+res.to_s.strip

    cmd='mkdir -p '+pathClient
    res = Actions.SSH(hostClient, hostClientUsr, hostClientPwd, cmd, CONFIG.get['SSH_TIMEOUT'].to_i, true, '')
  else
    cmd='mkdir -p '+pathClient
    res = Actions.SSH(hostClient, hostClientUsr, hostClientPwd, cmd, CONFIG.get['SSH_TIMEOUT'].to_i, true, '')
  end

  uploadDir2RemoteAutomationFolder2(hostClient, hostClientUsr, hostClientPwd, storagePathClient, pathClient)
  Actions.SSH(hostClient, hostClientUsr, hostClientPwd, 'chmod 755 '+pathClient+'/*.jar', CONFIG.get['SSH_TIMEOUT'].to_i, true, '')
end


Given /^scripts are copied$/ do
  hostServerUsr=ENV['PUBLISHER_SERVER_USER']
  hostServerPwd=ENV['PUBLISHER_SERVER_PWD']

  hostClientUsr=ENV['PUBLISHER_CLIENT_USER']
  hostClientPwd=ENV['PUBLISHER_CLIENT_PWD']

  hostServer=ENV['PUBLISHER_SERVER_HOST']
  pathServer=ENV['PUBLISHER_SERVER_PATH']
  scriptServer='server.sh'

  hostClient=ENV['PUBLISHER_CLIENT_HOST']
  pathClient=ENV['PUBLISHER_CLIENT_PATH']
  scriptClient='client.sh'

  uploadFile2RemoteFolder2(hostServer,hostServerUsr,hostServerPwd,scriptServer,Dir.getwd+'/templates/Publisher',pathServer)
  Actions.rigthsForFile(hostServer,hostServerUsr,hostServerPwd,pathServer,scriptServer,'755')

  uploadFile2RemoteFolder2(hostClient,hostClientUsr,hostClientPwd,scriptClient,Dir.getwd+'/templates/Publisher',pathClient)
  Actions.rigthsForFile(hostClient,hostClientUsr,hostClientPwd,pathClient,scriptClient,'755')
end


def launchCmdReturnRes(host,usr,pwd,path,cmd)
  cmd = 'cd '+path+' && '+cmd
  res = Actions.SSH(host, usr, pwd, cmd, CONFIG.get['SSH_TIMEOUT'].to_i, true, '')
  return res
end


Given /^Publisher server is launched$/ do
  hostServerUsr=ENV['PUBLISHER_SERVER_USER']
  hostServerPwd=ENV['PUBLISHER_SERVER_PWD']

  hostServer=ENV['PUBLISHER_SERVER_HOST']
  pathServer=ENV['PUBLISHER_SERVER_PATH']
  scriptServer='server.sh'
  cmdServerRestart='./server.sh -restart'
  cmdServerStop='./server.sh -stop'

  Actions.v 'Launching server at '+hostServer+':'+pathServer
  Actions.rigthsForFile(hostServer,hostServerUsr,hostServerPwd,pathServer,scriptServer,'755')
  res=launchCmdReturnRes(hostServer,hostServerUsr,hostServerPwd,pathServer,cmdServerRestart)
  Actions.v 'Server launched: "'+res.to_s+'"'
  sleep 1
end

Given /^Publisher server is launched with config file "(.*?)"$/ do |config|
  hostServerUsr=ENV['PUBLISHER_SERVER_USER']
  hostServerPwd=ENV['PUBLISHER_SERVER_PWD']

  hostServer=ENV['PUBLISHER_SERVER_HOST']
  pathServer=ENV['PUBLISHER_SERVER_PATH']
  scriptServer='server.sh'
  cmdServerRestart='./server.sh CONFIG: '+config.to_s+' -restart'
  cmdServerStop='./server.sh -stop'

  Actions.c "----------------------------\n"+'Using config file "'+config.to_s+'"'
  Actions.v 'Launching server at '+hostServer+':'+pathServer
  Actions.rigthsForFile(hostServer,hostServerUsr,hostServerPwd,pathServer,scriptServer,'755')
  res=launchCmdReturnRes(hostServer,hostServerUsr,hostServerPwd,pathServer,cmdServerRestart)
  Actions.v 'Server launched: "'+res.to_s+'"'
  sleep 1
  serverLaunchConfig=config
end


Given /^Publisher client is launched$/ do
  hostClientUsr=ENV['PUBLISHER_CLIENT_USER']
  hostClientPwd=ENV['PUBLISHER_CLIENT_PWD']

  hostClient=ENV['PUBLISHER_CLIENT_HOST']
  pathClient=ENV['PUBLISHER_CLIENT_PATH']
  scriptClient='client.sh'
  cmdClientRestart='./client.sh -restart'
  cmdClientStop='./client.sh -stop'

  Actions.v 'Launching client at '+hostClient+':'+pathClient
  Actions.rigthsForFile(hostClient,hostClientUsr,hostClientPwd,pathClient,scriptClient,'755')
  res=launchCmdReturnRes(hostClient,hostClientUsr,hostClientPwd,pathClient,cmdClientRestart)
  Actions.v 'Client launched: "'+res.to_s+'"'
  sleep 1
end

clientLaunchConfig=''
Given /^Publisher client is launched with config file "(.*?)"$/ do |config|
  hostClientUsr=ENV['PUBLISHER_CLIENT_USER']
  hostClientPwd=ENV['PUBLISHER_CLIENT_PWD']

  hostClient=ENV['PUBLISHER_CLIENT_HOST']
  pathClient=ENV['PUBLISHER_CLIENT_PATH']
  scriptClient='client.sh'
  cmdClientRestart='./client.sh CONFIG: '+config.to_s+' -restart'
  cmdClientStop='./client.sh -stop'

  Actions.c 'Using config file "'+config.to_s+'"'
  Actions.v 'Launching client at '+hostClient+':'+pathClient
  Actions.rigthsForFile(hostClient,hostClientUsr,hostClientPwd,pathClient,scriptClient,'755')
  res=launchCmdReturnRes(hostClient,hostClientUsr,hostClientPwd,pathClient,cmdClientRestart)
  Actions.v 'Client launched: "'+res.to_s+'"'
  sleep 1
  clientLaunchConfig=config
end


Given /^wait for "(.*?)" seconds$/ do |timeSec|
  Actions.c 'Waiting '+timeSec.to_s+' seconds'
  sleep timeSec.to_i
end


Given /^wait for given time period$/ do
  timeSec=ENV['PUBLISHER_RUN_TIME_SEC']
  Actions.c 'Waiting '+timeSec.to_s+' seconds for Publisher to run'
  sleep timeSec.to_i
end


Given /^Publisher server is stopped$/ do
  hostServerUsr=ENV['PUBLISHER_SERVER_USER']
  hostServerPwd=ENV['PUBLISHER_SERVER_PWD']

  hostServer=ENV['PUBLISHER_SERVER_HOST']
  pathServer=ENV['PUBLISHER_SERVER_PATH']
  scriptServer='server.sh'
  cmdServerRestart='./server.sh -restart'
  cmdServerStop='./server.sh -stop'

  Actions.v 'Stopping server at '+hostServer+':'+pathServer
  res=launchCmdReturnRes(hostServer,hostServerUsr,hostServerPwd,pathServer,cmdServerStop)
  Actions.v 'Server stopped: "'+res.to_s+'"'
  sleep 1
end


Given /^Publisher server is killed$/ do
  sleep 1
  Actions.killPublisherServer
  sleep 1
end


Given /^Publisher client is stopped$/ do
  hostClientUsr=ENV['PUBLISHER_CLIENT_USER']
  hostClientPwd=ENV['PUBLISHER_CLIENT_PWD']

  hostClient=ENV['PUBLISHER_CLIENT_HOST']
  pathClient=ENV['PUBLISHER_CLIENT_PATH']
  scriptClient='client.sh'
  cmdClientRestart='./client.sh -restart'
  cmdClientStop='./client.sh -stop'

  Actions.v 'Stopping client at '+hostClient+':'+pathClient
  res=launchCmdReturnRes(hostClient,hostClientUsr,hostClientPwd,pathClient,cmdClientStop)
  Actions.v 'Client stopped: "'+res.to_s+'"'
  sleep 1
end


Given /^Publisher client is killed$/ do
  sleep 1
  Actions.killPublisherClient
  sleep 1
end


Given /^Publisher output is gathered$/ do
  hostServerUsr=ENV['PUBLISHER_SERVER_USER']
  hostServerPwd=ENV['PUBLISHER_SERVER_PWD']

  hostClientUsr=ENV['PUBLISHER_CLIENT_USER']
  hostClientPwd=ENV['PUBLISHER_CLIENT_PWD']

  hostServer=ENV['PUBLISHER_SERVER_HOST']
  pathServer=ENV['PUBLISHER_SERVER_PATH']
  scriptServer='server.sh'
  cmdServerRestart='./server.sh -restart'
  cmdServerStop='./server.sh -stop'

  hostClient=ENV['PUBLISHER_CLIENT_HOST']
  pathClient=ENV['PUBLISHER_CLIENT_PATH']
  scriptClient='client.sh'
  cmdClientRestart='./client.sh -restart'
  cmdClientStop='./client.sh -stop'

  serverConfigFile='server.cnfg'
  serverSnapshotFile='snapshot.txt'
  serverUpdateFile='update.txt'

  pathServerLogsDir=pathServer+'/logs_server'
  serverLog='server.log'
  serverLogRedirect='server_redirect.log'

  localDirServer=''
  pathServer2 = ''
  serverCnfgFilename2 = ''
  if !cnfgFilesPathClient.to_s.empty?
    localDirServer=Dir.getwd.gsub('/','\\')+'\logs\logs_'+@@time_stamp+'\server\\'+serverCnfgFilename.gsub('.cnfg','')
    pathServer2 = cnfgFilesPathServer
    serverCnfgFilename2 = serverCnfgFilename
  else
    localDirServer=Dir.getwd.gsub('/','\\')+'\logs\logs_'+@@time_stamp+'\server'
    pathServer2 = pathServer
    serverCnfgFilename2 = serverConfigFile
  end

  downloadFileFromRemoteWithoutTimestamp(hostServer, hostServerUsr, hostServerPwd, localDirServer, pathServer2, serverCnfgFilename2)
  downloadFileFromRemoteWithoutTimestamp(hostServer, hostServerUsr, hostServerPwd, localDirServer, pathServer, serverSnapshotFile)
  downloadFileFromRemoteWithoutTimestamp(hostServer, hostServerUsr, hostServerPwd, localDirServer, pathServer, serverUpdateFile)

  downloadFileFromRemoteWithoutTimestamp(hostServer, hostServerUsr, hostServerPwd, localDirServer, pathServerLogsDir, serverLog)
  downloadFileFromRemoteWithoutTimestamp(hostServer, hostServerUsr, hostServerPwd, localDirServer, pathServerLogsDir, serverLogRedirect)

  clientConfigFile='client.cnfg'
  clientSnapshotFile='snapshot.txt'
  clientUpdateFile='update.txt'

  pathClientLogsDir=pathClient+'/logs_client'
  clientLog='client.log'
  clientLogRedirect='client_redirect.log'

  pathClient2 = ''
  clientCnfgFilename2 = ''
  if !cnfgFilesPathClient.to_s.empty?
    localDirClient=Dir.getwd.gsub('/','\\')+'\logs\logs_'+@@time_stamp+'\client\\'+clientCnfgFilename.gsub('.cnfg','')
    pathClient2 = cnfgFilesPathClient
    clientCnfgFilename2 = clientCnfgFilename
  else
    localDirClient=Dir.getwd.gsub('/','\\')+'\logs\logs_'+@@time_stamp+'\client'
    pathClient2 = pathClient
    clientCnfgFilename2 = clientConfigFile
  end

  downloadFileFromRemoteWithoutTimestamp(hostClient, hostClientUsr, hostClientPwd, localDirClient, pathClient2, clientCnfgFilename2)
  downloadFileFromRemoteWithoutTimestamp(hostClient, hostClientUsr, hostClientPwd, localDirClient, pathClient, clientSnapshotFile)
  downloadFileFromRemoteWithoutTimestamp(hostClient, hostClientUsr, hostClientPwd, localDirClient, pathClient, clientUpdateFile)

  downloadFileFromRemoteWithoutTimestamp(hostClient, hostClientUsr, hostClientPwd, localDirClient, pathClientLogsDir, clientLog)
  downloadFileFromRemoteWithoutTimestamp(hostClient, hostClientUsr, hostClientPwd, localDirClient, pathClientLogsDir, clientLogRedirect)

  Actions.c 'Files from server:'
  # Actions.displayFilesForDownloadInFolder(localDirServer)
  Actions.displayFileLinkInReport(localDirServer+'/'+serverLogRedirect)
  Actions.cc 'Files from server:'
  Actions.displayFileLinkInReport(localDirServer+'/'+serverCnfgFilename2,true)
  Actions.displayFileLinkInReport(localDirServer+'/'+serverLog,true)
  Actions.displayFileLinkInReport(localDirServer+'/'+serverSnapshotFile,true)
  Actions.displayFileLinkInReport(localDirServer+'/'+serverUpdateFile,true)
  Actions.c 'Files from client:'
  # Actions.displayFilesForDownloadInFolder(localDirClient)
  Actions.displayFileLinkInReport(localDirClient+'/'+clientLogRedirect)
  Actions.cc 'Files from client:'
  Actions.displayFileLinkInReport(localDirClient+'/'+clientCnfgFilename2,true)
  Actions.displayFileLinkInReport(localDirClient+'/'+clientLog,true)
  Actions.displayFileLinkInReport(localDirClient+'/'+clientSnapshotFile,true)
  Actions.displayFileLinkInReport(localDirClient+'/'+clientUpdateFile,true)
end



####


############Upgrade

Given /^Code Tested2$/  do
  debugUpgrade
end