require 'time'
begin
  require '../../features/helpers/Actions'
rescue LoadError
end

automation_log_counter=0
Before do |scenario|
  $world = self
  @@run_fails = []
  @@scenario_fails = []
  @@email_properties = {}
  time = Time.new
  @@time_stamp = time.day.to_s+'-'+time.month.to_s+'-'+time.year.to_s+'_'+time.hour.to_s+'-'+time.min.to_s+'-'+time.sec.to_s #Time.now.to_i.to_s
  @@before_upgrade_timestamp=@@time_stamp
  automation_log_counter+=1
  @@automation_log_file='automation_log_'+automation_log_counter.to_s+'.html'
  @@automation_log_file_path=Dir.getwd+'/logs/'+@@automation_log_file
  @@automation_build_file_path=Dir.getwd+'/config/build.properties'
  $VERBOSE = nil
  @@old_ptrade_version_number = nil
  @@new_ptrade_version_number = nil

  File.open(@@automation_log_file_path, 'w')
  File.open(@@automation_build_file_path, 'w')

  if ENV['debugWithoutKill'].to_s.downcase != 'true'
    #Actions.WINCMD_NO_FAIL("TASKKILL /F /IM cmd.exe /T",20)
    if (scenario.source[1].tags[0].name.to_s.include?('@sanity-via-LFR'))
      # Actions.valid_IP_v4?(CONFIG.get['MDS_HOST_IP'])
      # Actions.isUp?(CONFIG.get['MDS_HOST_IP'])
      Actions.killMdsPerUser(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'])
      Actions.killMdsPerUser(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'])
      Actions.killArbStreamerPerUser(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'])
      Actions.killArbStreamerPerUser(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'])

      fail('Please provide obligatory parameter "MDS_ARB_LOG_PATH"') if (CONFIG.get['MDS_ARB_LOG_PATH'].to_s.empty?)
      fail('Please provide obligatory parameter "MDS_ARB_LOG_PATH1"') if (CONFIG.get['MDS_ARB_LOG_PATH1'].to_s.empty?)
      fail('Please provide obligatory parameter "MDS_ARB_STREAMER_PORT"') if (CONFIG.get['MDS_ARB_STREAMER_PORT'].to_s.empty?)
      fail('Please provide obligatory parameter "MDS_ARB_STREAMER_PORT1"') if (CONFIG.get['MDS_ARB_STREAMER_PORT1'].to_s.empty?)
      fail('Please provide obligatory parameter "MDS_ARB_STREAMER_IP"') if (CONFIG.get['MDS_ARB_STREAMER_IP'].to_s.empty?)
      fail('Please provide obligatory parameter "MDS_ARB_STREAMER_IP1"') if (CONFIG.get['MDS_ARB_STREAMER_IP1'].to_s.empty?)
      fail('Please provide obligatory parameter "MDS_ARB_STREAMER_STOP_TIME"') if (CONFIG.get['MDS_ARB_STREAMER_STOP_TIME'].to_s.empty?)
      fail('Please provide obligatory parameter "MDS_ARB_STREAMER_STOP_TIME1"') if (CONFIG.get['MDS_ARB_STREAMER_STOP_TIME1'].to_s.empty?)
    elsif (scenario.source[1].tags[0].name.to_s.include?('@publisher'))
      Actions.valid_IP_v4?(ENV['PUBLISHER_SERVER_HOST'])
      Actions.isUp?(ENV['PUBLISHER_SERVER_HOST'])
      Actions.valid_IP_v4?(ENV['PUBLISHER_CLIENT_HOST'])
      Actions.isUp?(ENV['PUBLISHER_CLIENT_HOST'])

      Actions.killPublisherServer
      sleep 1
      Actions.killPublisherClient
    elsif (scenario.source[1].tags[0].name.to_s.include?('@sanity-via-MSL'))
      Actions.valid_IP_v4?(ENV['MOUNT_HOST'])
      Actions.isUp?(ENV['MOUNT_HOST'])
      Actions.valid_IP_v4?(ENV['MDS_HOST_IP_OLD'])
      Actions.isUp?(ENV['MDS_HOST_IP_OLD'])
      Actions.valid_IP_v4?(ENV['MDS_HOST_IP_NEW'])
      Actions.isUp?(ENV['MDS_HOST_IP_NEW'])

      Actions.killMdsPerUser(ENV['MDS_HOST_IP_OLD'], ENV['MDS_HOST_USER_OLD'], ENV['MDS_HOST_PWD_OLD'])
      Actions.killMdsPerUser(ENV['MDS_HOST_IP_NEW'], ENV['MDS_HOST_USER_NEW'], ENV['MDS_HOST_PWD_NEW'])
    elsif (scenario.source[1].tags[0].name.to_s.include?('@performance-via-MSL'))
      if ENV['DEPLOY_MDS'] == 'true'
        Actions.valid_IP_v4?(ENV['MOUNT_HOST'])
        Actions.isUp?(ENV['MOUNT_HOST'])
      end
      Actions.valid_IP_v4?(ENV['MDS_PERF_HOST_IP'])
      Actions.isUp?(ENV['MDS_PERF_HOST_IP'])
      Actions.valid_IP_v4?(ENV['MDS_PERF_CLIENT_IP'])
      Actions.isUp?(ENV['MDS_PERF_CLIENT_IP'])

      Actions.killMdsPerUser(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'])
      Actions.killMdsPerUser(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
    elsif (scenario.source[1].tags[0].name.to_s.include?('@performance-concurrent-via-MSL'))
      if ENV['DEPLOY_MDS'] == 'true'
        Actions.valid_IP_v4?(ENV['MOUNT_HOST'])
        Actions.isUp?(ENV['MOUNT_HOST'])
      end
      Actions.valid_IP_v4?(ENV['MDS_PERF_HOST_IP'])
      Actions.isUp?(ENV['MDS_PERF_HOST_IP'])
      Actions.valid_IP_v4?(ENV['MDS_PERF_HOST_IP_2'])
      Actions.isUp?(ENV['MDS_PERF_HOST_IP_2'])
      Actions.valid_IP_v4?(ENV['MDS_PERF_CLIENT_IP'])
      Actions.isUp?(ENV['MDS_PERF_CLIENT_IP'])
      Actions.valid_IP_v4?(ENV['MDS_PERF_CLIENT_IP_2'])
      Actions.isUp?(ENV['MDS_PERF_CLIENT_IP_2'])
      Actions.valid_IP_v4?(ENV['MDS_MSL_LOADER_IP'])
      Actions.isUp?(ENV['MDS_MSL_LOADER_IP'])

      Actions.killMdsPerUser(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'])
      Actions.killMdsPerUser(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
      Actions.killMdsPerUser(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'])
      Actions.killMdsPerUser(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'])
      Actions.killTelnConnCountPerUser(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
      Actions.killTelnConnCountPerUser(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'])
    elsif (scenario.source[1].tags[0].name.to_s.include?('@performance-concurrent-via-LFR'))
      if (ENV['DEPLOY_MDS'] == 'true' || ENV['DEPLOY_MDS_2'] == 'true')
        Actions.valid_IP_v4?(ENV['MOUNT_HOST'])
        Actions.isUp?(ENV['MOUNT_HOST'])
      end
      Actions.valid_IP_v4?(ENV['MDS_PERF_HOST_IP'])
      Actions.isUp?(ENV['MDS_PERF_HOST_IP'])
      Actions.valid_IP_v4?(ENV['MDS_PERF_HOST_IP_2'])
      Actions.isUp?(ENV['MDS_PERF_HOST_IP_2'])
      Actions.valid_IP_v4?(ENV['MDS_PERF_CLIENT_IP'])
      Actions.isUp?(ENV['MDS_PERF_CLIENT_IP'])
      Actions.valid_IP_v4?(ENV['MDS_PERF_CLIENT_IP_2'])
      Actions.isUp?(ENV['MDS_PERF_CLIENT_IP_2'])
      Actions.valid_IP_v4?(ENV['MDS_LFR_HOST_IP'])
      Actions.isUp?(ENV['MDS_LFR_HOST_IP'])

      Actions.killMdsPerUser(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'])
      Actions.killMdsPerUser(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
      Actions.killMdsPerUser(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'])
      Actions.killMdsPerUser(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'])
      Actions.killArbStreamerPerUser(ENV['MDS_LFR_HOST_IP'], ENV['MDS_LFR_HOST_USER'], ENV['MDS_LFR_HOST_PWD'])
      Actions.killTelnConnCountPerUser(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
      Actions.killTelnConnCountPerUser(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'])
    end
  end
end

After do |scenario|

  if ENV['debugWithoutEnv'].to_s.downcase != 'true'
    Actions.v 'Starting post-scenario tasks...'

    #saving versions to file for email
    Actions.v 'Saving build versions for emailing'
    file = File.new(Dir.getwd+'/config/build.properties', 'w+')
    @@email_properties.each_key { |key, value|
      begin
        file.puts "#{key}=#{@@email_properties[key]}\n"
      rescue Exception => e
        self.f('ERROR on writing build properties '+ e.message)
      end
    }

    #sanity scratch
    if scenario.source[1].tags[0].name.to_s.include?('@sanity-via-LFR')
      #scenario.fail('See Errors in Red') if(!@@scenario_fails.empty?)
      Actions.killMdsPerUser(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'])
      Actions.killMdsPerUser(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'])
      Actions.killArbStreamerPerUser(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER'], CONFIG.get['MDS_HOST_PWD'])
      Actions.killArbStreamerPerUser(CONFIG.get['MDS_HOST_IP'], CONFIG.get['MDS_HOST_USER1'], CONFIG.get['MDS_HOST_PWD'])
    elsif scenario.source[1].tags[0].name.to_s.include?('@publisher')
      Actions.killPublisherServer
      sleep 1
      Actions.killPublisherClient
    elsif (scenario.source[1].tags[0].name.to_s.include?('@performance-via-MSL'))
      Actions.killMdsPerUser(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'])
      Actions.killMdsPerUser(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
    elsif (scenario.source[1].tags[0].name.to_s.include?('@performance-concurrent-via-MSL'))
      Actions.killMdsPerUser(ENV['MDS_PERF_HOST_IP'], ENV['MDS_PERF_HOST_USER'], ENV['MDS_PERF_HOST_PWD'])
      Actions.killMdsPerUser(ENV['MDS_PERF_CLIENT_IP'], ENV['MDS_PERF_CLIENT_USER'], ENV['MDS_PERF_CLIENT_PWD'])
      Actions.killMdsPerUser(ENV['MDS_PERF_HOST_IP_2'], ENV['MDS_PERF_HOST_USER_2'], ENV['MDS_PERF_HOST_PWD_2'])
      Actions.killMdsPerUser(ENV['MDS_PERF_CLIENT_IP_2'], ENV['MDS_PERF_CLIENT_USER_2'], ENV['MDS_PERF_CLIENT_PWD_2'])
    end

    if Dir.getwd.include?(@@CONFIG['JENKINS_JOB_NAME'])
      log_file_path = @@CONFIG['JENKINS_URL'].to_s+'/job/'+@@CONFIG['JENKINS_JOB_NAME'].to_s+'/ws/logs/'+@@automation_log_file
    else
      log_file_path = Dir.getwd+'/logs/'+@@automation_log_file
    end
    Actions.c "<a href='"+log_file_path.to_s+"'>Click to view detailed execution log: "+@@automation_log_file+'</a>'

    Actions.v '@@scenario_fails: "'+@@scenario_fails.to_s+'"'
    Actions.v '@@run_fails: "'+@@run_fails.to_s+'"'
    if !@@scenario_fails.empty?
      @@run_fails.push('Scenario "'+scenario.source[1].tags[0].name.to_s+'" failed')
      scenario.fail('Scenario failed. See errors in red')
    end
  end
end


Around('@test') do |scenario, block|
  Timeout.timeout(600) do
    block.call
    #puts '@test TIMEOUT'
  end
end

Around('@sanity-sdata-only') do |scenario, block|
  #Actions.displaySanityLogs(true, true, false, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(3000) do
    block.call
  end
end

Around('@sanity-with-sdata-oldAndNewVsUpgrade2') do |scenario, block|
  #Actions.displaySanityLogs(true, true, true, true) if(!@@scenario_fails.empty?)
  Timeout.timeout(3600) do
    block.call
  end
end

# Around('@publisher') do |scenario, block|
#Actions.displaySanityLogs(true, true, false, false) if(!@@scenario_fails.empty?)
# Timeout.timeout(3000) do
#   block.call
# end
# end


### Custom Builds

Around('@sdata_and_ptrade_lab') do |scenario, block|
  #Actions.displaySanityLogs(true, false, true, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i) do
    block.call
  end
end

Around('@sdata_lab') do |scenario, block|
  #Actions.displaySanityLogs(true, false, true, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i) do
    block.call
  end
end

Around('@ptrade_lab') do |scenario, block|
  #Actions.displaySanityLogs(true, false, true, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i) do
    block.call
  end
end

Around('@ptrade_upgrade_lab') do |scenario, block|
  #Actions.displaySanityLogs(true, false, false, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i) do
    block.call
  end
end

Around('@ptrade_scratch_and_upgrade_lab') do |scenario, block|
  #Actions.displaySanityLogs(true, false, false, false) if(!@@scenario_fails.empty?)
  Timeout.timeout(CONFIG.get['DEPLOYMENT_TIMEOUT'].to_i) do
    block.call
  end
end