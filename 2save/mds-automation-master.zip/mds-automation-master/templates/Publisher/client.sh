#!/bin/bash

argsQty="$#"
argFirst=${1:-}
argSecond=${2:-}

### Init
watchedPID=""
errorMsg="terminated"
specialMode=""
silentMode=""
scriptFolderPath=$(dirname $(readlink -f "$0"))
scriptName=$(basename "$0")
baseScriptName=${scriptName%*.sh}
pidFile="$scriptFolderPath/pid_$baseScriptName.log"
pidFromFile=""
myName="Client"
configPath="$scriptFolderPath/client.cnfg"

### handling special arguments
if [ "$argFirst" = "CONFIG:" ]; then
	shift
	shift
	
	if [ -f "$argSecond" ]; then
		configPath="$argSecond"
		echo -e "Path to config file given: \""$argSecond"\"\n">>"$logFile"
	else
		echo -e "Error: config file \""$argSecond"\" not found, continuing with the default value of the folder for unpacking: \""$configPath"\"\n">>"$logFile"
	fi
fi

argsQty="$#"
argFirst=${1:-}

case "$argFirst" in
		-v)
			specialMode="v"
			shift
			;;
		-s)
			specialMode="s"
			shift
			;;
	esac

argsQty="$#"
argFirst=${1:-}

myCmdPath="$scriptFolderPath"
myCmdLaunch1="java -server -jar publisher.jar path=$configPath client"

logsDir="$scriptFolderPath"/logs_client
mkdir -p "$logsDir"

logFile="$logsDir"/"$baseScriptName".log
touch "$logFile"

logDebug="$logsDir"/"$baseScriptName"_debug.log
touch "$logDebug"

logFileRedirect="$logsDir"/"$baseScriptName"_redirect.log
touch "$logFileRedirect"

clearLogFiles()
{
	echo "">"$logFile"
	echo "">"$logDebug"
	echo "">"$logFileRedirect"
}

### cleaning log files if starting/stopping/restarting
if [ "$argsQty" -lt 2 ]; then
	if [ "$argFirst" = "-start" -o "$argFirst" = "-restart" ] ; then clearLogFiles ; fi
else
	echo -e "\n\e[31m $(date +%Y-%m-%d_%H:%M:%S,%3N) -- Incorrect quantity of arguments given: \""$argsQty"\", exiting  \e[0m \n"|tee -a "$logFile"
	#help_function
	exit 1
fi

# set -o noclobber

### debug features
exec 5>> "$logDebug" #TODO: >> ?
BASH_XTRACEFD="5"
PS4='$LINENO: '
set -x

if [ "$specialMode" = "v" ]; then
	exec > >(tee -a "$logFile") 2>&1
else
	exec 1>> "$logFile"
	# exec 1> "$logFileTemp"
fi

echoEverywhere()
{
	argGiven=${1:-}
	echo -e "$argGiven"|tee -a /dev/stderr "$logFileRedirect"
}

echoIfNotSilent()
{
	argGiven=${1:-}
	argGivenSecond=${2:-}
	if [ "$specialMode" = "v" ]; then
		echo -e "$argGiven"
	elif [ "$specialMode" = "s" ]; then
		echo -e "$argGiven"
	else
		if [ "$argGivenSecond" = "indent-begin-nonverbose" ] ; then echo "" > /dev/stderr ; fi
		echo -e "$argGiven"|tee -a /dev/stderr
	fi
}

echoIfNotSilent "\n-----------------------"
echoIfNotSilent " $(date +%Y-%m-%d_%H:%M:%S,%3N) -- $myName script is launched with option \""$argFirst"\""

echo -e "\n---Writing regular output to log $logFile---"
echo -e "---Writing debug output to log $logDebug---\n"

### catching exit
MyExit()
{
	if [ "$specialMode" = "v" ]; then
		if [ "$watchedPID" != "" ]; then
			echoEverywhere "\n\e[31m $(date +%Y-%m-%d_%H:%M:%S,%3N) -- Stopped by user \e[0m"
		else
			echo -e "\n\e[31m $(date +%Y-%m-%d_%H:%M:%S,%3N) -- Stopped by user \e[0m"|tee -a /dev/stderr
		fi
	fi
    exit 1
}
trap MyExit INT

anotherExit()
{
	if [ "$watchedPID" != "" ]; then
		echoEverywhere "\n\e[31m $(date +%Y-%m-%d_%H:%M:%S,%3N) -- Stopped by user \e[0m"
	else
		echo -e "\n\e[31m $(date +%Y-%m-%d_%H:%M:%S,%3N) -- Stopped by user \e[0m"|tee -a /dev/stderr
	fi
	exit 1
}
trap anotherExit SIGTERM SIGHUP HUP QUIT PIPE TERM

exit_status=0
giveErrorMsg()
{
	exit_status="$?"
	if [ $exit_status -ne 0 ]; then
		if [ "$watchedPID" != "" ]; then
			echoEverywhere "\n\e[31m $(date +%Y-%m-%d_%H:%M:%S,%3N) -- Stopped by user \e[0m"
		else
			echo -e "\n\e[31m $(date +%Y-%m-%d_%H:%M:%S,%3N) -- Stopped by user \e[0m"|tee -a /dev/stderr
		fi
		# echo "exit_status: $exit_status"
		exit 1
	fi
}
trap giveErrorMsg EXIT

checkPidFile()
{
	if [ -f "$pidFile" ]; then
		pidFromFile=$(<"$pidFile")
		if [ ! -z "$pidFromFile" -a "$pidFromFile" != " " ]; then
			if [ $(/bin/ps -aef|egrep "$pidFromFile"|grep "$myCmdLaunch1"|grep -v grep) ]; then
				errorMsg="Error: another $scriptName script is running with PID \""$pidFromFile"\", exiting"
				exit 1
			fi
		else
			echo "Found empty PID from file"
		fi
	fi
}

sleepSecCount()
{
	argGiven=${1:-}
	n=0
	
	for i in $(seq $n $argGiven);
	do
		if [ "$specialMode" = "v" ]; then
			echo -ne " $i sec"\\r
		elif [ "$specialMode" = "s" ]; then
			echo -ne " $i sec"\\r
		else
			echo -ne " $i sec"\\r|tee -a /dev/stderr
		fi
		sleep 1
	done
	
	if [ "$specialMode" = "v" ]; then
		echo
	elif [ "$specialMode" = "s" ]; then
		echo
	else
		echo|tee -a /dev/stderr
	fi
}

### behaviour settings
### this script will terminate on any error with return value <> 0
set -o errexit
set -o pipefail
set -o nounset

myCmdLaunch="nohup $myCmdLaunch1 >> $logFileRedirect 2>&1 &"
statusPID=""

status()
{
	modeSilent=""
	argGiven=${1:-}
	if [ "$argGiven" = "silent" ] ; then modeSilent=true ; fi
	
	if [ -f "$pidFile" ]; then
		pidFromFile=$(<"$pidFile")
		if [ ! -z "$pidFromFile" -a "$pidFromFile" != " " ];
		then
			### the following command provides exit code=1, excluding it
			psPID="$(/bin/ps -aef|grep $pidFromFile|egrep "$myCmdLaunch1"|grep -v grep|awk '{print $2}')" || true #TODO: check it is only one row; what about -U?			
			if [ ! -z "$psPID" -a "$psPID" != " " ];
			then
				echoIfNotSilent "\e[32m $(date +%Y-%m-%d_%H:%M:%S,%3N) -- $myName process is up with PID \""$psPID"\" \e[0m\n" indent-begin-nonverbose
				#echo "$myName process is up with PID \""$psPID"\"" >> "$logFileRedirect"
				statusPID="$psPID"
			else
				if [ "$modeSilent" != true ] ; then echoIfNotSilent "\e[33m No $myName processes found with PID \""$pidFromFile"\" \e[0m \n" indent-begin-nonverbose ; fi
			fi
		else
			if [ "$modeSilent" != true ] ; then echoIfNotSilent "\e[33m No PID found in the file $pidFile \e[0m\n" indent-begin-nonverbose ; fi
		fi
	else
		if [ "$modeSilent" != true ] ; then echoIfNotSilent " No PID file found \n" indent-begin-nonverbose ; fi
	fi
	
	psPID2=""
	if [ ! -z "$statusPID" -a "$statusPID" != " " ]; then
		psPID2="$(/bin/ps -aef|egrep "$myCmdLaunch1"|grep -v "$statusPID"|grep -v grep)" || true
	else
		psPID2="$(/bin/ps -aef|egrep "$myCmdLaunch1"|grep -v grep)" || true
	fi
	
	if [ ! -z "$psPID2" -a "$psPID2" != " " ];
	then
		if [ "$modeSilent" != true ];
		then
			echoIfNotSilent "\e[33m Found other processes that include the same command '$myCmdLaunch1': \e[0m"
			echoIfNotSilent "$psPID2 \n"
		fi
	else
		if [ "$modeSilent" != true ];
		then
			echoIfNotSilent "\e[33m No other processes with the same command '$myCmdLaunch1' found \e[0m \n"
		fi
	fi
}

start()
{
	status silent
	
	if [ ! -z "$statusPID" -a "$statusPID" != " " ]; then
		errorMsg="$myName process is already up"
		exit 0
	fi

	chmod -R 755 "$myCmdPath"
	cd "$myCmdPath"
	
	echoIfNotSilent "\n $(date +%Y-%m-%d_%H:%M:%S,%3N) -- Launching $myName process... \n"
	echo "$(date +%Y-%m-%d_%H:%M:%S,%3N) -- Launching $myName process" >> "$logFileRedirect"
	echo "$myCmdLaunch1" >> "$logFileRedirect"
	echo "-----------------------------------------------------------" >> "$logFileRedirect"
	eval "$myCmdLaunch"
	
	watchedPID="$!"
	echo "$watchedPID" > "$pidFile"
			
	sleepSecCount 3
	status
}

restart()
{
	status silent
	
	if [ ! -z "$statusPID" -a "$statusPID" != " " ]; then
		echoIfNotSilent " $(date +%Y-%m-%d_%H:%M:%S,%3N) -- Killing $myName process with PID \""$statusPID"\"..."
		echo "$(date +%Y-%m-%d_%H:%M:%S,%3N) -- Killing $myName process with PID \""$statusPID"\"" >> "$logFileRedirect"
		/bin/kill -9 "$psPID"
	fi
	
	sleepSecCount 3

	cd "$myCmdPath"
	
	echoIfNotSilent "\n $(date +%Y-%m-%d_%H:%M:%S,%3N) -- Launching $myName process... \n"
	echo "$(date +%Y-%m-%d_%H:%M:%S,%3N) -- Launching $myName process" >> "$logFileRedirect"
	echo "$myCmdLaunch1" >> "$logFileRedirect"
	echo "-----------------------------------------------------------" >> "$logFileRedirect"
	
	eval "$myCmdLaunch"
	
	watchedPID="$!"
	echo "$watchedPID" > "$pidFile"
	
	sleepSecCount 3
	status
}

stop()
{
	status silent
	
	if [ ! -z "$statusPID" -a "$statusPID" != " " ]; then
		echoIfNotSilent " $(date +%Y-%m-%d_%H:%M:%S,%3N) -- Killing $myName process with PID \""$statusPID"\"..."
		echo "-----------------------------------------------------------" >> "$logFileRedirect"
		echo "$(date +%Y-%m-%d_%H:%M:%S,%3N) -- Killing $myName process with PID \""$statusPID"\"" >> "$logFileRedirect"
		/bin/kill -9 "$statusPID"
	# else
		# echoIfNotSilent " \e[33m No $myName processes found \e[0m\n" indent-begin-nonverbose
	fi
	
	echoIfNotSilent " Double-checking..." indent-begin-nonverbose
	sleepSecCount 3
	status
}

readParam()
{
	case "$argFirst" in
		-help|--help|-h|--h)
			#help_function
			exit 0
			;;
		-status)
			status
			;;
		-start)
			start
			;;
		-stop)
			stop
			;;
		-restart)
			restart
			;;
		*)
			errorMsg="Incorrect argument given - \""$argFirst"\", exiting"
			#help_function
			exit 1
			;;
	esac
}

readParam

echo -e "$(date +%Y-%m-%d_%H:%M:%S,%3N) -- $myName script is stopped \n"