#!/bin/bash

scriptFolderPath=$(dirname $(readlink -f "$0"))
scriptName=$(basename "$0")
mslLoaderPath="$scriptFolderPath"
# ipCurr="$(/sbin/ifconfig eth0 | grep 'inet addr' | awk -F: '{print $2}' | awk '{print $1}')"
ipCurr="$(/sbin/ifconfig | grep -A 1 'eth0' | tail -1 | cut -d ':' -f 2 | cut -d ' ' -f 1)"
logsDir="$scriptFolderPath"/"logs_msl_loader"
mkdir -p "$logsDir"
logFile="$logsDir"/"mslLoader_output"_"$ipCurr"."log"
echo > "$logFile"

arbLogPath=""
mslIP=""
startTime="0"
stopTime="2h"

logConsole="$logsDir"/"console_MSLloader.log"
echo > "$logConsole"

echo -e "\n$(date +%Y-%m-%d_%H:%M:%S,%3N) -- Started $scriptName\n" >> "$logConsole"

### debug info
logDebug="$logsDir"/"debug_MSLloader.log"
echo > "$logDebug"
exec 5> "$logDebug"
BASH_XTRACEFD="5"
PS4='$LINENO: '
set -x

### handling special arguments
argFirst=${1:-}
argSecond=${2:-}
if [ "$argFirst" = "mslLoaderPath:" ]; then
	shift
	shift
	
	mslLoaderPath="$argSecond"
fi

argFirst=${1:-}
argSecond=${2:-}
if [ "$argFirst" = "arbLogPath:" ]; then
	shift
	shift
	
	arbLogPath="$argSecond"
fi

argFirst=${1:-}
argSecond=${2:-}
if [ "$argFirst" = "mslIP:" ]; then
	shift
	shift
	
	mslIP="$argSecond"
fi

argFirst=${1:-}
argSecond=${2:-}
if [ "$argFirst" = "startTime:" ]; then
	shift
	shift
	
	startTime="$argSecond"
fi

argFirst=${1:-}
argSecond=${2:-}
if [ "$argFirst" = "stopTime:" ]; then
	shift
	shift
	
	stopTime="$argSecond"
fi

logFilePrev="$logFile"
logFile="$logsDir"/"mslLoader_output"_"$ipCurr"_"$mslIP"."log"
mv "$logFilePrev" "$logFile"
echo > "$logFile"

echo -e "\n$(date +%Y-%m-%d_%H:%M:%S,%3N) -- Launching msl-loader\n" >> "$logConsole"
echo -e "\n$(date +%Y-%m-%d_%H:%M:%S,%3N) -- Launching msl-loader\n" >> "$logFile"
# cmd="msl-loader -in $arbLogPath -ip $mslIP -start $startTime -stop $stopTime"
cmd="cd $mslLoaderPath && nohup msl-loader -in $arbLogPath -ip $mslIP -start $startTime -stop $stopTime >> $logFile &"
eval "$cmd"

echo -e "\n$(date +%Y-%m-%d_%H:%M:%S,%3N) -- Finished $scriptName\n" >> "$logConsole"