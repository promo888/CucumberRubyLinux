#!/bin/sh

argsAll=${@:-}
echo "argsAll: $argsAll"
scriptFolderPath=$(dirname $(readlink -f "$0"))
scriptName=$(basename "$0")
baseScriptName=${scriptName%*.sh}

logDebug="$scriptFolderPath"/"$baseScriptName"_debug_"$(date +%Y-%m-%d_%H-%M-%S-%3N)".log
echo "">"$logDebug"
exec 5> "$logDebug"
BASH_XTRACEFD="5"
PS4='$LINENO: '
set -x

logFile="$scriptFolderPath"/redirect_"$baseScriptName"_"$(date +%Y-%m-%d_%H-%M-%S-%3N)".log

eval nohup ./mds.sh "$argsAll" > "$logFile" &