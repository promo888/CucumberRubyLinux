#!/bin/bash

scriptFolderPath=$(dirname $(readlink -f "$0"))
# ipCurr="$(/sbin/ifconfig eth0 | grep 'inet addr' | awk -F: '{print $2}' | awk '{print $1}')"
ipCurr="$(/sbin/ifconfig | grep -A 1 'eth0' | tail -1 | cut -d ':' -f 2 | cut -d ' ' -f 1)"
# logDir="$scriptFolderPath"/"logs_telnet_expect_$(date +%Y-%m-%d_%H-%M-%S-%3N)"
scriptName=$(basename "$0")
logDir="$scriptFolderPath"/logs_telnet_expect

### handling special arguments
argFirst=${1:-}
argSecond=${2:-}
if [ "$argFirst" = "LOGS_DIR:" ]; then
        shift
        shift
	logDir="$argSecond"
fi

mkdir -p "$logDir"
if [ ! -d "$logDir" ]; then
	echo -e "Error: given LOGS_DIR $argSecond does not exist"
	exit 1
fi

logFile="$logDir"/"telnet_output"_"$ipCurr"_"$(date +%Y-%m-%d_%H-%M-%S-%3N)"."log"
echo > "$logFile"

ip="localhost"
port="8080"

### debug info
logDebug="$logDir"/"debug_telnet"_"$(date +%Y-%m-%d_%H-%M-%S-%3N)"."log"
echo > "$logDebug"
# exec 5> "$logDebug"
# BASH_XTRACEFD="5"
# PS4='$LINENO: '
# set -x

echo -e "\n$(date +%Y-%m-%d_%H:%M:%S,%3N) -- Started $scriptName\n" >> "$logDebug"

argFirst=${1:-}
argSecond=${2:-}
if [ "$argFirst" = "HOST:" ]; then
	shift
	shift
	
	ip="$argSecond"
fi

argFirst=${1:-}
argSecond=${2:-}
if [ "$argFirst" = "PORT:" ]; then
	shift
	shift
	
	port="$argSecond"
fi

logFilePrev="$logFile"
logFile="$logDir"/"telnet_output"_"$ipCurr"_"$ip"_"$(date +%Y-%m-%d_%H-%M-%S-%3N)"."log"

mv "$logFilePrev" "$logFile"
echo > "$logFile"

# nohup nc -d "$ip" "$port" > "$logFile"
nc -d "$ip" "$port" > "$logFile"

echo -e "\n$(date +%Y-%m-%d_%H:%M:%S,%3N) -- Finished $scriptName\n" >> "$logDebug"