#!/bin/bash

scriptFolderPath=$(dirname $(readlink -f "$0"))
# ipCurr="$(/sbin/ifconfig eth0 | grep 'inet addr' | awk -F: '{print $2}' | awk '{print $1}')"
ipCurr="$(/sbin/ifconfig | grep -A 1 'eth0' | tail -1 | cut -d ':' -f 2 | cut -d ' ' -f 1)"
# logDir="$scriptFolderPath"/"logs_telnet_expect_$(date +%Y-%m-%d_%H-%M-%S-%3N)"
scriptName=$(basename "$0")

argFirst=${1:-}

logDir="$scriptFolderPath"/logs_telnet_count
mkdir -p "$logDir"

logFile="$logDir"/"telnet_count"_"$ipCurr"_"$(date +%Y-%m-%d_%H-%M-%S-%3N)"."log"
# echo > "$logFile"
echo "$(date +%Y-%m-%d_%H:%M:%S,%3N) --- Started" >> "$logFile"

### catching exit
MyExit()
{
	echo "$(date +%Y-%m-%d_%H:%M:%S,%3N) --- Stopped by user" >> "$logFile"
    exit 1
}
trap MyExit INT

anotherExit()
{
	echo "$(date +%Y-%m-%d_%H:%M:%S,%3N) --- Terminated" >> "$logFile"
}
trap anotherExit SIGTERM SIGHUP HUP QUIT PIPE TERM EXIT

cmd="ps -aef|grep -v grep|grep telnet|wc -l"
res1=""

while true
	do
		sleep 1
		res=$(eval "$cmd")
		if [[ "$res" != "$1" && "$res" != "$res1" ]]; then
			res1="$res"
			echo "$(date +%Y-%m-%d_%H:%M:%S,%3N) --- $res telnet processes found (expected: $argFirst)" >> "$logFile"
		fi
	done;
	
echo "$(date +%Y-%m-%d_%H:%M:%S,%3N) --- Finished" > "$logFile"