#!/bin/bash

scriptFolderPath=$(dirname $(readlink -f "$0"))
ipCurr="$(/sbin/ifconfig | grep -A 1 'eth0' | tail -1 | cut -d ':' -f 2 | cut -d ' ' -f 1)"
scriptName=$(basename "$0")
logDir="$scriptFolderPath"/logs_telnet_expect

### handling special arguments
argFirst=${1:-}
argSecond=${2:-}
if [ "$argFirst" = "LOGS_DIR:" ]; then
        shift
        shift
        logDir="$argSecond"
fi

mkdir -p "$logDir"
if [ ! -d "$logDir" ]; then
	echo -e "Error: given LOGS_DIR $argSecond does not exist"
	exit 1
fi

logConsole="$logDir"/"$scriptName"_"$(date +%Y-%m-%d_%H-%M-%S-%3N)"."log"
echo > "$logConsole"

echo -e "\n$(date +%Y-%m-%d_%H:%M:%S,%3N) -- Started $scriptName\n" >> "$logConsole"

argFirst=${1:-}
argSecond=${2:-}
if [ "$argFirst" = "HOST:" ]; then
        shift
        shift

        ip="$argSecond"
fi

argFirst=${1:-}
argSecond=${2:-}
if [ "$argFirst" = "PORT:" ]; then
        shift
        shift

        port="$argSecond"
fi

quantity="1"
argFirst=${1:-}
argSecond=${2:-}
if [ "$argFirst" = "QUANTITY:" ]; then
        shift
        shift

        quantity="$argSecond"
fi

for ((n=0; n<"$quantity"; n++)); do
	cd "$scriptFolderPath"
	sleep 0.5
	echo "Opening client connection # $n" >> "$logConsole"
	/usr/bin/nohup ./MDS_client_conn.sh LOGS_DIR: "$logDir" HOST: "$ip" PORT: "$port" &
done

echo -e "\n$(date +%Y-%m-%d_%H:%M:%S,%3N) -- Finished $scriptName\n" >> "$logConsole"