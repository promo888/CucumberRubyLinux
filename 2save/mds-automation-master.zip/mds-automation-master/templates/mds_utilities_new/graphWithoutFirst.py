__author__ = 'agrosland'

import sys
import getopt
import re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# if len(sys.argv) == 2:
    # cmd_parameter_user = sys.argv[1]
# else:
    # print("Error: there should be only one argument after script name")
    # exit(-1)
	
# print('Number of arguments:' + str(len(sys.argv)))
# print('Argument List:' + str(sys.argv))

# hlines = ''
# vlines = ''
# try:
	# opts, args = getopt.getopt(sys.argv,"hv:d", ["hlines", "vlines="])
# except getopt.GetoptError:
	# print('<scriptname> -hlines <horizontal line values> -vlines <horizontal line values>')
	# sys.exit(2)
# for opt, arg in opts:
	# if opt in ("-help", "--help", "help"):
		# print('<scriptname> -hlines <horizontal line values> -vlines <horizontal line values>')
		# sys.exit(2)
	# elif opt in ("-h", "-hlines"):
		# hlines = arg
	# elif opt in ("-v", "-vlines"):
		# vlines = arg
	# elif opt == '-d':
		# global _debug               
		# _debug = 1
# print('Horizontal lines values: "' + str(hlines))
# print('Vertical lines values: "' + str(vlines))

fig = plt.figure(num=None, figsize=(20, 10), dpi=100)

# file = 'mdsLatency.log'
file = 'mdsLatency_withoutFirst.log'

arr1 = []
arr2 = []
arr3 = []
fileLines = [line.rstrip('\n') for line in open(file)]
for i in fileLines:
	i = i.split(',')
	arr1.append(i[0])
	arr2.append(i[1])
	arr3.append(i[2])

plt.plot(arr1, 'b', label='mdsLatency')
plt.plot(arr2, 'c', label='pubLatency')
plt.plot(arr3, 'y', label='netLatency')

axSupplVal = 1
axSupplVal2 = 5
hline07 = plt.axhline(y=axSupplVal, color='r', linewidth=1, label=str(axSupplVal) + ' ms')
hline07 = plt.axhline(y=axSupplVal2, color='r', linewidth=1, label=str(axSupplVal2) + ' ms')

# vline5k = plt.axvline(x=5000, linestyle='--', color='k', linewidth=1, label='5 000')
# vline10k = plt.axvline(x=10000, linestyle='-.', color='k', linewidth=1, label='10 000')
# vline15k = plt.axvline(x=15000, linestyle=':', color='k', linewidth=1, label='15 000')
# vline20k = plt.axvline(x=20000, linestyle='--', color='b', linewidth=1, label='20 000')

# vline5k = plt.axvline(x=30000, linestyle='--', color='k', linewidth=1, label='30 000')
# vline10k = plt.axvline(x=30000, linestyle='-.', color='k', linewidth=1, label='30 000')
# vline15k = plt.axvline(x=60000, linestyle=':', color='g', linewidth=1, label='60 000')
# vline20k = plt.axvline(x=60000, linestyle='--', color='k', linewidth=1, label='60 000')

# title = 'MDS latency'
title = 'MDS latency without the first data'
plt.title(title)

plt.xlabel('Messages', fontsize=16)
plt.ylabel('Time in milliseconds', fontsize=16)

plt.legend()

plt.grid(True)

## plt.savefig('test.svg', format='svg')
# plt.savefig('mdsLatency.png', format='png')
plt.savefig('mdsLatency_withoutFirst.png', format='png')

# plt.show()