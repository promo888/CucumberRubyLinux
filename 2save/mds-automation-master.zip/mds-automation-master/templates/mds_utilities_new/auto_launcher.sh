#!/bin/bash

rm -f nohup.out

nohup python auto.py >> nohup.out 2>&1 &