__author__ = 'zurab.khukhashvili@ebs.com'

# arp streamer batch file
ARP_STREAMER_BATCH_FILE = '/export/home/dashboard1/MDS_tools/arbFilter/appassembler/bin/ArbStreamer'

#arb log file
ARB_LOG_FILE            = '/export/home/dashboard1/MDS_tools/lfr-log-3/arblogs/nyla9874_8.log'

#arb streamer IP address
ARB_STREAMER_IP         = '127.0.0.1'

#arb streamer port
ARB_STREAMER_PORT       = '3551'

#arb streamer start time - relative(ms, s, m, h, d) or absolute
ARB_STREAMER_START      = '0ms'

#arb streamer stop time - relative(ms, s, m, h, d) or absolute
ARB_STREAMER_STOP       = '7d'

# mds telnet host address
MDS_TELNET_HOST         = "127.0.0.1"

# mds telnet port address
MDS_TELNET_PORT         = 12891

# mds batch file
MDS_BATCH_FILE          = '/export/home/dashboard1/MDS_tools/mds/appassembler/bin/mds-app'

# mds vm options not specified in batch
MDS_VM_OPTS             = '-DconfigPath=/export/home/dashboard1/MDS_tools/app/config -DrollbackHours=0 -DAPP_HOME=/export/home/dashboard1/MDS_tools/app'

# mds dumpcalc output location
MDS_DUMPCALC_DIR        = '/export/home/dashboard1/MDS_tools/app/logs'

# splitter batch file
SPLITTER_BATCH_FILE     = '/export/home/dashboard1/MDS_tools/DumpCalcSplitter/appassembler/bin/splitter'

# splitter tmp files location
SPLITTER_TMP_DIR        = '/export/home/dashboard1/MDS_tools/app/SPLITTED'

# location of new generated calculation files
CALC_DIR                = '/export/home/dashboard1/MDS_tools/app/CALCS/Log/new_version'

# compare new generated files to located in following directory
CMP_DIR                 = '/export/home/dashboard1/MDS_tools/app/CALCS/Log/old_version'

# log file
LOG_FILE             = '/export/home/dashboard1/MDS_tools/app/report/auto.log'